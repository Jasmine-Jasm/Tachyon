#include <errno.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "apk/apk.h"
#include "apk/axml.h"
#include "common/arena.h"
#include "common/buf.h"
#include "common/io.h"
#include "common/pool.h"
#include "common/writer.h"
#include "dex/dex.h"
#include "emit/java.h"
#include "emit/heuristic.h"
#include "emit/stubs.h"
#include "emit/platform_ctors.h"
#include "emit/renamer.h"
#include "emit/remap.h"
#include "ir/opcode.h"
#include "zip/zip.h"
#include "formats/provider.h"

#ifndef TACHYON_VERSION
#define TACHYON_VERSION "0.0.0"
#endif

/* Machine-readable progress: one line per step on stdout, flushed immediately so
 * a front end can drive a progress bar. Format: "#PROGRESS <0-100> <text>". */
static int g_progress;

static void progress(int pct, const char *msg)
{
    if (!g_progress)
        return;
    printf("#PROGRESS %d %s\n", pct, msg);
    fflush(stdout);
}

static void usage(FILE *fp)
{
    fprintf(fp,
            "tachyon %s - DEX/APK decompiler written in C\n"
            "\n"
            "usage:\n"
            "  tachyon info   <file.dex|apk|jar>     summary of every dex in the input\n"
            "  tachyon d      <file> [-o <dir>] [-j N] [--mode M] [--bodies]\n"
            "                                        decompile to Java sources\n"
            "  tachyon dis    <file> [-n methods]    disassemble methods\n"
            "  tachyon list   <file.apk|jar>         list archive entries\n"
            "  tachyon json   <file>                 dump structure as JSON\n"
            "  tachyon --version | --help\n"
            "\n"
            "options:\n"
            "  -o DIR        output directory (default: ./out, cleared before each run)\n"
            "  -j N          worker threads (default: online CPUs)\n"
            "  --mode M      balanced (default), fast, accurate, or max\n"
            "                max uses every core and is EXPERIMENTAL: measured on a\n"
            "                desktop only, do not run it on a phone\n"
            "  --keep        do not clear the output directory first\n"
            "  --progress    print \"#PROGRESS <0-100> <step>\" lines for a front end\n"
            "  --bodies      decompile method bodies (default: stubs only)\n"
            "  --strict      make undecoded bodies throw instead of returning 0/null\n"
            "  --rename F    apply a ProGuard/R8 mapping.txt\n"
            "  -n N          limit the number of methods (dis only)\n"
            "\n",
            TACHYON_VERSION);
}

/* ------------------------------------------------------------------ */
/* helpers                                                            */
/* ------------------------------------------------------------------ */

/* Warms every lazily built cache so worker threads only ever read them. */
static void warm_caches(Dex *d)
{
    for (uint32_t i = 0; i < d->hdr.string_ids_size; i++)
        dex_string(d, i);
    for (uint32_t i = 0; i < d->hdr.type_ids_size; i++)
        dex_type_name(d, i);
    for (uint32_t i = 0; i < d->hdr.proto_ids_size; i++)
        dex_proto_params(d, i);
    for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
        const DexClassData *cd = dex_class_data(d, i);
        if (!cd)
            continue;
        for (uint32_t k = 0; k < cd->direct_count; k++)
            if (cd->direct_methods[k].code_off)
                dex_code(d, cd->direct_methods[k].code_off);
        for (uint32_t k = 0; k < cd->virtual_count; k++)
            if (cd->virtual_methods[k].code_off)
                dex_code(d, cd->virtual_methods[k].code_off);
    }
}

/* Totals across every dex in the set. */
typedef struct {
    uint64_t strings, types, protos, fields, methods, classes;
} Totals;

static void tally(Dex *d, Totals *t)
{
    t->strings += d->hdr.string_ids_size;
    t->types += d->hdr.type_ids_size;
    t->protos += d->hdr.proto_ids_size;
    t->fields += d->hdr.field_ids_size;
    t->methods += d->hdr.method_ids_size;
    t->classes += d->hdr.class_defs_size;
}

/* ------------------------------------------------------------------ */
/* info                                                               */
/* ------------------------------------------------------------------ */

static int cmd_info(const char *path)
{
    Arena arena;
    arena_init(&arena, 1 << 20);
    char err[512];
    DexSet *set = apk_open(path, &arena, err, sizeof(err));
    if (!set) {
        fprintf(stderr, "error: %s\n", err);
        arena_destroy(&arena);
        return 1;
    }

    Totals t;
    memset(&t, 0, sizeof(t));

    printf("source      : %s (%s)\n", path, set->is_archive ? "archive" : "dex");
    printf("dex files   : %u\n", set->count);
    for (uint32_t i = 0; i < set->count; i++) {
        Dex *d = set->dex[i];
        printf("\n  [%u] %s  %zu bytes  dex %c%c%c\n", i, d->path ? d->path : "?", d->size,
               d->hdr.version[0], d->hdr.version[1], d->hdr.version[2]);
        printf("      strings %-8u types %-8u protos %-8u\n", d->hdr.string_ids_size,
               d->hdr.type_ids_size, d->hdr.proto_ids_size);
        printf("      fields  %-8u methods %-6u classes %-8u\n", d->hdr.field_ids_size,
               d->hdr.method_ids_size, d->hdr.class_defs_size);
        tally(d, &t);
    }

    printf("\ntotal       : strings %llu  types %llu  protos %llu\n",
           (unsigned long long)t.strings, (unsigned long long)t.types,
           (unsigned long long)t.protos);
    printf("              fields %llu  methods %llu  classes %llu\n",
           (unsigned long long)t.fields, (unsigned long long)t.methods,
           (unsigned long long)t.classes);

    for (uint32_t i = 0; i < set->count; i++)
        dex_close(set->dex[i]);
    arena_destroy(&arena);
    return 0;
}

/* ------------------------------------------------------------------ */
/* disassembly                                                        */
/* ------------------------------------------------------------------ */

static int cmd_disasm(const char *path, uint32_t limit)
{
    Arena arena;
    arena_init(&arena, 1 << 20);
    char err[512];
    DexSet *set = apk_open(path, &arena, err, sizeof(err));
    if (!set) {
        fprintf(stderr, "error: %s\n", err);
        arena_destroy(&arena);
        return 1;
    }

    Buf out;
    buf_init(&out, 1 << 16);
    uint32_t printed = 0;

    for (uint32_t di = 0; di < set->count && printed < limit; di++) {
        Dex *d = set->dex[di];
        for (uint32_t i = 0; i < d->hdr.class_defs_size && printed < limit; i++) {
            const DexClassData *cd = dex_class_data(d, i);
            if (!cd)
                continue;
            for (int pass = 0; pass < 2 && printed < limit; pass++) {
                uint32_t n = pass ? cd->virtual_count : cd->direct_count;
                const DexEncodedMethod *m = pass ? cd->virtual_methods : cd->direct_methods;
                for (uint32_t k = 0; k < n && printed < limit; k++) {
                    if (!m[k].code_off)
                        continue;
                    DexCode *code = dex_code(d, m[k].code_off);
                    if (!code)
                        continue;
                    buf_reset(&out);
                    buf_printf(&out, "method %s.%s regs=%u ins=%u outs=%u\n",
                               dex_type_name(d, d->methods[m[k].method_idx].class_idx),
                               dex_method_name(d, m[k].method_idx), code->registers_size,
                               code->ins_size, code->outs_size);
                    for (uint32_t pc = 0; pc < code->insns_size;) {
                        uint16_t raw = code->insns[pc];
                        if ((raw & 0xff) == 0 && raw != 0) {
                            /* payload blob: skip */
                            uint32_t ident = raw;
                            uint32_t size = (pc + 1 < code->insns_size) ? code->insns[pc + 1] : 0;
                            uint32_t words = 0;
                            if (ident == 0x0100)
                                words = ((size * 2 + 1) / 2) + 4;
                            else if (ident == 0x0200)
                                words = size * 4 + 2;
                            else if (ident == 0x0300 && pc + 3 < code->insns_size) {
                                uint32_t elems = (uint32_t)code->insns[pc + 2] |
                                                 ((uint32_t)code->insns[pc + 3] << 16);
                                words = 4 + (size * elems + 1) / 2;
                            } else
                                words = 1;
                            if (pc + words > code->insns_size)
                                words = code->insns_size - pc;
                            buf_printf(&out, "  %04x: array-data (%u elems)\n", pc,
                                       ident == 0x0300 ? size : size);
                            pc += words;
                            continue;
                        }
                        Insn in;
                        uint32_t len = insn_decode(code->insns, code->insns_size, pc, &in);
                        if (!len) {
                            buf_printf(&out, "  %04x: <undecodable 0x%02x>\n", pc, raw & 0xff);
                            break;
                        }
                        char txt[256];
                        insn_format(&in, txt, sizeof(txt));
                        buf_printf(&out, "  %04x: %s\n", pc, txt);
                        pc += len;
                    }
                    fwrite(out.data, 1, out.len, stdout);
                    printed++;
                }
            }
        }
    }

    buf_free(&out);
    for (uint32_t i = 0; i < set->count; i++)
        dex_close(set->dex[i]);
    arena_destroy(&arena);
    return 0;
}

/* ------------------------------------------------------------------ */
/* list archive entries                                               */
/* ------------------------------------------------------------------ */

static int cmd_list(const char *path)
{
    char err[512];
    if (apk_list(path, stdout, err, sizeof(err)) != 0) {
        fprintf(stderr, "error: %s\n", err);
        return 1;
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* json                                                               */
/* ------------------------------------------------------------------ */

static void json_escape(Buf *b, const char *s)
{
    buf_putc(b, '"');
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        switch (*p) {
        case '"': buf_puts(b, "\\\""); break;
        case '\\': buf_puts(b, "\\\\"); break;
        case '\n': buf_puts(b, "\\n"); break;
        case '\r': buf_puts(b, "\\r"); break;
        case '\t': buf_puts(b, "\\t"); break;
        default:
            if (*p < 0x20)
                buf_printf(b, "\\u%04x", *p);
            else
                buf_putc(b, (char)*p);
        }
    }
    buf_putc(b, '"');
}

static int cmd_json(const char *path)
{
    Arena arena;
    arena_init(&arena, 1 << 20);
    char err[512];
    DexSet *set = apk_open(path, &arena, err, sizeof(err));
    if (!set) {
        fprintf(stderr, "error: %s\n", err);
        arena_destroy(&arena);
        return 1;
    }

    Buf b;
    buf_init(&b, 1 << 16);
    buf_puts(&b, "{\n  \"source\": ");
    json_escape(&b, path);
    buf_printf(&b, ",\n  \"dex\": [\n");

    for (uint32_t di = 0; di < set->count; di++) {
        Dex *d = set->dex[di];
        if (di)
            buf_puts(&b, ",\n");
        buf_puts(&b, "    {\n      \"name\": ");
        json_escape(&b, d->path ? d->path : "?");
        buf_printf(&b,
                   ",\n      \"size\": %zu,\n      \"version\": \"%c%c%c\",\n"
                   "      \"strings\": %u,\n      \"types\": %u,\n      \"protos\": %u,\n"
                   "      \"fields\": %u,\n      \"methods\": %u,\n      \"classes\": %u,\n"
                   "      \"class_list\": [\n",
                   d->size, d->hdr.version[0], d->hdr.version[1], d->hdr.version[2],
                   d->hdr.string_ids_size, d->hdr.type_ids_size, d->hdr.proto_ids_size,
                   d->hdr.field_ids_size, d->hdr.method_ids_size, d->hdr.class_defs_size);

        for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
            const DexClassDef *cd = &d->classes[i];
            const DexClassData *data = dex_class_data(d, i);
            if (i)
                buf_puts(&b, ",\n");
            buf_puts(&b, "        {\"name\": ");
            json_escape(&b, dex_type_name(d, cd->class_idx));
            buf_printf(&b, ", \"access\": %u, \"methods\": %u, \"fields\": %u}", cd->access_flags,
                       data ? data->direct_count + data->virtual_count : 0,
                       data ? data->static_count + data->instance_count : 0);
        }
        buf_puts(&b, "\n      ]\n    }");
    }
    buf_puts(&b, "\n  ]\n}\n");

    fwrite(b.data, 1, b.len, stdout);
    buf_free(&b);
    for (uint32_t i = 0; i < set->count; i++)
        dex_close(set->dex[i]);
    arena_destroy(&arena);
    return 0;
}

/* ------------------------------------------------------------------ */
/* decompile                                                          */
/* ------------------------------------------------------------------ */

typedef struct {
    Dex *dex;
    const char *outdir;
    _Atomic uint32_t written;
    _Atomic uint32_t failed;
    _Atomic uint32_t skipped;
    /* One output path per class, resolved before the pool starts. Resolving it
     * per worker would let the shadow table change shape mid-run and hand two
     * different classes the same file name. */
    char **paths;
    int emit_only;
    int merge;
    int merged_seen;
} DecompileCtx;

static int decompile_one(void *ctxp, uint32_t i, void *unused)
{
    DecompileCtx *c = ctxp;
    (void)unused;

    /* A per-task arena keeps workers off each other's allocator state. Start
     * small: most classes need only a few KB, and a 64 KB first chunk for every
     * one of 15k classes costs hundreds of MB of allocator traffic. */
    Arena arena;
    arena_init(&arena, 4096);
    Arena *prev = java_body_arena();
    java_set_body_arena(&arena);

    Buf buf;
    buf_init(&buf, 4096);

    int rc = -1;
    int emitted = java_emit_class(c->dex, i, &buf);
    if (emitted == 0) {
        const char *rel = (c->paths && i < c->dex->hdr.class_defs_size && c->paths[i])
                              ? c->paths[i]
                              : "";
        if (c->emit_only) {
            atomic_fetch_add(&c->written, 1);
            buf_free(&buf);
            java_set_body_arena(prev);
            arena_destroy(&arena);
            return 0;
        }
        /* In merge mode every class of a directory is appended to one file; Java
         * allows several top-level classes per file as long as only one is public,
         * and the emitter already demotes the rest. This removes most of the
         * per-file create cost, which dominates on f2fs. */
        if (c->merge) {
            char mrel[1024];
            const char *slash = strrchr(rel, '/');
            if (slash)
                snprintf(mrel, sizeof(mrel), "%.*s/_merged.java", (int)(slash - rel), rel);
            else
                snprintf(mrel, sizeof(mrel), "_merged.java");
            /* Skip the package declaration on append: only the first class in a
             * file may carry it. */
            const char *body = buf.data;
            size_t blen = buf.len;
            /* A merged file may contain at most one public type. Every class here
             * is documented as merged output for reading, not as a compilable
             * tree, so `public` is dropped from the declaration line. */
            {
                static _Thread_local Buf fixed;
                static _Thread_local int fixed_init;
                if (!fixed_init) {
                    buf_init(&fixed, 4096);
                    fixed_init = 1;
                }
                const char *decl = strstr(body, "\npublic ");
                if (decl) {
                    /* Remove exactly the word "public " at the start of the
                     * declaration line. */
                    size_t pre = (size_t)(decl - body) + 1;
                    static _Thread_local Buf fixed;
                    buf_reset(&fixed);
                    buf_write(&fixed, body, pre);
                    buf_write(&fixed, body + pre + 7, blen - pre - 7);
                    body = fixed.data;
                    blen = fixed.len;
                }
            }
            /* Always strip the package line. It is written once, up front, by
             * cmd_decompile for every merged file; racing on access() here would
             * let two workers both decide the header is missing. */
            if (!strncmp(body, "package ", 8)) {
                const char *nl = memchr(body, '\n', blen);
                if (nl) {
                    size_t skip = (size_t)(nl - body) + 1;
                    if (skip < blen) {
                        body += skip;
                        blen -= skip;
                    }
                }
            }
            if (writer_append(c->outdir, mrel, body, blen) == 0)
                rc = 0;
        } else if (writer_write(c->outdir, rel, buf.data, buf.len) == 0) {
            rc = 0;
        }
        else if (getenv("TACHYON_DEBUG_WRITE"))
            fprintf(stderr, "[write-fail] rel='%s' i=%u paths=%p defs=%u %s\n", rel, i,
                    (void *)c->paths, c->dex->hdr.class_defs_size, strerror(errno));
    } else if (emitted == -2) {
        /* Skipped on purpose: the class cannot be expressed as compilable Java. */
        rc = 1;
    }

    if (rc == 0)
        atomic_fetch_add(&c->written, 1);
    else if (rc == 1)
        atomic_fetch_add(&c->skipped, 1);
    else
        atomic_fetch_add(&c->failed, 1);

    buf_free(&buf);
    java_set_body_arena(prev);
    arena_destroy(&arena);
    return rc;
}

/* Path of the merged file for a directory: "<dir>/_merged.java". */
static const char *mrel_for(const char *dir_rel)
{
    static _Thread_local char buf[1024];
    snprintf(buf, sizeof(buf), "%s/_merged.java", dir_rel);
    return buf;
}

/* Speed/accuracy presets. Every check below is a correctness measure that costs
 * time, so they are grouped rather than individually switchable. */
enum {
    MODE_FAST,     /* skip the expensive whole-graph analyses */
    MODE_BALANCED, /* default: all checks that are linear in the class count */
    MODE_ACCURATE, /* add the supertype walks that catch rare shapes */
    MODE_MAX       /* EXPERIMENTAL: oversubscribes every core; desktop only */
};


/* ------------------------------------------------------------------ */
/* project scaffolding                                                */
/* ------------------------------------------------------------------ */

/* Reads an attribute from the manifest, returning `fallback` when it is absent. */
static void manifest_attr(const uint8_t *m, size_t mlen, const char *name,
                          const char *fallback, char *out, size_t cap)
{
    if (axml_manifest_attr(m, mlen, name, out, cap) != 0)
        snprintf(out, cap, "%s", fallback);
}

/* Turns the decoded manifest into the Gradle files a real project needs, so the
 * emitted tree opens as a module instead of a bag of .java files. */
static void emit_project_files(const char *src_path, const char *outdir)
{
    uint8_t *m = NULL;
    size_t mlen = 0;
    if (apk_extract(src_path, "AndroidManifest.xml", &m, &mlen) != 0)
        return;

    Buf xml;
    buf_init(&xml, 8192);
    if (axml_to_xml(m, mlen, &xml) == 0 && xml.len) {
        if (writer_mkdirs_for(outdir, "AndroidManifest.xml") == 0)
            writer_write(outdir, "AndroidManifest.xml", xml.data, xml.len);
    }
    buf_free(&xml);

    char pkg[512], ver_code[64], ver_name[128], min_sdk[32], target_sdk[32];
    char app_name[256];
    manifest_attr(m, mlen, "package", "com.unknown", pkg, sizeof(pkg));
    manifest_attr(m, mlen, "android:versionCode", "1", ver_code, sizeof(ver_code));
    manifest_attr(m, mlen, "android:versionName", "1.0", ver_name, sizeof(ver_name));
    manifest_attr(m, mlen, "android:minSdkVersion", "21", min_sdk, sizeof(min_sdk));
    manifest_attr(m, mlen, "android:targetSdkVersion", "34", target_sdk, sizeof(target_sdk));
    /* The manifest records the SDK the APK was actually compiled against, which
     * is what compileSdk should be; targetSdk is only the fallback. */
    char compile_sdk[32];
    manifest_attr(m, mlen, "android:compileSdkVersion", "", compile_sdk, sizeof(compile_sdk));
    manifest_attr(m, mlen, "android:label", "", app_name, sizeof(app_name));
    free(m);

    /* versionName is a string resource reference for most apps; a literal is only
     * usable when it came through as text. */
    if (ver_name[0] == '@' || strchr(ver_name, '/'))
        snprintf(ver_name, sizeof(ver_name), "1.0");
    if (ver_code[0] < '0' || ver_code[0] > '9')
        snprintf(ver_code, sizeof(ver_code), "1");
    if (min_sdk[0] < '0' || min_sdk[0] > '9')
        snprintf(min_sdk, sizeof(min_sdk), "21");
    if (target_sdk[0] < '0' || target_sdk[0] > '9')
        snprintf(target_sdk, sizeof(target_sdk), "34");

    char name[512];
    const char *slash = strrchr(pkg, '.');
    snprintf(name, sizeof(name), "%s", slash ? slash + 1 : pkg);
    if (!name[0])
        snprintf(name, sizeof(name), "app");

    char body[4096];
    int n = snprintf(body, sizeof(body),
        "// Restored from the APK by tachyon.\n"
        "//\n"
        "// This describes the app as it was built, not the source layout that\n"
        "// produced it: resource references remain symbolic, and libraries the APK\n"
        "// bundled appear as ordinary sources.\n"
        "plugins {\n"
        "    id 'com.android.application'\n"
        "}\n"
        "\n"
        "android {\n"
        "    namespace '%s'\n"
        "    compileSdk %s\n"
        "\n"
        "    defaultConfig {\n"
        "        applicationId \"%s\"\n"
        "        minSdk %s\n"
        "        targetSdk %s\n"
        "        versionCode %s\n"
        "        versionName \"%s\"\n"
        "    }\n"
        "\n"
        "    sourceSets {\n"
        "        main {\n"
        "            java.srcDirs = ['.']\n"
        "            manifest.srcFile 'AndroidManifest.xml'\n"
        "        }\n"
        "    }\n"
        "\n"
        "    compileOptions {\n"
        "        sourceCompatibility JavaVersion.VERSION_11\n"
        "        targetCompatibility JavaVersion.VERSION_11\n"
        "    }\n"
        "}\n",
        pkg, compile_sdk[0] >= '0' && compile_sdk[0] <= '9' ? compile_sdk : target_sdk, pkg,
        min_sdk, target_sdk, ver_code, ver_name);
    if (n > 0 && (size_t)n < sizeof(body) &&
        writer_mkdirs_for(outdir, "build.gradle") == 0)
        writer_write(outdir, "build.gradle", body, (size_t)n);

    n = snprintf(body, sizeof(body),
                 "rootProject.name = '%s'\n"
                 "include ':app'\n", name);
    if (n > 0 && (size_t)n < sizeof(body))
        writer_write(outdir, "settings.gradle", body, (size_t)n);

    /* Gradle refuses to configure an Android module without an SDK path, and it
     * must not be committed: it points at one machine's install. */
    n = snprintf(body, sizeof(body),
                 "# Local machine configuration, not part of the project.\n"
                 "# Point sdk.dir at your Android SDK before building.\n"
                 "sdk.dir=/path/to/android-sdk\n");
    if (n > 0 && (size_t)n < sizeof(body))
        writer_write(outdir, "local.properties", body, (size_t)n);
}

static int cmd_decompile(const char *path, const char *outdir, int threads, int bodies,
                        int strict,
                         const char *rename_map, int mode, int emit_only, int merge)
{
    Arena arena;
    arena_init(&arena, 1 << 20);
    char err[512];
    struct timespec z0, z1;
    clock_gettime(CLOCK_MONOTONIC, &z0);
    DexSet *set = apk_open(path, &arena, err, sizeof(err));
    clock_gettime(CLOCK_MONOTONIC, &z1);
    if (getenv("TACHYON_TIME"))
        fprintf(stderr, "[time] apk_open=%.3fs\n",
                (z1.tv_sec - z0.tv_sec) + (z1.tv_nsec - z0.tv_nsec) / 1e9);
    if (!set) {
        fprintf(stderr, "error: %s\n", err);
        arena_destroy(&arena);
        return 1;
    }

    if (io_mkdirs(outdir) < 0) {
        fprintf(stderr, "error: cannot create '%s': %s\n", outdir, strerror(errno));
        arena_destroy(&arena);
        return 1;
    }

    Renamer *renamer = NULL;
    if (rename_map) {
        renamer = renamer_load(rename_map, &arena);
        if (!renamer) {
            fprintf(stderr, "error: cannot read mapping '%s'\n", rename_map);
            arena_destroy(&arena);
            return 1;
        }
        fprintf(stderr, "tachyon: loaded %u class mappings\n", renamer_class_count(renamer));
    }

    /* Optional: if an Android SDK is present, platform constructor signatures are
     * read from it so super() calls match the real superclass. Without it the
     * emitter falls back to the no-arg form. */
    {
        /* The Android SDK class tree is optional: when present it supplies the
         * real platform constructor signatures, which removes most
         * "no suitable constructor" errors. Looked up in the usual places so no
         * environment variable is required. */
        const char *sdk = getenv("TACHYON_SDK_CLASSES");
        if (sdk && sdk[0]) {
            platform_set_sdk(sdk);
        } else {
            static const char *const candidates[] = {
                "/tmp/sdkcls",
                "/opt/android-sdk/sdk-classes",
                "/root/.cache/tachyon/sdk-classes",
            };
            for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
                if (access(candidates[i], F_OK) == 0) {
                    platform_set_sdk(candidates[i]);
                    break;
                }
            }
        }
    }
    progress(10, "APK opened, dex parsed");
    g_relocate_default_pkg = 1;
    g_all_dex = set->dex;
    java_build_global_defs(set->dex, set->count, &arena);
    progress(15, "global index built");
    g_all_dex_count = set->count;
    java_set_emit_bodies(bodies);
    java_set_strict_bodies(strict);
    if (mode == MODE_FAST)
        java_set_accurate_mode(0);
    if (renamer)
        java_set_renamer(renamer);

    /* Give single-letter classes a name derived from what they actually contain.
     * Anything with no evidence keeps its obfuscated name. */
    {
        HeurNames *hn = heuristic_build(set->dex, set->count, &arena);
        if (hn && hn->count) {
            java_set_heuristic(hn);
            fprintf(stderr, "tachyon: %u obfuscated class(es) renamed\n", hn->count);
        }
    }

    /* Collect the placeholder types before any class is emitted: references to
     * them must be spelled the way the placeholder file will be named. */
    StubSet *stubs = NULL;
    if (!emit_only) {
        struct timespec ts0, ts1;
        clock_gettime(CLOCK_MONOTONIC, &ts0);
        stubs = stub_collect(set->dex, set->count, &arena);
        clock_gettime(CLOCK_MONOTONIC, &ts1);
        if (getenv("TACHYON_TIME"))
            fprintf(stderr, "[time] stub_collect=%.3fs (n=%u)\n",
                    (ts1.tv_sec - ts0.tv_sec) + (ts1.tv_nsec - ts0.tv_nsec) / 1e9,
                    stubs ? stubs->count : 0);
        if (stubs && stubs->count)
            java_set_stub_descs(stubs->descs, stubs->count);
        progress(20, "dependency analysis done");
    }

    PoolConfig cfg;
    cfg.workers = threads > 0 ? threads : 0;
    cfg.io_workers = cfg.workers;
    cfg.chunk = 0;

    uint64_t total_classes = 0;
    uint64_t total_failed = 0;
    double total_secs = 0.0;

    for (uint32_t di = 0; di < set->count; di++) {
        Dex *d = set->dex[di];
        if (set->count > 1)
            fprintf(stderr, "tachyon: [%u/%u] %s\n", di + 1, set->count, d->path ? d->path : "?");

        {
            char msg[128];
            snprintf(msg, sizeof(msg), "decompiling dex %u/%u", di + 1, set->count);
            progress(25 + (int)(60.0 * di / (set->count ? set->count : 1)), msg);
        }
        struct timespec p0, p1;
        clock_gettime(CLOCK_MONOTONIC, &p0);
        remap_init(d);
        java_reset_shadow_table();
        java_prepare_shadow_table(d);
        clock_gettime(CLOCK_MONOTONIC, &p1);
        if (getenv("TACHYON_TIME"))
            fprintf(stderr, "[time] remap+shadow=%.3fs\n",
                    (p1.tv_sec - p0.tv_sec) + (p1.tv_nsec - p0.tv_nsec) / 1e9);
        g_current_dex = d;
        clock_gettime(CLOCK_MONOTONIC, &p0);
        for (uint32_t i = 0; i < d->hdr.class_defs_size; i++)
            dex_class_data(d, i);
        clock_gettime(CLOCK_MONOTONIC, &p1);
        if (getenv("TACHYON_TIME"))
            fprintf(stderr, "[time] class_data warm=%.3fs\n",
                    (p1.tv_sec - p0.tv_sec) + (p1.tv_nsec - p0.tv_nsec) / 1e9);

        clock_gettime(CLOCK_MONOTONIC, &p0);
        warm_caches(d);
        clock_gettime(CLOCK_MONOTONIC, &p1);
        if (getenv("TACHYON_TIME"))
            fprintf(stderr, "[time] warm_caches=%.3fs\n",
                    (p1.tv_sec - p0.tv_sec) + (p1.tv_nsec - p0.tv_nsec) / 1e9);

        /* Size the pool for this dex: a tiny input does not need more threads
         * than it has classes, and a very large one benefits from slight
         * oversubscription to hide I/O latency. */
        int cpus = pool_cpu_count();
        if (mode == MODE_MAX)
            cpus *= 4; /* experimental: oversubscribe every core */
        int want;
        if (threads > 0) {
            want = threads;
        } else {
            uint32_t classes = d->hdr.class_defs_size;
            if (classes < (uint32_t)cpus)
                want = (int)(classes ? classes : 1);
            else if (d->size > (size_t)64 * 1024 * 1024)
                want = cpus + cpus / 2;
            else
                want = cpus;
        }
        if (want < 1)
            want = 1;
        if (want > 512)
            want = 512;

        /* Small enough that the tail is balanced, large enough that the atomic
         * fetch is amortised over many classes. */
        uint32_t chunk = d->hdr.class_defs_size / ((uint32_t)want * 16);
        if (chunk < 8)
            chunk = 8;
        if (chunk > 512)
            chunk = 512;

        cfg.workers = want;
        cfg.io_workers = want;
        cfg.chunk = chunk;

        DecompileCtx ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.dex = d;
        ctx.outdir = outdir;
        ctx.emit_only = emit_only;
        ctx.merge = merge;

        struct timespec t0, t1;
        /* Resolve every output path up front and create all directories before
         * any worker starts. io_mkdirs walks the path one component at a time, so
         * doing it per file costs thousands of redundant stat calls; doing it
         * once here also removes the last shared write from the hot path. */
        java_prepare_missing_bitmap(d, &arena);
        java_build_package_dirs(d, &arena);
        ctx.paths = arena_zalloc(&arena, ((size_t)d->hdr.class_defs_size + 1) * sizeof(char *));
        if (ctx.paths) {
            /* io_mkdirs walks each component, so calling it per class repeats the
             * same stat/mkdir thousands of times. Sort-free dedup with a small
             * hash set keeps this to one call per distinct directory. */
            char **seen = arena_zalloc(&arena, 4096 * sizeof(char *));
            for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
                char rel[1024];
                java_class_path(d, i, rel, sizeof(rel));
                ctx.paths[i] = arena_strdup(&arena, rel);

                char *slash = strrchr(rel, '/');
                if (!slash || !seen)
                    continue;
                *slash = '\0';
                uint32_t h = 2166136261u;
                for (const char *q = rel; *q; q++)
                    h = (h ^ (uint8_t)*q) * 16777619u;
                h &= 4095;
                int dup = 0;
                for (uint32_t step = 0; step < 4096 && seen[h]; step++, h = (h + 1) & 4095)
                    if (!strcmp(seen[h], rel)) {
                        dup = 1;
                        break;
                    }
                if (!dup) {
                    seen[h] = arena_strdup(&arena, rel);
                    char full[4096];
                    snprintf(full, sizeof(full), "%s/%s", outdir, rel);
                    (void)full;
                    io_mkdirs(full);
                    if (merge) {
                        /* One header per merged file, written before any worker
                         * appends class bodies. */
                        char mpkg[1024];
                        for (size_t k = 0; rel[k]; k++)
                            mpkg[k] = (rel[k] == '/') ? '.' : rel[k];
                        mpkg[strlen(rel)] = '\0';
                        char header[1200];
                        int hl = snprintf(header, sizeof(header), "package %s;\n\n", mpkg);
                        if (hl > 0)
                            writer_write(outdir, mrel_for(rel), header, (size_t)hl);
                    }
                }
            }
        }

        struct timespec w0, w1;
        clock_gettime(CLOCK_MONOTONIC, &w0);

        clock_gettime(CLOCK_MONOTONIC, &t0);
        uint32_t failed = pool_run(&cfg, d->hdr.class_defs_size, decompile_one, &ctx, NULL);
        clock_gettime(CLOCK_MONOTONIC, &t1);

        clock_gettime(CLOCK_MONOTONIC, &w1);
        double wall = (double)(w1.tv_sec - w0.tv_sec) + (double)(w1.tv_nsec - w0.tv_nsec) / 1e9;
        if (getenv("TACHYON_TIME"))
            fprintf(stderr, "[time] pool_run wall=%.3fs\n", wall);

        double secs = (double)(t1.tv_sec - t0.tv_sec) + (double)(t1.tv_nsec - t0.tv_nsec) / 1e9;
        total_secs += secs;
        total_classes += d->hdr.class_defs_size;
        total_failed += failed;

        uint32_t written = atomic_load(&ctx.written);
        uint32_t skipped = atomic_load(&ctx.skipped);
        fprintf(stderr,
                "tachyon: %u written, %u skipped, %u failed in %.3fs "
                "(%.0f classes/s, %d threads)\n",
                written, skipped, failed, secs,
                secs > 0 ? (double)d->hdr.class_defs_size / secs : 0.0, cfg.workers);
    }

    if (set->count > 1)
        fprintf(stderr, "tachyon: total %llu classes in %.3fs\n",
                (unsigned long long)total_classes, total_secs);

    /* Types the app references but does not carry (hidden platform APIs,
     * compile-only libraries) get a placeholder declaration, so the emitted tree
     * compiles on its own. */
    progress(90, "decompilation finished");
    /* The manifest and Gradle files turn the output into an openable project. */
    if (!emit_only && set->is_archive)
        emit_project_files(path, outdir);
    progress(95, "project files written");

    if (stubs && stubs->count) {
        uint32_t n = stub_write(stubs, outdir);
        if (n)
            fprintf(stderr, "tachyon: %u stub type(s) written\n", n);
    }
    progress(100, "done");

    if (getenv("TACHYON_TIME"))
        fprintf(stderr, "[time] before cleanup\n");
    remap_free();
    java_set_renamer(NULL);
    for (uint32_t i = 0; i < set->count; i++)
        dex_close(set->dex[i]);
    arena_destroy(&arena);
    if (getenv("TACHYON_TIME"))
        fprintf(stderr, "[time] after cleanup\n");
    return total_failed ? 1 : 0;
}

/* ------------------------------------------------------------------ */

int main(int argc, char **argv)
{
    if (argc < 2) {
        usage(stderr);
        return 2;
    }
    const char *cmd = argv[1];
    if (!strcmp(cmd, "--version") || !strcmp(cmd, "-V")) {
        printf("tachyon %s\n", TACHYON_VERSION);
        return 0;
    }
    if (!strcmp(cmd, "--help") || !strcmp(cmd, "-h")) {
        usage(stdout);
        return 0;
    }

    if (!strcmp(cmd, "info")) {
        if (argc < 3) {
            fprintf(stderr, "error: info requires a file\n");
            return 2;
        }
        /* Try the built-in DEX path first; anything else goes through the
         * pluggable formatter table (JVM class, CPython pyc, ...). */
        MappedFile probe;
        if (io_map(argv[2], &probe) == 0) {
            int is_dex = probe.len >= 4 && !memcmp(probe.data, "dex\n", 4);
            int is_zip = probe.len >= 4 && probe.data[0] == 'P' && probe.data[1] == 'K';
            io_unmap(&probe);
            if (!is_dex && !is_zip) {
                FormatOptions opt;
                memset(&opt, 0, sizeof(opt));
                opt.depth = 2;
                return format_run(argv[2], "describe", &opt);
            }
        }
        return cmd_info(argv[2]);
    }
    if (!strcmp(cmd, "formats")) {
        size_t n = 0;
        const Formatter **all = formatters(&n);
        for (size_t i = 0; i < n; i++)
            printf("%-10s %s\n", all[i]->name, all[i]->description);
        return 0;
    }
    if (!strcmp(cmd, "list")) {
        if (argc < 3) {
            fprintf(stderr, "error: list requires an archive\n");
            return 2;
        }
        return cmd_list(argv[2]);
    }
    if (!strcmp(cmd, "json")) {
        if (argc < 3) {
            fprintf(stderr, "error: json requires a file\n");
            return 2;
        }
        return cmd_json(argv[2]);
    }
    if (!strcmp(cmd, "dis") || !strcmp(cmd, "disasm")) {
        const char *path = NULL;
        uint32_t limit = 3;
        int probe_only = 0;
        for (int i = 2; i < argc; i++) {
            if (!strcmp(argv[i], "-n") && i + 1 < argc)
                limit = (uint32_t)atoi(argv[++i]);
            else if (!path)
                path = argv[i];
        }
        if (!path) {
            fprintf(stderr, "error: dis requires a file\n");
            return 2;
        }
        MappedFile probe;
        if (io_map(path, &probe) == 0) {
            int is_dex = probe.len >= 4 && !memcmp(probe.data, "dex\n", 4);
            int is_zip = probe.len >= 4 && probe.data[0] == 'P' && probe.data[1] == 'K';
            io_unmap(&probe);
            if (!is_dex && !is_zip) {
                FormatOptions opt;
                memset(&opt, 0, sizeof(opt));
                opt.limit = (int)limit;
                probe_only = 1;
                return format_run(path, "disassemble", &opt);
            }
        }
        (void)probe_only;
        return cmd_disasm(path, limit);
    }
    if (!strcmp(cmd, "d") || !strcmp(cmd, "decompile")) {
        const char *path = NULL, *outdir = NULL, *rename_map = NULL;
        int threads = 0, bodies = 0, emit_only = 0, merge = 0, keep = 0, strict = 0;
        int mode = MODE_BALANCED;
        for (int i = 2; i < argc; i++) {
            if (!strcmp(argv[i], "-o") && i + 1 < argc)
                outdir = argv[++i];
            else if (!strcmp(argv[i], "-j") && i + 1 < argc)
                threads = atoi(argv[++i]);
            else if (!strcmp(argv[i], "--bodies"))
                bodies = 1;
            else if (!strcmp(argv[i], "--strict"))
                strict = 1;
            else if (!strcmp(argv[i], "--emit-only"))
                emit_only = 1;
            else if (!strcmp(argv[i], "--merge"))
                merge = 1;
            else if (!strcmp(argv[i], "--keep"))
                keep = 1;
            else if (!strcmp(argv[i], "--progress"))
                g_progress = 1;
            else if (!strcmp(argv[i], "--rename") && i + 1 < argc)
                rename_map = argv[++i];
            else if (!strcmp(argv[i], "--mode") && i + 1 < argc) {
                const char *m = argv[++i];
                if (!strcmp(m, "fast"))
                    mode = MODE_FAST;
                else if (!strcmp(m, "accurate"))
                    mode = MODE_ACCURATE;
                else if (!strcmp(m, "balanced"))
                    mode = MODE_BALANCED;
                else if (!strcmp(m, "max"))
                    mode = MODE_MAX;
                else {
                    fprintf(stderr,
                            "error: --mode must be fast, balanced, accurate or max\n");
                    return 2;
                }
            }
            else if (!path)
                path = argv[i];
        }
        if (!path) {
            fprintf(stderr, "error: d requires <file>\n");
            usage(stderr);
            return 2;
        }
        /* One fixed destination keeps repeated runs from filling the disk with
         * old trees: it is cleared before writing unless --keep is given. */
        if (!outdir)
            outdir = "out";
        if (!emit_only && !keep && io_rmtree(outdir) != 0 && errno != ENOENT)
            fprintf(stderr, "tachyon: could not clear '%s'\n", outdir);
        return cmd_decompile(path, outdir, threads, bodies, strict, rename_map, mode,
                             emit_only, merge);
    }

    fprintf(stderr, "error: unknown command '%s'\n", cmd);
    usage(stderr);
    return 2;
}
