src/formats/jvm/jvm_disasm.o: src/formats/jvm/jvm_disasm.c \
 src/formats/jvm/jvm.h src/common/arena.h src/common/buf.h

src/formats/jvm/jvm.h:

src/common/arena.h:

src/common/buf.h:
