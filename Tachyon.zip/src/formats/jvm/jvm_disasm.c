#include "formats/jvm/jvm.h"

#include <stdio.h>
#include <string.h>

/* JVM opcodes that take operands. Everything else is a single byte. */
typedef enum {
    OP_NONE, OP_U1, OP_S1, OP_U2, OP_S2, OP_U4, OP_S4,
    OP_CP1, OP_CP2, OP_CP2U1, OP_LV_U1, OP_IINC, OP_INVOKE, OP_INVOKE_IF,
    OP_TABLESWITCH, OP_LOOKUPSWITCH, OP_MULTIANEWARRAY, OP_NEWARRAY,
} OpForm;

typedef struct {
    const char *name;
    OpForm form;
} OpInfo;

/* 0x00 - 0xca, 0xc4 is wide (handled specially), 0xc9 is jsr. */
static const OpInfo OPS[256] = {
    [0x00] = {"nop", OP_NONE},
    [0x01] = {"aconst_null", OP_NONE},
    [0x02] = {"iconst_m1", OP_NONE},
    [0x03] = {"iconst_0", OP_NONE},
    [0x04] = {"iconst_1", OP_NONE},
    [0x05] = {"iconst_2", OP_NONE},
    [0x06] = {"iconst_3", OP_NONE},
    [0x07] = {"iconst_4", OP_NONE},
    [0x08] = {"iconst_5", OP_NONE},
    [0x09] = {"lconst_0", OP_NONE},
    [0x0a] = {"lconst_1", OP_NONE},
    [0x0b] = {"fconst_0", OP_NONE},
    [0x0c] = {"fconst_1", OP_NONE},
    [0x0d] = {"fconst_2", OP_NONE},
    [0x0e] = {"dconst_0", OP_NONE},
    [0x0f] = {"dconst_1", OP_NONE},
    [0x10] = {"bipush", OP_S1},
    [0x11] = {"sipush", OP_S2},
    [0x12] = {"ldc", OP_CP1},
    [0x13] = {"ldc_w", OP_CP2},
    [0x14] = {"ldc2_w", OP_CP2},
    [0x15] = {"iload", OP_LV_U1},
    [0x16] = {"lload", OP_LV_U1},
    [0x17] = {"fload", OP_LV_U1},
    [0x18] = {"dload", OP_LV_U1},
    [0x19] = {"aload", OP_LV_U1},
    [0x1a] = {"iload_0", OP_NONE},
    [0x1b] = {"iload_1", OP_NONE},
    [0x1c] = {"iload_2", OP_NONE},
    [0x1d] = {"iload_3", OP_NONE},
    [0x1e] = {"lload_0", OP_NONE},
    [0x1f] = {"lload_1", OP_NONE},
    [0x20] = {"lload_2", OP_NONE},
    [0x21] = {"lload_3", OP_NONE},
    [0x22] = {"fload_0", OP_NONE},
    [0x23] = {"fload_1", OP_NONE},
    [0x24] = {"fload_2", OP_NONE},
    [0x25] = {"fload_3", OP_NONE},
    [0x26] = {"dload_0", OP_NONE},
    [0x27] = {"dload_1", OP_NONE},
    [0x28] = {"dload_2", OP_NONE},
    [0x29] = {"dload_3", OP_NONE},
    [0x2a] = {"aload_0", OP_NONE},
    [0x2b] = {"aload_1", OP_NONE},
    [0x2c] = {"aload_2", OP_NONE},
    [0x2d] = {"aload_3", OP_NONE},
    [0x2e] = {"iaload", OP_NONE},
    [0x2f] = {"laload", OP_NONE},
    [0x30] = {"faload", OP_NONE},
    [0x31] = {"daload", OP_NONE},
    [0x32] = {"aaload", OP_NONE},
    [0x33] = {"baload", OP_NONE},
    [0x34] = {"caload", OP_NONE},
    [0x35] = {"saload", OP_NONE},
    [0x36] = {"istore", OP_LV_U1},
    [0x37] = {"lstore", OP_LV_U1},
    [0x38] = {"fstore", OP_LV_U1},
    [0x39] = {"dstore", OP_LV_U1},
    [0x3a] = {"astore", OP_LV_U1},
    [0x3b] = {"istore_0", OP_NONE},
    [0x3c] = {"istore_1", OP_NONE},
    [0x3d] = {"istore_2", OP_NONE},
    [0x3e] = {"istore_3", OP_NONE},
    [0x3f] = {"lstore_0", OP_NONE},
    [0x40] = {"lstore_1", OP_NONE},
    [0x41] = {"lstore_2", OP_NONE},
    [0x42] = {"lstore_3", OP_NONE},
    [0x43] = {"fstore_0", OP_NONE},
    [0x44] = {"fstore_1", OP_NONE},
    [0x45] = {"fstore_2", OP_NONE},
    [0x46] = {"fstore_3", OP_NONE},
    [0x47] = {"dstore_0", OP_NONE},
    [0x48] = {"dstore_1", OP_NONE},
    [0x49] = {"dstore_2", OP_NONE},
    [0x4a] = {"dstore_3", OP_NONE},
    [0x4b] = {"astore_0", OP_NONE},
    [0x4c] = {"astore_1", OP_NONE},
    [0x4d] = {"astore_2", OP_NONE},
    [0x4e] = {"astore_3", OP_NONE},
    [0x4f] = {"iastore", OP_NONE},
    [0x50] = {"lastore", OP_NONE},
    [0x51] = {"fastore", OP_NONE},
    [0x52] = {"dastore", OP_NONE},
    [0x53] = {"aastore", OP_NONE},
    [0x54] = {"bastore", OP_NONE},
    [0x55] = {"castore", OP_NONE},
    [0x56] = {"sastore", OP_NONE},
    [0x57] = {"pop", OP_NONE},
    [0x58] = {"pop2", OP_NONE},
    [0x59] = {"dup", OP_NONE},
    [0x5a] = {"dup_x1", OP_NONE},
    [0x5b] = {"dup_x2", OP_NONE},
    [0x5c] = {"dup2", OP_NONE},
    [0x5d] = {"dup2_x1", OP_NONE},
    [0x5e] = {"dup2_x2", OP_NONE},
    [0x5f] = {"swap", OP_NONE},
    [0x60] = {"iadd", OP_NONE},
    [0x61] = {"ladd", OP_NONE},
    [0x62] = {"fadd", OP_NONE},
    [0x63] = {"dadd", OP_NONE},
    [0x64] = {"isub", OP_NONE},
    [0x65] = {"lsub", OP_NONE},
    [0x66] = {"fsub", OP_NONE},
    [0x67] = {"dsub", OP_NONE},
    [0x68] = {"imul", OP_NONE},
    [0x69] = {"lmul", OP_NONE},
    [0x6a] = {"fmul", OP_NONE},
    [0x6b] = {"dmul", OP_NONE},
    [0x6c] = {"idiv", OP_NONE},
    [0x6d] = {"ldiv", OP_NONE},
    [0x6e] = {"fdiv", OP_NONE},
    [0x6f] = {"ddiv", OP_NONE},
    [0x70] = {"irem", OP_NONE},
    [0x71] = {"lrem", OP_NONE},
    [0x72] = {"frem", OP_NONE},
    [0x73] = {"drem", OP_NONE},
    [0x74] = {"ineg", OP_NONE},
    [0x75] = {"lneg", OP_NONE},
    [0x76] = {"fneg", OP_NONE},
    [0x77] = {"dneg", OP_NONE},
    [0x78] = {"ishl", OP_NONE},
    [0x79] = {"lshl", OP_NONE},
    [0x7a] = {"ishr", OP_NONE},
    [0x7b] = {"lshr", OP_NONE},
    [0x7c] = {"iushr", OP_NONE},
    [0x7d] = {"lushr", OP_NONE},
    [0x7e] = {"iand", OP_NONE},
    [0x7f] = {"land", OP_NONE},
    [0x80] = {"ior", OP_NONE},
    [0x81] = {"lor", OP_NONE},
    [0x82] = {"ixor", OP_NONE},
    [0x83] = {"lxor", OP_NONE},
    [0x84] = {"iinc", OP_IINC},
    [0x85] = {"i2l", OP_NONE},
    [0x86] = {"i2f", OP_NONE},
    [0x87] = {"i2d", OP_NONE},
    [0x88] = {"l2i", OP_NONE},
    [0x89] = {"l2f", OP_NONE},
    [0x8a] = {"l2d", OP_NONE},
    [0x8b] = {"f2i", OP_NONE},
    [0x8c] = {"f2l", OP_NONE},
    [0x8d] = {"f2d", OP_NONE},
    [0x8e] = {"d2i", OP_NONE},
    [0x8f] = {"d2l", OP_NONE},
    [0x90] = {"d2f", OP_NONE},
    [0x91] = {"i2b", OP_NONE},
    [0x92] = {"i2c", OP_NONE},
    [0x93] = {"i2s", OP_NONE},
    [0x94] = {"lcmp", OP_NONE},
    [0x95] = {"fcmpl", OP_NONE},
    [0x96] = {"fcmpg", OP_NONE},
    [0x97] = {"dcmpl", OP_NONE},
    [0x98] = {"dcmpg", OP_NONE},
    [0x99] = {"ifeq", OP_S2},
    [0x9a] = {"ifne", OP_S2},
    [0x9b] = {"iflt", OP_S2},
    [0x9c] = {"ifge", OP_S2},
    [0x9d] = {"ifgt", OP_S2},
    [0x9e] = {"ifle", OP_S2},
    [0x9f] = {"if_icmpeq", OP_S2},
    [0xa0] = {"if_icmpne", OP_S2},
    [0xa1] = {"if_icmplt", OP_S2},
    [0xa2] = {"if_icmpge", OP_S2},
    [0xa3] = {"if_icmpgt", OP_S2},
    [0xa4] = {"if_icmple", OP_S2},
    [0xa5] = {"if_acmpeq", OP_S2},
    [0xa6] = {"if_acmpne", OP_S2},
    [0xa7] = {"goto", OP_S2},
    [0xa8] = {"jsr", OP_S2},
    [0xa9] = {"ret", OP_LV_U1},
    [0xaa] = {"tableswitch", OP_TABLESWITCH},
    [0xab] = {"lookupswitch", OP_LOOKUPSWITCH},
    [0xac] = {"ireturn", OP_NONE},
    [0xad] = {"lreturn", OP_NONE},
    [0xae] = {"freturn", OP_NONE},
    [0xaf] = {"dreturn", OP_NONE},
    [0xb0] = {"areturn", OP_NONE},
    [0xb1] = {"return", OP_NONE},
    [0xb2] = {"getstatic", OP_CP2},
    [0xb3] = {"putstatic", OP_CP2},
    [0xb4] = {"getfield", OP_CP2},
    [0xb5] = {"putfield", OP_CP2},
    [0xb6] = {"invokevirtual", OP_INVOKE},
    [0xb7] = {"invokespecial", OP_INVOKE},
    [0xb8] = {"invokestatic", OP_INVOKE},
    [0xb9] = {"invokeinterface", OP_INVOKE_IF},
    [0xba] = {"invokedynamic", OP_CP2U1},
    [0xbb] = {"new", OP_CP2},
    [0xbc] = {"newarray", OP_NEWARRAY},
    [0xbd] = {"anewarray", OP_CP2},
    [0xbe] = {"arraylength", OP_NONE},
    [0xbf] = {"athrow", OP_NONE},
    [0xc0] = {"checkcast", OP_CP2},
    [0xc1] = {"instanceof", OP_CP2},
    [0xc2] = {"monitorenter", OP_NONE},
    [0xc3] = {"monitorexit", OP_NONE},
    [0xc4] = {"wide", OP_NONE},
    [0xc5] = {"multianewarray", OP_MULTIANEWARRAY},
    [0xc6] = {"ifnull", OP_S2},
    [0xc7] = {"ifnonnull", OP_S2},
    [0xc8] = {"goto_w", OP_S4},
    [0xc9] = {"jsr_w", OP_S4},
    [0xca] = {"breakpoint", OP_NONE},
    [0xfe] = {"impdep1", OP_NONE},
    [0xff] = {"impdep2", OP_NONE},
};

static int16_t s2(const uint8_t *p)
{
    return (int16_t)((p[0] << 8) | p[1]);
}

static int32_t s4(const uint8_t *p)
{
    return (int32_t)(((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
                     ((uint32_t)p[2] << 8) | (uint32_t)p[3]);
}

static uint32_t u4v(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) |
           (uint32_t)p[3];
}

/* Returns the instruction length at pc, or 0 on a malformed stream. */
static uint32_t insn_len(const JvmCode *code, uint32_t pc)
{
    if (pc >= code->code_len)
        return 0;
    const uint8_t *p = code->code + pc;
    uint8_t op = p[0];
    const OpInfo *info = &OPS[op];

    switch (info->form) {
    case OP_NONE: return 1;
    case OP_U1:
    case OP_S1:
    case OP_CP1:
    case OP_LV_U1:
    case OP_NEWARRAY: return 2;
    case OP_U2:
    case OP_S2:
    case OP_CP2:
    case OP_IINC:
    case OP_INVOKE:
    case OP_MULTIANEWARRAY: return 3;
    case OP_CP2U1:
    case OP_INVOKE_IF: return 5;
    case OP_S4: return 5;
    case OP_U4: return 5;
    case OP_TABLESWITCH: {
        /* padding to a 4-byte boundary relative to the method start */
        uint32_t pad = (4 - ((pc + 1) & 3)) & 3;
        if (pc + 1 + pad + 12 > code->code_len)
            return 0;
        int32_t lo = s4(p + 1 + pad + 4);
        int32_t hi = s4(p + 1 + pad + 8);
        if (hi < lo)
            return 0;
        uint64_t n = (uint64_t)(hi - lo + 1);
        if (n > 65536)
            return 0;
        return 1 + pad + 12 + (uint32_t)(n * 4);
    }
    case OP_LOOKUPSWITCH: {
        uint32_t pad = (4 - ((pc + 1) & 3)) & 3;
        if (pc + 1 + pad + 8 > code->code_len)
            return 0;
        int32_t npairs = s4(p + 1 + pad + 4);
        if (npairs < 0 || npairs > 65536)
            return 0;
        return 1 + pad + 8 + (uint32_t)(npairs * 8);
    }
    default:
        return 0;
    }
}

void jvm_disassemble(JvmClass *c, JvmMethod *m, Buf *out, int indent)
{
    if (!m->code)
        return;
    const JvmCode *code = m->code;

    for (uint32_t pc = 0; pc < code->code_len;) {
        uint32_t len = insn_len(code, pc);
        if (!len) {
            buf_indent(out, indent);
            buf_printf(out, "%6u: <undecodable 0x%02x>\n", pc, code->code[pc]);
            break;
        }
        const uint8_t *p = code->code + pc;
        uint8_t op = p[0];
        const OpInfo *info = &OPS[op];
        const char *name = info->name ? info->name : "<illegal>";

        buf_indent(out, indent);
        buf_printf(out, "%6u: %-16s", pc, name);

        switch (info->form) {
        case OP_S1:
            buf_printf(out, "%d", (int8_t)p[1]);
            break;
        case OP_S2:
            buf_printf(out, "%d", pc + s2(p + 1));
            break;
        case OP_S4:
            buf_printf(out, "%d", (int64_t)pc + s4(p + 1));
            break;
        case OP_CP1:
        case OP_CP2:
            buf_printf(out, "#%u", info->form == OP_CP1 ? p[1]
                                                            : (unsigned)((p[1] << 8) | p[2]));
            break;
        case OP_LV_U1:
            buf_printf(out, "%u", p[1]);
            break;
        case OP_IINC:
            buf_printf(out, "%u, %d", p[1], (int8_t)p[2]);
            break;
        case OP_INVOKE: {
            uint16_t idx = (uint16_t)((p[1] << 8) | p[2]);
            buf_printf(out, "%s", jvm_ref_name(c, idx));
            break;
        }
        case OP_INVOKE_IF: {
            uint16_t idx = (uint16_t)((p[1] << 8) | p[2]);
            buf_printf(out, "%s, %u", jvm_ref_name(c, idx), p[3]);
            break;
        }
        case OP_NEWARRAY: {
            static const char *t[] = {"boolean", "char", "float", "double", "byte",
                                      "short", "int", "long"};
            uint8_t at = p[1];
            buf_printf(out, "%s", at < 8 ? t[at - 4 < 0 ? 0 : at - 4] : "?");
            break;
        }
        case OP_MULTIANEWARRAY: {
            uint16_t idx = (uint16_t)((p[1] << 8) | p[2]);
            buf_printf(out, "%s, %u", jvm_class_name(c, idx), p[3]);
            break;
        }
        case OP_TABLESWITCH: {
            uint32_t pad = (4 - ((pc + 1) & 3)) & 3;
            int32_t def = s4(p + 1 + pad);
            int32_t lo = s4(p + 1 + pad + 4);
            int32_t hi = s4(p + 1 + pad + 8);
            buf_printf(out, "default=%d lo=%d hi=%d", pc + def, lo, hi);
            break;
        }
        case OP_LOOKUPSWITCH: {
            uint32_t pad = (4 - ((pc + 1) & 3)) & 3;
            int32_t def = s4(p + 1 + pad);
            int32_t np = s4(p + 1 + pad + 4);
            buf_printf(out, "default=%d pairs=%d", pc + def, np);
            break;
        }
        default:
            break;
        }

        /* Constant annotations make the listing readable. */
        if (op == 0x12 || op == 0x13) {
            uint16_t idx = op == 0x12 ? p[1] : (uint16_t)((p[1] << 8) | p[2]);
            if (idx && idx < c->cp_count) {
                JvmCp *e = &c->cp[idx];
                if (e->tag == JVM_STRING)
                    buf_printf(out, "   // \"%s\"", jvm_utf8(c, e->a));
                else if (e->tag == JVM_CLASS)
                    buf_printf(out, "   // %s", jvm_class_name(c, idx));
                else if (e->tag == JVM_INT)
                    buf_printf(out, "   // %d", (int)e->number);
            }
        }
        if (op == 0xb2 || op == 0xb3 || op == 0xb4 || op == 0xb5) {
            uint16_t idx = (uint16_t)((p[1] << 8) | p[2]);
            if (idx && idx < c->cp_count) {
                JvmCp *e = &c->cp[idx];
                if (e->b && e->b < c->cp_count && c->cp[e->b].tag == JVM_NAME_AND_TYPE)
                    buf_printf(out, "   // %s %s",
                                   jvm_utf8(c, c->cp[e->b].b), jvm_utf8(c, c->cp[e->b].a));
            }
        }

        buf_putc(out, '\n');
        pc += len;
    }
    (void)u4v;
}
