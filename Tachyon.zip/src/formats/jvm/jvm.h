#ifndef REA_JVM_H
#define REA_JVM_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "common/buf.h"

#define JVM_MAGIC 0xCAFEBABEu

enum {
    JVM_UTF8 = 1,
    JVM_INT = 3,
    JVM_FLOAT = 4,
    JVM_LONG = 5,
    JVM_DOUBLE = 6,
    JVM_CLASS = 7,
    JVM_STRING = 8,
    JVM_FIELDREF = 9,
    JVM_METHODREF = 10,
    JVM_INTERFACE_METHODREF = 11,
    JVM_NAME_AND_TYPE = 12,
    JVM_METHOD_HANDLE = 15,
    JVM_METHOD_TYPE = 16,
    JVM_DYNAMIC = 17,
    JVM_INVOKE_DYNAMIC = 18,
    JVM_MODULE = 19,
    JVM_PACKAGE = 20,
};

typedef struct {
    uint8_t tag;
    uint16_t a, b;          /* generic pair of pool indices */
    const char *utf8;       /* JVM_UTF8 */
    int64_t number;         /* int/long value */
    double fnumber;         /* float/double value */
} JvmCp;

typedef struct {
    uint16_t access_flags, name_idx, desc_idx;
} JvmMember;

typedef struct {
    uint16_t start_pc, end_pc, handler_pc, catch_type;
} JvmExc;

typedef struct {
    uint16_t max_stack, max_locals;
    uint32_t code_len;
    const uint8_t *code;
    uint16_t exception_count;
    JvmExc *exceptions;
} JvmCode;

typedef struct {
    uint16_t access_flags, name_idx, desc_idx;
    JvmCode *code;
} JvmMethod;

typedef struct {
    uint16_t minor, major;
    uint16_t cp_count;
    JvmCp *cp;
    uint16_t access_flags, this_class, super_class;
    uint16_t interface_count;
    uint16_t *interfaces;
    uint16_t field_count;
    JvmMember *fields;
    uint16_t method_count;
    JvmMethod *methods;
    const char *source_file;
    Arena *arena;
} JvmClass;

JvmClass *jvm_parse(const uint8_t *data, size_t len, Arena *arena);
const char *jvm_utf8(JvmClass *c, uint16_t idx);
const char *jvm_class_name(JvmClass *c, uint16_t class_idx);
const char *jvm_ref_name(JvmClass *c, uint16_t ref_idx);

/* Renders a method body as JVM bytecode listing. */
void jvm_disassemble(JvmClass *c, JvmMethod *m, Buf *out, int indent);

/* Renders the whole class as Java-like source. Returns 0 on success. */
int jvm_decompile(JvmClass *c, Buf *out);

#endif
