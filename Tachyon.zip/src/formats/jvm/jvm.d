src/formats/jvm/jvm.o: src/formats/jvm/jvm.c src/formats/jvm/jvm.h \
 src/common/arena.h src/common/buf.h

src/formats/jvm/jvm.h:

src/common/arena.h:

src/common/buf.h:
