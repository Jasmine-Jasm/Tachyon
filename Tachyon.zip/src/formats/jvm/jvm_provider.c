#include "formats/provider.h"
#include "formats/jvm/jvm.h"

#include <stdio.h>
#include <string.h>

static int jvm_probe(const uint8_t *data, size_t len)
{
    if (len < 10)
        return 0;
    if (data[0] != 0xca || data[1] != 0xfe || data[2] != 0xba || data[3] != 0xbe)
        return 0;
    /* Major version sanity keeps random data from scoring high. */
    uint16_t major = (uint16_t)((data[6] << 8) | data[7]);
    if (major < 45 || major > 100)
        return 3;
    return 9;
}

/* Converts a JVM descriptor ("Ljava/lang/String;") to a Java type name. */
static const char *jtype(const char *desc, char *buf, size_t cap)
{
    int dims = 0;
    while (desc[dims] == '[')
        dims++;
    const char *b = desc + dims;
    const char *prim = NULL;
    switch (b[0]) {
    case 'V': prim = "void"; break;
    case 'Z': prim = "boolean"; break;
    case 'B': prim = "byte"; break;
    case 'S': prim = "short"; break;
    case 'C': prim = "char"; break;
    case 'I': prim = "int"; break;
    case 'J': prim = "long"; break;
    case 'F': prim = "float"; break;
    case 'D': prim = "double"; break;
    default: break;
    }

    char body[384];
    size_t o = 0;
    if (prim && !b[1]) {
        snprintf(body, sizeof(body), "%s", prim);
    } else if (b[0] == 'L') {
        const char *end = strrchr(b, ';');
        size_t n = end ? (size_t)(end - b - 1) : strlen(b + 1);
        if (n >= sizeof(body))
            n = sizeof(body) - 1;
        for (size_t i = 0; i < n; i++)
            body[o++] = b[i + 1] == '/' ? '.' : b[i + 1];
        body[o] = '\0';
    } else {
        snprintf(body, sizeof(body), "Object");
    }

    size_t len = strlen(body);
    for (int i = 0; i < dims && len + 2 < cap; i++) {
        body[len++] = '[';
        body[len++] = ']';
        body[len] = '\0';
    }
    snprintf(buf, cap, "%s", body);
    return buf;
}

/* Splits a method descriptor into its parameter descriptors. */
static int split_params(const char *desc, char out[][256], int max)
{
    int n = 0;
    const char *p = desc;
    if (*p != '(')
        return 0;
    p++;
    while (*p && *p != ')' && n < max) {
        const char *start = p;
        while (*p == '[')
            p++;
        if (*p == 'L') {
            while (*p && *p != ';')
                p++;
            if (*p)
                p++;
        } else if (*p) {
            p++;
        }
        size_t len = (size_t)(p - start);
        if (len >= 256)
            len = 255;
        memcpy(out[n], start, len);
        out[n][len] = '\0';
        n++;
    }
    return n;
}

static void access_str(uint16_t f, int is_method, int is_interface, char *buf, size_t cap)
{
    size_t o = 0;
    buf[0] = '\0';
#define ADD(w)                                                                     \
    do {                                                                           \
        size_t l = strlen(w);                                                      \
        if (o + l + 1 < cap) {                                                     \
            memcpy(buf + o, w, l);                                                 \
            o += l;                                                                \
            buf[o++] = ' ';                                                        \
            buf[o] = '\0';                                                         \
        }                                                                          \
    } while (0)

    if (f & 0x0001) ADD("public");
    if (f & 0x0002) ADD("private");
    if (f & 0x0004) ADD("protected");
    if (f & 0x0008) ADD("static");
    if (f & 0x0010) ADD("final");
    if ((f & 0x0020) && is_method && !is_interface) ADD("synchronized");
    if ((f & 0x0040) && !is_method) ADD("volatile");
    if ((f & 0x0080) && !is_method) ADD("transient");
    if ((f & 0x0100) && is_method) ADD("native");
    if ((f & 0x0400) && is_method && !is_interface) ADD("abstract");
    if ((f & 0x0800) && is_method) ADD("strictfp");
#undef ADD
}

static int jvm_describe(FormatCtx *ctx)
{
    JvmClass *c = jvm_parse(ctx->data, ctx->len, ctx->arena);
    if (!c) {
        buf_puts(ctx->out, "error: not a valid class file\n");
        return -1;
    }

    char name[512];
    snprintf(name, sizeof(name), "%s", jvm_class_name(c, c->this_class));
    for (char *p = name; *p; p++)
        if (*p == '/')
            *p = '.';

    buf_printf(ctx->out, "class      : %s\n", name);
    buf_printf(ctx->out, "version    : %u.%u (major %u)\n", c->major, c->minor, c->major);
    buf_printf(ctx->out, "constant   : %u entries\n", c->cp_count);
    buf_printf(ctx->out, "super      : %s\n", jvm_class_name(c, c->super_class));
    buf_printf(ctx->out, "interfaces : %u\n", c->interface_count);
    buf_printf(ctx->out, "fields     : %u\n", c->field_count);
    buf_printf(ctx->out, "methods    : %u\n", c->method_count);
    if (c->source_file)
        buf_printf(ctx->out, "source     : %s\n", c->source_file);

    uint32_t with_code = 0;
    for (uint16_t i = 0; i < c->method_count; i++)
        if (c->methods[i].code)
            with_code++;
    buf_printf(ctx->out, "with code  : %u\n", with_code);
    return 0;
}

static int jvm_disassemble_all(FormatCtx *ctx)
{
    JvmClass *c = jvm_parse(ctx->data, ctx->len, ctx->arena);
    if (!c)
        return -1;

    char cls[512];
    snprintf(cls, sizeof(cls), "%s", jvm_class_name(c, c->this_class));
    for (char *p = cls; *p; p++)
        if (*p == '/')
            *p = '.';

    uint32_t emitted = 0;
    for (uint16_t i = 0; i < c->method_count; i++) {
        JvmMethod *m = &c->methods[i];
        if (!m->code)
            continue;
        if (ctx->opt.limit && emitted >= (uint32_t)ctx->opt.limit)
            break;

        const char *d = jvm_utf8(c, m->desc_idx);
        char params[64][256];
        int np = split_params(d, params, 64);
        const char *close = strrchr(d, ')');
        char ret[256];
        jtype(close ? close + 1 : "V", ret, sizeof(ret));

        /* Render the full signature so the listing is self-explanatory. */
        char sig[1024];
        size_t so = 0;
        for (int k = 0; k < np && so + 260 < sizeof(sig); k++) {
            char pt[256];
            jtype(params[k], pt, sizeof(pt));
            so += (size_t)snprintf(sig + so, sizeof(sig) - so, "%s%s", k ? ", " : "", pt);
        }
        sig[so] = '\0';

        buf_printf(ctx->out, "\n%s.%s(%s) %s (max_stack=%u, max_locals=%u)\n", cls,
                       jvm_utf8(c, m->name_idx), sig, ret, m->code->max_stack,
                       m->code->max_locals);
        jvm_disassemble(c, m, ctx->out, 2);
        emitted++;
    }
    return 0;
}

static int jvm_decompile_all(FormatCtx *ctx)
{
    JvmClass *c = jvm_parse(ctx->data, ctx->len, ctx->arena);
    if (!c)
        return -1;

    char fq[512];
    snprintf(fq, sizeof(fq), "%s", jvm_class_name(c, c->this_class));
    for (char *p = fq; *p; p++)
        if (*p == '/')
            *p = '.';

    /* package + simple name */
    char pkg[512] = "";
    const char *simple = fq;
    char *dot = strrchr(fq, '.');
    if (dot) {
        size_t n = (size_t)(dot - fq);
        memcpy(pkg, fq, n);
        pkg[n] = '\0';
        simple = dot + 1;
    }
    if (pkg[0])
        buf_printf(ctx->out, "package %s;\n\n", pkg);

    int is_iface = (c->access_flags & 0x0200) != 0;
    char acc[128];
    uint16_t cls_acc = c->access_flags & (uint16_t)~(0x0200 | 0x2000 | 0x4000 | 0x1000);
    access_str(cls_acc, 0, 0, acc, sizeof(acc));
    buf_printf(ctx->out, "%s%s %s", acc, is_iface ? "interface" : "class", simple);

    const char *sup = jvm_class_name(c, c->super_class);
    if (!is_iface && sup && strcmp(sup, "java/lang/Object")) {
        char sb[256];
        jtype(sup[0] == 'L' ? sup : "Ljava/lang/Object;", sb, sizeof(sb));
        /* jvm_class_name returns "java/lang/Object"; wrap to reuse jtype */
        char wrapped[300];
        snprintf(wrapped, sizeof(wrapped), "L%s;", sup);
        jtype(wrapped, sb, sizeof(sb));
        buf_printf(ctx->out, " extends %s", sb);
    }

    if (c->interface_count) {
        buf_printf(ctx->out, is_iface ? " extends " : " implements ");
        for (uint16_t i = 0; i < c->interface_count; i++) {
            char wrapped[300], ib[256];
            snprintf(wrapped, sizeof(wrapped), "L%s;", jvm_class_name(c, c->interfaces[i]));
            jtype(wrapped, ib, sizeof(ib));
            buf_printf(ctx->out, "%s%s", i ? ", " : "", ib);
        }
    }
    buf_puts(ctx->out, " {\n");

    for (uint16_t i = 0; i < c->field_count; i++) {
        JvmMember *f = &c->fields[i];
        char t[256], a[128];
        uint16_t fa = f->access_flags;
        if (is_iface)
            fa |= 0x0019;
        access_str(fa, 0, is_iface, a, sizeof(a));
        jtype(jvm_utf8(c, f->desc_idx), t, sizeof(t));
        buf_printf(ctx->out, "    %s%s %s", a, t, jvm_utf8(c, f->name_idx));
        /* A final field needs an initializer to compile. */
        if (fa & 0x0010)
            buf_printf(ctx->out, " = %s",
                           !strcmp(t, "boolean") ? "false"
                           : (!strcmp(t, "int") || !strcmp(t, "byte") || !strcmp(t, "short") ||
                              !strcmp(t, "char"))
                               ? "0"
                           : !strcmp(t, "long") ? "0L"
                           : !strcmp(t, "float") ? "0.0f"
                           : !strcmp(t, "double") ? "0.0"
                                                  : "null");
        buf_puts(ctx->out, ";\n");
    }
    if (c->field_count && c->method_count)
        buf_putc(ctx->out, '\n');

    for (uint16_t i = 0; i < c->method_count; i++) {
        JvmMethod *m = &c->methods[i];
        const char *name = jvm_utf8(c, m->name_idx);
        const char *desc = jvm_utf8(c, m->desc_idx);

        char params[64][256];
        int np = split_params(desc, params, 64);
        const char *close = strrchr(desc, ')');
        char ret[256];
        jtype(close ? close + 1 : "V", ret, sizeof(ret));

        int is_ctor = !strcmp(name, "<init>");
        int is_clinit = !strcmp(name, "<clinit>");
        if (is_clinit) {
            buf_puts(ctx->out, "    static {\n    }\n");
            continue;
        }

        char a[128];
        uint16_t fa = m->access_flags;
        if (is_iface)
            fa &= (uint16_t)~0x0400;
        access_str(fa, 1, is_iface, a, sizeof(a));

        buf_printf(ctx->out, "    %s", a);
        if (is_ctor) {
            buf_printf(ctx->out, "%s(", simple);
        } else {
            buf_printf(ctx->out, "%s %s(", ret, name);
        }
        for (int k = 0; k < np; k++) {
            char pt[256];
            jtype(params[k], pt, sizeof(pt));
            buf_printf(ctx->out, "%sp%d", k ? ", " : "", k);
            (void)pt;
        }
        buf_puts(ctx->out, ")");

        if ((fa & 0x0400) || (fa & 0x0100) || (is_iface && !(fa & 0x0008))) {
            buf_puts(ctx->out, ";\n");
            continue;
        }

        buf_puts(ctx->out, " {\n");
        if (is_ctor)
            buf_puts(ctx->out, "        super();\n");
        else if (strcmp(ret, "void"))
            buf_printf(ctx->out, "        return %s;\n",
                           !strcmp(ret, "boolean") ? "false"
                           : (!strcmp(ret, "int") || !strcmp(ret, "byte") ||
                              !strcmp(ret, "short") || !strcmp(ret, "char"))
                               ? "0"
                           : !strcmp(ret, "long") ? "0L"
                           : !strcmp(ret, "float") ? "0.0f"
                           : !strcmp(ret, "double") ? "0.0"
                                                  : "null");
        else if (m->code)
            buf_puts(ctx->out, "        throw new RuntimeException(\"rea: body not decompiled\");\n");
        buf_puts(ctx->out, "    }\n");
    }

    buf_puts(ctx->out, "}\n");
    return 0;
}

const Formatter formatter_jvm = {
    .name = "jvm",
    .description = "JVM class file (Java bytecode)",
    .probe = jvm_probe,
    .describe = jvm_describe,
    .disassemble = jvm_disassemble_all,
    .decompile = jvm_decompile_all,
    .extract = NULL,
};
