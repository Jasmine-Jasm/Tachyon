#include "formats/jvm/jvm.h"

#include <stdio.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/* bounds-checked readers                                             */
/* ------------------------------------------------------------------ */

typedef struct {
    const uint8_t *p;
    size_t len;
    size_t pos;
    int bad;
} Rd;

static int need(Rd *r, size_t n)
{
    if (r->bad)
        return 0;
    if (r->pos > r->len || n > r->len - r->pos) {
        r->bad = 1;
        return 0;
    }
    return 1;
}

static uint8_t u1(Rd *r)
{
    if (!need(r, 1))
        return 0;
    return r->p[r->pos++];
}

static uint16_t u2(Rd *r)
{
    if (!need(r, 2))
        return 0;
    uint16_t v = (uint16_t)((r->p[r->pos] << 8) | r->p[r->pos + 1]);
    r->pos += 2;
    return v;
}

static uint32_t u4(Rd *r)
{
    if (!need(r, 4))
        return 0;
    uint32_t v = ((uint32_t)r->p[r->pos] << 24) | ((uint32_t)r->p[r->pos + 1] << 16) |
                 ((uint32_t)r->p[r->pos + 2] << 8) | (uint32_t)r->p[r->pos + 3];
    r->pos += 4;
    return v;
}

static void skip(Rd *r, size_t n)
{
    if (need(r, n))
        r->pos += n;
}

/* Skips an attribute body given its length. */
static void skip_attr(Rd *r, uint32_t len)
{
    skip(r, len);
}

/* ------------------------------------------------------------------ */
/* constant pool                                                      */
/* ------------------------------------------------------------------ */

static void parse_cp(Rd *r, JvmClass *c, Arena *a)
{
    c->cp_count = u2(r);
    if (r->bad || c->cp_count == 0)
        return;

    c->cp = arena_zalloc(a, (size_t)c->cp_count * sizeof(JvmCp));
    if (!c->cp) {
        r->bad = 1;
        return;
    }

    for (uint16_t i = 1; i < c->cp_count && !r->bad; i++) {
        JvmCp *e = &c->cp[i];
        e->tag = u1(r);
        switch (e->tag) {
        case JVM_UTF8: {
            uint16_t n = u2(r);
            if (!need(r, n))
                return;
            /* Modified UTF-8: NUL is encoded as C0 80, and supplementary
             * characters as a surrogate pair of 3-byte sequences. Decode to
             * plain UTF-8 so callers see ordinary strings. */
            char *s = arena_alloc(a, (size_t)n * 3 + 1);
            if (!s) {
                r->bad = 1;
                return;
            }
            size_t o = 0;
            for (uint16_t k = 0; k < n;) {
                uint8_t b = r->p[r->pos + k];
                if (b < 0x80) {
                    s[o++] = (char)b;
                    k++;
                } else if ((b & 0xe0) == 0xc0 && k + 1 < n) {
                    uint32_t cp = ((uint32_t)(b & 0x1f) << 6) |
                                  (r->p[r->pos + k + 1] & 0x3f);
                    s[o++] = (char)cp;
                    k += 2;
                } else if ((b & 0xf0) == 0xe0 && k + 2 < n) {
                    uint32_t cp = ((uint32_t)(b & 0x0f) << 12) |
                                  ((uint32_t)(r->p[r->pos + k + 1] & 0x3f) << 6) |
                                  (r->p[r->pos + k + 2] & 0x3f);
                    /* Surrogate pair: combine into a single code point. */
                    if (cp >= 0xd800 && cp <= 0xdbff && k + 5 < n &&
                        (r->p[r->pos + k + 3] & 0xf0) == 0xe0) {
                        uint32_t lo = ((uint32_t)(r->p[r->pos + k + 3] & 0x0f) << 12) |
                                      ((uint32_t)(r->p[r->pos + k + 4] & 0x3f) << 6) |
                                      (r->p[r->pos + k + 5] & 0x3f);
                        if (lo >= 0xdc00 && lo <= 0xdfff) {
                            cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
                            k += 6;
                        } else {
                            k += 3;
                        }
                    } else {
                        k += 3;
                    }
                    if (cp < 0x800) {
                        s[o++] = (char)(0xc0 | (cp >> 6));
                        s[o++] = (char)(0x80 | (cp & 0x3f));
                    } else if (cp < 0x10000) {
                        s[o++] = (char)(0xe0 | (cp >> 12));
                        s[o++] = (char)(0x80 | ((cp >> 6) & 0x3f));
                        s[o++] = (char)(0x80 | (cp & 0x3f));
                    } else {
                        s[o++] = (char)(0xf0 | (cp >> 18));
                        s[o++] = (char)(0x80 | ((cp >> 12) & 0x3f));
                        s[o++] = (char)(0x80 | ((cp >> 6) & 0x3f));
                        s[o++] = (char)(0x80 | (cp & 0x3f));
                    }
                } else {
                    s[o++] = '?';
                    k++;
                }
            }
            s[o] = '\0';
            e->utf8 = s;
            r->pos += n;
            break;
        }
        case JVM_INT:
            e->number = (int32_t)u4(r);
            break;
        case JVM_FLOAT: {
            uint32_t bits = u4(r);
            float f;
            memcpy(&f, &bits, 4);
            e->fnumber = f;
            break;
        }
        case JVM_LONG:
            e->number = (int64_t)(((uint64_t)u4(r) << 32) | u4(r));
            i++; /* long occupies two slots */
            break;
        case JVM_DOUBLE: {
            uint64_t hi = u4(r), lo = u4(r);
            uint64_t bits = (hi << 32) | lo;
            double d;
            memcpy(&d, &bits, 8);
            e->fnumber = d;
            i++;
            break;
        }
        case JVM_CLASS:
        case JVM_STRING:
        case JVM_METHOD_TYPE:
        case JVM_MODULE:
        case JVM_PACKAGE:
            e->a = u2(r);
            break;
        case JVM_FIELDREF:
        case JVM_METHODREF:
        case JVM_INTERFACE_METHODREF:
        case JVM_NAME_AND_TYPE:
        case JVM_DYNAMIC:
        case JVM_INVOKE_DYNAMIC:
            e->a = u2(r);
            e->b = u2(r);
            break;
        case JVM_METHOD_HANDLE:
            e->a = u1(r);
            e->b = u2(r);
            break;
        default:
            /* Unknown tag: the pool cannot be parsed further. */
            r->bad = 1;
            return;
        }
    }
}

const char *jvm_utf8(JvmClass *c, uint16_t idx)
{
    if (!c->cp || idx == 0 || idx >= c->cp_count)
        return "";
    if (c->cp[idx].tag != JVM_UTF8)
        return "";
    return c->cp[idx].utf8 ? c->cp[idx].utf8 : "";
}

const char *jvm_class_name(JvmClass *c, uint16_t class_idx)
{
    if (!c->cp || class_idx == 0 || class_idx >= c->cp_count)
        return "";
    if (c->cp[class_idx].tag != JVM_CLASS)
        return "";
    return jvm_utf8(c, c->cp[class_idx].a);
}

const char *jvm_ref_name(JvmClass *c, uint16_t ref_idx)
{
    if (!c->cp || ref_idx == 0 || ref_idx >= c->cp_count)
        return "";
    const JvmCp *e = &c->cp[ref_idx];
    if (e->tag != JVM_FIELDREF && e->tag != JVM_METHODREF &&
        e->tag != JVM_INTERFACE_METHODREF)
        return "";
    const char *cls = jvm_class_name(c, e->a);
    const char *name = "";
    if (e->b && e->b < c->cp_count && c->cp[e->b].tag == JVM_NAME_AND_TYPE)
        name = jvm_utf8(c, c->cp[e->b].a);
    static _Thread_local char buf[512];
    snprintf(buf, sizeof(buf), "%s.%s", cls, name);
    return buf;
}

/* ------------------------------------------------------------------ */
/* attributes                                                         */
/* ------------------------------------------------------------------ */

static void parse_code_attr(Rd *r, JvmClass *c, JvmMethod *m, uint32_t len, Arena *a)
{
    size_t end = r->pos + len;
    JvmCode *code = arena_zalloc(a, sizeof(*code));
    if (!code) {
        r->bad = 1;
        return;
    }
    code->max_stack = u2(r);
    code->max_locals = u2(r);
    code->code_len = u4(r);
    if (!need(r, code->code_len)) {
        r->bad = 1;
        return;
    }
    code->code = r->p + r->pos;
    r->pos += code->code_len;

    code->exception_count = u2(r);
    if (code->exception_count && need(r, (size_t)code->exception_count * 8)) {
        code->exceptions = arena_zalloc(a, (size_t)code->exception_count * sizeof(JvmExc));
        if (code->exceptions) {
            for (uint16_t i = 0; i < code->exception_count; i++) {
                code->exceptions[i].start_pc = u2(r);
                code->exceptions[i].end_pc = u2(r);
                code->exceptions[i].handler_pc = u2(r);
                code->exceptions[i].catch_type = u2(r);
            }
        }
    } else if (code->exception_count) {
        r->bad = 1;
        return;
    }

    /* Nested attributes of Code (LineNumberTable, LocalVariableTable, ...). The
     * debug tables are not needed for disassembly, so they are skipped. */
    uint16_t nested = u2(r);
    for (uint16_t i = 0; i < nested && !r->bad; i++) {
        u2(r);              /* name index */
        uint32_t nlen = u4(r);
        skip_attr(r, nlen);
    }

    m->code = code;
    if (r->pos > end)
        r->bad = 1;
    else
        r->pos = end;
}

static void parse_member_attrs(Rd *r, JvmClass *c, JvmMethod *m, Arena *a)
{
    uint16_t count = u2(r);
    for (uint16_t i = 0; i < count && !r->bad; i++) {
        uint16_t name_idx = u2(r);
        uint32_t len = u4(r);
        const char *name = jvm_utf8(c, name_idx);
        if (!strcmp(name, "Code") && m) {
            parse_code_attr(r, c, m, len, a);
        } else {
            skip_attr(r, len);
        }
    }
}

/* ------------------------------------------------------------------ */
/* class                                                              */
/* ------------------------------------------------------------------ */

JvmClass *jvm_parse(const uint8_t *data, size_t len, Arena *arena)
{
    if (!data || len < 10)
        return NULL;
    if (((uint32_t)data[0] << 24 | (uint32_t)data[1] << 16 | (uint32_t)data[2] << 8 |
         (uint32_t)data[3]) != JVM_MAGIC)
        return NULL;

    Rd r = { data, len, 4, 0 };
    JvmClass *c = arena_zalloc(arena, sizeof(*c));
    if (!c)
        return NULL;
    c->arena = arena;
    c->minor = u2(&r);
    c->major = u2(&r);
    if (r.bad)
        return NULL;

    parse_cp(&r, c, arena);
    if (r.bad)
        return NULL;

    c->access_flags = u2(&r);
    c->this_class = u2(&r);
    c->super_class = u2(&r);

    c->interface_count = u2(&r);
    if (c->interface_count && need(&r, (size_t)c->interface_count * 2)) {
        c->interfaces = arena_zalloc(arena, (size_t)c->interface_count * sizeof(uint16_t));
        for (uint16_t i = 0; i < c->interface_count; i++)
            c->interfaces[i] = u2(&r);
    }
    if (r.bad)
        return NULL;

    c->field_count = u2(&r);
    if (c->field_count && need(&r, (size_t)c->field_count * 6)) {
        c->fields = arena_zalloc(arena, (size_t)c->field_count * sizeof(JvmMember));
        for (uint16_t i = 0; i < c->field_count && !r.bad; i++) {
            c->fields[i].access_flags = u2(&r);
            c->fields[i].name_idx = u2(&r);
            c->fields[i].desc_idx = u2(&r);
            parse_member_attrs(&r, c, NULL, arena);
        }
    }
    if (r.bad)
        return NULL;

    c->method_count = u2(&r);
    if (c->method_count && need(&r, (size_t)c->method_count * 6)) {
        c->methods = arena_zalloc(arena, (size_t)c->method_count * sizeof(JvmMethod));
        for (uint16_t i = 0; i < c->method_count && !r.bad; i++) {
            c->methods[i].access_flags = u2(&r);
            c->methods[i].name_idx = u2(&r);
            c->methods[i].desc_idx = u2(&r);
            parse_member_attrs(&r, c, &c->methods[i], arena);
        }
    }
    if (r.bad)
        return NULL;

    uint16_t attr_count = u2(&r);
    for (uint16_t i = 0; i < attr_count && !r.bad; i++) {
        uint16_t name_idx = u2(&r);
        uint32_t alen = u4(&r);
        const char *name = jvm_utf8(c, name_idx);
        if (!strcmp(name, "SourceFile") && alen == 2) {
            c->source_file = jvm_utf8(c, u2(&r));
        } else {
            skip_attr(&r, alen);
        }
    }

    return c;
}
