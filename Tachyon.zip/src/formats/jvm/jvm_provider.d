src/formats/jvm/jvm_provider.o: src/formats/jvm/jvm_provider.c \
 src/formats/provider.h src/common/arena.h src/common/buf.h \
 src/formats/jvm/jvm.h

src/formats/provider.h:

src/common/arena.h:

src/common/buf.h:

src/formats/jvm/jvm.h:
