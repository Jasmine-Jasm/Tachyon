src/formats/pyc/pyc_provider.o: src/formats/pyc/pyc_provider.c \
 src/formats/provider.h src/common/arena.h src/common/buf.h \
 src/formats/pyc/pyc.h

src/formats/provider.h:

src/common/arena.h:

src/common/buf.h:

src/formats/pyc/pyc.h:
