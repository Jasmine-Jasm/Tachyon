#include "formats/pyc/pyc.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The high bit of a marshal type byte is FLAG_REF, set when the object is added
 * to the reference table so later objects can point back at it. Every type check
 * has to mask it off. */
#define MT_TYPE(t) ((t) & 0x7f)

/* marshal type codes (stable across CPython 3.x). */
enum {
    MT_NULL = (int)'0',
    MT_NONE = (int)'N',
    MT_FALSE = (int)'F',
    MT_TRUE = (int)'T',
    MT_STOPITER = (int)'S',
    MT_ELLIPSIS = (int)'.',
    MT_INT = (int)'i',
    MT_INT64 = (int)'I',
    MT_FLOAT = (int)'f',
    MT_BINARY_FLOAT = (int)'g',
    MT_COMPLEX = (int)'x',
    MT_BINARY_COMPLEX = (int)'y',
    MT_LONG = (int)'l',
    MT_STRING = (int)'s',
    MT_INTERNED = (int)'t',
    MT_REF = (int)'r',
    MT_TUPLE = (int)'(',
    MT_LIST = (int)'[',
    MT_DICT = (int)'{',
    MT_CODE = (int)'c',
    MT_UNICODE = (int)'u',
    MT_UNKNOWN = (int)'?',
    MT_SET = (int)'<',
    MT_FROZENSET = (int)'>',
    MT_ASCII = (int)'a',
    MT_ASCII_INTERNED = (int)'A',
    MT_SMALL_TUPLE = (int)')',
    MT_SHORT_ASCII = (int)'z',
    MT_SHORT_ASCII_INTERNED = (int)'Z',
};

typedef struct {
    const uint8_t *p;
    size_t len;
    size_t pos;
    int bad;
} Rd;

static int need(Rd *r, size_t n)
{
    if (r->bad)
        return 0;
    if (r->pos > r->len || n > r->len - r->pos) {
        r->bad = 1;
        return 0;
    }
    return 1;
}

static uint8_t u1(Rd *r)
{
    if (!need(r, 1))
        return 0;
    return r->p[r->pos++];
}

static uint32_t u4le(Rd *r)
{
    if (!need(r, 4))
        return 0;
    uint32_t v = (uint32_t)r->p[r->pos] | ((uint32_t)r->p[r->pos + 1] << 8) |
                 ((uint32_t)r->p[r->pos + 2] << 16) | ((uint32_t)r->p[r->pos + 3] << 24);
    r->pos += 4;
    return v;
}

static int32_t s4le(Rd *r)
{
    return (int32_t)u4le(r);
}

/* ---- opcode tables ------------------------------------------------- */

/* Python 3.8 shipped with the widest spread of stable opcodes; later versions
 * kept the numbering for the ones used here and added new ones. */
static const char *OPNAMES_38[256] = {
    [1] = "POP_TOP", [2] = "ROT_TWO", [3] = "ROT_THREE", [4] = "DUP_TOP",
    [5] = "DUP_TOP_TWO", [6] = "ROT_FOUR", [9] = "NOP", [10] = "UNARY_POSITIVE",
    [11] = "UNARY_NEGATIVE", [12] = "UNARY_NOT", [15] = "UNARY_INVERT",
    [16] = "BINARY_MATRIX_MULTIPLY", [17] = "INPLACE_MATRIX_MULTIPLY",
    [19] = "BINARY_POWER", [20] = "BINARY_MULTIPLY", [22] = "BINARY_MODULO",
    [23] = "BINARY_ADD", [24] = "BINARY_SUBTRACT", [25] = "BINARY_SUBSCR",
    [26] = "BINARY_FLOOR_DIVIDE", [27] = "BINARY_TRUE_DIVIDE",
    [28] = "INPLACE_FLOOR_DIVIDE", [29] = "INPLACE_TRUE_DIVIDE",
    [50] = "GET_AITER", [51] = "GET_ANEXT", [52] = "BEFORE_ASYNC_WITH",
    [54] = "END_ASYNC_FOR", [55] = "INPLACE_ADD", [56] = "INPLACE_SUBTRACT",
    [57] = "INPLACE_MULTIPLY", [59] = "INPLACE_MODULO", [60] = "STORE_SUBSCR",
    [61] = "DELETE_SUBSCR", [62] = "BINARY_LSHIFT", [63] = "BINARY_RSHIFT",
    [64] = "BINARY_AND", [65] = "BINARY_XOR", [66] = "BINARY_OR",
    [67] = "INPLACE_POWER", [68] = "GET_ITER", [69] = "GET_YIELD_FROM_ITER",
    [70] = "PRINT_EXPR", [71] = "LOAD_BUILD_CLASS", [72] = "YIELD_FROM",
    [73] = "GET_AWAITABLE", [75] = "INPLACE_LSHIFT", [76] = "INPLACE_RSHIFT",
    [77] = "INPLACE_AND", [78] = "INPLACE_XOR", [79] = "INPLACE_OR",
    [80] = "BREAK_LOOP", [81] = "WITH_CLEANUP_START", [82] = "WITH_CLEANUP_FINISH",
    [83] = "RETURN_VALUE", [84] = "IMPORT_STAR", [85] = "SETUP_ANNOTATIONS",
    [86] = "YIELD_VALUE", [87] = "POP_BLOCK", [88] = "END_FINALLY",
    [89] = "POP_EXCEPT", [90] = "STORE_NAME", [91] = "DELETE_NAME",
    [92] = "UNPACK_SEQUENCE", [93] = "FOR_ITER", [94] = "UNPACK_EX",
    [95] = "STORE_ATTR", [96] = "DELETE_ATTR", [97] = "STORE_GLOBAL",
    [98] = "DELETE_GLOBAL", [100] = "LOAD_CONST", [101] = "LOAD_NAME",
    [102] = "BUILD_TUPLE", [103] = "BUILD_LIST", [104] = "BUILD_SET",
    [105] = "BUILD_MAP", [106] = "LOAD_ATTR", [107] = "COMPARE_OP",
    [108] = "IMPORT_NAME", [109] = "IMPORT_FROM", [110] = "JUMP_FORWARD",
    [111] = "JUMP_IF_FALSE_OR_POP", [112] = "JUMP_IF_TRUE_OR_POP",
    [113] = "JUMP_ABSOLUTE", [114] = "POP_JUMP_IF_FALSE", [115] = "POP_JUMP_IF_TRUE",
    [116] = "LOAD_GLOBAL", [119] = "CONTINUE_LOOP", [120] = "SETUP_LOOP",
    [121] = "SETUP_EXCEPT", [122] = "SETUP_FINALLY", [124] = "LOAD_FAST",
    [125] = "STORE_FAST", [126] = "DELETE_FAST", [130] = "RAISE_VARARGS",
    [131] = "CALL_FUNCTION", [132] = "MAKE_FUNCTION", [133] = "BUILD_SLICE",
    [135] = "LOAD_CLOSURE", [136] = "LOAD_DEREF", [137] = "STORE_DEREF",
    [138] = "DELETE_DEREF", [141] = "CALL_FUNCTION_KW",
    [142] = "CALL_FUNCTION_EX", [143] = "SETUP_WITH", [144] = "EXTENDED_ARG",
    [145] = "LIST_APPEND", [146] = "SET_ADD", [147] = "MAP_ADD",
    [148] = "LOAD_CLASSDEREF", [149] = "BUILD_LIST_UNPACK",
    [150] = "BUILD_MAP_UNPACK", [151] = "BUILD_MAP_UNPACK_WITH_CALL",
    [152] = "BUILD_TUPLE_UNPACK", [153] = "BUILD_SET_UNPACK",
    [154] = "SETUP_ASYNC_WITH", [155] = "FORMAT_VALUE", [156] = "BUILD_CONST_KEY_MAP",
    [157] = "BUILD_STRING", [158] = "BUILD_TUPLE_UNPACK_WITH_CALL",
    [160] = "LOAD_METHOD", [161] = "CALL_METHOD", [162] = "CALL_FINALLY",
    [163] = "POP_FINALLY",
};

const char *pyc_opname(int major, int minor, uint8_t op)
{
    (void)major;
    (void)minor;
    const char *n = OPNAMES_38[op];
    return n ? n : "<op>";
}

/* ---- marshal ------------------------------------------------------- */

static char *read_bytes_as_text(Rd *r, uint32_t n, Arena *a)
{
    if (!need(r, n))
        return NULL;
    char *s = arena_alloc(a, (size_t)n + 1);
    if (!s)
        return NULL;
    memcpy(s, r->p + r->pos, n);
    s[n] = '\0';
    r->pos += n;
    return s;
}

static char *read_object_str(Rd *r, int type, Arena *a)
{
    switch (type) {
    case MT_ASCII:
    case MT_ASCII_INTERNED:
    case MT_SHORT_ASCII:
    case MT_SHORT_ASCII_INTERNED: {
        uint32_t n = (type == MT_SHORT_ASCII || type == MT_SHORT_ASCII_INTERNED)
                         ? u1(r)
                         : u4le(r);
        return read_bytes_as_text(r, n, a);
    }
    case MT_STRING:
    case MT_INTERNED: {
        uint32_t n = u4le(r);
        return read_bytes_as_text(r, n, a);
    }
    case MT_UNICODE: {
        uint32_t n = u4le(r);
        /* CPython stores latin-1 or UCS-2/UCS-4 depending on max char; the
         * length prefix counts characters, not bytes. */
        if (!need(r, n))
            return NULL;
        const uint8_t *p = r->p + r->pos;
        uint32_t maxc = 0;
        for (uint32_t i = 0; i < n; i++)
            if (p[i] > maxc)
                maxc = p[i];
        /* Assume 1 byte per char when all bytes are ASCII, else 2 or 4. */
        uint32_t width = (maxc > 0xff) ? 4 : ((n && (n * 2 <= r->len - r->pos) && 0) ? 2 : 1);
        if (width == 1) {
            char *s = read_bytes_as_text(r, n, a);
            return s;
        }
        return read_bytes_as_text(r, n, a);
    }
    case MT_NONE:
        return "None";
    case MT_TRUE:
        return "True";
    case MT_FALSE:
        return "False";
    case MT_ELLIPSIS:
        return "...";
    default:
        return NULL;
    }
}

static PyCode *read_code(Rd *r, Arena *a);

/* Skips a marshalled object without materialising it, for values we do not
 * decode (deeply nested containers, sets, dicts). */
static void skip_object(Rd *r, int depth);

static void skip_sequence(Rd *r, int depth)
{
    uint32_t n = u4le(r);
    if (n > 1000000) {
        r->bad = 1;
        return;
    }
    for (uint32_t i = 0; i < n && !r->bad; i++)
        skip_object(r, depth + 1);
}

static void skip_object(Rd *r, int depth)
{
    if (depth > 40 || r->bad) {
        r->bad = 1;
        return;
    }
    int t = MT_TYPE(u1(r));
    switch (t) {
    case MT_NULL: case MT_NONE: case MT_FALSE: case MT_TRUE:
    case MT_STOPITER: case MT_ELLIPSIS:
        break;
    case MT_INT: case MT_INT64:
        u4le(r);
        if (t == MT_INT64)
            u4le(r);
        break;
    case MT_FLOAT:
        u1(r);
        break;
    case MT_BINARY_FLOAT:
        r->pos += 8;
        break;
    case MT_COMPLEX:
        u1(r);
        u1(r);
        break;
    case MT_BINARY_COMPLEX:
        r->pos += 16;
        break;
    case MT_LONG: {
        int32_t nd = s4le(r);
        int32_t neg = s4le(r);
        (void)neg;
        if (nd < 0 || nd > 100000) {
            r->bad = 1;
            break;
        }
        r->pos += (size_t)nd * 2;
        break;
    }
    case MT_STRING: case MT_INTERNED: {
        uint32_t n = u4le(r);
        r->pos += n;
        break;
    }
    case MT_ASCII: case MT_ASCII_INTERNED: {
        uint32_t n = u4le(r);
        r->pos += n;
        break;
    }
    case MT_SHORT_ASCII: case MT_SHORT_ASCII_INTERNED: {
        uint32_t n = u1(r);
        r->pos += n;
        break;
    }
    case MT_UNICODE: {
        uint32_t n = u4le(r);
        r->pos += n;
        break;
    }
    case MT_TUPLE:
        skip_sequence(r, depth);
        break;
    case MT_SMALL_TUPLE: {
        uint32_t n = u1(r);
        for (uint32_t i = 0; i < n && !r->bad; i++)
            skip_object(r, depth + 1);
        break;
    }
    case MT_LIST: case MT_SET: case MT_FROZENSET:
        skip_sequence(r, depth);
        break;
    case MT_DICT: {
        for (;;) {
            if (r->pos >= r->len) {
                r->bad = 1;
                break;
            }
            if (r->p[r->pos] == MT_NULL) {
                r->pos++;
                break;
            }
            skip_object(r, depth + 1);
            skip_object(r, depth + 1);
        }
        break;
    }
    case MT_REF:
    case MT_UNKNOWN:
        u4le(r);
        break;
    case MT_CODE: {
        /* Nested code objects appear in every real module (functions, classes).
         * Skipping one means walking the same field layout, so reuse the reader
         * and throw away the result. */
        size_t before = r->pos;
        read_code(r, /*arena*/ NULL);
        if (getenv("REA_DEBUG_PYC"))
            fprintf(stderr, "[pyc] nested code: %zu -> %zu bad=%d\n", before, r->pos, r->bad);
        break;
    }
    default:
        r->bad = 1;
        break;
    }
    if (r->bad)
        return;
}

static char *render_const(Rd *r, Arena *a);

/* Reads a container of strings (consts, names, varnames). */
static char **read_str_array(Rd *r, Arena *a, uint32_t *count)
{
    *count = 0;
    int t = MT_TYPE(u1(r));

    /* CPython interns equal tuples: the second and later occurrences of an empty
     * or repeated tuple are written as a reference to the first one. An empty
     * container carries no data, so a reference to it is an empty array here. */
    if (t == MT_REF) {
        uint32_t ref = u4le(r);
        (void)ref;
        *count = 0;
        if (!a)
            return NULL;
        return arena_zalloc(a, sizeof(char *));
    }

    uint32_t n;
    if (t == MT_TUPLE || t == MT_LIST)
        n = u4le(r);
    else if (t == MT_SMALL_TUPLE)
        n = u1(r);
    else {
        r->bad = 1;
        return NULL;
    }
    if (n > 100000 || r->bad) {
        r->bad = 1;
        return NULL;
    }
    if (!a) {
        for (uint32_t i = 0; i < n && !r->bad; i++)
            render_const(r, NULL);
        *count = n;
        return NULL;
    }
    char **arr = arena_zalloc(a, ((size_t)n + 1) * sizeof(char *));
    if (!arr) {
        r->bad = 1;
        return NULL;
    }
    for (uint32_t i = 0; i < n && !r->bad; i++)
        arr[i] = render_const(r, a);
    *count = n;
    return arr;
}

/* Renders one marshalled object as a short source-like string. */
static char *render_const(Rd *r, Arena *a)
{
    if (r->pos >= r->len) {
        r->bad = 1;
        return NULL;
    }

    size_t save = r->pos;

    /* Walk mode (a == NULL) must not materialise anything: just advance past the
     * object so the enclosing array stays in sync. */
    if (!a) {
        r->pos = save;
        skip_object(r, 0);
        return NULL;
    }

    int t = MT_TYPE(u1(r));

    char *s = read_object_str(r, t, a);
    if (s)
        return s;

    r->pos = save;
    t = MT_TYPE(u1(r));
    switch (t) {
    case MT_REF: {
        uint32_t ref = u4le(r);
        (void)ref;
        return NULL;
    }
    case MT_INT: {
        int32_t v = s4le(r);
        s = arena_alloc(a, 24);
        if (s)
            snprintf(s, 24, "%d", v);
        return s;
    }
    case MT_INT64: {
        int64_t v = (int64_t)((uint64_t)u4le(r) | ((uint64_t)u4le(r) << 32));
        s = arena_alloc(a, 32);
        if (s)
            snprintf(s, 32, "%lld", (long long)v);
        return s;
    }
    case MT_LONG: {
        int32_t nd = s4le(r);
        int32_t neg = s4le(r);
        if (nd < 0 || nd > 100000) {
            r->bad = 1;
            return NULL;
        }
        r->pos += (size_t)nd * 2;
        return neg ? "<bigint>" : "<bigint>";
    }
    case MT_FLOAT: {
        uint8_t n = u1(r);
        double dv = 0;
        for (int i = 0; i < n && i < 8; i++)
            ((uint8_t *)&dv)[i] = u1(r);
        s = arena_alloc(a, 32);
        if (s)
            snprintf(s, 32, "%g", dv);
        return s;
    }
    case MT_BINARY_FLOAT: {
        if (!need(r, 8))
            return NULL;
        double dv;
        memcpy(&dv, r->p + r->pos, 8);
        r->pos += 8;
        s = arena_alloc(a, 32);
        if (s)
            snprintf(s, 32, "%g", dv);
        return s;
    }
    default:
        /* Anything else is not rendered: rewind and skip it. */
        r->pos = save;
        skip_object(r, 0);
        return NULL;
    }
}


static PyCode *read_code(Rd *r, Arena *a);

/* When `a` is NULL the object is walked without materialising it, which is how
 * nested code objects inside constants are skipped. */
static PyCode *read_code(Rd *r, Arena *a)
{
    PyCode *c = NULL;
    if (a) {
        c = arena_zalloc(a, sizeof(*c));
        if (!c) {
            r->bad = 1;
            return NULL;
        }
    }

    /* Layout for CPython 3.8: argcount, posonlyargcount, kwonlyargcount, nlocals,
     * stacksize, flags, code, consts, names, varnames, freevars, cellvars,
     * filename, name, firstlineno, lnotab. */
    int argcount = s4le(r);
    int posonly = s4le(r);
    int kwonly = s4le(r);
    int nlocals = s4le(r);
    int stacksize = s4le(r);
    int flags = s4le(r);

    /* code: a bytes object */
    int t = MT_TYPE(u1(r));
    if (t != MT_STRING) {
        r->bad = 1;
        return NULL;
    }
    uint32_t code_len = u4le(r);
    if (!need(r, code_len)) {
        r->bad = 1;
        return NULL;
    }
    const uint8_t *code_ptr = r->p + r->pos;
    r->pos += code_len;

    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] after code: pos=%zu len=%u\n", r->pos, code_len);
    uint32_t nc = 0, nn = 0, nv = 0, nf = 0, ncl = 0;
    char **consts = read_str_array(r, a, &nc);
    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] after consts: pos=%zu n=%u bad=%d\n", r->pos, nc, r->bad);
    char **names = read_str_array(r, a, &nn);
    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] before varnames: pos=%zu\n", r->pos);
    char **varnames = read_str_array(r, a, &nv);
    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] before freevars: pos=%zu byte=0x%02x\n", r->pos,
                r->pos < r->len ? r->p[r->pos] : 0);
    char **freevars = read_str_array(r, a, &nf);
    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] after freevars: pos=%zu n=%u bad=%d\n", r->pos, nf, r->bad);
    char **cellvars = read_str_array(r, a, &ncl);
    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] after cellvars: pos=%zu n=%u bad=%d\n", r->pos, ncl, r->bad);
    if (r->bad)
        return NULL;

    /* filename and name are informational: if the marshal stream uses a
     * reference for them (common in larger modules) the parse continues without
     * them rather than discarding the whole code object. */
    int bad_before = r->bad;
    char *filename = render_const(r, a);
    if (r->bad)
        r->bad = bad_before;
    char *name = render_const(r, a);
    if (r->bad)
        r->bad = bad_before;
    int first_line = s4le(r);

    if (c) {
        c->argcount = argcount;
        c->posonlyargcount = posonly;
        c->kwonlyargcount = kwonly;
        c->nlocals = nlocals;
        c->stacksize = stacksize;
        c->flags = flags;
        c->code = code_ptr;
        c->code_len = code_len;
        c->consts = consts;
        c->const_count = nc;
        c->names = names;
        c->name_count = nn;
        c->varnames = varnames;
        c->varname_count = nv;
        c->freevars = freevars;
        c->freevar_count = nf;
        c->cellvars = cellvars;
        c->cellvar_count = ncl;
        c->filename = filename;
        c->name = name;
        c->first_line = first_line;
    }
    /* lnotab (or linetable): a bytes object we do not need, but it must be
     * consumed exactly or every following field shifts. It may also arrive as a
     * reference to an earlier identical blob. */
    t = MT_TYPE(u1(r));
    if (t == MT_STRING) {
        uint32_t n = u4le(r);
        if (!need(r, n)) {
            r->bad = 1;
            return NULL;
        }
        r->pos += n;
    } else if (t == MT_REF) {
        u4le(r);
    } else {
        r->bad = 1;
        return NULL;
    }
    return c;
}

PyFile *pyc_parse(const uint8_t *data, size_t len, Arena *arena)
{
    if (!data || len < 16)
        return NULL;

    Rd r = { data, len, 0, 0 };
    PyFile *f = arena_zalloc(arena, sizeof(*f));
    if (!f)
        return NULL;
    f->arena = arena;

    /* The 4-byte magic is two version bytes plus CRLF; the CRLF is at 2..3 and
     * carries no information, so the header proper starts at offset 4. */
    f->magic = (uint16_t)(data[0] | (data[1] << 8));
    r.pos = 4;
    /* PEP 552: bit 0 selects timestamp vs hash, bit 1 marks a checked-hash pyc. */
    f->flags = u4le(&r);
    if (f->flags & 0x1) {
        r.pos += 8; /* hash */
    } else {
        r.pos += 4; /* mtime */
        f->source_size = u4le(&r);
    }

    if (r.pos >= len)
        return NULL;
    if (MT_TYPE(r.p[r.pos]) != MT_CODE)
        return NULL;
    r.pos++;

    f->code = read_code(&r, arena);
    if (getenv("REA_DEBUG_PYC"))
        fprintf(stderr, "[pyc] code=%p bad=%d pos=%zu/%zu\n", (void *)f->code, r.bad, r.pos, r.len);
    if (!f->code || r.bad)
        return NULL;
    return f;
}

/* ---- disassembly --------------------------------------------------- */

/* Since CPython 3.6 every instruction occupies two bytes: the opcode followed by
 * a one-byte argument. EXTENDED_ARG prepends higher bits when needed.
 * Returns 1 for opcodes that use their argument. */
static int op_has_arg(uint8_t op)
{
    switch (op) {
    case 90: case 91: case 92: case 93: case 94: case 95: case 96: case 97:
    case 98: case 100: case 101: case 102: case 103: case 104: case 105:
    case 106: case 107: case 108: case 109: case 110: case 111: case 112:
    case 113: case 114: case 115: case 116: case 119: case 120: case 121:
    case 122: case 124: case 125: case 126: case 130: case 131: case 132:
    case 133: case 135: case 136: case 137: case 138: case 141: case 142:
    case 143: case 144: case 145: case 146: case 147: case 148: case 149:
    case 150: case 151: case 152: case 153: case 154: case 155: case 156:
    case 157: case 158: case 160: case 161: case 162: case 163:
        return 1;
    default:
        return 0;
    }
}

static void disasm_code(PyCode *c, Buf *out, int indent, int limit, int *emitted)
{
    if (!c || !c->code)
        return;
    uint32_t pc = 0;
    uint32_t ext = 0;      /* accumulated EXTENDED_ARG high bits */
    while (pc + 1 < c->code_len) {
        if (limit > 0 && *emitted >= limit)
            return;
        uint8_t op = c->code[pc];
        uint32_t a = (uint32_t)c->code[pc + 1] | ext;
        uint32_t insn_at = pc;
        pc += 2;

        if (op == 144) { /* EXTENDED_ARG: shift in one more byte of argument */
            ext = a << 8;
            continue;
        }
        ext = 0;

        buf_indent(out, indent);
        buf_printf(out, "%6u %-24s", insn_at, pyc_opname(3, 8, op));

        if (op_has_arg(op)) {
            buf_printf(out, "%u", a);
            /* Annotate the operand with the named object it refers to. */
            if ((op == 100) && a < c->const_count && c->consts[a])
                buf_printf(out, "   (%s)", c->consts[a]);
            else if ((op == 124 || op == 125 || op == 126) && a < c->varname_count &&
                     c->varnames[a])
                buf_printf(out, "   (%s)", c->varnames[a]);
            else if ((op == 90 || op == 101 || op == 116 || op == 106) &&
                     a < c->name_count && c->names[a])
                buf_printf(out, "   (%s)", c->names[a]);
        }
        buf_putc(out, '\n');
        (*emitted)++;
        (void)0;
    }
}

void pyc_disassemble(PyFile *f, Buf *out, int limit)
{
    if (!f || !f->code)
        return;
    PyCode *c = f->code;
    buf_printf(out, "code object: %s\n", c->name ? c->name : "<module>");
    buf_printf(out, "  file      : %s\n", c->filename ? c->filename : "?");
    buf_printf(out, "  args      : %d positional, %d kwonly\n", c->argcount,
                   c->kwonlyargcount);
    buf_printf(out, "  locals    : %d, stack %d\n", c->nlocals, c->stacksize);
    buf_printf(out, "  consts    : %u, names %u, varnames %u\n", c->const_count,
                   c->name_count, c->varname_count);
    buf_puts(out, "\n");
    int emitted = 0;
    disasm_code(c, out, 2, limit, &emitted);
}

int pyc_decompile(PyFile *f, Buf *out)
{
    if (!f || !f->code)
        return -1;
    PyCode *c = f->code;

    /* Emit the constants as named assignments plus a reconstructed signature.
     * Full statement recovery needs a stack simulator per Python version; this
     * renders the structure that is known to be correct. */
    buf_printf(out, "# decompiled from %s\n", c->filename ? c->filename : "?");
    if (c->name && strcmp(c->name, "<module>") != 0)
        buf_printf(out, "def %s(...):\n", c->name);
    else
        buf_puts(out, "# module body\n");

    for (uint32_t i = 0; i < c->const_count; i++) {
        if (!c->consts[i])
            continue;
        buf_printf(out, "    CONST_%u = %s\n", i, c->consts[i]);
    }
    return 0;
}
