#ifndef REA_PYC_H
#define REA_PYC_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "common/buf.h"

/* A CPython code object as it appears inside marshalled data. Only the fields
 * needed for analysis are kept. */
typedef struct {
    const char *name;
    const char *qualname;
    const char *filename;
    int first_line;
    int argcount;
    int posonlyargcount;
    int kwonlyargcount;
    int nlocals;
    int stacksize;
    int flags;
    const uint8_t *code;
    uint32_t code_len;

    /* consts and names are rendered lazily into strings. */
    char **consts;
    uint32_t const_count;
    char **names;
    uint32_t name_count;
    char **varnames;
    uint32_t varname_count;
    char **freevars;
    uint32_t freevar_count;
    char **cellvars;
    uint32_t cellvar_count;
} PyCode;

typedef struct {
    uint16_t magic;
    uint32_t flags;
    uint32_t source_size;
    PyCode *code;
    Arena *arena;
} PyFile;

/* Parses a .pyc. Returns NULL for unsupported versions or malformed data. */
PyFile *pyc_parse(const uint8_t *data, size_t len, Arena *arena);

/* Disassembles the code object into `out`. */
void pyc_disassemble(PyFile *f, Buf *out, int limit);

/* Renders a Python-like source reconstruction. */
int pyc_decompile(PyFile *f, Buf *out);

/* Human-readable bytecode name for an opcode at the given Python version. */
const char *pyc_opname(int major, int minor, uint8_t op);

#endif
