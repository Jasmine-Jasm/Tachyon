#include "formats/provider.h"
#include "formats/pyc/pyc.h"

#include <stdio.h>
#include <string.h>

/* CPython writes a 4-byte magic whose first two bytes vary per version and whose
 * last two are always CR/LF. That plus a plausible flags field is enough to
 * separate a .pyc from arbitrary binary data. */
static int pyc_probe(const uint8_t *data, size_t len)
{
    if (len < 16)
        return 0;
    if (data[2] != '\r' || data[3] != '\n')
        return 0;
    /* Python 3.0-3.13 magic numbers start with 0x0d0a in the low half. */
    uint16_t magic = (uint16_t)(data[0] | (data[1] << 8));
    if (magic < 3000 || magic > 3600)
        return 0;
    uint32_t flags = (uint32_t)data[4] | ((uint32_t)data[5] << 8) |
                     ((uint32_t)data[6] << 16) | ((uint32_t)data[7] << 24);
    if (flags & ~0x3u)
        return 4;
    return 9;
}

static int pyc_describe(FormatCtx *ctx)
{
    PyFile *f = pyc_parse(ctx->data, ctx->len, ctx->arena);
    if (!f) {
        buf_puts(ctx->out,
                     "error: could not decode this pyc\n"
                     "  CPython's marshal format changes between minor versions,\n"
                     "  and this parser targets the 3.8 layout. Report the version:\n");
        if (ctx->len >= 4)
            buf_printf(ctx->out, "  magic bytes: %02x %02x %02x %02x\n", ctx->data[0],
                           ctx->data[1], ctx->data[2], ctx->data[3]);
        return -1;
    }
    buf_printf(ctx->out, "format     : CPython bytecode (magic 0x%04x)\n", f->magic);
    buf_printf(ctx->out, "flags      : 0x%x (%s)\n", f->flags,
                   (f->flags & 1) ? "hash-based" : "timestamp-based");
    buf_printf(ctx->out, "source size: %u\n", f->source_size);
    if (f->code) {
        buf_printf(ctx->out, "module     : %s\n", f->code->filename ? f->code->filename : "?");
        buf_printf(ctx->out, "code bytes : %u\n", f->code->code_len);
        buf_printf(ctx->out, "consts     : %u\n", f->code->const_count);
        buf_printf(ctx->out, "names      : %u\n", f->code->name_count);
        buf_printf(ctx->out, "varnames   : %u\n", f->code->varname_count);
    }
    return 0;
}

static int pyc_disasm(FormatCtx *ctx)
{
    PyFile *f = pyc_parse(ctx->data, ctx->len, ctx->arena);
    if (!f)
        return -1;
    pyc_disassemble(f, ctx->out, ctx->opt.limit);
    return 0;
}

static int pyc_decomp(FormatCtx *ctx)
{
    PyFile *f = pyc_parse(ctx->data, ctx->len, ctx->arena);
    if (!f)
        return -1;
    return pyc_decompile(f, ctx->out);
}

const Formatter formatter_pyc = {
    .name = "pyc",
    .description = "CPython bytecode (.pyc)",
    .probe = pyc_probe,
    .describe = pyc_describe,
    .disassemble = pyc_disasm,
    .decompile = pyc_decomp,
    .extract = NULL,
};
