src/formats/pyc/pyc.o: src/formats/pyc/pyc.c src/formats/pyc/pyc.h \
 src/common/arena.h src/common/buf.h

src/formats/pyc/pyc.h:

src/common/arena.h:

src/common/buf.h:
