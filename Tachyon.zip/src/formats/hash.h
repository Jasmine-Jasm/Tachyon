#ifndef REA_HASH_H
#define REA_HASH_H

#include <stddef.h>
#include <stdint.h>

/* CRC-32 (IEEE 802.3), used by ZIP entries. */
uint32_t rea_crc32(const void *data, size_t len);

/* SHA-256. digest must hold 32 bytes. */
void rea_sha256(const void *data, size_t len, uint8_t digest[32]);

/* Writes the lowercase hex form of a 32-byte digest (65 bytes incl. NUL). */
void rea_hex32(const uint8_t digest[32], char out[65]);

/* Shannon entropy of a byte buffer, in bits per byte (0.0 - 8.0). */
double rea_entropy(const uint8_t *data, size_t len);

#endif
