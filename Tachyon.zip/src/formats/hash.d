src/formats/hash.o: src/formats/hash.c src/formats/hash.h

src/formats/hash.h:
