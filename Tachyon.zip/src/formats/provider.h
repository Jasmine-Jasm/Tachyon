#ifndef REA_PROVIDER_H
#define REA_PROVIDER_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "common/buf.h"

/* Output verbosity and feature switches shared by every provider. */
typedef struct {
    int verbose;
    int json;          /* emit machine-readable output where supported */
    int depth;         /* recursion depth for container formats */
    int limit;         /* max items to emit; 0 = no limit */
    const char *outdir;
} FormatOptions;

/* Everything a provider needs to analyse one input. */
typedef struct {
    const uint8_t *data;
    size_t len;
    const char *path;
    Arena *arena;
    Buf *out;
    FormatOptions opt;
} FormatCtx;

/* Result of a probe: 0 means "not this format"; higher is more confident. */
typedef int (*ReaProbeFn)(const uint8_t *data, size_t len);

typedef struct Formatter {
    const char *name;
    const char *description;
    ReaProbeFn probe;
    /* Optional hooks; NULL means unsupported. */
    int (*describe)(FormatCtx *ctx);
    int (*disassemble)(FormatCtx *ctx);
    int (*decompile)(FormatCtx *ctx);
    /* Optional: extract members of a container into ctx->opt.outdir. */
    int (*extract)(FormatCtx *ctx);
} Formatter;

/* Registry of all compiled-in providers. */
const Formatter **formatters(size_t *count);

/* Chooses the best provider for the input, or NULL when nothing matches.
 * When `verbose`, prints every candidate and its score. */
const Formatter *format_select(const uint8_t *data, size_t len, int verbose);

/* Runs the requested action with the selected provider. */
int format_run(const char *path, const char *action, const FormatOptions *opt);

/* Scans a directory of inputs, probing each file and reporting what it is.
 * This is the "drop files in libs/ and it just works" entry point. */
int rea_scan_libs(const char *dir);

#endif
