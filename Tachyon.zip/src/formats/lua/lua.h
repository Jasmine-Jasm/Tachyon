#ifndef TACHYON_LUA_H
#define TACHYON_LUA_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "common/buf.h"

/* Lua 5.1 through 5.4 bytecode share the same overall shape:
 *   header (signature, version, format, endianness, sizes)
 *   function prototypes, each with its own constant and instruction arrays.
 * The details differ per version, so the reader adapts to the header. */

typedef struct LuaProto {
    char *name;
    int line_defined;
    int last_line_defined;
    int num_params;
    int is_vararg;
    int max_stack;

    uint32_t *code;          /* instruction words */
    uint32_t code_count;

    /* constants, rendered as source-like text */
    char **consts;
    uint32_t const_count;

    /* nested prototypes */
    struct LuaProto **protos;
    uint32_t proto_count;
} LuaProto;

typedef struct {
    int version;
    int little_endian;
    int size_int;
    int size_size_t;
    int size_instruction;
    int size_lua_number;
    int is_integer_only;   /* 5.3+ can store integers separately */

    LuaProto *main;
    Arena *arena;
} LuaChunk;

/* Parses a luac output. Returns NULL when the signature or version is not
 * supported. */
LuaChunk *lua_parse(const uint8_t *data, size_t len, Arena *arena);

/* Disassembles every prototype into `out`. */
void lua_disassemble(LuaChunk *chunk, Buf *out, int limit);

/* Human-readable opcode name, or NULL when the version is unknown. */
const char *lua_opname(int version, uint32_t opcode);

#endif
