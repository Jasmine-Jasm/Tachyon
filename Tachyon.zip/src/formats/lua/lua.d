src/formats/lua/lua.o: src/formats/lua/lua.c src/formats/lua/lua.h \
 src/common/arena.h src/common/buf.h

src/formats/lua/lua.h:

src/common/arena.h:

src/common/buf.h:
