src/formats/lua/lua_provider.o: src/formats/lua/lua_provider.c \
 src/formats/provider.h src/common/arena.h src/common/buf.h \
 src/formats/lua/lua.h

src/formats/provider.h:

src/common/arena.h:

src/common/buf.h:

src/formats/lua/lua.h:
