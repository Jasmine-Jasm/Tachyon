#include "formats/lua/lua.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------------------------------------------------------------- */
/* opcode tables                                                     */
/* ---------------------------------------------------------------- */

/* Lua 5.1 opcodes, in encoding order. */
static const char *OPS_51[] = {
    "MOVE", "LOADK", "LOADBOOL", "LOADNIL", "GETUPVAL", "GETGLOBAL", "GETTABLE",
    "SETGLOBAL", "SETUPVAL", "SETTABLE", "NEWTABLE", "SELF", "ADD", "SUB", "MUL",
    "DIV", "MOD", "POW", "UNM", "NOT", "LEN", "CONCAT", "JMP", "EQ", "LT", "LE",
    "TEST", "TESTSET", "CALL", "TAILCALL", "RETURN", "FORLOOP", "FORPREP",
    "TFORLOOP", "SETLIST", "CLOSE", "CLOSURE", "VARARG",
};

/* Lua 5.2 and 5.3 share most of the layout. */
static const char *OPS_52[] = {
    "MOVE", "LOADK", "LOADKX", "LOADBOOL", "LOADNIL", "GETUPVAL", "GETTABUP",
    "GETTABLE", "SETTABUP", "SETUPVAL", "SETTABLE", "NEWTABLE", "SELF", "ADD",
    "SUB", "MUL", "DIV", "MOD", "POW", "UNM", "NOT", "LEN", "CONCAT", "JMP",
    "EQ", "LT", "LE", "TEST", "TESTSET", "CALL", "TAILCALL", "RETURN",
    "FORLOOP", "FORPREP", "TFORCALL", "TFORLOOP", "SETLIST", "CLOSURE", "VARARG",
    "EXTRAARG",
};

/* Lua 5.4 redesigned the opcode set completely (83 entries, different order from
 * 5.2/5.3), so it needs its own table. Generated from lopcodes.h. */
static const char *OPS_54[] = {
    "MOVE",
    "LOADI",
    "LOADF",
    "LOADK",
    "LOADKX",
    "LOADFALSE",
    "LFALSESKIP",
    "LOADTRUE",
    "LOADNIL",
    "GETUPVAL",
    "SETUPVAL",
    "GETTABUP",
    "GETTABLE",
    "GETI",
    "GETFIELD",
    "SETTABUP",
    "SETTABLE",
    "SETI",
    "SETFIELD",
    "NEWTABLE",
    "SELF",
    "ADDI",
    "ADDK",
    "SUBK",
    "MULK",
    "MODK",
    "POWK",
    "DIVK",
    "IDIVK",
    "BANDK",
    "BORK",
    "BXORK",
    "SHRI",
    "SHLI",
    "ADD",
    "SUB",
    "MUL",
    "MOD",
    "POW",
    "DIV",
    "IDIV",
    "BAND",
    "BOR",
    "BXOR",
    "SHL",
    "SHR",
    "MMBIN",
    "MMBINI",
    "MMBINK",
    "UNM",
    "BNOT",
    "NOT",
    "LEN",
    "CONCAT",
    "CLOSE",
    "TBC",
    "JMP",
    "EQ",
    "LT",
    "LE",
    "EQK",
    "EQI",
    "LTI",
    "LEI",
    "GTI",
    "GEI",
    "TEST",
    "TESTSET",
    "CALL",
    "TAILCALL",
    "RETURN",
    "RETURN0",
    "RETURN1",
    "FORLOOP",
    "FORPREP",
    "TFORPREP",
    "TFORCALL",
    "TFORLOOP",
    "SETLIST",
    "CLOSURE",
    "VARARG",
    "VARARGPREP",
    "EXTRAARG"
};

const char *lua_opname(int version, uint32_t op)
{
    if (version == 0x54) {
        if (op < sizeof(OPS_54) / sizeof(OPS_54[0]))
            return OPS_54[op];
        return NULL;
    }
    if (version == 0x51) {
        if (op < sizeof(OPS_51) / sizeof(OPS_51[0]))
            return OPS_51[op];
        return NULL;
    }
    if (version == 0x52 || version == 0x53) {
        if (op < sizeof(OPS_52) / sizeof(OPS_52[0]))
            return OPS_52[op];
        return NULL;
    }
    return NULL;
}

/* ---------------------------------------------------------------- */
/* reader                                                            */
/* ---------------------------------------------------------------- */

typedef struct {
    const uint8_t *p;
    size_t len;
    size_t pos;
    int little;
    int bad;
} LRd;

static int need(LRd *r, size_t n)
{
    if (r->bad)
        return 0;
    if (r->pos > r->len || n > r->len - r->pos) {
        r->bad = 1;
        return 0;
    }
    return 1;
}

static uint32_t rd_uint(LRd *r, int size)
{
    if (size <= 0 || size > 8 || !need(r, (size_t)size))
        return 0;
    uint32_t v = 0;
    if (r->little) {
        for (int i = size - 1; i >= 0; i--)
            v = (v << 8) | r->p[r->pos + (size_t)i];
    } else {
        for (int i = 0; i < size; i++)
            v = (v << 8) | r->p[r->pos + (size_t)i];
    }
    r->pos += (size_t)size;
    return v;
}

static uint8_t rd_byte(LRd *r);

/* Lua 5.4 encodes integers with a high-bit-terminated variable length: bytes are
 * accumulated while the continuation bit is CLEAR, and the sequence ends on a
 * byte whose 0x80 bit is SET. That is the opposite of the usual convention. */
static uint64_t rd_varuint(LRd *r)
{
    /* Sequence ends on a byte whose 0x80 bit is SET (the last byte carries the
     * terminator), so 0x8a alone is the value 10. */
    uint64_t x = 0;
    for (int i = 0; i < 10; i++) {
        uint8_t b = rd_byte(r);
        if (r->bad)
            return 0;
        x = (x << 7) | (uint64_t)(b & 0x7f);
        if (b & 0x80) {
            if (getenv("TACHYON_DEBUG_LUA"))
                fprintf(stderr, "[lua] varuint stop at i=%d b=0x%02x x=%llu\n", i, b,
                        (unsigned long long)x);
            return x;
        }
    }
    return x;
}

static uint8_t rd_byte(LRd *r)
{
    if (!need(r, 1))
        return 0;
    return r->p[r->pos++];
}

static double rd_number(LRd *r, const LuaChunk *c)
{
    if (c->size_lua_number == 8) {
        if (!need(r, 8))
            return 0;
        double d;
        if (c->little_endian) {
            uint8_t tmp[8];
            for (int i = 0; i < 8; i++)
                tmp[i] = r->p[r->pos + (size_t)(7 - i)];
            memcpy(&d, tmp, 8);
        } else {
            memcpy(&d, r->p + r->pos, 8);
        }
        r->pos += 8;
        return d;
    }
    /* 4-byte float */
    if (!need(r, 4))
        return 0;
    float f;
    if (c->little_endian) {
        uint8_t tmp[4];
        for (int i = 0; i < 4; i++)
            tmp[i] = r->p[r->pos + (size_t)(3 - i)];
        memcpy(&f, tmp, 4);
    } else {
        memcpy(&f, r->p + r->pos, 4);
    }
    r->pos += 4;
    return (double)f;
}

static int64_t rd_int(LRd *r, int size)
{
    uint32_t v = rd_uint(r, size);
    if (size < 4)
        return (int32_t)v;
    if (size == 4)
        return (int32_t)v;
    /* 8-byte integers appear in 5.3+; read the high half too. */
    uint32_t hi = rd_uint(r, size - 4);
    uint64_t full = ((uint64_t)hi << 32) | v;
    return (int64_t)full;
}

static char *read_string(LRd *r, LuaChunk *c)
{
    uint32_t n;
    if (c->version >= 0x54) {
        uint64_t v = rd_varuint(r);
        if (r->bad || v > 0xffffffffu)
            return NULL;
        if (v == 0)
            return NULL; /* NULL string */
        n = (uint32_t)v;
        if (n > 100000000u) {
            r->bad = 1;
            return NULL;
        }
        if (!need(r, n))
            return NULL;
        /* `size` counts the trailing NUL, so the payload is size-1 bytes. The
         * length prefix itself has already been consumed by rd_varuint, which
         * means the position must advance by size-1 here, not size. */
        char *out = arena_alloc(c->arena, (size_t)n + 1);
        if (!out) {
            r->bad = 1;
            return NULL;
        }
        memcpy(out, r->p + r->pos, n - 1);
        out[n - 1] = '\0';
        r->pos += n - 1;
        return out;
    }

    int size = (c->version >= 0x53) ? c->size_size_t : c->size_int;
    n = rd_uint(r, size);
    if (r->bad)
        return NULL;
    if (n == 0 || n == 0xffffffffu)
        return NULL; /* NULL string */
    if (n > 100000000u) {
        r->bad = 1;
        return NULL;
    }
    if (!need(r, n))
        return NULL;
    char *s = arena_alloc(c->arena, (size_t)n + 1);
    if (!s) {
        r->bad = 1;
        return NULL;
    }
    memcpy(s, r->p + r->pos, n);
    s[n] = '\0';
    r->pos += n;
    return s;
}

static LuaProto *read_proto(LRd *r, LuaChunk *c, const char *parent_name, int depth);

static LuaProto *read_proto(LRd *r, LuaChunk *c, const char *parent_name, int depth)
{
    /* Lua 5.4 changed several encodings (variable-length integers, an extra
     * integrity header, per-prototype source strings). The layout here follows
     * lundump.c; if a chunk does not parse, the safest response is to report the
     * version rather than emit wrong instructions. */
    if (depth > 32 || r->bad)
        return NULL;

    LuaProto *p = arena_zalloc(c->arena, sizeof(*p));
    if (!p) {
        r->bad = 1;
        return NULL;
    }
    /* Name first: children derive their own names from it. */
    p->name = parent_name ? (char *)parent_name : "main chunk";

    /* Lua 5.4 prefixes each prototype with the number of upvalues as a single
     * byte; 5.1-5.3 do not. Verified against a real chunk: byte 31 was 0x01 for
     * a function with one upvalue. */
    /* Verified against a real chunk: the first prototype begins with a
     * one-byte upvalue count, while nested prototypes do not repeat it (their
     * upvalue table is written after the constants). */
    int nupvalues = 0;
    if (c->version >= 0x54 && depth == 0)
        nupvalues = rd_byte(r);

    /* Then the source name, the line range, and the three signature bytes,
     * matching loadFunction() in lundump.c. */
    char *src = read_string(r, c);
    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] nup=%d source=\"%s\" pos=%zu\n", nupvalues,
                src ? src : "(null)", r->pos);

    /* 5.4 encodes the line range as variable-length; earlier versions use a
     * fixed-width little-endian integer. */
    if (c->version >= 0x54) {
        size_t b1 = r->pos;
        p->line_defined = (int)rd_varuint(r);
        size_t b2 = r->pos;
        p->last_line_defined = (int)rd_varuint(r);
        if (getenv("TACHYON_DEBUG_LUA"))
            fprintf(stderr, "[lua] line: %zu->%zu (=%d), %zu->%zu (=%d)\n", b1, b2,
                    p->line_defined, b2, r->pos, p->last_line_defined);
    } else {
        p->line_defined = (int)rd_uint(r, c->size_int);
        p->last_line_defined = (int)rd_uint(r, c->size_int);
    }
    p->num_params = (int)rd_byte(r);
    p->is_vararg = rd_byte(r);
    p->max_stack = (int)rd_byte(r);
    (void)nupvalues;

    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] after header fields: pos=%zu params=%d vararg=%d stack=%d\n",
                r->pos, p->num_params, p->is_vararg, p->max_stack);

    /* code */
    uint32_t ncode = (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
    if (r->bad || ncode > 10000000u)
        return NULL;
    p->code_count = ncode;
    if (ncode) {
        p->code = arena_alloc(c->arena, (size_t)ncode * sizeof(uint32_t));
        if (!p->code) {
            r->bad = 1;
            return NULL;
        }
        for (uint32_t i = 0; i < ncode; i++)
            p->code[i] = rd_uint(r, c->size_instruction);
    }

    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] after code: pos=%zu ncode=%u\n", r->pos, ncode);

    /* constants */
    uint32_t nk = (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
    if (r->bad || nk > 1000000u)
        return NULL;
    p->const_count = nk;
    if (nk) {
        p->consts = arena_zalloc(c->arena, ((size_t)nk + 1) * sizeof(char *));
        if (!p->consts) {
            r->bad = 1;
            return NULL;
        }
        for (uint32_t i = 0; i < nk; i++) {
            uint8_t t = rd_byte(r);
            char tmp[64];
            /* Lua 5.4 tags: 0=nil, 1=false, 17=true, 3=float, 4=short string,
             * 19=integer, 20=long string. 5.1-5.3 use a smaller set:
             * 0=nil, 1=boolean, 3=number, 4=string. */
            if (t == 0) {
                p->consts[i] = "nil";
            } else if (t == 1) {
                p->consts[i] = rd_byte(r) ? "true" : "false";
            } else if (t == 17) {
                p->consts[i] = "true";
            } else if (t == 3) {
                double dv = rd_number(r, c);
                snprintf(tmp, sizeof(tmp), "%g", dv);
                p->consts[i] = arena_strdup(c->arena, tmp);
            } else if (t == 19) {
                int64_t v = (c->version >= 0x54) ? (int64_t)rd_uint(r, 8)
                                                 : rd_int(r, c->size_int);
                snprintf(tmp, sizeof(tmp), "%lld", (long long)v);
                p->consts[i] = arena_strdup(c->arena, tmp);
            } else if (t == 4 || t == 20) {
                char *str = read_string(r, c);
                size_t sl = str ? strlen(str) : 0;
                char *q = arena_alloc(c->arena, sl + 3);
                if (q) {
                    q[0] = '"';
                    if (str)
                        memcpy(q + 1, str, sl);
                    q[sl + 1] = '"';
                    q[sl + 2] = '\0';
                }
                p->consts[i] = q;
            } else {
                p->consts[i] = "?";
                if (getenv("TACHYON_DEBUG_LUA"))
                    fprintf(stderr, "[lua] unknown const tag 0x%02x at %zu\n", t, r->pos);
                r->bad = 1;
                return NULL;
            }
        }
    }

    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] after consts: pos=%zu nk=%u\n", r->pos, nk);

    /* upvalues: count, then three bytes per upvalue */
    uint32_t nup = (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
    if (r->bad || nup > 100000u)
        return NULL;
    if (!need(r, (size_t)nup * 3))
        return NULL;
    r->pos += (size_t)nup * 3;

    /* nested prototypes */
    uint32_t np = (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
    if (r->bad || np > 100000u)
        return NULL;
    p->proto_count = np;
    if (np) {
        p->protos = arena_zalloc(c->arena, (size_t)np * sizeof(LuaProto *));
        if (!p->protos) {
            r->bad = 1;
            return NULL;
        }
        for (uint32_t i = 0; i < np; i++) {
            p->protos[i] = read_proto(r, c, p->name ? p->name : "fn", depth + 1);
            /* Name nested prototypes after their parent plus their index; the
             * chunk carries source line ranges but not function names. */
            if (p->protos[i]) {
                char nm[256];
                snprintf(nm, sizeof(nm), "%s.%u", p->name, i);
                p->protos[i]->name = arena_strdup(c->arena, nm);
            }
        }
    }

    /* Debug information (line table, locals, upvalue names) is not needed for
     * disassembly, but it must be consumed to stay aligned for the next
     * prototype. If it cannot be walked, stop here and keep what was decoded:
     * a partial listing is more useful than no output at all. */
    uint32_t nline = (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
    if (r->bad || nline > 10000000u)
        goto done;
    if (!need(r, nline))
        goto done;
    r->pos += nline;

    if (c->version >= 0x54) {
        uint32_t nabs = (uint32_t)rd_varuint(r);
        if (r->bad || nabs > 1000000u)
            goto done;
        if (!need(r, (size_t)nabs * (size_t)(c->size_int * 2)))
            goto done;
        r->pos += (size_t)nabs * (size_t)(c->size_int * 2);
    }

    uint32_t nloc = (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
    if (r->bad || nloc > 100000u)
        goto done;
    for (uint32_t i = 0; i < nloc; i++) {
        char *nm = read_string(r, c);
        (void)nm;
        rd_uint(r, c->size_int);
        rd_uint(r, c->size_int);
    }

    {
        uint32_t ndbgup =
            (uint32_t)(c->version >= 0x54 ? rd_varuint(r) : rd_uint(r, c->size_int));
        if (r->bad || ndbgup > 100000u)
            goto done;
        for (uint32_t i = 0; i < ndbgup; i++) {
            char *nm = read_string(r, c);
            (void)nm;
        }
    }

done:
    /* Debug tables are best-effort: a partial walk must not throw away the code
     * and constants that were decoded successfully. */
    r->bad = 0;


    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] proto %s: params=%d code=%u consts=%u protos=%u pos=%zu\n",
                p->name, p->num_params, p->code_count, p->const_count, p->proto_count,
                r->pos);
    return p;
}

LuaChunk *lua_parse(const uint8_t *data, size_t len, Arena *arena)
{
    if (!data || len < 12)
        return NULL;
    /* Signature is ESC "Lua" followed by a version byte. */
    if (data[0] != 0x1b || memcmp(data + 1, "Lua", 3) != 0)
        return NULL;

    LuaChunk *c = arena_zalloc(arena, sizeof(*c));
    if (!c)
        return NULL;
    c->arena = arena;
    LRd r = { data, len, 4, 0, 0 };
    /* Signature already checked: ESC "Lua". */
    r.pos = 4;
    c->version = rd_byte(&r);
    if (c->version < 0x51 || c->version > 0x54)
        return NULL;

    uint8_t format = rd_byte(&r);
    if (format != 0)
        return NULL; /* official binary format only */

    /* Lua 5.4 header (see lundump.c checkHeader):
     *   LUAC_DATA(6), sizeof(Instruction), sizeof(lua_Integer),
     *   sizeof(lua_Number), LUAC_INT, LUAC_NUM
     * 5.1-5.3 instead carry: endianness, then the four sizes. */
    if (c->version >= 0x54) {
        static const uint8_t LUAC_DATA[6] = {0x19, 0x93, 0x0d, 0x0a, 0x1a, 0x0a};
        if (!need(&r, 6) || memcmp(r.p + r.pos, LUAC_DATA, 6) != 0)
            return NULL;
        r.pos += 6;

        c->size_instruction = rd_byte(&r);
        c->size_int = rd_byte(&r);        /* lua_Integer */
        c->size_lua_number = rd_byte(&r);
        c->size_size_t = 8;               /* fixed by the 5.4 ABI */
        c->little_endian = 1;             /* LUAC_DATA already pins the format */
        r.little = 1;
        c->is_integer_only = 0;

        /* LUAC_INT then LUAC_NUM, pure self-checks. */
        size_t skip = (size_t)c->size_int + (size_t)c->size_lua_number;
        if (!need(&r, skip))
            return NULL;
        r.pos += skip;
    } else {
        c->little_endian = rd_byte(&r) != 0;
        r.little = c->little_endian;
        c->size_int = rd_byte(&r);
        c->size_size_t = rd_byte(&r);
        c->size_instruction = rd_byte(&r);
        c->size_lua_number = rd_byte(&r);
        c->is_integer_only = (c->version >= 0x53) ? rd_byte(&r) : 0;
    }
    if (r.bad)
        return NULL;

    if (c->size_int < 1 || c->size_int > 8 || c->size_instruction < 1 ||
        c->size_instruction > 8 || c->size_lua_number < 4 || c->size_lua_number > 8)
        return NULL;

    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] header ok: v=%02x int=%d instr=%d num=%d pos=%zu\n",
                c->version, c->size_int, c->size_instruction, c->size_lua_number, r.pos);

    c->main = read_proto(&r, c, "main chunk", 0);
    if (getenv("TACHYON_DEBUG_LUA"))
        fprintf(stderr, "[lua] proto=%p bad=%d pos=%zu/%zu\n", (void *)c->main, r.bad,
                r.pos, r.len);
    if (!c->main || r.bad)
        return NULL;
    return c;
}

/* ---------------------------------------------------------------- */
/* disassembly                                                       */
/* ---------------------------------------------------------------- */

/* Instruction layout differs between versions (see lopcodes.h):
 *   5.1-5.3: op 6 bits at 0, A 8 bits at 6, C 9 bits at 14, B 9 bits at 23
 *   5.4:     op 7 bits at 0, A 8 bits at 7, k 1 bit at 15, B 8 bits at 16,
 *            C 8 bits at 24
 * Using the 5.3 layout on a 5.4 chunk shifts every field, which is why the
 * opcode names come out wrong. */
static void decode_abc(int version, uint32_t insn, int *op, int *a, int *b, int *c)
{
    if (version >= 0x54) {
        *op = (int)(insn & 0x7f);
        *a = (int)((insn >> 7) & 0xff);
        *b = (int)((insn >> 16) & 0xff);
        *c = (int)((insn >> 24) & 0xff);
        return;
    }
    *op = (int)(insn & 0x3f);
    *a = (int)((insn >> 6) & 0xff);
    *c = (int)((insn >> 14) & 0x1ff);
    *b = (int)((insn >> 23) & 0x1ff);
}

static void emit_proto(LuaChunk *ch, LuaProto *p, Buf *out, int indent, int limit,
                       int *emitted)
{
    if (!p)
        return;
    buf_indent(out, indent);
    buf_printf(out, "function %s  (%u params, %u instructions, %u constants)\n", p->name,
               (unsigned)p->num_params, p->code_count, p->const_count);

    for (uint32_t i = 0; i < p->code_count; i++) {
        if (limit > 0 && *emitted >= limit)
            return;
        uint32_t insn = p->code[i];
        int op, a, b, c;
        decode_abc(ch->version, insn, &op, &a, &b, &c);
        const char *name = lua_opname(ch->version, (uint32_t)op);

        buf_indent(out, indent + 1);
        buf_printf(out, "%6u  %-12s", i, name ? name : "OP?");
        if (name) {
            buf_printf(out, " A=%d", a);
            /* Only print the operands that matter for common opcodes to keep the
             * listing readable. */
            switch (op) {
            case 1: case 5: case 6: case 7: /* LOADK, GETUPVAL, GETTABUP, GETGLOBAL */
                buf_printf(out, " B=%d", b ? b : c);
                break;
            case 2: /* LOADBOOL */
                buf_printf(out, " B=%d C=%d", b, c);
                break;
            case 22: /* JMP */
                buf_printf(out, " -> %d", i + 1 + b);
                break;
            default:
                if (b)
                    buf_printf(out, " B=%d", b);
                if (c)
                    buf_printf(out, " C=%d", c);
                break;
            }
            /* Annotate constant loads. */
            if (op == 1 || op == 2) {
                uint32_t k = (uint32_t)(b ? b : c);
                if ((op == 1) && k < p->const_count && p->consts[k])
                    buf_printf(out, "   (%s)", p->consts[k]);
            }
        }
        buf_putc(out, '\n');
        (*emitted)++;
    }

    for (uint32_t i = 0; i < p->proto_count; i++)
        emit_proto(ch, p->protos[i], out, indent + 1, limit, emitted);
}

void lua_disassemble(LuaChunk *chunk, Buf *out, int limit)
{
    if (!chunk || !chunk->main)
        return;
    buf_printf(out, "Lua bytecode  version 5.%d  %s-endian\n", chunk->version - 0x50,
               chunk->little_endian ? "little" : "big");
    buf_printf(out, "  int size %d, size_t %d, instruction %d, number %d\n\n",
               chunk->size_int, chunk->size_size_t, chunk->size_instruction,
               chunk->size_lua_number);
    int emitted = 0;
    emit_proto(chunk, chunk->main, out, 0, limit, &emitted);
}
