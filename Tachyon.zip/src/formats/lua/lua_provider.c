#include "formats/provider.h"
#include "formats/lua/lua.h"

#include <stdio.h>
#include <string.h>

/* luac output starts with ESC "Lua" and a version byte in 0x51-0x54. */
static int lua_probe(const uint8_t *data, size_t len)
{
    if (len < 12)
        return 0;
    if (data[0] != 0x1b || memcmp(data + 1, "Lua", 3) != 0)
        return 0;
    uint8_t v = data[4];
    if (v < 0x51 || v > 0x54)
        return 3;
    return 9;
}

static int lua_describe(FormatCtx *ctx)
{
    LuaChunk *c = lua_parse(ctx->data, ctx->len, ctx->arena);
    if (!c) {
        buf_puts(ctx->out,
                 "error: could not decode this Lua chunk\n"
                 "  Only the official binary format is supported; the reader\n"
                 "  follows lundump.c for 5.1-5.4.\n");
        if (ctx->len >= 5)
            buf_printf(ctx->out, "  version byte: 0x%02x (supported 0x51-0x54)\n",
                       ctx->data[4]);
        return -1;
    }
    buf_printf(ctx->out, "format     : Lua bytecode 5.%d\n", c->version - 0x50);
    buf_printf(ctx->out, "endianness : %s\n", c->little_endian ? "little" : "big");
    buf_printf(ctx->out, "word sizes : int %d, size_t %d, insn %d, number %d\n",
               c->size_int, c->size_size_t, c->size_instruction, c->size_lua_number);
    if (c->main) {
        buf_printf(ctx->out, "prototypes : %u nested\n", c->main->proto_count);
        buf_printf(ctx->out, "main code  : %u instructions, %u constants\n",
                   c->main->code_count, c->main->const_count);
    }
    return 0;
}

static int lua_disasm(FormatCtx *ctx)
{
    LuaChunk *c = lua_parse(ctx->data, ctx->len, ctx->arena);
    if (!c)
        return -1;
    lua_disassemble(c, ctx->out, ctx->opt.limit);
    return 0;
}

const Formatter formatter_lua = {
    .name = "lua",
    .description = "Lua bytecode (luac 5.1-5.4)",
    .probe = lua_probe,
    .describe = lua_describe,
    .disassemble = lua_disasm,
    .decompile = NULL,
    .extract = NULL,
};
