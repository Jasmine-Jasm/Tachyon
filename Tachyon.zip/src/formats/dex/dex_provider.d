src/formats/dex/dex_provider.o: src/formats/dex/dex_provider.c \
 src/formats/provider.h src/common/arena.h src/common/buf.h src/dex/dex.h \
 src/common/io.h

src/formats/provider.h:

src/common/arena.h:

src/common/buf.h:

src/dex/dex.h:

src/common/io.h:
