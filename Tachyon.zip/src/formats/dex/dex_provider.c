#include "formats/provider.h"

#include <stdio.h>
#include <string.h>

#include "common/arena.h"
#include "common/buf.h"
#include "dex/dex.h"

/* A DEX file starts with "dex\n" and a three-digit version then NUL. */
static int fmtdex_probe(const uint8_t *data, size_t len)
{
    if (len < 0x70)
        return 0;
    if (memcmp(data, "dex\n", 4) != 0)
        return 0;
    for (int i = 4; i < 7; i++)
        if (data[i] < '0' || data[i] > '9')
            return 1;
    if (data[7] != '\0')
        return 1;
    return 9;
}

static int fmtdex_describe(FormatCtx *ctx)
{
    char err[256];
    Dex *d = dex_open_memory(ctx->data, ctx->len, ctx->arena, err, sizeof(err));
    if (!d) {
        buf_printf(ctx->out, "error: %s\n", err);
        return -1;
    }

    buf_printf(ctx->out, "format     : DEX %c%c%c\n", d->hdr.version[0], d->hdr.version[1],
               d->hdr.version[2]);
    buf_printf(ctx->out, "checksum   : 0x%08x\n", d->hdr.checksum);
    buf_printf(ctx->out, "file size  : %u bytes\n", d->hdr.file_size);
    buf_printf(ctx->out, "strings    : %u\n", d->hdr.string_ids_size);
    buf_printf(ctx->out, "types      : %u\n", d->hdr.type_ids_size);
    buf_printf(ctx->out, "protos     : %u\n", d->hdr.proto_ids_size);
    buf_printf(ctx->out, "fields     : %u\n", d->hdr.field_ids_size);
    buf_printf(ctx->out, "methods    : %u\n", d->hdr.method_ids_size);
    buf_printf(ctx->out, "classes    : %u\n", d->hdr.class_defs_size);
    return 0;
}

static int fmtdex_disasm(FormatCtx *ctx)
{
    char err[256];
    Dex *d = dex_open_memory(ctx->data, ctx->len, ctx->arena, err, sizeof(err));
    if (!d) {
        buf_printf(ctx->out, "error: %s\n", err);
        return -1;
    }

    buf_printf(ctx->out, "DEX %c%c%c  %u classes\n\n", d->hdr.version[0], d->hdr.version[1],
               d->hdr.version[2], d->hdr.class_defs_size);

    uint32_t shown = 0;
    for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
        if (ctx->opt.limit && shown >= ctx->opt.limit)
            break;
        const DexClassDef *cd = &d->classes[i];
        buf_printf(ctx->out, "class %s\n", dex_type_name(d, cd->class_idx));
        shown++;
    }
    return 0;
}

static int fmtdex_decompile(FormatCtx *ctx)
{
    /* Source generation lives in the main java emitter, which needs the target
     * directory and the thread pool; the CLI routes APK/DEX input there. */
    buf_puts(ctx->out,
             "error: DEX to Java is handled by the main decompile path\n"
             "  use: tachyon d <file.dex> -o <outdir>\n");
    return -1;
}

const Formatter formatter_dex = {
    .name = "dex",
    .description = "Dalvik executable (classes.dex)",
    .probe = fmtdex_probe,
    .describe = fmtdex_describe,
    .disassemble = fmtdex_disasm,
    .decompile = fmtdex_decompile,
    .extract = NULL,
};
