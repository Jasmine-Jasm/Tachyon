#include "formats/provider.h"

#include <stdio.h>
#include <string.h>

#include "common/io.h"
#include "common/arena.h"
#include "common/buf.h"

/* Each provider exports one symbol; the registry links them by hand so that no
 * constructor tricks or linker sections are needed. */
extern const Formatter formatter_dex;
extern const Formatter formatter_jvm;
extern const Formatter formatter_pyc;
extern const Formatter formatter_lua;

static const Formatter *g_providers[] = {
    &formatter_dex,
    &formatter_jvm,
    &formatter_pyc,
    &formatter_lua,
};

const Formatter **formatters(size_t *count)
{
    *count = sizeof(g_providers) / sizeof(g_providers[0]);
    return g_providers;
}

const Formatter *format_select(const uint8_t *data, size_t len, int verbose)
{
    size_t n = 0;
    const Formatter **all = formatters(&n);

    const Formatter *best = NULL;
    int best_score = 0;

    for (size_t i = 0; i < n; i++) {
        int score = all[i]->probe ? all[i]->probe(data, len) : 0;
        if (verbose)
            fprintf(stderr, "  probe %-10s score=%d\n", all[i]->name, score);
        if (score > best_score) {
            best_score = score;
            best = all[i];
        }
    }
    return best;
}

int format_run(const char *path, const char *action, const FormatOptions *opt)
{
    MappedFile map;
    if (io_map(path, &map) < 0) {
        fprintf(stderr, "error: cannot read '%s'\n", path);
        return 1;
    }

    const Formatter *p = format_select(map.data, map.len, opt->verbose);
    if (!p) {
        fprintf(stderr, "error: no provider recognizes '%s'\n", path);
        if (opt->verbose) {
            fprintf(stderr, "known providers:\n");
            size_t n = 0;
            const Formatter **all = formatters(&n);
            for (size_t i = 0; i < n; i++)
                fprintf(stderr, "  %-10s %s\n", all[i]->name, all[i]->description);
        }
        io_unmap(&map);
        return 1;
    }

    Arena arena;
    arena_init(&arena, 1 << 20);
    Buf out;
    buf_init(&out, 1 << 16);

    FormatCtx ctx;
    ctx.data = map.data;
    ctx.len = map.len;
    ctx.path = path;
    ctx.arena = &arena;
    ctx.out = &out;
    ctx.opt = *opt;

    int rc = -1;
    if (!strcmp(action, "describe") && p->describe)
        rc = p->describe(&ctx);
    else if (!strcmp(action, "disassemble") && p->disassemble)
        rc = p->disassemble(&ctx);
    else if (!strcmp(action, "decompile") && p->decompile)
        rc = p->decompile(&ctx);
    else if (!strcmp(action, "extract") && p->extract)
        rc = p->extract(&ctx);
    else {
        fprintf(stderr, "error: provider '%s' does not support '%s'\n", p->name, action);
        rc = 2;
    }

    /* Providers may write a diagnostic into the buffer even when they fail, so
     * flush whatever was produced instead of only on success. */
    if (out.len)
        fwrite(out.data, 1, out.len, stdout);

    buf_free(&out);
    arena_destroy(&arena);
    io_unmap(&map);
    return rc;
}

