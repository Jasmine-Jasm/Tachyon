src/formats/dispatch.o: src/formats/dispatch.c src/formats/provider.h \
 src/common/arena.h src/common/buf.h src/common/io.h

src/formats/provider.h:

src/common/arena.h:

src/common/buf.h:

src/common/io.h:
