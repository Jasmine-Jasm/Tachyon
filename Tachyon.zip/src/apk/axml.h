#ifndef TACHYON_AXML_H
#define TACHYON_AXML_H

#include <stddef.h>
#include <stdint.h>

#include "common/buf.h"

/* Android binary XML (AXML) decoder.
 *
 * An APK stores AndroidManifest.xml in the platform's binary XML format, not as
 * text: a string pool followed by a flat list of element chunks. Decoding it is
 * mechanical, so the decompiler can emit a real manifest and derive the Gradle
 * coordinates from it without any external tool.
 */

/* Decodes `data` into indented XML text. Returns 0 on success. */
int axml_to_xml(const uint8_t *data, size_t len, Buf *out);

/* Reads one manifest attribute by name, e.g. "package" or "versionCode".
 * Namespaced attributes may be looked up as "android:versionCode".
 * The value is written as text; returns 0 when found. */
int axml_manifest_attr(const uint8_t *data, size_t len, const char *name, char *out,
                       size_t cap);

#endif
