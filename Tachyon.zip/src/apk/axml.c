#include "apk/axml.h"

#include <stdio.h>
#include <string.h>

/* Chunk types from ResourceTypes.h. */
enum {
    RES_STRING_POOL_TYPE = 0x0001,
    RES_XML_TYPE = 0x0003,
    RES_XML_START_NAMESPACE_TYPE = 0x0100,
    RES_XML_END_NAMESPACE_TYPE = 0x0101,
    RES_XML_START_ELEMENT_TYPE = 0x0102,
    RES_XML_END_ELEMENT_TYPE = 0x0103,
    RES_XML_CDATA_TYPE = 0x0104,
    RES_XML_RESOURCE_MAP_TYPE = 0x0180,
};

/* Res_value data types. */
enum {
    TYPE_NULL = 0x00,
    TYPE_REFERENCE = 0x01,
    TYPE_ATTRIBUTE = 0x02,
    TYPE_STRING = 0x03,
    TYPE_FLOAT = 0x04,
    TYPE_DIMENSION = 0x05,
    TYPE_FRACTION = 0x06,
    TYPE_INT_DEC = 0x10,
    TYPE_INT_HEX = 0x11,
    TYPE_INT_BOOLEAN = 0x12,
};

#define NO_ENTRY 0xffffffffu

typedef struct {
    const uint8_t *data;
    size_t len;

    /* string pool */
    const uint8_t *str_pool;
    uint32_t str_count;
    uint32_t *str_offsets;
    int utf8;

    /* namespace prefixes seen so far */
    struct {
        uint32_t uri;
        uint32_t prefix;
    } ns[16];
    uint32_t ns_count;
} Axml;

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)(p[0] | (p[1] << 8));
}

static uint32_t rd32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

/* Decodes string pool entry `idx` into `out`. Returns 0 on success. */
static int pool_string(const Axml *a, uint32_t idx, char *out, size_t cap)
{
    if (idx == NO_ENTRY || idx >= a->str_count || !a->str_offsets)
        return -1;
    const uint8_t *p = a->str_pool + a->str_offsets[idx];
    const uint8_t *end = a->data + a->len;
    if (p < a->data || p >= end)
        return -1;
    size_t o = 0;
    if (a->utf8) {
        /* two lengths: character count, then byte count, each 1-2 bytes */
        for (int k = 0; k < 2; k++) {
            uint8_t b = *p++;
            if (b & 0x80)
                p++;
        }
        while (p < end && *p && o + 1 < cap)
            out[o++] = (char)*p++;
    } else {
        uint16_t n = rd16(p);
        p += 2;
        if (n & 0x8000) {
            n = (uint16_t)(((n & 0x7fff) << 16) | rd16(p));
            p += 2;
        }
        for (uint16_t i = 0; i < n && o + 4 < cap && p + 1 < end; i++) {
            uint32_t c = rd16(p);
            p += 2;
            if (c < 0x80) {
                out[o++] = (char)c;
            } else if (c < 0x800) {
                out[o++] = (char)(0xc0 | (c >> 6));
                out[o++] = (char)(0x80 | (c & 0x3f));
            } else {
                out[o++] = (char)(0xe0 | (c >> 12));
                out[o++] = (char)(0x80 | ((c >> 6) & 0x3f));
                out[o++] = (char)(0x80 | (c & 0x3f));
            }
        }
    }
    out[o] = '\0';
    return 0;
}

/* Formats a typed value. `raw` is the rawValue string index, used when present
 * because it preserves how the value was written in source. */
static void format_value(Axml *a, uint32_t raw, uint8_t type, uint32_t data, char *out,
                         size_t cap)
{
    char s[512];
    if (raw != NO_ENTRY && pool_string(a, raw, s, sizeof(s)) == 0) {
        snprintf(out, cap, "%s", s);
        return;
    }
    switch (type) {
    case TYPE_STRING:
        if (pool_string(a, data, s, sizeof(s)) == 0)
            snprintf(out, cap, "%s", s);
        else
            out[0] = '\0';
        break;
    case TYPE_REFERENCE:
        snprintf(out, cap, "@ref/0x%08x", data);
        break;
    case TYPE_ATTRIBUTE:
        snprintf(out, cap, "?attr/0x%08x", data);
        break;
    case TYPE_INT_DEC:
        snprintf(out, cap, "%d", (int32_t)data);
        break;
    case TYPE_INT_HEX:
        snprintf(out, cap, "0x%x", data);
        break;
    case TYPE_INT_BOOLEAN:
        snprintf(out, cap, "%s", data ? "true" : "false");
        break;
    case TYPE_FLOAT: {
        float f;
        memcpy(&f, &data, 4);
        snprintf(out, cap, "%g", (double)f);
        break;
    }
    case TYPE_DIMENSION: {
        static const char *units[] = {"px", "dp", "sp", "pt", "in", "mm"};
        uint32_t unit = data & 0xf;
        int32_t v = (int32_t)data >> 4;
        snprintf(out, cap, "%g%s", v / 16.0, unit < 6 ? units[unit] : "");
        break;
    }
    case TYPE_FRACTION: {
        int32_t v = (int32_t)data >> 4;
        snprintf(out, cap, "%g%%", v / 16.0 / 100.0);
        break;
    }
    default:
        snprintf(out, cap, "0x%08x", data);
        break;
    }
}

static const char *ns_prefix(Axml *a, uint32_t uri)
{
    if (uri == NO_ENTRY)
        return NULL;
    for (uint32_t i = 0; i < a->ns_count; i++)
        if (a->ns[i].uri == uri) {
            static char buf[64];
            if (pool_string(a, a->ns[i].prefix, buf, sizeof(buf)) == 0)
                return buf;
        }
    return NULL;
}

static void write_escape(Buf *out, const char *s)
{
    for (; *s; s++) {
        switch (*s) {
        case '<': buf_puts(out, "&lt;"); break;
        case '>': buf_puts(out, "&gt;"); break;
        case '&': buf_puts(out, "&amp;"); break;
        case '"': buf_puts(out, "&quot;"); break;
        default: buf_putc(out, *s); break;
        }
    }
}

static void indent(Buf *out, int n)
{
    for (int i = 0; i < n; i++)
        buf_puts(out, "    ");
}

/* Scans the string pool and the namespace table, which must be known before any
 * element can be rendered. */
static int scan_header(Axml *a)
{
    size_t off = 8; /* skip the RES_XML header */
    while (off + 8 <= a->len) {
        uint16_t type = rd16(a->data + off);
        uint32_t size = rd32(a->data + off + 4);
        if (size < 8 || off + size > a->len)
            break;
        if (type == RES_STRING_POOL_TYPE) {
            uint32_t count = rd32(a->data + off + 8);
            uint32_t flags = rd32(a->data + off + 16);
            uint32_t strings_start = rd32(a->data + off + 20);
            uint16_t hdr = rd16(a->data + off + 2);
            a->str_count = count;
            a->utf8 = (flags & 0x100) != 0;
            a->str_offsets = (uint32_t *)(a->data + off + hdr);
            a->str_pool = a->data + off + strings_start;
            if ((size_t)((const uint8_t *)a->str_offsets - a->data) + count * 4 > a->len)
                a->str_offsets = NULL;
            return 0;
        }
        if (type != RES_XML_RESOURCE_MAP_TYPE)
            break; /* the pool always precedes everything else */
        off += size;
    }
    return -1;
}

int axml_to_xml(const uint8_t *data, size_t len, Buf *out)
{
    if (!data || len < 8 || !out)
        return -1;
    if (rd16(data) != RES_XML_TYPE)
        return -1;

    Axml a;
    memset(&a, 0, sizeof(a));
    a.data = data;
    a.len = len;
    if (scan_header(&a) != 0 || !a.str_offsets)
        return -1;

    buf_puts(out, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");

    int depth = 0;
    size_t off = 8;
    while (off + 8 <= len) {
        uint16_t type = rd16(data + off);
        uint16_t hdr = rd16(data + off + 2);
        uint32_t size = rd32(data + off + 4);
        if (size < 8 || off + size > len)
            break;

        if (type == RES_XML_START_NAMESPACE_TYPE) {
            if (a.ns_count < 16) {
                a.ns[a.ns_count].prefix = rd32(data + off + hdr);
                a.ns[a.ns_count].uri = rd32(data + off + hdr + 4);
                a.ns_count++;
            }
        } else if (type == RES_XML_START_ELEMENT_TYPE) {
            uint32_t name_idx = rd32(data + off + hdr + 4);
            uint16_t attr_start = rd16(data + off + hdr + 8);
            uint16_t attr_size = rd16(data + off + hdr + 10);
            uint16_t attr_count = rd16(data + off + hdr + 12);

            char name[256];
            if (pool_string(&a, name_idx, name, sizeof(name)) != 0)
                name[0] = '?';

            /* Peek: a start element immediately followed by its end element is
             * written as a self-closing tag, and that end chunk must then be
             * skipped or the closing tag would be emitted twice. */
            int self_close = 0;
            uint32_t skip_extra = 0;
            size_t nxt = off + size;
            if (nxt + 8 <= len && rd16(data + nxt) == RES_XML_END_ELEMENT_TYPE) {
                uint32_t esz = rd32(data + nxt + 4);
                if (esz >= 8 && nxt + esz <= len) {
                    self_close = 1;
                    skip_extra = esz;
                }
            }

            indent(out, depth);
            buf_putc(out, '<');
            write_escape(out, name);

            const uint8_t *ap = data + off + hdr + attr_start;
            for (uint16_t i = 0; i < attr_count; i++) {
                const uint8_t *e = ap + (size_t)i * attr_size;
                if (e + 20 > data + len)
                    break;
                uint32_t ans = rd32(e);
                uint32_t aname = rd32(e + 4);
                uint32_t raw = rd32(e + 8);
                uint8_t vtype = e[15];
                uint32_t vdata = rd32(e + 16);

                char nm[256];
                if (pool_string(&a, aname, nm, sizeof(nm)) != 0)
                    continue;
                char val[512];
                format_value(&a, raw, vtype, vdata, val, sizeof(val));

                buf_putc(out, ' ');
                const char *pfx = ns_prefix(&a, ans);
                if (pfx && pfx[0]) {
                    write_escape(out, pfx);
                    buf_putc(out, ':');
                }
                write_escape(out, nm);
                buf_puts(out, "=\"");
                write_escape(out, val);
                buf_putc(out, '"');
            }

            if (self_close) {
                buf_puts(out, " />\n");
                off += skip_extra;
            } else {
                buf_puts(out, ">\n");
                depth++;
            }
        } else if (type == RES_XML_END_ELEMENT_TYPE) {
            if (depth > 0)
                depth--;
            uint32_t name_idx = rd32(data + off + hdr + 4);
            char name[256];
            if (pool_string(&a, name_idx, name, sizeof(name)) != 0)
                name[0] = '?';
            indent(out, depth);
            buf_puts(out, "</");
            write_escape(out, name);
            buf_puts(out, ">\n");
        } else if (type == RES_XML_CDATA_TYPE) {
            uint32_t data_idx = rd32(data + off + hdr);
            char s[1024];
            if (pool_string(&a, data_idx, s, sizeof(s)) == 0 && s[0]) {
                indent(out, depth);
                write_escape(out, s);
                buf_putc(out, '\n');
            }
        }
        off += size;
    }
    return 0;
}

int axml_manifest_attr(const uint8_t *data, size_t len, const char *name, char *out,
                       size_t cap)
{
    if (!data || len < 8 || !name || !out)
        return -1;
    Axml a;
    memset(&a, 0, sizeof(a));
    a.data = data;
    a.len = len;
    if (scan_header(&a) != 0 || !a.str_offsets)
        return -1;

    /* Record namespace prefixes first: attributes are matched on the name only,
     * but "android:name" style queries need the prefix to be resolvable. */
    size_t off = 8;
    while (off + 8 <= len) {
        uint16_t type = rd16(data + off);
        uint16_t hdr = rd16(data + off + 2);
        uint32_t size = rd32(data + off + 4);
        if (size < 8 || off + size > len)
            break;
        if (type == RES_XML_START_NAMESPACE_TYPE) {
            if (a.ns_count < 16) {
                a.ns[a.ns_count].prefix = rd32(data + off + hdr);
                a.ns[a.ns_count].uri = rd32(data + off + hdr + 4);
                a.ns_count++;
            }
        } else if (type == RES_XML_START_ELEMENT_TYPE) {
            uint16_t attr_start = rd16(data + off + hdr + 8);
            uint16_t attr_size = rd16(data + off + hdr + 10);
            uint16_t attr_count = rd16(data + off + hdr + 12);
            const uint8_t *ap = data + off + hdr + attr_start;
            for (uint16_t i = 0; i < attr_count; i++) {
                const uint8_t *e = ap + (size_t)i * attr_size;
                if (e + 20 > data + len)
                    break;
                char nm[256];
                if (pool_string(&a, rd32(e + 4), nm, sizeof(nm)) != 0)
                    continue;

                /* "package" means the un-namespaced attribute; "android:name"
                 * means the one bound to the android URI. Matching on the bare
                 * name would let android:name answer a query for name. */
                const char *colon = strchr(name, ':');
                uint32_t ans = rd32(e);
                if (colon) {
                    const char *pfx = ns_prefix(&a, ans);
                    size_t plen = (size_t)(colon - name);
                    if (!pfx || strlen(pfx) != plen || strncmp(pfx, name, plen))
                        continue;
                    if (strcmp(nm, colon + 1))
                        continue;
                } else {
                    if (ans != NO_ENTRY)
                        continue;
                    if (strcmp(nm, name))
                        continue;
                }
                format_value(&a, rd32(e + 8), e[15], rd32(e + 16), out, cap);
                return 0;
            }
        }
        off += size;
    }
    return -1;
}
