#ifndef TACHYON_APK_APK_H
#define TACHYON_APK_APK_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "dex/dex.h"

/* A decompilation target is a set of dex files. For a plain .dex there is one;
 * for an .apk there can be many (classes.dex, classes2.dex, ...). */
typedef struct {
    Dex **dex;
    uint32_t count;
    const char *source_path;   /* the file the user passed */
    int is_archive;
} DexSet;

/* Opens a .dex, .apk, .jar or .zip and returns every embedded dex.
 * Returns NULL on failure with `err` filled in. */
DexSet *apk_open(const char *path, Arena *arena, char *err, size_t errlen);

/* Extracts one archive entry by name into a freshly allocated buffer.
 * Returns 0 on success; the caller frees *out. */
int apk_extract(const char *path, const char *entry, uint8_t **out, size_t *len);

/* Lists archive entry names (for `tachyon list`). */
int apk_list(const char *path, void *fp, char *err, size_t errlen);

#endif
