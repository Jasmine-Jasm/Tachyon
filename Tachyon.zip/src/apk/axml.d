src/apk/axml.o: src/apk/axml.c src/apk/axml.h src/common/buf.h

src/apk/axml.h:

src/common/buf.h:
