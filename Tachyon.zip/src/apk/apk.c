#include "apk/apk.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common/io.h"
#include "zip/zip.h"

/* classes.dex, classes2.dex, classes3.dex ... */
static int dex_name_index(const char *name)
{
    if (strcmp(name, "classes.dex") == 0)
        return 1;
    if (strncmp(name, "classes", 7) != 0)
        return 0;
    const char *p = name + 7;
    int n = 0;
    int digits = 0;
    while (*p >= '0' && *p <= '9') {
        n = n * 10 + (*p - '0');
        p++;
        digits++;
        if (digits > 6)
            return 0;
    }
    if (digits == 0 || strcmp(p, ".dex") != 0)
        return 0;
    return n;
}

static int cmp_int(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (x > y) - (x < y);
}

DexSet *apk_open(const char *path, Arena *arena, char *err, size_t errlen)
{
    MappedFile *mf = malloc(sizeof(*mf));
    if (!mf) {
        snprintf(err, errlen, "out of memory");
        return NULL;
    }
    if (io_map(path, mf) < 0) {
        snprintf(err, errlen, "cannot read '%s'", path);
        free(mf);
        return NULL;
    }

    /* A dex file starts with "dex\n"; anything else is treated as an archive. */
    if (mf->len >= 8 && !memcmp(mf->data, "dex\n", 4)) {
        Dex *d = dex_open_memory(mf->data, mf->len, arena, err, errlen);
        if (!d) {
            io_unmap(mf);
            free(mf);
            return NULL;
        }
        d->path = arena_strdup(arena, path);
        d->mapped = mf;
        DexSet *set = arena_zalloc(arena, sizeof(*set));
        if (!set) {
            io_unmap(mf);
            free(mf);
            snprintf(err, errlen, "out of memory");
            return NULL;
        }
        set->dex = arena_alloc(arena, sizeof(Dex *));
        set->dex[0] = d;
        set->count = 1;
        set->source_path = arena_strdup(arena, path);
        set->is_archive = 0;
        return set;
    }

    ZipFile *z = zip_open(mf->data, mf->len, arena);
    if (!z) {
        snprintf(err, errlen, "'%s' is neither a dex file nor a zip archive", path);
        io_unmap(mf);
        free(mf);
        return NULL;
    }

    /* Collect and order the dex entries by their numeric suffix. */
    int *order = calloc(z->count ? z->count : 1, sizeof(int));
    if (!order) {
        snprintf(err, errlen, "out of memory");
        io_unmap(mf);
        free(mf);
        return NULL;
    }
    uint32_t n = 0;
    for (uint32_t i = 0; i < z->count; i++) {
        if (dex_name_index(z->entries[i].name) > 0)
            order[n++] = (int)i;
    }
    if (n == 0) {
        free(order);
        snprintf(err, errlen, "no classes*.dex entry found in '%s'", path);
        return NULL;
    }

    DexSet *set = arena_zalloc(arena, sizeof(*set));
    set->dex = arena_zalloc(arena, (size_t)n * sizeof(Dex *));
    if (!set->dex) {
        free(order);
        snprintf(err, errlen, "out of memory");
        return NULL;
    }

    for (uint32_t k = 0; k < n; k++) {
        const ZipEntry *e = &z->entries[order[k]];
        uint8_t *buf = NULL;
        size_t blen = 0;
        if (zip_extract(z, e, &buf, &blen) != 0) {
            free(order);
            snprintf(err, errlen, "cannot extract '%s' from '%s'", e->name, path);
            return NULL;
        }
        char derr[256];
        Dex *d = dex_open_memory(buf, blen, arena, derr, sizeof(derr));
        if (!d) {
            free(order);
            snprintf(err, errlen, "%s: %s", e->name, derr);
            return NULL;
        }
        d->path = arena_strdup(arena, e->name);
        set->dex[set->count++] = d;
    }
    free(order);

    /* Keep the mapping alive for the lifetime of the set; the dex views point
     * into buffers the archive owns, and those buffers live in the arena. */
    set->source_path = arena_strdup(arena, path);
    set->is_archive = 1;
    io_unmap(mf);
    free(mf);
    return set;
}

int apk_list(const char *path, void *fp, char *err, size_t errlen)
{
    FILE *out = fp;
    MappedFile *mf = malloc(sizeof(*mf));
    if (!mf) {
        snprintf(err, errlen, "out of memory");
        return -1;
    }
    if (io_map(path, mf) < 0) {
        snprintf(err, errlen, "cannot read '%s'", path);
        free(mf);
        return -1;
    }
    Arena arena;
    arena_init(&arena, 1 << 20);
    ZipFile *z = zip_open(mf->data, mf->len, &arena);
    if (!z) {
        snprintf(err, errlen, "'%s' is not a zip archive", path);
        arena_destroy(&arena);
        io_unmap(mf);
        free(mf);
        return -1;
    }
    for (uint32_t i = 0; i < z->count; i++)
        fprintf(out, "%10u  %10u  %s\n", z->entries[i].uncomp_size, z->entries[i].comp_size,
                z->entries[i].name);
    arena_destroy(&arena);
    io_unmap(mf);
    free(mf);
    return 0;
}

int apk_extract(const char *path, const char *entry, uint8_t **out, size_t *len)
{
    if (!path || !entry || !out || !len)
        return -1;
    *out = NULL;
    *len = 0;

    MappedFile *mf = malloc(sizeof(*mf));
    if (!mf)
        return -1;
    if (io_map(path, mf) < 0) {
        free(mf);
        return -1;
    }
    if (mf->len >= 8 && !memcmp(mf->data, "dex\n", 4)) {
        io_unmap(mf);
        free(mf);
        return -1; /* a bare dex has no entries */
    }

    Arena arena;
    arena_init(&arena, 1 << 16);
    int rc = -1;
    ZipFile *z = zip_open(mf->data, mf->len, &arena);
    if (z) {
        const ZipEntry *e = zip_find(z, entry);
        uint8_t *tmp = NULL;
        size_t tlen = 0;
        if (e && zip_extract(z, e, &tmp, &tlen) == 0 && tmp) {
            /* zip_extract allocates from this temporary arena, so the result has
             * to be copied out before the arena goes away. */
            uint8_t *copy = malloc(tlen ? tlen : 1);
            if (copy) {
                memcpy(copy, tmp, tlen);
                *out = copy;
                *len = tlen;
                rc = 0;
            }
        }
    }
    arena_destroy(&arena);
    io_unmap(mf);
    free(mf);
    return rc;
}
