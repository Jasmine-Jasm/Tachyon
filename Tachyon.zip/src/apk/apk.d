src/apk/apk.o: src/apk/apk.c src/apk/apk.h src/common/arena.h \
 src/dex/dex.h src/common/buf.h src/common/io.h src/zip/zip.h

src/apk/apk.h:

src/common/arena.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/zip/zip.h:
