src/dex/dex.o: src/dex/dex.c src/dex/dex.h src/common/arena.h \
 src/common/buf.h src/common/io.h

src/dex/dex.h:

src/common/arena.h:

src/common/buf.h:

src/common/io.h:
