#ifndef TACHYON_DEX_H
#define TACHYON_DEX_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "common/buf.h"
#include "common/io.h"

#define DEX_ENDIAN_CONSTANT 0x12345678u
#define DEX_NO_INDEX 0xffffffffu

enum {
    DEX_ACC_PUBLIC       = 0x0001,
    DEX_ACC_PRIVATE      = 0x0002,
    DEX_ACC_PROTECTED    = 0x0004,
    DEX_ACC_STATIC       = 0x0008,
    DEX_ACC_FINAL        = 0x0010,
    DEX_ACC_SYNCHRONIZED = 0x0020,
    DEX_ACC_VOLATILE     = 0x0040,
    DEX_ACC_BRIDGE       = 0x0040,
    DEX_ACC_TRANSIENT    = 0x0080,
    DEX_ACC_VARARGS      = 0x0080,
    DEX_ACC_NATIVE       = 0x0100,
    DEX_ACC_INTERFACE    = 0x0200,
    DEX_ACC_ABSTRACT     = 0x0400,
    DEX_ACC_STRICT       = 0x0800,
    DEX_ACC_SYNTHETIC    = 0x1000,
    DEX_ACC_ANNOTATION   = 0x2000,
    DEX_ACC_ENUM         = 0x4000,
    DEX_ACC_CONSTRUCTOR  = 0x10000,
};

typedef struct {
    uint32_t string_idx;
    uint32_t off;
} DexStringId;

typedef struct {
    uint32_t descriptor_idx;
} DexTypeId;

typedef struct {
    uint32_t shorty_idx;
    uint32_t return_type_idx;
    uint32_t parameters_off;
} DexProtoId;

typedef struct {
    uint16_t class_idx;
    uint16_t type_idx;
    uint32_t name_idx;
} DexFieldId;

typedef struct {
    uint16_t class_idx;
    uint16_t proto_idx;
    uint32_t name_idx;
} DexMethodId;

typedef struct {
    uint32_t class_idx;
    uint32_t access_flags;
    uint32_t superclass_idx;
    uint32_t interfaces_off;
    uint32_t source_file_idx;
    uint32_t annotations_off;
    uint32_t class_data_off;
    uint32_t static_values_off;
} DexClassDef;

typedef struct {
    uint32_t method_idx;
    uint32_t access_flags;
    uint32_t code_off;
} DexEncodedMethod;

typedef struct {
    uint32_t field_idx;
    uint32_t access_flags;
} DexEncodedField;

typedef struct {
    uint32_t class_idx;
    uint32_t annotations_off;
} DexTypeItem;

typedef struct {
    uint32_t field_idx;
    uint32_t annotations_off;
} DexFieldAnnotItem;

typedef struct {
    uint32_t method_idx;
    uint32_t annotations_off;
} DexMethodAnnotItem;

typedef struct {
    uint32_t class_annotations_off;
    uint32_t fields_size;
    uint32_t methods_size;
    DexFieldAnnotItem *fields;
    DexMethodAnnotItem *methods;
} DexClassAnnotations;

/* Encoded value tag byte, per DEX spec. */
typedef struct {
    uint8_t value_type;
    uint8_t value_arg;
    union {
        uint64_t u;
        int64_t s;
        uint32_t string_idx;
        uint32_t type_idx;
        uint32_t field_idx;
        uint32_t method_idx;
        uint32_t enum_idx;
        const void *raw;
    } v;
    uint32_t raw_size;
    const uint8_t *raw;
} DexValue;

typedef struct {
    uint32_t type_idx;      /* NO_INDEX means catch-all */
    uint32_t addr;
} DexHandler;

typedef struct {
    uint32_t start_addr;
    uint16_t insn_count;
    DexHandler *handlers;
    uint16_t handler_count;
} DexTryBlock;

typedef struct {
    uint16_t registers_size;
    uint16_t ins_size;
    uint16_t outs_size;
    uint16_t tries_size;
    uint32_t debug_info_off;
    uint32_t insns_size;
    const uint16_t *insns;
    DexTryBlock *tries;
} DexCode;

typedef struct {
    uint32_t start_addr;
    uint16_t register_num;
    const char *name;
    const char *type;
    const char *sig;
} DexDebugLocal;

typedef struct {
    int32_t line;
    uint32_t addr;
} DexLineEntry;

typedef struct {
    uint32_t line_start;
    uint32_t params_size;
    const char **param_names;
    DexLineEntry *lines;
    uint32_t line_count;
    DexDebugLocal *locals;
    uint32_t local_count;
} DexDebugInfo;

/* Encodes a Unicode code point as UTF-8. Returns byte count (1-3). */
size_t utf8_encode(uint32_t cp, char *out);

typedef struct {
    uint32_t string_ids_size;
    uint32_t string_ids_off;
    uint32_t type_ids_size;
    uint32_t type_ids_off;
    uint32_t proto_ids_size;
    uint32_t proto_ids_off;
    uint32_t field_ids_size;
    uint32_t field_ids_off;
    uint32_t method_ids_size;
    uint32_t method_ids_off;
    uint32_t class_defs_size;
    uint32_t class_defs_off;
    uint32_t link_size;
    uint32_t link_off;
    uint32_t file_size;
    uint32_t header_size;
    uint32_t checksum;
    uint8_t version[4];
    uint32_t map_off;
    uint32_t data_size;
    uint32_t data_off;
} DexHeader;

typedef struct {
    uint32_t param_count;
    uint32_t *type_idx;
} DexParamList;

typedef struct DexClassDataTag DexClassData;

/* All decoded strings live in one contiguous UTF-8 block; string_slot[i] is an
 * offset into it (or DEX_NO_INDEX when not yet decoded). */
typedef struct Dex {
    const uint8_t *base;
    size_t size;
    const char *path;
    DexHeader hdr;
    Arena *arena;

    const DexStringId *strings;
    const DexTypeId *types;
    const DexProtoId *protos;
    const DexFieldId *fields;
    const DexMethodId *methods;
    const DexClassDef *classes;

    /* lazy string cache: index -> decoded UTF-8, NULL until first use */
    const char **string_cache;

    /* lazy proto params cache */
    DexParamList **proto_params;

    /* per-class and per-code-item caches, built on first use but installed
     * before worker threads start so reads are race-free */
    const DexClassData **class_data_cache;

    /* code_off -> DexCode*, open addressing. Built lazily but installed under a
     * mutex so concurrent decompilation cannot allocate twice for one item. */
    DexCode **code_cache;
    uint32_t *code_keys;
    uint32_t code_cache_cap;

    /* type index -> class_def index (DEX_NO_INDEX when absent) and a
     * "has subclass" bitmap. Both are built once; the linear scans they replace
     * were quadratic and dominated the whole run on large dex files. */
    uint32_t *type_to_class_def;
    uint8_t *has_subclass;

    /* lazy "dotted" type name cache (descriptor with '/'-'.') */
    const char **type_name_cache;

    /* borrow of caller-owned mapped file, closed by dex_close if owned */
    MappedFile *mapped;
} Dex;

/* Opens and validates a dex file. Returns NULL and fills err on failure. */
Dex *dex_open(const char *path, Arena *arena, char *err, size_t errlen);
/* Builds a Dex view over an in-memory buffer (used for APK entries). */
Dex *dex_open_memory(const uint8_t *data, size_t size, Arena *arena, char *err, size_t errlen);
void dex_close(Dex *dex);

/* --- accessors -------------------------------------------------------- */

const char *dex_string(Dex *dex, uint32_t idx);
const char *dex_type_desc(Dex *dex, uint32_t idx);
const char *dex_type_name(Dex *dex, uint32_t idx);
const char *dex_method_name(Dex *dex, uint32_t idx);
const char *dex_field_name(Dex *dex, uint32_t idx);
const char *dex_proto_shorty(Dex *dex, uint32_t idx);
DexParamList *dex_proto_params(Dex *dex, uint32_t proto_idx);

/* --- class data ------------------------------------------------------- */

struct DexClassDataTag {
    DexEncodedField *static_fields;
    uint32_t static_count;
    DexEncodedField *instance_fields;
    uint32_t instance_count;
    DexEncodedMethod *direct_methods;
    uint32_t direct_count;
    DexEncodedMethod *virtual_methods;
    uint32_t virtual_count;
};

const DexClassData *dex_class_data(Dex *dex, uint32_t class_def_idx);
DexCode *dex_code(Dex *dex, uint32_t code_off);
DexDebugInfo *dex_debug_info(Dex *dex, uint32_t debug_off, uint32_t param_count);
const DexClassAnnotations *dex_class_annotations(Dex *dex, uint32_t off);
uint32_t dex_static_values(Dex *dex, uint32_t static_values_off, DexValue **vals);

/* --- diagnostics ------------------------------------------------------ */

/* Returns 1 when some class in the dex lists `type_idx` as its superclass. */
int dex_class_has_subclass(Dex *dex, uint32_t type_idx);
uint32_t dex_class_def_of_type(Dex *dex, uint32_t type_idx);

const char *dex_access_string(uint32_t flags);
/* Same, but resolves the flag bits that collide between fields and methods
 * (ACC_VOLATILE/ACC_BRIDGE and ACC_TRANSIENT/ACC_VARARGS share values). */
const char *dex_access_string_for(uint32_t flags, int is_method);
void dex_describe(Dex *dex, Buf *out);

#endif
