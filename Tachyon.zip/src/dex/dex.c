#include "dex/dex.h"

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/* bounds-checked little-endian readers                                */
/* ------------------------------------------------------------------ */

typedef struct {
    const uint8_t *base;
    size_t size;
    int bad;
} Rd;

static inline int rd_ok(Rd *r, size_t off, size_t len)
{
    if (r->bad)
        return 0;
    if (off > r->size || len > r->size - off) {
        r->bad = 1;
        return 0;
    }
    return 1;
}

static inline uint8_t rd_u1(Rd *r, size_t off)
{
    if (!rd_ok(r, off, 1))
        return 0;
    return r->base[off];
}

static inline uint16_t rd_u2(Rd *r, size_t off)
{
    if (!rd_ok(r, off, 2))
        return 0;
    return (uint16_t)(r->base[off] | (r->base[off + 1] << 8));
}

static inline uint32_t rd_u4(Rd *r, size_t off)
{
    if (!rd_ok(r, off, 4))
        return 0;
    return (uint32_t)r->base[off] | ((uint32_t)r->base[off + 1] << 8) |
           ((uint32_t)r->base[off + 2] << 16) | ((uint32_t)r->base[off + 3] << 24);
}

static inline uint32_t u4(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static inline uint16_t u2(const uint8_t *p)
{
    return (uint16_t)(p[0] | (p[1] << 8));
}

/* uleb128 with overflow protection; returns number of bytes consumed (>=1). */
static uint32_t rd_uleb(Rd *r, size_t off, uint32_t *out)
{
    uint32_t result = 0;
    uint32_t shift = 0;
    size_t p = off;
    for (int i = 0; i < 5; i++) {
        uint8_t b = rd_u1(r, p);
        if (r->bad)
            return 0;
        result |= (uint32_t)(b & 0x7f) << shift;
        p++;
        if (!(b & 0x80)) {
            *out = result;
            return (uint32_t)(p - off);
        }
        shift += 7;
    }
    r->bad = 1;
    return 0;
}

/* ------------------------------------------------------------------ */
/* header                                                              */
/* ------------------------------------------------------------------ */

static int dex_parse_header(Rd *r, DexHeader *h)
{
    if (r->size < 0x70) {
        r->bad = 1;
        return -1;
    }
    static const char magic[] = "dex\n";
    if (memcmp(r->base, magic, 4) != 0) {
        r->bad = 1;
        return -1;
    }
    uint32_t endian = rd_u4(r, 40);
    if (endian != DEX_ENDIAN_CONSTANT) {
        r->bad = 1;
        return -1;
    }
    h->checksum = rd_u4(r, 8);
    memcpy(h->version, r->base + 4, 4);
    h->header_size = rd_u4(r, 0x24);
    h->string_ids_size = rd_u4(r, 0x38);
    h->string_ids_off = rd_u4(r, 0x3c);
    h->type_ids_size = rd_u4(r, 0x40);
    h->type_ids_off = rd_u4(r, 0x44);
    h->proto_ids_size = rd_u4(r, 0x48);
    h->proto_ids_off = rd_u4(r, 0x4c);
    h->field_ids_size = rd_u4(r, 0x50);
    h->field_ids_off = rd_u4(r, 0x54);
    h->method_ids_size = rd_u4(r, 0x58);
    h->method_ids_off = rd_u4(r, 0x5c);
    h->class_defs_size = rd_u4(r, 0x60);
    h->class_defs_off = rd_u4(r, 0x64);
    h->data_size = rd_u4(r, 0x68);
    h->data_off = rd_u4(r, 0x6c);
    h->link_size = rd_u4(r, 0x2c);
    h->link_off = rd_u4(r, 0x30);
    h->map_off = rd_u4(r, 0x34);
    h->file_size = rd_u4(r, 0x20);
    return r->bad ? -1 : 0;
}

/* Validates that a table of `count` items of `item_size` at `off` is in bounds. */
static int check_table(Rd *r, uint32_t off, uint32_t count, size_t item_size)
{
    if (count == 0)
        return 1;
    uint64_t need = (uint64_t)count * item_size;
    return off <= r->size && need <= (uint64_t)r->size - off;
}

/* ------------------------------------------------------------------ */
/* open / close                                                        */
/* ------------------------------------------------------------------ */

static Dex *dex_setup(const uint8_t *data, size_t size, Arena *arena, char *err,
                      size_t errlen)
{
    Rd r = { data, size, 0 };
    DexHeader h;
    if (dex_parse_header(&r, &h)) {
        snprintf(err, errlen, "not a valid dex file (bad magic/endian/truncated)");
        return NULL;
    }

#define FAILF(...)                                                              \
    do {                                                                        \
        snprintf(err, errlen, __VA_ARGS__);                                     \
        return NULL;                                                            \
    } while (0)

    if (!check_table(&r, h.string_ids_off, h.string_ids_size, 4))
        FAILF("string_ids table out of bounds");
    if (!check_table(&r, h.type_ids_off, h.type_ids_size, 4))
        FAILF("type_ids table out of bounds");
    if (!check_table(&r, h.proto_ids_off, h.proto_ids_size, 12))
        FAILF("proto_ids table out of bounds");
    if (!check_table(&r, h.field_ids_off, h.field_ids_size, 8))
        FAILF("field_ids table out of bounds");
    if (!check_table(&r, h.method_ids_off, h.method_ids_size, 8))
        FAILF("method_ids table out of bounds");
    if (!check_table(&r, h.class_defs_off, h.class_defs_size, 32))
        FAILF("class_defs table out of bounds");
#undef FAILF

    Dex *d = arena_zalloc(arena, sizeof(*d));
    if (!d) {
        snprintf(err, errlen, "out of memory");
        return NULL;
    }
    d->base = data;
    d->size = size;
    d->hdr = h;
    d->arena = arena;

    d->strings = (const DexStringId *)(data + (h.string_ids_size ? h.string_ids_off : 0));
    d->types = (const DexTypeId *)(data + (h.type_ids_size ? h.type_ids_off : 0));
    d->protos = (const DexProtoId *)(data + (h.proto_ids_size ? h.proto_ids_off : 0));
    d->fields = (const DexFieldId *)(data + (h.field_ids_size ? h.field_ids_off : 0));
    d->methods = (const DexMethodId *)(data + (h.method_ids_size ? h.method_ids_off : 0));
    d->classes = (const DexClassDef *)(data + (h.class_defs_size ? h.class_defs_off : 0));

    /* Pre-allocate every lazy cache table here, single-threaded, so worker
     * threads only ever read these pointers. Without this the first-use checks
     * race and two threads can install different tables. */
    if (h.string_ids_size)
        d->string_cache = arena_zalloc(arena, (size_t)h.string_ids_size * sizeof(char *));
    if (h.proto_ids_size)
        d->proto_params = arena_zalloc(arena, (size_t)h.proto_ids_size * sizeof(DexParamList *));
    if (h.type_ids_size)
        d->type_name_cache = arena_zalloc(arena, (size_t)h.type_ids_size * sizeof(char *));
    if (h.class_defs_size) {
        d->class_data_cache =
            arena_zalloc(arena, (size_t)h.class_defs_size * sizeof(DexClassData *));
        d->code_cache_cap = 64;
        while (d->code_cache_cap < h.class_defs_size * 4)
            d->code_cache_cap <<= 1;
        d->code_cache = arena_zalloc(arena, (size_t)d->code_cache_cap * sizeof(DexCode *));
        d->code_keys = arena_zalloc(arena, (size_t)d->code_cache_cap * sizeof(uint32_t));

        d->type_to_class_def =
            arena_alloc(arena, ((size_t)h.type_ids_size + 1) * sizeof(uint32_t));
        d->has_subclass = arena_zalloc(arena, (size_t)h.type_ids_size + 1);
        if (d->type_to_class_def) {
            for (uint32_t i = 0; i <= h.type_ids_size; i++)
                d->type_to_class_def[i] = DEX_NO_INDEX;
            for (uint32_t i = 0; i < h.class_defs_size; i++) {
                uint32_t t = d->classes[i].class_idx;
                if (t < h.type_ids_size)
                    d->type_to_class_def[t] = i;
                uint32_t sup = d->classes[i].superclass_idx;
                if (sup != DEX_NO_INDEX && sup < h.type_ids_size)
                    d->has_subclass[sup] = 1;
            }
        }
    }
    return d;
}

Dex *dex_open_memory(const uint8_t *data, size_t size, Arena *arena, char *err,
                     size_t errlen)
{
    return dex_setup(data, size, arena, err, errlen);
}

Dex *dex_open(const char *path, Arena *arena, char *err, size_t errlen)
{
    MappedFile *m = malloc(sizeof(*m));
    if (!m) {
        snprintf(err, errlen, "out of memory");
        return NULL;
    }
    if (io_map(path, m) < 0) {
        snprintf(err, errlen, "cannot read '%s': %s", path, strerror(errno));
        free(m);
        return NULL;
    }
    Dex *d = dex_setup(m->data, m->len, arena, err, errlen);
    if (!d) {
        io_unmap(m);
        free(m);
        return NULL;
    }
    d->path = arena_strdup(arena, path);
    d->mapped = m;
    return d;
}

void dex_close(Dex *d)
{
    if (!d)
        return;
    if (d->mapped) {
        io_unmap(d->mapped);
        free(d->mapped);
        d->mapped = NULL;
    }
}

/* ------------------------------------------------------------------ */
/* MUTF-8 decoding                                                     */
/* ------------------------------------------------------------------ */

/* Decodes a DEX MUTF-8 string at *off into out (NUL terminated). Returns the
 * number of bytes consumed from the source, or 0 on error. */
static size_t mutf8_decode(const uint8_t *base, size_t size, size_t off, char *out,
                           size_t outcap)
{
    size_t i = off, o = 0;
    if (off >= size)
        return 0;
    /* skip the utf16 length prefix (uleb128) */
    for (int k = 0; k < 5; k++) {
        if (i >= size)
            return 0;
        uint8_t b = base[i++];
        if (!(b & 0x80))
            break;
    }
    for (;;) {
        if (i >= size)
            return 0;
        uint8_t b = base[i];
        if (b == 0)
            break;
        if (b < 0x80) {
            if (o + 1 >= outcap)
                return 0;
            out[o++] = (char)b;
            i++;
        } else if ((b & 0xe0) == 0xc0) {
            if (i + 1 >= size || o + 2 >= outcap)
                return 0;
            uint32_t cp = ((b & 0x1f) << 6) | (base[i + 1] & 0x3f);
            o += (size_t)utf8_encode(cp, out + o);
            i += 2;
        } else if ((b & 0xf0) == 0xe0) {
            if (i + 2 >= size || o + 4 >= outcap)
                return 0;
            uint32_t cp = ((b & 0x0f) << 12) | ((base[i + 1] & 0x3f) << 6) |
                          (base[i + 2] & 0x3f);
            /* MUTF-8 encodes anything above U+FFFF as a UTF-16 surrogate pair of
             * two 3-byte sequences. Java strings are UTF-16, so this is the
             * normal case for emoji and CJK extension blocks; without joining
             * them the output contains invalid UTF-8. */
            if (cp >= 0xd800 && cp <= 0xdbff && i + 5 < size &&
                (base[i + 3] & 0xf0) == 0xe0) {
                uint32_t lo = ((base[i + 3] & 0x0f) << 12) |
                              ((base[i + 4] & 0x3f) << 6) | (base[i + 5] & 0x3f);
                if (lo >= 0xdc00 && lo <= 0xdfff) {
                    cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
                    i += 6;
                    out[o++] = (char)(0xf0 | (cp >> 18));
                    out[o++] = (char)(0x80 | ((cp >> 12) & 0x3f));
                    out[o++] = (char)(0x80 | ((cp >> 6) & 0x3f));
                    out[o++] = (char)(0x80 | (cp & 0x3f));
                    continue;
                }
            }
            o += (size_t)utf8_encode(cp, out + o);
            i += 3;
        } else {
            return 0;
        }
    }
    out[o] = '\0';
    return i + 1 - off;
}

size_t utf8_encode(uint32_t cp, char *out)
{
    if (cp < 0x80) {
        out[0] = (char)cp;
        return 1;
    }
    if (cp < 0x800) {
        out[0] = (char)(0xc0 | (cp >> 6));
        out[1] = (char)(0x80 | (cp & 0x3f));
        return 2;
    }
    out[0] = (char)(0xe0 | (cp >> 12));
    out[1] = (char)(0x80 | ((cp >> 6) & 0x3f));
    out[2] = (char)(0x80 | (cp & 0x3f));
    return 3;
}

static uint32_t enc_sleb(const uint8_t *base, size_t size, size_t off, int64_t *out,
                         int *bad);

/* ------------------------------------------------------------------ */
/* accessors                                                           */
/* ------------------------------------------------------------------ */

/* Upper bound on a MUTF-8 payload's encoded size, from the uleb128 UTF-16 length
 * at `off`. MUTF-8 uses at most three bytes per UTF-16 unit, so this is exact
 * enough to allocate once. Returns 0 when the prefix runs past the file. */
static size_t mutf8_max_bytes(Dex *d, uint32_t off)
{
    size_t p = off;
    uint32_t units = 0;
    for (int shift = 0; shift < 35 && p < d->size; shift += 7) {
        uint8_t b = d->base[p++];
        units |= (uint32_t)(b & 0x7f) << shift;
        if (!(b & 0x80))
            break;
    }
    if (p > d->size)
        return 0;
    size_t cap = (size_t)units * 3 + 8;
    size_t left = d->size - off + 8;
    return cap < left ? cap : left;
}

const char *dex_string(Dex *d, uint32_t idx)
{
    if (idx >= d->hdr.string_ids_size)
        return "<bad-string>";
    if (!d->string_cache)
        return "<oom>";
    const char *c = d->string_cache[idx];
    if (c)
        return c;

    /* data_off of the string_id marks the start of its MUTF-8 payload */
    uint32_t off = u4(d->base + d->hdr.string_ids_off + (size_t)idx * 4);
    if (off >= d->size)
        return "<bad-string>";

    /* Size the buffer from the string itself. Allocating the whole remaining
     * file per string (the old behaviour) reserved megabytes for a few dozen
     * bytes, and on a multi-dex app the arena ran out and every later allocation
     * failed. */
    /* Allocating the whole remaining file per string (the old behaviour) reserved
     * megabytes for a few dozen bytes; on a multi-dex app the arena ran out and
     * every later allocation failed. Size it from the string's own length. */
    size_t cap = mutf8_max_bytes(d, off);
    if (cap == 0)
        return "<bad-utf8>";
    char *buf = arena_alloc(d->arena, cap);
    if (!buf)
        return "<oom>";
    size_t n = mutf8_decode(d->base, d->size, off, buf, cap);
    if (n == 0) {
        d->string_cache[idx] = "<bad-utf8>";
        return d->string_cache[idx];
    }
    d->string_cache[idx] = buf;
    return buf;
}

const char *dex_type_desc(Dex *d, uint32_t idx)
{
    if (idx >= d->hdr.type_ids_size)
        return "<bad-type>";
    return dex_string(d, u4(d->base + d->hdr.type_ids_off + (size_t)idx * 4));
}

const char *dex_method_name(Dex *d, uint32_t idx)
{
    if (idx >= d->hdr.method_ids_size)
        return "<bad-method>";
    return dex_string(d, u4(d->base + d->hdr.method_ids_off + (size_t)idx * 8 + 4));
}

const char *dex_field_name(Dex *d, uint32_t idx)
{
    if (idx >= d->hdr.field_ids_size)
        return "<bad-field>";
    return dex_string(d, u4(d->base + d->hdr.field_ids_off + (size_t)idx * 8 + 4));
}

const char *dex_proto_shorty(Dex *d, uint32_t idx)
{
    if (idx >= d->hdr.proto_ids_size)
        return "<bad-proto>";
    return dex_string(d, u4(d->base + d->hdr.proto_ids_off + (size_t)idx * 12));
}

DexParamList *dex_proto_params(Dex *d, uint32_t proto_idx)
{
    if (proto_idx >= d->hdr.proto_ids_size)
        return NULL;
    if (!d->proto_params)
        return NULL;
    DexParamList *pl = d->proto_params[proto_idx];
    if (pl)
        return pl;

    uint32_t poff = u4(d->base + d->hdr.proto_ids_off + (size_t)proto_idx * 12 + 8);
    pl = arena_zalloc(d->arena, sizeof(*pl));
    if (!pl)
        return NULL;
    if (poff != 0 && poff < d->size) {
        Rd r = { d->base, d->size, 0 };
        uint32_t n = rd_u4(&r, poff);
        if (!r.bad && n < 0x10000) {
            size_t base = (size_t)poff + 4;
            if (base <= d->size && (uint64_t)n * 2 <= (uint64_t)d->size - base) {
                pl->param_count = n;
                pl->type_idx = arena_alloc(d->arena, (size_t)n * sizeof(uint32_t) + 4);
                if (pl->type_idx) {
                    for (uint32_t i = 0; i < n; i++)
                        pl->type_idx[i] = u2(d->base + base + (size_t)i * 2);
                }
            }
        }
    }
    d->proto_params[proto_idx] = pl;
    return pl;
}

/* ------------------------------------------------------------------ */
/* class data                                                          */
/* ------------------------------------------------------------------ */

const DexClassData *dex_class_data_uncached(Dex *d, uint32_t class_def_idx);

const DexClassData *dex_class_data(Dex *d, uint32_t class_def_idx)
{
    if (class_def_idx >= d->hdr.class_defs_size)
        return NULL;
    if (d->class_data_cache) {
        const DexClassData *cached = d->class_data_cache[class_def_idx];
        if (cached)
            return cached;
        DexClassData *built = (DexClassData *)dex_class_data_uncached(d, class_def_idx);
        d->class_data_cache[class_def_idx] = built;
        return built;
    }
    return dex_class_data_uncached(d, class_def_idx);
}

const DexClassData *dex_class_data_uncached(Dex *d, uint32_t class_def_idx)
{
    const DexClassDef *cd = &d->classes[class_def_idx];
    if (cd->class_data_off == 0 || cd->class_data_off >= d->size)
        return NULL;

    Rd r = { d->base, d->size, 0 };
    size_t p = cd->class_data_off;
    uint32_t sf, inf, dm, vm;
    p += rd_uleb(&r, p, &sf);
    p += rd_uleb(&r, p, &inf);
    p += rd_uleb(&r, p, &dm);
    p += rd_uleb(&r, p, &vm);
    if (r.bad)
        return NULL;
    /* sanity: a class cannot have more members than the global table */
    if (sf > d->hdr.field_ids_size || inf > d->hdr.field_ids_size ||
        dm > d->hdr.method_ids_size || vm > d->hdr.method_ids_size)
        return NULL;

    DexClassData *out = arena_zalloc(d->arena, sizeof(*out));
    if (!out)
        return NULL;

    uint32_t total_f = sf + inf;
    uint32_t total_m = dm + vm;
    DexEncodedField *fs = arena_alloc(d->arena, ((size_t)total_f + 1) * sizeof(*fs));
    DexEncodedMethod *ms = arena_alloc(d->arena, ((size_t)total_m + 1) * sizeof(*ms));
    if (!fs || !ms)
        return NULL;

    /* Per the DEX spec, field_idx_diff and method_idx_diff restart from zero at
     * each section boundary (static/instance fields, direct/virtual methods).
     * Carrying one running index across sections misaligns every class whose
     * sections are not globally ordered. */
    uint32_t fidx = 0;
    for (uint32_t i = 0; i < total_f; i++) {
        uint32_t diff, acc;
        p += rd_uleb(&r, p, &diff);
        p += rd_uleb(&r, p, &acc);
        if (r.bad)
            return NULL;
        if (i == sf)
            fidx = 0;
        if (diff >= d->hdr.field_ids_size || fidx + diff >= d->hdr.field_ids_size) {
            uint32_t kept = i;
            out->static_fields = fs;
            out->static_count = kept < sf ? kept : sf;
            out->instance_fields = fs + sf;
            out->instance_count = (kept > sf ? kept - sf : 0);
            out->direct_methods = ms;
            out->direct_count = 0;
            out->virtual_methods = ms;
            out->virtual_count = 0;
            return out;
        }
        fidx += diff;
        fs[i].field_idx = fidx;
        fs[i].access_flags = acc;
    }

    uint32_t midx = 0;
    for (uint32_t i = 0; i < total_m; i++) {
        uint32_t diff, acc, code;
        p += rd_uleb(&r, p, &diff);
        p += rd_uleb(&r, p, &acc);
        p += rd_uleb(&r, p, &code);
        if (r.bad)
            return out;
        if (i == dm)
            midx = 0;
        if (diff >= d->hdr.method_ids_size || midx + diff >= d->hdr.method_ids_size) {
            out->direct_methods = ms;
            out->direct_count = i < dm ? i : dm;
            out->virtual_methods = ms + dm;
            out->virtual_count = (i > dm ? i - dm : 0);
            return out;
        }
        midx += diff;
        ms[i].method_idx = midx;
        ms[i].access_flags = acc;
        ms[i].code_off = code;
    }

    out->static_fields = fs;
    out->static_count = sf;
    out->instance_fields = fs + sf;
    out->instance_count = inf;
    out->direct_methods = ms;
    out->direct_count = dm;
    out->virtual_methods = ms + dm;
    out->virtual_count = vm;
    return out;
}

static DexCode *dex_code_uncached(Dex *d, uint32_t code_off);

DexCode *dex_code(Dex *d, uint32_t code_off)
{
    if (code_off == 0 || code_off >= d->size)
        return NULL;
    if (!d->code_cache || d->code_cache_cap == 0)
        return dex_code_uncached(d, code_off);

    uint32_t mask = d->code_cache_cap - 1;
    uint32_t k = (code_off * 2654435761u) & mask;
    for (uint32_t probe = 0; probe < d->code_cache_cap; probe++) {
        if (d->code_keys[k] == code_off) {
            DexCode *hit = d->code_cache[k];
            if (hit)
                return hit;
            break;
        }
        if (d->code_keys[k] == 0)
            break;
        k = (k + 1) & mask;
    }

    DexCode *built = dex_code_uncached(d, code_off);
    if (!built)
        return NULL;

    /* Publish under a lock: two workers can reach the same item at once. */
    static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&lock);
    k = (code_off * 2654435761u) & mask;
    for (uint32_t probe = 0; probe < d->code_cache_cap; probe++) {
        if (d->code_keys[k] == code_off || d->code_keys[k] == 0) {
            d->code_keys[k] = code_off;
            d->code_cache[k] = built;
            break;
        }
        k = (k + 1) & mask;
    }
    pthread_mutex_unlock(&lock);
    return built;
}

static DexCode *dex_code_uncached(Dex *d, uint32_t code_off)
{
    Rd r = { d->base, d->size, 0 };
    DexCode *c = arena_zalloc(d->arena, sizeof(*c));
    if (!c)
        return NULL;
    size_t p = code_off;
    c->registers_size = rd_u2(&r, p);
    c->ins_size = rd_u2(&r, p + 2);
    c->outs_size = rd_u2(&r, p + 4);
    c->tries_size = rd_u2(&r, p + 6);
    c->debug_info_off = rd_u4(&r, p + 8);
    c->insns_size = rd_u4(&r, p + 12);
    if (r.bad || c->insns_size > 0x1000000)
        return NULL;
    size_t insn_off = p + 16;
    if (insn_off > d->size || (uint64_t)c->insns_size * 2 > (uint64_t)d->size - insn_off)
        return NULL;
    c->insns = (const uint16_t *)(d->base + insn_off);

    if (c->tries_size) {
        /* tries[] is 4-byte aligned after the insns array */
        size_t t = (insn_off + (size_t)c->insns_size * 2 + 3) & ~(size_t)3;
        if (t > d->size || (uint64_t)c->tries_size * 8 > (uint64_t)d->size - t)
            return NULL;
        c->tries = arena_zalloc(d->arena, (size_t)c->tries_size * sizeof(DexTryBlock));
        if (!c->tries)
            return NULL;
        r.bad = 0;
        for (uint32_t i = 0; i < c->tries_size; i++) {
            DexTryBlock *tb = &c->tries[i];
            tb->start_addr = rd_u4(&r, t + (size_t)i * 8);
            tb->insn_count = rd_u2(&r, t + (size_t)i * 8 + 4);
            tb->handler_count = rd_u2(&r, t + (size_t)i * 8 + 6);
            tb->handlers = arena_zalloc(
                d->arena, ((size_t)tb->handler_count + 1) * sizeof(DexHandler));
            if (!tb->handlers)
                return NULL;
        }
        /* The encoded_catch_handler_list follows the tries array; handlers are
         * sleb128-prefixed and variable length, so it must be walked in order. */
        size_t hp = t + (size_t)c->tries_size * 8;
        uint32_t list_size = 0;
        hp += rd_uleb(&r, hp, &list_size);
        if (r.bad || list_size > c->tries_size)
            return NULL;
        for (uint32_t i = 0; i < list_size; i++) {
            DexTryBlock *tb = &c->tries[i];
            int64_t size = 0;
            hp += enc_sleb(d->base, d->size, hp, &size, &r.bad);
            if (r.bad)
                return NULL;
            int64_t typed = size < 0 ? -size : size;
            uint32_t written = 0;
            for (int64_t k = 0; k < typed; k++) {
                uint32_t tidx = 0, addr = 0;
                hp += rd_uleb(&r, hp, &tidx);
                hp += rd_uleb(&r, hp, &addr);
                if (r.bad)
                    return NULL;
                if (written < tb->handler_count) {
                    tb->handlers[written].type_idx = tidx;
                    tb->handlers[written].addr = addr;
                    written++;
                }
            }
            if (size <= 0) {
                uint32_t addr = 0;
                hp += rd_uleb(&r, hp, &addr);
                if (r.bad)
                    return NULL;
                if (written < tb->handler_count) {
                    tb->handlers[written].type_idx = DEX_NO_INDEX;
                    tb->handlers[written].addr = addr;
                    written++;
                }
            }
            tb->handler_count = (uint16_t)written;
        }
    }
    return c;
}

DexDebugInfo *dex_debug_info(Dex *d, uint32_t debug_off, uint32_t param_count)
{
    if (debug_off == 0 || debug_off >= d->size)
        return NULL;
    DexDebugInfo *di = arena_zalloc(d->arena, sizeof(*di));
    if (!di)
        return NULL;

    Rd r = { d->base, d->size, 0 };
    size_t p = debug_off;
    uint32_t line;
    p += rd_uleb(&r, p, &line);
    di->line_start = line;
    p += rd_uleb(&r, p, &di->params_size);
    if (r.bad || di->params_size > 0x10000)
        return NULL;

    di->param_names = arena_zalloc(d->arena, ((size_t)di->params_size + 1) * sizeof(char *));
    if (!di->param_names)
        return NULL;
    for (uint32_t i = 0; i < di->params_size; i++) {
        uint32_t sidx;
        p += rd_uleb(&r, p, &sidx);
        if (r.bad)
            return NULL;
        di->param_names[i] = sidx ? dex_string(d, sidx - 1) : NULL;
    }

    /* growable arrays for line table and locals */
    uint32_t line_cap = 32, local_cap = 8;
    di->lines = arena_alloc(d->arena, (size_t)line_cap * sizeof(DexLineEntry));
    di->locals = arena_alloc(d->arena, (size_t)local_cap * sizeof(DexDebugLocal));
    if (!di->lines || !di->locals)
        return NULL;

    uint32_t addr = 0;
    for (;;) {
        uint8_t op = rd_u1(&r, p);
        if (r.bad)
            break;
        p++;
        if (op == 0x00) { /* DBG_END_SEQUENCE */
            break;
        } else if (op == 0x01) { /* DBG_ADVANCE_PC */
            uint32_t delta = 0;
            p += rd_uleb(&r, p, &delta);
            if (r.bad)
                break;
            addr += delta;
        } else if (op == 0x02) { /* DBG_ADVANCE_LINE */
            int64_t delta = 0;
            p += enc_sleb(d->base, d->size, p, &delta, &r.bad);
            if (r.bad)
                break;
            line = (uint32_t)((int64_t)line + delta);
        } else if (op == 0x03 || op == 0x04) { /* START_LOCAL / START_LOCAL_EXTENDED */
            uint32_t reg = 0, nidx = 0, tidx = 0, sidx = 0;
            p += rd_uleb(&r, p, &reg);
            p += rd_uleb(&r, p, &nidx);
            p += rd_uleb(&r, p, &tidx);
            if (op == 0x04)
                p += rd_uleb(&r, p, &sidx);
            if (r.bad)
                break;
            if (di->local_count == local_cap) {
                local_cap *= 2;
                DexDebugLocal *nl = arena_alloc(d->arena, (size_t)local_cap * sizeof(*nl));
                if (!nl)
                    break;
                memcpy(nl, di->locals, (size_t)di->local_count * sizeof(*nl));
                di->locals = nl;
            }
            DexDebugLocal *dl = &di->locals[di->local_count++];
            memset(dl, 0, sizeof(*dl));
            dl->start_addr = addr;
            dl->register_num = (uint16_t)reg;
            dl->name = nidx ? dex_string(d, nidx - 1) : NULL;
            dl->type = tidx ? dex_type_desc(d, tidx - 1) : NULL;
            dl->sig = sidx ? dex_string(d, sidx - 1) : NULL;
        } else if (op == 0x05) { /* END_LOCAL */
            uint32_t reg = 0;
            p += rd_uleb(&r, p, &reg);
            if (r.bad)
                break;
        } else if (op == 0x06) { /* DBG_RESTART_LOCAL */
            uint32_t reg = 0;
            p += rd_uleb(&r, p, &reg);
            if (r.bad)
                break;
        } else if (op == 0x07 || op == 0x08) {
            /* DBG_SET_PROLOGUE_END / DBG_SET_EPILOGUE_BEGIN: no payload */
        } else if (op == 0x09) { /* DBG_SET_FILE */
            uint32_t sidx = 0;
            p += rd_uleb(&r, p, &sidx);
            if (r.bad)
                break;
        } else { /* 0x0a..0xff: special opcode, 15 lines x 1 PC unit per step */
            uint32_t special = (uint32_t)(op - 0x0a);
            addr += special / 15;
            line = (uint32_t)((int64_t)line - 4 + (int64_t)(special % 15));
            if (di->line_count == line_cap) {
                line_cap *= 2;
                DexLineEntry *nl = arena_alloc(d->arena, (size_t)line_cap * sizeof(*nl));
                if (!nl)
                    break;
                memcpy(nl, di->lines, (size_t)di->line_count * sizeof(*nl));
                di->lines = nl;
            }
            di->lines[di->line_count].addr = addr;
            di->lines[di->line_count].line = (int32_t)line;
            di->line_count++;
        }
    }
    return di;
}

/* ------------------------------------------------------------------ */
/* annotations / values                                                */
/* ------------------------------------------------------------------ */

static uint32_t enc_uleb(const uint8_t *base, size_t size, size_t off, uint64_t *out,
                         int *bad)
{
    uint64_t result = 0;
    uint32_t shift = 0;
    size_t p = off;
    for (int i = 0; i < 10; i++) {
        if (p >= size) {
            *bad = 1;
            return 0;
        }
        uint8_t b = base[p++];
        result |= (uint64_t)(b & 0x7f) << shift;
        if (!(b & 0x80)) {
            *out = result;
            return (uint32_t)(p - off);
        }
        shift += 7;
    }
    *bad = 1;
    return 0;
}

static uint32_t enc_sleb(const uint8_t *base, size_t size, size_t off, int64_t *out,
                         int *bad)
{
    int64_t result = 0;
    int shift = 0;
    size_t p = off;
    for (int i = 0; i < 10; i++) {
        if (p >= size) {
            *bad = 1;
            return 0;
        }
        uint8_t b = base[p++];
        result |= (int64_t)(b & 0x7f) << shift;
        shift += 7;
        if (!(b & 0x80)) {
            if (shift < 64 && (b & 0x40))
                result |= -((int64_t)1 << shift);
            *out = result;
            return (uint32_t)(p - off);
        }
    }
    *bad = 1;
    return 0;
}

static uint32_t dex_read_encoded_value(Dex *d, size_t off, DexValue *v);

static uint32_t dex_read_encoded_array(Dex *d, size_t off, DexValue **arr, uint32_t *count)
{
    int bad = 0;
    uint64_t n = 0;
    uint32_t used = enc_uleb(d->base, d->size, off, &n, &bad);
    if (bad || n > 0x100000) {
        *arr = NULL;
        *count = 0;
        return used ? used : 1;
    }
    DexValue *a = arena_zalloc(d->arena, ((size_t)n + 1) * sizeof(DexValue));
    if (!a) {
        *arr = NULL;
        *count = 0;
        return used;
    }
    size_t p = (size_t)off + used;
    for (uint64_t i = 0; i < n; i++)
        p += dex_read_encoded_value(d, p, &a[i]);
    *arr = a;
    *count = (uint32_t)n;
    return (uint32_t)(p - off);
}

static uint32_t dex_read_encoded_value(Dex *d, size_t off, DexValue *v)
{
    memset(v, 0, sizeof(*v));
    if (off >= d->size)
        return 1;
    uint8_t hdr = d->base[off];
    v->value_type = (uint8_t)(hdr & 0x1f);
    v->value_arg = (uint8_t)(hdr >> 5);
    size_t p = off + 1;
    uint32_t n = (uint32_t)v->value_arg + 1;

    switch (v->value_type) {
    case 0x00: /* byte */
    case 0x02: /* short */
    case 0x04: /* int */
    case 0x06: /* long */
    case 0x10: /* float */
    case 0x11: /* double */
    {
        if (p + n > d->size)
            return 1;
        uint64_t acc = 0;
        for (uint32_t i = 0; i < n; i++)
            acc |= (uint64_t)d->base[p + i] << (8 * i);
        /* Integer encodings are sign-extended from the encoded width: a 4-byte
         * value with the top bit set is a negative int, not a large positive
         * one. Without this, negative long constants print as huge numbers. */
        if (v->value_type == 0x00 || v->value_type == 0x02 ||
            v->value_type == 0x04 || v->value_type == 0x06) {
            if (n < 8 && (acc & ((uint64_t)1 << (n * 8 - 1))))
                acc |= ~((uint64_t)0) << (n * 8);
        }
        v->v.u = acc;
        v->raw = d->base + p;
        v->raw_size = n;
        return 1 + n;
    }
    case 0x03: /* char */
    case 0x05: /* int (already) */
    case 0x01:
        break;
    default:
        break;
    }

    switch (v->value_type) {
    case 0x15: /* method_type */
    case 0x16: /* method_handle */
    case 0x17: /* string */
    case 0x18: /* type */
    case 0x19: /* field */
    case 0x1a: /* method */
    case 0x1b: /* enum */
    {
        uint64_t acc = 0;
        if (p + n > d->size)
            return 1;
        for (uint32_t i = 0; i < n; i++)
            acc |= (uint64_t)d->base[p + i] << (8 * i);
        v->v.u = acc;
        return 1 + n;
    }
    case 0x1c: /* array */
    {
        DexValue *a;
        uint32_t c;
        uint32_t used = dex_read_encoded_array(d, p, &a, &c);
        v->v.raw = a;
        v->raw_size = c;
        return 1 + used;
    }
    case 0x1d: /* annotation */
    case 0x1e: /* null */
    case 0x1f: /* boolean */
    default:
        break;
    }
    return 1 + n;
}

uint32_t dex_static_values(Dex *d, uint32_t static_values_off, DexValue **vals)
{
    *vals = NULL;
    if (static_values_off == 0 || static_values_off >= d->size)
        return 0;
    DexValue *a;
    uint32_t c;
    dex_read_encoded_array(d, static_values_off, &a, &c);
    *vals = a;
    return c;
}

const DexClassAnnotations *dex_class_annotations(Dex *d, uint32_t off)
{
    if (off == 0 || off >= d->size)
        return NULL;
    DexClassAnnotations *ca = arena_zalloc(d->arena, sizeof(*ca));
    if (!ca)
        return NULL;
    Rd r = { d->base, d->size, 0 };
    ca->class_annotations_off = rd_u4(&r, off);
    ca->fields_size = rd_u4(&r, off + 4);
    ca->methods_size = rd_u4(&r, off + 8);
    if (r.bad)
        return NULL;
    size_t p = off + 12;
    if ((uint64_t)ca->fields_size * 8 > (uint64_t)d->size - p)
        return NULL;
    ca->fields = arena_zalloc(d->arena, ((size_t)ca->fields_size + 1) * sizeof(DexFieldAnnotItem));
    for (uint32_t i = 0; i < ca->fields_size; i++) {
        ca->fields[i].field_idx = rd_u4(&r, p);
        ca->fields[i].annotations_off = rd_u4(&r, p + 4);
        p += 8;
    }
    if ((uint64_t)ca->methods_size * 8 > (uint64_t)d->size - p)
        return NULL;
    ca->methods = arena_zalloc(d->arena, ((size_t)ca->methods_size + 1) * sizeof(DexMethodAnnotItem));
    for (uint32_t i = 0; i < ca->methods_size; i++) {
        ca->methods[i].method_idx = rd_u4(&r, p);
        ca->methods[i].annotations_off = rd_u4(&r, p + 4);
        p += 8;
    }
    return ca;
}

/* ------------------------------------------------------------------ */
/* naming helpers                                                      */
/* ------------------------------------------------------------------ */

const char *dex_type_name(Dex *d, uint32_t idx)
{
    if (idx >= d->hdr.type_ids_size)
        return dex_type_desc(d, idx);
    if (!d->type_name_cache)
        return dex_type_desc(d, idx);
    const char *cached = d->type_name_cache[idx];
    if (cached)
        return cached;

    const char *desc = dex_type_desc(d, idx);
    if (!desc || desc[0] != 'L' || desc[1] == '\0')
        return desc;

    size_t n = strlen(desc);
    size_t len = n > 2 ? n - 2 : 0;
    char *out = arena_alloc(d->arena, len + 1);
    if (!out)
        return desc;
    /* '/' becomes '.'; '$' only becomes '.' when it introduces a nested class
     * name ("Map$Entry"), never inside a package identifier ("j$/..."). */
    for (size_t i = 0; i < len; i++) {
        char c = desc[i + 1];
        if (c == '/') {
            out[i] = '.';
        } else if (c == '$') {
            char next = desc[i + 2];
            /* Keep '$' before a digit: Foo$1 is an anonymous class and "Foo.1"
             * is not a legal Java identifier. */
            int named_nested = (next >= 'A' && next <= 'Z');
            out[i] = named_nested ? '.' : '$';
        } else {
            out[i] = c;
        }
    }
    out[len] = '\0';
    d->type_name_cache[idx] = out;
    return out;
}

/* Builds the Java modifier list for a member. Flags are mapped individually so
 * that DEX-only bits (synthetic, enum, annotation) never leak a keyword and no
 * keyword can be emitted twice. `is_method` disambiguates the flag bits that
 * collide between fields (volatile/transient) and methods (bridge/varargs). */
const char *dex_access_string_for(uint32_t f, int is_method)
{
    static _Thread_local char buf[256];
    buf[0] = '\0';

    struct { uint32_t bit; const char *word; } common[] = {
        { DEX_ACC_PUBLIC, "public " },
        { DEX_ACC_PRIVATE, "private " },
        { DEX_ACC_PROTECTED, "protected " },
        { DEX_ACC_STATIC, "static " },
        { DEX_ACC_FINAL, "final " },
        { DEX_ACC_ABSTRACT, "abstract " },
        { DEX_ACC_STRICT, "strictfp " },
    };

    size_t used = 0;
    for (size_t i = 0; i < sizeof(common) / sizeof(common[0]); i++) {
        if (!(f & common[i].bit))
            continue;
        size_t l = strlen(common[i].word);
        if (used + l >= sizeof(buf))
            break;
        memcpy(buf + used, common[i].word, l);
        used += l;
    }

    /* synchronized and native are independent bits and may both be set; the
     * earlier "else if" chain silently dropped native on synchronized natives,
     * which javac then rejects for having no body. */
    const char *extra[2] = {NULL, NULL};
    if (is_method) {
        if (f & DEX_ACC_SYNCHRONIZED)
            extra[0] = "synchronized ";
        if (f & DEX_ACC_NATIVE)
            extra[1] = "native ";
    } else {
        if (f & DEX_ACC_VOLATILE)
            extra[0] = "volatile ";
        if (f & DEX_ACC_TRANSIENT)
            extra[1] = "transient ";
    }
    for (int i = 0; i < 2; i++) {
        if (!extra[i])
            continue;
        size_t l = strlen(extra[i]);
        if (used + l < sizeof(buf)) {
            memcpy(buf + used, extra[i], l);
            used += l;
        }
    }
    buf[used] = '\0';
    return buf;
}

const char *dex_access_string(uint32_t f)
{
    return dex_access_string_for(f, 0);
}

void dex_describe(Dex *d, Buf *out)
{
    const DexHeader *h = &d->hdr;
    buf_printf(out, "file        : %s\n", d->path ? d->path : "<memory>");
    buf_printf(out, "size        : %zu bytes\n", d->size);
    buf_printf(out, "version     : %c%c%c\n", h->version[0], h->version[1], h->version[2]);
    buf_printf(out, "checksum    : 0x%08x\n", h->checksum);
    buf_printf(out, "strings     : %u\n", h->string_ids_size);
    buf_printf(out, "types       : %u\n", h->type_ids_size);
    buf_printf(out, "protos      : %u\n", h->proto_ids_size);
    buf_printf(out, "fields      : %u\n", h->field_ids_size);
    buf_printf(out, "methods     : %u\n", h->method_ids_size);
    buf_printf(out, "classes     : %u\n", h->class_defs_size);
}

int dex_class_has_subclass(Dex *dex, uint32_t type_idx)
{
    if (!dex->has_subclass || type_idx >= dex->hdr.type_ids_size)
        return 0;
    return dex->has_subclass[type_idx];
}

uint32_t dex_class_def_of_type(Dex *dex, uint32_t type_idx)
{
    if (!dex->type_to_class_def || type_idx >= dex->hdr.type_ids_size)
        return DEX_NO_INDEX;
    return dex->type_to_class_def[type_idx];
}
