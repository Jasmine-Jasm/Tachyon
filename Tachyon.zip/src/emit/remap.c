#include "emit/remap.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dex/dex.h"
#include "emit/java.h"
#include "emit/java_type.h"

const char *g_remap_prefix = "j$.";

/* Set of java/* descriptors defined by the dex, stored by pointer identity of
 * the interned descriptor strings (dex_type_desc returns stable pointers for a
 * given type index), so lookups are O(1) without strcmp. */
static const char **g_slots;
static uint32_t g_cap;
static const Dex *g_dex;

static uint32_t hash_ptr(const void *p)
{
    uintptr_t x = (uintptr_t)p;
    x ^= x >> 17;
    x *= (uintptr_t)0xed5ad4bbu;
    x ^= x >> 11;
    return (uint32_t)x;
}

void remap_free(void)
{
    free(g_slots);
    g_slots = NULL;
    g_cap = 0;
    g_dex = NULL;
}

void remap_init(Dex *dex)
{
    remap_free();
    if (!dex || dex->hdr.class_defs_size == 0)
        return;

    uint32_t cap = 64;
    while (cap < dex->hdr.class_defs_size * 2)
        cap <<= 1;
    g_slots = calloc(cap, sizeof(*g_slots));
    if (!g_slots)
        return;
    g_cap = cap;

    for (uint32_t i = 0; i < dex->hdr.class_defs_size; i++) {
        const char *desc = dex_type_desc(dex, dex->classes[i].class_idx);
        if (!desc || desc[0] != 'L' || strncmp(desc + 1, "java/", 5) != 0)
            continue;
        uint32_t k = hash_ptr(desc) & (cap - 1);
        while (g_slots[k])
            k = (k + 1) & (cap - 1);
        g_slots[k] = desc;
    }
    g_dex = dex;
}

/* Looks for a descriptor in the set of java/* classes this dex defines. */
static int defined_here(const char *desc)
{
    if (!g_slots)
        return 0;
    uint32_t k = hash_ptr(desc) & (g_cap - 1);
    for (uint32_t probe = 0; probe < g_cap; probe++) {
        if (!g_slots[k])
            return 0;
        if (g_slots[k] == desc)
            return 1;
        if (!strcmp(g_slots[k], desc))
            return 1;
        k = (k + 1) & (g_cap - 1);
    }
    return 0;
}

/* Dex files built with the desugar toolchain carry their own copy of the JDK
 * runtime under a "j$" package. Those classes are ordinary types, but their
 * names collide conceptually with java.* and every interface they implement
 * spells its methods differently, which makes the whole hierarchy uncompilable.
 * Renaming the prefix (the approach jadx takes with its alias provider) removes
 * the collision at the root: after the rename the two families are simply
 * unrelated classes, and each compiles on its own terms. */
#define DEX_RUNTIME_PREFIX "j$/"
#define RENAMED_PREFIX "jdruntime/"

static int is_dex_runtime(const char *desc)
{
    if (!desc)
        return 0;
    /* Skip array dimensions: "[Lj$/util/List;" is also a dex runtime type. */
    while (*desc == '[')
        desc++;
    return !strncmp(desc, "Lj$/", 4);
}

int remap_needed(const char *desc)
{
    if (!desc || (desc[0] != 'L' && desc[0] != '['))
        return 0;

    /* The dex runtime package is relocated unconditionally; it does not depend
     * on which classes this particular dex happens to define. */
    if (is_dex_runtime(desc))
        return 1;

    if (!g_slots)
        return 0;

    /* Two cases relocate a java.* reference:
     *   1. this dex defines java/X itself (an embedded JDK copy), or
     *   2. this dex defines j$/X instead, so the reference must follow the
     *      desugared naming or it will disagree with every other use of X.
     * The second case is what makes a dex that ships the whole j$ runtime
     * consistent: its classes reference j$.util.Set, so any java.util.Set
     * mention has to be rewritten to match. */
    if (!strncmp(desc + 1, "java/", 5) && defined_here(desc))
        return 1;

    if (!strncmp(desc + 1, "java/", 5)) {
        char alt[1024];
        snprintf(alt, sizeof(alt), "Lj$/%s", desc + 6);
        if (defined_here(alt))
            return 1;
    }
    return 0;
}

/* Declared in emit/java.c: reports whether a class name had to be renamed
 * because it is a reserved word or shadows a package. */
int java_simple_name_shadowed(Dex *dex, const char *simple);

/* Applies the reserved-word / shadow suffix that the declaration will also use.
 * Both the emitted class header and every reference go through this, so a class
 * can never be declared and referenced under different names. */
static void apply_declared_suffix(const char *simple, char *out, size_t cap)
{
    int needs = java_simple_name_shadowed(g_current_dex, simple);
    if (needs)
        snprintf(out, cap, "%s_", simple);
    else
        snprintf(out, cap, "%s", simple);
}

struct Dex *g_current_dex;

/* Classes in the DEX default package cannot be referenced from a class that
 * lives in a named package: Java has no syntax for it, and javac reports the
 * class as missing. Relocating every default-package class into this synthetic
 * package keeps both sides resolvable. */
#define DEFAULTPKG_NAME "defpkg"

int g_relocate_default_pkg;

static int is_default_package_class(const char *desc);

/* A class moved out of the default package sits in its own package now, so
 * package-private members would be unreachable from the code that used them
 * before. */
int remap_is_relocated_default(const char *desc)
{
    return is_default_package_class(desc) && g_relocate_default_pkg;
}

static int is_default_package_class(const char *desc)
{
    const char *p = desc;
    if (!p)
        return 0;
    /* Array dimensions come first: [Lcom/x/Cls; is an array of a class, and
     * [Lcls; is an array of a default-package class. */
    while (*p == '[')
        p++;
    if (*p != 'L')
        return 0;
    return strchr(p + 1, '/') == NULL;
}

/* Classes whose own path is also a package directory. Kept as descriptors so the
 * suffix can be applied from any reference, not just the declaration. */
static const char **g_conflict_descs;
static uint32_t g_conflict_count;
static uint32_t g_conflict_cap;

void remap_set_package_conflicts(char **descs, uint32_t count)
{
    g_conflict_descs = (const char **)descs;
    g_conflict_count = count;
    g_conflict_cap = count;
}

static int desc_is_package_conflict(const char *desc)
{
    if (!g_conflict_descs || !g_conflict_count || !desc || desc[0] != 'L')
        return 0;
    for (uint32_t i = 0; i < g_conflict_count; i++)
        if (!strcmp(g_conflict_descs[i], desc))
            return 1;
    return 0;
}

/* Fills `out` with the suffixed simple name when this descriptor collides with a
 * package directory. Returns 1 on a hit. */
int remap_conflict_name(const char *desc, char *out, size_t cap)
{
    if (getenv("TACHYON_DEBUG_CN") && desc && strstr(desc, "insight/log/a;"))
        fprintf(stderr, "[cn] desc='%s' count=%u hit=%d\n", desc, g_conflict_count,
                desc_is_package_conflict(desc));
    if (!desc_is_package_conflict(desc) || !desc || desc[0] != 'L')
        return 0;
    const char *slash = strrchr(desc, '/');
    const char *name = slash ? slash + 1 : desc + 1;
    size_t n = 0;
    while (name[n] && name[n] != ';' && n + 2 < cap)
        n++;
    size_t w = 0;
    for (size_t i = 0; i < n; i++) {
        char c = name[i];
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') || c == '_';
        out[w++] = ok ? c : '_';
    }
    out[w++] = '_';
    out[w] = '\0';
    return 1;
}

/* A class this APK defines is emitted with '$' folded to '_' in its simple
 * name, so every reference has to use that spelling. Without this, a reference to
 * android.view.WindowInsetsAnimation$Callback resolves to the platform class of
 * the same name instead of the copy in the tree, and the two disagree about their
 * constructors and supertypes.
 *
 * Platform types keep the dotted form: android.view.View$BaseSavedState must stay
 * android.view.View.BaseSavedState because that is how android.jar names it. */
static void fold_dollar_for_emitted(const char *desc, char *name, size_t cap)
{
    if (!desc || !strchr(desc, '$'))
        return;
    Dex *owner = NULL;
    if (java_lookup_dex_by_name(desc, NULL, &owner) == DEX_NO_INDEX &&
        !java_is_stub_desc(desc))
        return; /* platform type: leave the dotted form alone */

    /* java_type_of turned both '/' and '$' into '.', so the dots that stand for
     * '$' are the ones after the last slash. */
    size_t slashes = 0;
    for (const char *p = desc; *p && *p != ';'; p++)
        if (*p == '/')
            slashes++;
    size_t seen = 0;
    for (char *p = name; *p; p++) {
        if (*p == '[')
            break; /* array suffix: no more name to fold */
        if (*p != '.')
            continue;
        if (seen < slashes)
            seen++;
        else
            *p = '_';
    }
    (void)cap;
}

/* Replaces the simple name of a qualified Java type with the inferred one. The
 * package is untouched: renaming happens within a package, and the path is
 * derived from this same string. */
static void apply_heuristic_name(const char *desc, char *name)
{
    const char *guessed = heuristic_name(java_heur(), desc);
    if (getenv("TACHYON_DBG_HEUR") && strstr(desc, "ytc"))
        fprintf(stderr, "[heur] desc=%s heur=%p guessed=%s\n", desc,
                (void *)java_heur(), guessed ? guessed : "(none)");
    if (!guessed)
        return;
    char *dot = strrchr(name, '.');
    if (dot)
        snprintf(dot + 1, strlen(guessed) + 1, "%s", guessed);
    else
        snprintf(name, strlen(name) + strlen(guessed) + 2, "%s", guessed);
}

void remap_java_type(const char *desc, char *out, size_t cap)
{
    char base[512];
    java_type_of(desc, base, sizeof(base));
    fold_dollar_for_emitted(desc, base, sizeof(base));
    apply_heuristic_name(desc, base);

    /* A class named like a package directory gets a '_' suffix; every reference
     * must use the same spelling or javac reports the class as missing. */
    if (desc_is_package_conflict(desc)) {
        char *br = strchr(base, '[');
        size_t stem = br ? (size_t)(br - base) : strlen(base);
        if (stem + 2 < sizeof(base)) {
            char tmp[512];
            snprintf(tmp, sizeof(tmp), "%.*s_%s", (int)stem, base, br ? br : "");
            snprintf(out, cap, "%s", tmp);
            return;
        }
    }

    /* A default-package type used from inside a named package must move. Apply
     * the same reserved-word / shadow suffix the declaration uses, otherwise the
     * reference names a class that does not exist. */
    if (g_relocate_default_pkg && is_default_package_class(desc)) {
        /* Strip any array suffix so the class name can be qualified, then put it
         * back: bv6 becomes defpkg.bv6, and bv6[] becomes defpkg.bv6[]. */
        char stem[512];
        snprintf(stem, sizeof(stem), "%s", base);
        char *br = strchr(stem, '[');
        if (br)
            *br = '\0';
        char renamed[512];
        apply_declared_suffix(stem, renamed, sizeof(renamed));
        snprintf(out, cap, "%s.%s%s", DEFAULTPKG_NAME, renamed, br ? br : "");
        if (getenv("TACHYON_DEBUG_DP") && strchr(out, ';'))
            fprintf(stderr, "[dp] desc=%s base='%s' stem='%s' -> '%s'\n", desc, base, stem, out);
        return;
    }

    if (!remap_needed(desc)) {
        /* A class renamed to avoid a clash must keep the same name in every
         * reference, including bare ones inside its own package. */
        if (g_current_dex) {
            const char *simple = strrchr(base, '.');
            simple = simple ? simple + 1 : base;
            const char *br = strchr(simple, '[');
            char name[256];
            size_t n = br ? (size_t)(br - simple) : strlen(simple);
            if (n < sizeof(name)) {
                memcpy(name, simple, n);
                name[n] = '\0';
                if (java_simple_name_shadowed(g_current_dex, name)) {
                    size_t outn = (size_t)(simple - base) + n;
                    if (outn + 2 >= cap)
                        goto plain;
                    memcpy(out, base, outn);
                    out[outn] = '_';
                    out[outn + 1] = '\0';
                    if (br) {
                        size_t used = outn + 1;
                        size_t rl = strlen(br);
                        if (used + rl + 1 <= cap) {
                            memcpy(out + used, br, rl + 1);
                        }
                    }
                    return;
                }
            }
        }
plain:
        snprintf(out, cap, "%s", base);
        return;
    }

    /* Split the Java name into a stem and any trailing "[]" dimensions. */
    const char *bracket = strchr(base, '[');
    size_t stem_len = bracket ? (size_t)(bracket - base) : strlen(base);
    if (stem_len >= sizeof(base))
        stem_len = sizeof(base) - 1;
    char stem[512];
    memcpy(stem, base, stem_len);
    stem[stem_len] = '\0';
    const char *dims = bracket ? bracket : "";

    /* The dex runtime package is renamed wholesale, keeping the rest of the path
     * so class names stay recognisable: j$.util.List -> jdruntime.util.List. */
    if (!strncmp(stem, "j$.", 3)) {
        snprintf(out, cap, "jdruntime.%s%s", stem + 3, dims);
        return;
    }

    /* Relocated JDK classes take the desugared shape: the leading "java." is
     * replaced by the prefix rather than prepended, otherwise the result names a
     * package that does not exist. */
    const char *body = stem;
    if (!strncmp(body, "java.", 5))
        body += 5;
    snprintf(out, cap, "%s%s%s", g_remap_prefix, body, dims);
}
