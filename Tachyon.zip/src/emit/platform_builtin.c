#include "emit/platform_builtin.h"

#include <string.h>

/* Constructor signatures for framework classes that every Android app extends or
 * instantiates. Kept in the binary so decompilation does not depend on an
 * android.jar being unpacked on the machine.
 *
 * Only the constructor with the fewest parameters is listed. The emitter fills
 * each parameter with a typed default, so a shorter signature is both the easiest
 * to satisfy and the least likely to collide with an overload.
 *
 * A class absent from this table falls back to the on-disk SDK class tree when
 * one is configured, and to a bare super() otherwise -- which is correct for the
 * many framework classes that do declare a no-arg constructor. */
typedef struct {
    const char *desc;
    const char *params; /* comma-separated descriptors, "" for no-arg */
} BuiltinCtor;

static const BuiltinCtor g_builtin[] = {
    /* --- android.view --- */
    {"Landroid/view/View;", "Landroid/content/Context;"},
    {"Landroid/view/ViewGroup;", "Landroid/content/Context;"},
    {"Landroid/view/ViewGroup$LayoutParams;", "II"},
    {"Landroid/view/ViewGroup$MarginLayoutParams;", "II"},
    {"Landroid/view/View$BaseSavedState;", "Landroid/os/Parcel;"},
    {"Landroid/view/SurfaceView;", "Landroid/content/Context;"},
    {"Landroid/view/TextureView;", "Landroid/content/Context;"},
    {"Landroid/view/Window;", "Landroid/content/Context;"},

    /* --- android.widget --- */
    {"Landroid/widget/FrameLayout;", "Landroid/content/Context;"},
    {"Landroid/widget/LinearLayout;", "Landroid/content/Context;"},
    {"Landroid/widget/RelativeLayout;", "Landroid/content/Context;"},
    {"Landroid/widget/RelativeLayout$LayoutParams;", "II"},
    {"Landroid/widget/LinearLayout$LayoutParams;", "II"},
    {"Landroid/widget/FrameLayout$LayoutParams;", "II"},
    {"Landroid/widget/HorizontalScrollView;", "Landroid/content/Context;"},
    {"Landroid/widget/ScrollView;", "Landroid/content/Context;"},
    {"Landroid/widget/ImageView;", "Landroid/content/Context;"},
    {"Landroid/widget/TextView;", "Landroid/content/Context;"},
    {"Landroid/widget/EditText;", "Landroid/content/Context;"},
    {"Landroid/widget/Button;", "Landroid/content/Context;"},
    {"Landroid/widget/ProgressBar;", "Landroid/content/Context;"},
    {"Landroid/widget/Toast;", "Landroid/content/Context;"},
    {"Landroid/widget/ArrayAdapter;", "Landroid/content/Context;I"},
    {"Landroid/widget/BaseAdapter;", ""},
    {"Landroid/widget/PopupWindow;", "Landroid/content/Context;"},
    {"Landroid/widget/AdapterView;", "Landroid/content/Context;"},

    /* --- android.webkit --- */
    {"Landroid/webkit/WebView;", "Landroid/content/Context;"},
    {"Landroid/webkit/WebViewClient;", ""},
    {"Landroid/webkit/WebChromeClient;", ""},

    /* --- android.app --- */
    {"Landroid/app/Activity;", ""},
    {"Landroid/app/Service;", ""},
    {"Landroid/app/Application;", ""},
    {"Landroid/app/Dialog;", "Landroid/content/Context;"},
    {"Landroid/app/AlertDialog;", "Landroid/content/Context;"},
    {"Landroid/app/Fragment;", ""},
    {"Landroid/app/IntentService;", "Ljava/lang/String;"},

    /* --- android.content --- */
    {"Landroid/content/ContentResolver;", "Landroid/content/Context;"},
    {"Landroid/content/ContentProvider;", ""},
    {"Landroid/content/BroadcastReceiver;", ""},
    {"Landroid/content/ContextWrapper;", "Landroid/content/Context;"},
    {"Landroid/content/Context;", ""},
    {"Landroid/content/SharedPreferences;", ""},

    /* --- android.os --- */
    {"Landroid/os/Handler;", ""},
    {"Landroid/os/Binder;", ""},
    {"Landroid/os/AsyncTask;", ""},
    {"Landroid/os/Parcelable$Creator;", ""},
    {"Landroid/os/HandlerThread;", "Ljava/lang/String;"},

    /* --- android.database --- */
    {"Landroid/database/sqlite/SQLiteOpenHelper;",
     "Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I"},

    /* --- androidx --- */
    {"Landroidx/fragment/app/Fragment;", ""},
    {"Landroidx/appcompat/app/AppCompatActivity;", ""},
    {"Landroidx/appcompat/app/ActionBarActivity;", ""},
    {"Landroidx/recyclerview/widget/RecyclerView;", "Landroid/content/Context;"},
    {"Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "Landroid/view/View;"},
    {"Landroidx/recyclerview/widget/RecyclerView$LayoutManager;", ""},
    {"Landroidx/viewpager/widget/ViewPager;", "Landroid/content/Context;"},

    /* --- java.lang / java.util --- */
    {"Ljava/lang/ref/WeakReference;", "Ljava/lang/Object;"},
    {"Ljava/lang/ref/SoftReference;", "Ljava/lang/Object;"},
    {"Ljava/lang/Thread;", ""},
    {"Ljava/lang/Throwable;", ""},
    {"Ljava/lang/Exception;", ""},
    {"Ljava/lang/RuntimeException;", ""},
    {"Ljava/lang/Error;", ""},
    {"Ljava/util/AbstractList;", ""},
    {"Ljava/util/AbstractMap;", ""},
    {"Ljava/util/TimerTask;", ""},

    /* --- java.io / java.net / java.util.concurrent / java.util.zip --- */
    {"Ljava/io/PrintWriter;", "Ljava/io/Writer;"},
    {"Ljava/io/PrintStream;", "Ljava/io/OutputStream;"},
    {"Ljava/io/FilterOutputStream;", "Ljava/io/OutputStream;"},
    {"Ljava/io/FilterInputStream;", "Ljava/io/InputStream;"},
    {"Ljava/io/BufferedWriter;", "Ljava/io/Writer;"},
    {"Ljava/io/BufferedReader;", "Ljava/io/Reader;"},
    {"Ljava/io/OutputStreamWriter;", "Ljava/io/OutputStream;"},
    {"Ljava/io/InputStreamReader;", "Ljava/io/InputStream;"},
    {"Ljava/io/FileReader;", "Ljava/io/File;"},
    {"Ljava/io/FileWriter;", "Ljava/io/File;"},
    {"Ljava/util/zip/GZIPOutputStream;", "Ljava/io/OutputStream;"},
    {"Ljava/util/zip/GZIPInputStream;", "Ljava/io/InputStream;"},
    {"Ljava/util/zip/ZipOutputStream;", "Ljava/io/OutputStream;"},
    {"Ljava/util/zip/InflaterInputStream;", "Ljava/io/InputStream;"},
    {"Ljava/util/concurrent/ThreadPoolExecutor;",
     "IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;"},
    {"Ljava/util/concurrent/ScheduledThreadPoolExecutor;", "I"},
    {"Ljava/util/concurrent/ThreadLocalRandom;", ""},
    {"Ljava/security/SecureRandom;", ""},
    {"Ljava/net/URL;", "Ljava/lang/String;"},
    {"Ljava/net/URI;", "Ljava/lang/String;"},
    {"Ljava/net/InetSocketAddress;", "Ljava/lang/String;I"},

    /* --- javax --- */
    {"Ljavax/net/ssl/SSLSocketFactory;", ""},
    {"Ljavax/net/ssl/TrustManager;", ""},
    {"Ljavax/crypto/Cipher;", ""},
    {"Ljavax/crypto/spec/SecretKeySpec;", "[BLjava/lang/String;"},
};

/* Looks a descriptor up in the built-in table. Returns the parameter descriptors
 * ("" for a no-arg constructor) or NULL when the class is not covered. */
const char *platform_builtin_params(const char *desc)
{
    if (!desc)
        return NULL;
    for (size_t i = 0; i < sizeof(g_builtin) / sizeof(g_builtin[0]); i++)
        if (!strcmp(g_builtin[i].desc, desc))
            return g_builtin[i].params;
    return NULL;
}

static const PlatformAbstract g_abs[] = {
    {"Landroid/app/Service;", "onBind", "Landroid/os/IBinder;", "Landroid/content/Intent;"},
    {"Landroid/content/BroadcastReceiver;", "onReceive", "V",
     "Landroid/content/Context;Landroid/content/Intent;"},
    {"Landroid/content/ContentProvider;", "onCreate", "Z", ""},
    {"Landroid/content/ContentProvider;", "query", "Landroid/database/Cursor;",
     "Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;"},
    {"Landroid/content/ContentProvider;", "getType", "Ljava/lang/String;", "Landroid/net/Uri;"},
    {"Landroid/content/ContentProvider;", "insert", "Landroid/net/Uri;",
     "Landroid/net/Uri;Landroid/content/ContentValues;"},
    {"Landroid/content/ContentProvider;", "delete", "I",
     "Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;"},
    {"Landroid/content/ContentProvider;", "update", "I",
     "Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;"},
    {"Ljava/util/TimerTask;", "run", "V", ""},
    {"Ljava/lang/Runnable;", "run", "V", ""},
    {"Landroid/widget/BaseAdapter;", "getCount", "I", ""},
    {"Landroid/widget/BaseAdapter;", "getItem", "Ljava/lang/Object;", "I"},
    {"Landroid/widget/BaseAdapter;", "getItemId", "J", "I"},
    {"Landroid/widget/BaseAdapter;", "getView", "Landroid/view/View;",
     "ILandroid/view/View;Landroid/view/ViewGroup;"},
    {"Landroid/os/AsyncTask;", "doInBackground", "Ljava/lang/Object;", "[Ljava/lang/Object;"},
    {"Landroidx/recyclerview/widget/RecyclerView$Adapter;", "getItemCount", "I", ""},
};

const PlatformAbstract *platform_builtin_abstracts(const char *owner_desc, int *count)
{
    if (count)
        *count = 0;
    if (!owner_desc)
        return NULL;
    for (size_t i = 0; i < sizeof(g_abs) / sizeof(g_abs[0]); i++) {
        if (strcmp(g_abs[i].owner, owner_desc))
            continue;
        int n = 1;
        while (i + (size_t)n < sizeof(g_abs) / sizeof(g_abs[0]) &&
               !strcmp(g_abs[i + n].owner, owner_desc))
            n++;
        if (count)
            *count = n;
        return &g_abs[i];
    }
    return NULL;
}

/* Splits a compact descriptor list ("Landroid/content/Context;I") into its
 * parameters. Descriptors are self-delimiting, so no separator is needed. */
int platform_builtin_split_params(const char *params, char out[][128], int max)
{
    int n = 0;
    const char *p = params;
    while (p && *p && n < max) {
        const char *start = p;
        while (*p == '[')
            p++;
        if (*p == 'L') {
            const char *semi = strchr(p, ';');
            if (!semi)
                break;
            p = semi + 1;
        } else if (*p) {
            p++;
        } else {
            break;
        }
        size_t len = (size_t)(p - start);
        if (len >= 128)
            len = 127;
        memcpy(out[n], start, len);
        out[n][len] = '\0';
        n++;
    }
    return n;
}

static const PlatformMethod g_methods[] = {
    {"Landroid/view/ViewParent;", "getLayoutDirection", "", "I", 0},
    {"Landroid/view/ViewParent;", "requestLayout", "", "V", 0},
    {"Landroid/view/ViewParent;", "isLayoutRequested", "", "Z", 0},
    /* ViewGroup and View implement ViewParent, so their subclasses inherit those
     * declarations without the parent link showing it. */
    {"Landroid/view/ViewGroup;", "getLayoutDirection", "", "I", 0},
    {"Landroid/view/View;", "getLayoutDirection", "", "I", 0},
    /* AdapterView<T> and Spinner both declare a setAdapter whose erasures meet,
     * so a subclass may keep only the inherited one. */
    {"Landroid/widget/AdapterView;", "setAdapter", "Landroid/widget/Adapter;", "V", 1},
    {"Landroid/widget/Spinner;", "setAdapter", "Landroid/widget/Adapter;", "V", 1},
    {"Landroid/widget/AbsSpinner;", "setAdapter", "Landroid/widget/Adapter;", "V", 1},
    {"Landroid/widget/AdapterView;", "getAdapter", "", "Landroid/widget/Adapter;", 0},
    {"Landroid/widget/AdapterView;", "getSelectedView", "", "Landroid/view/View;", 0},
    {"Landroid/widget/AdapterView;", "setSelection", "I", "V", 0},
};

/* Framework superclass chain, enough to reach the types that declare methods an
 * app class overrides. */
static const char *const g_parents[][2] = {
    {"Landroid/widget/Spinner;", "Landroid/widget/AbsSpinner;"},
    {"Landroid/widget/AbsSpinner;", "Landroid/widget/AdapterView;"},
    {"Landroid/widget/AdapterView;", "Landroid/view/ViewGroup;"},
    {"Landroid/widget/FrameLayout;", "Landroid/view/ViewGroup;"},
    {"Landroid/widget/LinearLayout;", "Landroid/view/ViewGroup;"},
    {"Landroid/widget/RelativeLayout;", "Landroid/view/ViewGroup;"},
    {"Landroid/widget/ScrollView;", "Landroid/widget/FrameLayout;"},
    {"Landroid/widget/HorizontalScrollView;", "Landroid/widget/FrameLayout;"},
    {"Landroid/view/ViewGroup;", "Landroid/view/View;"},
    {"Landroid/view/View;", "Ljava/lang/Object;"},
    {"Landroid/webkit/WebView;", "Landroid/widget/AbsoluteLayout;"},
    {"Landroid/widget/AbsoluteLayout;", "Landroid/view/ViewGroup;"},
};

const char *platform_builtin_parent(const char *desc)
{
    if (!desc)
        return NULL;
    for (size_t i = 0; i < sizeof(g_parents) / sizeof(g_parents[0]); i++)
        if (!strcmp(g_parents[i][0], desc))
            return g_parents[i][1];
    return NULL;
}

/* `key` comes from the emitter's proto_key, which writes "%s;" per parameter, so
 * an object descriptor ending in ';' yields ";;". Compare parameter by parameter
 * instead of byte by byte. */
static int params_match(const char *key, const char *expect)
{
    if (!key || !expect)
        return 0;
    while (*expect) {
        const char *semi = strchr(expect, ';');
        size_t len = semi ? (size_t)(semi - expect) + 1 : strlen(expect);
        if (strncmp(key, expect, len))
            return 0;
        key += len;
        expect += len;
        if (*key == ';')
            key++;
    }
    return *key == '\0';
}

const PlatformMethod *platform_builtin_method(const char *owner, const char *name,
                                              const char *params)
{
    if (!owner || !name)
        return NULL;
    for (size_t i = 0; i < sizeof(g_methods) / sizeof(g_methods[0]); i++) {
        if (strcmp(g_methods[i].owner, owner) || strcmp(g_methods[i].name, name))
            continue;
        if (params && !params_match(params, g_methods[i].params))
            continue;
        return &g_methods[i];
    }
    return NULL;
}

/* Framework types whose shortest constructor declares throws IOException. */
static const char *const kIoThrowing[] = {
    "Ljava/util/zip/GZIPOutputStream;",
    "Ljava/util/zip/ZipOutputStream;",
    "Ljava/util/zip/InflaterInputStream;",
    "Ljava/util/zip/ZipInputStream;",
    "Ljava/io/FileInputStream;",
    "Ljava/io/FileOutputStream;",
    "Ljava/io/FileReader;",
    "Ljava/io/FileWriter;",
    "Ljava/net/Socket;",
    "Ljava/net/ServerSocket;",
    "Ljavax/crypto/CipherInputStream;",
};

int platform_builtin_ctor_throws_io(const char *desc)
{
    if (!desc)
        return 0;
    for (size_t i = 0; i < sizeof(kIoThrowing) / sizeof(kIoThrowing[0]); i++)
        if (!strcmp(kIoThrowing[i], desc))
            return 1;
    return 0;
}
