#include "emit/java.h"
#include "emit/heuristic.h"
#include "emit/platform_builtin.h"
#include "emit/platform_ctors.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "emit/java_type.h"
#include "emit/remap.h"
#include "ir/body.h"

#define NO_INDEX DEX_NO_INDEX

static _Thread_local Arena *g_member_arena;

/* Names that must gain a suffix because they shadow a package. Built once in
 * java_prepare_shadow_table so lookups are table scans over a handful of names
 * instead of a scan of every class. */
static char **g_shadow_names;
static uint32_t g_shadow_count;
static uint32_t g_shadow_cap;
static uint64_t g_shadow_bits;

typedef struct {
    Dex *dex;
    Buf *out;
    int indent;
    Arena *arena;
} Emitter;

/* Thread-local so parallel class emission does not share scratch space or
 * clobber a sibling worker's arena. */
static _Thread_local Arena *g_body_arena;
static int g_emit_bodies;
static int g_accurate_mode = 1;
static int g_skip_conflicts = 0;
static Renamer *g_renamer;
static HeurNames *g_heur;

void java_set_renamer(Renamer *r)
{
    g_renamer = r;
}

Renamer *java_renamer(void)
{
    return g_renamer;
}

void java_set_heuristic(HeurNames *h)
{
    g_heur = h;
}

HeurNames *java_heur(void)
{
    return g_heur;
}

static char **g_stub_descs;
static uint32_t g_stub_count;

void java_set_stub_descs(char **descs, uint32_t count)
{
    g_stub_descs = descs;
    g_stub_count = count;
}

int java_is_stub_desc(const char *desc)
{
    if (!desc || !g_stub_count)
        return 0;
    for (uint32_t i = 0; i < g_stub_count; i++)
        if (!strcmp(g_stub_descs[i], desc))
            return 1;
    return 0;
}

/* Applies the mapping when one is loaded; otherwise returns the dex name. */
const char *java_class_name(Dex *dex, uint32_t type_idx)
{
    const char *desc = dex_type_desc(dex, type_idx);
    if (g_renamer) {
        const char *mapped = renamer_class(g_renamer, desc);
        if (mapped)
            return mapped;
    }
    if (g_heur) {
        const char *guessed = heuristic_name(g_heur, desc);
        if (guessed)
            return guessed;
    }
    return dex_type_name(dex, type_idx);
}

/* Kotlin inline classes mangle their accessors with a hyphen suffix
 * ("getSize-bOM6tXw"), which is illegal in Java source. Fold any character that
 * cannot appear in an identifier to '_' and remember the result per name so the
 * emitted call sites agree with the declaration. */
static const char *sanitize_member(const char *name, Arena *arena)
{
    int clean = 1;
    for (const char *p = name; *p; p++) {
        if (!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
              (*p >= '0' && *p <= '9') || *p == '_' || *p == '$')) {
            clean = 0;
            break;
        }
    }
    if (clean || !arena)
        return name;

    size_t n = strlen(name);
    char *out = arena_alloc(arena, n + 1);
    if (!out)
        return name;
    for (size_t i = 0; i < n; i++) {
        char c = name[i];
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') || c == '_' || c == '$';
        out[i] = ok ? c : '_';
    }
    out[n] = '\0';
    return out;
}

const char *java_member_name(Dex *dex, uint32_t class_type_idx, uint32_t member_idx,
                             int is_method)
{
    const char *name = is_method ? dex_method_name(dex, member_idx) : dex_field_name(dex, member_idx);

    /* Constructors and class initialisers are not identifiers: "<init>" becomes
     * the class name and "<clinit>" becomes a static block. Sanitising them here
     * would turn every constructor into a normal method called "_init_". */
    if (name && name[0] == '<')
        return name;

    if (g_renamer) {
        const char *cls = dex_type_desc(dex, class_type_idx);
        const char *mapped = renamer_member(g_renamer, cls, name);
        if (mapped)
            return mapped;
    }
    return sanitize_member(name, g_member_arena);
}

static void indent(Emitter *e)
{
    buf_indent(e->out, e->indent);
}

static void line(Emitter *e, const char *fmt, ...)
{
    indent(e);
    va_list ap;
    va_start(ap, fmt);
    char tmp[2048];
    vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    buf_puts(e->out, tmp);
    buf_putc(e->out, '\n');
}

/* Java reserved words that cannot be used as a type name. R8 happily emits
 * classes called "do" or "int" after obfuscation. */
static int is_java_keyword(const char *s)
{
    static const char *kw[] = {
        "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char",
        "class", "const", "continue", "default", "do", "double", "else", "enum",
        "extends", "final", "finally", "float", "for", "goto", "if", "implements",
        "import", "instanceof", "int", "interface", "long", "native", "new",
        "package", "private", "protected", "public", "return", "short", "static",
        "strictfp", "super", "switch", "synchronized", "this", "throw", "throws",
        "transient", "try", "void", "volatile", "while", "true", "false", "null",
        "_",
    };
    for (size_t i = 0; i < sizeof(kw) / sizeof(kw[0]); i++)
        if (!strcmp(s, kw[i]))
            return 1;
    return 0;
}
/* DEX descriptors can carry bytes that are not legal Java identifier
 * characters ('-' in R8 synthetic suffixes such as "Foo$-CC"). */
static const char *java_ident(const char *name, char *out, size_t cap)
{
    size_t o = 0;
    for (size_t i = 0; name[i] && o + 1 < cap; i++) {
        unsigned char c = (unsigned char)name[i];
        /* A '$' inside a class simple name marks an anonymous or synthetic class
         * ("ch$b", "Foo$1"). Java reads '$' in a type name as the nested-class
         * separator, so such a top-level name cannot be referred to at all; fold
         * it to '_' to keep declaration and reference in sync. */
        if (c == '$') {
            out[o++] = '_';
            continue;
        }
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') || c == '_';
        if (i == 0 && c >= '0' && c <= '9')
            ok = 0;
        out[o++] = ok ? (char)c : '_';
    }
    out[o] = '\0';

    /* A reserved word needs a suffix to become a legal type name (R8 emits
     * classes literally called "do", "int", ...). */
    if (is_java_keyword(out) && o + 1 < cap) {
        out[o++] = '_';
        out[o] = '\0';
    }
    return out;
}

/* For each (name, parameters) group, DEX may hold several methods that differ
 * only in return type (a covariant override plus its bridge). Java permits just
 * one, and it must be the most specific, so preselect winners up front. */
typedef struct {
    uint32_t h;          /* name + params hash */
    uint32_t ret_type;   /* DEX type index of the chosen return type */
    int depth;           /* inheritance depth of that return type */
    int is_bridge;       /* 1 when the chosen method is a synthetic bridge */
    int in_chain;        /* 1 when the return type is the class itself or an ancestor */
    int drop;            /* 1 when emitting it would widen an inherited override */
    int parent_final;    /* 1 when an inherited declaration of this is final */
} MethodWinner;

/* Finds the winner for a signature, or NULL. */
static MethodWinner *winner_find(MethodWinner *w, uint32_t n, uint32_t h)
{
    for (uint32_t i = 0; i < n; i++)
        if (w[i].h == h)
            return &w[i];
    return NULL;
}

/* ---------------------------------------------------------------- */
/* duplicate signature filter                                        */
/* ---------------------------------------------------------------- */

typedef struct {
    uint32_t *hashes;
    uint32_t count;
    uint32_t cap;
} SigSet;

static int sigset_add(SigSet *s, uint32_t h)
{
    for (uint32_t i = 0; i < s->count; i++)
        if (s->hashes[i] == h)
            return 0;
    if (s->count == s->cap) {
        uint32_t nc = s->cap ? s->cap * 2 : 32;
        uint32_t *p = realloc(s->hashes, (size_t)nc * sizeof(uint32_t));
        if (!p)
            return 1;
        s->hashes = p;
        s->cap = nc;
    }
    s->hashes[s->count++] = h;
    return 1;
}

static uint32_t sig_hash(const char *name, const char *params)
{
    uint32_t h = 2166136261u;
    for (const char *p = name; *p; p++)
        h = (h ^ (uint8_t)*p) * 16777619u;
    h = (h ^ '|') * 16777619u;
    for (const char *p = params; *p; p++)
        h = (h ^ (uint8_t)*p) * 16777619u;
    return h;
}

/* Renders a proto's parameter types as a stable key, e.g. "I;Ljava/lang/String;". */
static void proto_key(Dex *d, uint32_t proto_idx, char *out, size_t cap)
{
    size_t o = 0;
    out[0] = '\0';
    DexParamList *pl = dex_proto_params(d, proto_idx);
    if (!pl)
        return;
    for (uint32_t i = 0; i < pl->param_count && o + 8 < cap; i++)
        o += (size_t)snprintf(out + o, cap - o, "%s;", dex_type_desc(d, pl->type_idx[i]));
}

/* ---------------------------------------------------------------- */
/* class facts                                                       */
/* ---------------------------------------------------------------- */

typedef struct {
    int is_interface;
    int is_enum;
    int has_ctor;
    uint32_t first_ctor_proto;
    int parent_has_noarg_ctor;
    /* When the parent has no no-arg constructor, a constructor body must call
     * one of its other constructors explicitly. These describe that target. */
    uint32_t parent_ctor_proto;
    int parent_ctor_known;
    /* The dex that owns the parent definition: proto indices are per-dex, so the
     * parameter list must be read from there, not from this class's dex. */
    Dex *parent_dex;
    int parent_known;
    /* Parameter counts used to forward a constructor's arguments to a platform
     * superclass, whose own signatures are not visible here. */
    uint32_t parent_ctor_param_count;
    uint32_t ctor_param_count;
    int parent_ctor_forward;
    int parent_ctors_known;
    /* Parameter descriptors of the platform superclass constructor to chain to. */
    char parent_params[8][128];
    int parent_param_count;
    char name[512];
} ClassFacts;

static int class_has_noarg_ctor(Dex *d, uint32_t class_def_idx)
{
    if (!d)
        return 0;
    const DexClassData *cd = dex_class_data(d, class_def_idx);
    if (!cd)
        return 0;
    for (uint32_t i = 0; i < cd->direct_count; i++) {
        uint32_t mi = cd->direct_methods[i].method_idx;
        if (mi >= d->hdr.method_ids_size)
            continue;
        if (strcmp(dex_method_name(d, mi), "<init>"))
            continue;
        /* A private constructor is not callable from a subclass, so it cannot
         * satisfy the implicit super() an emitted constructor would write. */
        if (cd->direct_methods[i].access_flags & DEX_ACC_PRIVATE)
            continue;
        DexParamList *pl = dex_proto_params(d, d->methods[mi].proto_idx);
        if (pl && pl->param_count == 0)
            return 1;
    }
    return 0;
}

/* Sibling dex files in one APK are separate type universes: a class in
 * classes.dex can extend a class defined only in classes3.dex, and this dex's
 * own table has no entry for it. Keep a list of every dex in the set so the
 * lookup can fall back to a global search instead of reporting "no parent". */
Dex **g_all_dex;
uint32_t g_all_dex_count;

/* Resolves a type index to the dex that defines it plus the class_def index
 * within that dex. Sibling dex files in one APK are separate type universes, so
 * a class_def index alone is meaningless across them: the owning Dex must travel
 * with it. */
static uint32_t class_def_of_type_in(Dex *d, uint32_t type_idx, Dex **owner);
static int iface_conflicts(Dex *dex, const DexClassDef *cd, uint32_t iface_ti);
static int platform_method_conflict(Dex *d, uint32_t class_def_idx, const char *name,
                                    const char *params_key, uint32_t ret_type);

uint32_t java_lookup_dex(uint32_t type_idx, Dex *from, Dex **owner);

/* Thread-local: workers resolve parent classes concurrently, and a shared
 * "last owner" pointer would leak one worker's answer into another's. */
static _Thread_local Dex *g_last_owner;

uint32_t java_lookup_dex(uint32_t type_idx, Dex *from, Dex **owner)
{
    return class_def_of_type_in(from, type_idx, owner);
}

static uint32_t class_def_of_type(Dex *d, uint32_t type_idx)
{
    Dex *owner = NULL;
    uint32_t def = class_def_of_type_in(d, type_idx, &owner);
    g_last_owner = owner;
    return def;
}

/* Like class_def_of_type but also reports which dex owns the definition.
 * Type indices are per-dex, so a cross-dex lookup must match on the descriptor
 * string rather than reusing the index from another file. */
/* Cross-dex lookup used to rescan every type descriptor of every other file,
 * which is O(types) string comparisons per parent resolution and dominated the
 * run on a three-dex APK. One global hash map is built before the workers start
 * and serves every later query in constant time. */
typedef struct {
    const char *desc;
    Dex *owner;
    uint32_t def;
} GlobalDef;

static GlobalDef *g_gdefs;
static uint32_t g_gdefs_cap;
static uint32_t g_gdefs_count;

void java_build_global_defs(Dex **dexs, uint32_t count, Arena *arena)
{
    if (g_gdefs || !dexs || !count)
        return;

    uint64_t total = 0;
    for (uint32_t i = 0; i < count; i++)
        total += dexs[i]->hdr.class_defs_size;
    if (total == 0)
        return;

    g_gdefs_cap = 1;
    while (g_gdefs_cap < total * 2)
        g_gdefs_cap <<= 1;
    if (getenv("TACHYON_DBG_PATH"))
        fprintf(stderr, "[gdefs] total=%llu cap=%u bytes=%zu before=%zu\n",
                (unsigned long long)total, g_gdefs_cap,
                (size_t)g_gdefs_cap * sizeof(GlobalDef), arena->total);
    g_gdefs = arena_zalloc(arena, (size_t)g_gdefs_cap * sizeof(GlobalDef));
    if (!g_gdefs)
        return;
    if (getenv("TACHYON_DBG_PATH"))
        fprintf(stderr, "[gdefs] after=%zu\n", arena->total);

    for (uint32_t i = 0; i < count; i++) {
        Dex *d = dexs[i];
        for (uint32_t k = 0; k < d->hdr.class_defs_size; k++) {
            const char *desc = dex_type_desc(d, d->classes[k].class_idx);
            if (!desc)
                continue;
            uint32_t h = 2166136261u;
            for (const char *q = desc; *q; q++)
                h = (h ^ (uint8_t)*q) * 16777619u;
            h &= g_gdefs_cap - 1;
            while (g_gdefs[h].desc) {
                if (!strcmp(g_gdefs[h].desc, desc))
                    break;
                h = (h + 1) & (g_gdefs_cap - 1);
            }
            if (!g_gdefs[h].desc) {
                g_gdefs[h].desc = desc;
                g_gdefs[h].owner = d;
                g_gdefs[h].def = k;
                g_gdefs_count++;
            }
        }
        if (getenv("TACHYON_DBG_PATH"))
            fprintf(stderr, "[gdefs] dex %u done, arena=%zu count=%u\n", i, arena->total,
                    g_gdefs_count);
    }
}

/* Resolves a class by descriptor across every dex of the input. */
uint32_t java_lookup_dex_by_name(const char *desc, Dex *from, Dex **owner)
{
    (void)from;
    if (!g_gdefs || !desc)
        return NO_INDEX;
    uint32_t h = 2166136261u;
    for (const char *q = desc; *q; q++)
        h = (h ^ (uint8_t)*q) * 16777619u;
    h &= g_gdefs_cap - 1;
    for (uint32_t step = 0; step < g_gdefs_cap; step++, h = (h + 1) & (g_gdefs_cap - 1)) {
        if (!g_gdefs[h].desc)
            return NO_INDEX;
        if (!strcmp(g_gdefs[h].desc, desc)) {
            *owner = g_gdefs[h].owner;
            return g_gdefs[h].def;
        }
    }
    return NO_INDEX;
}

static uint32_t class_def_of_type_in(Dex *d, uint32_t type_idx, Dex **owner)
{
    uint32_t def = dex_class_def_of_type(d, type_idx);
    if (def != NO_INDEX) {
        *owner = d;
        return def;
    }

    if (g_gdefs) {
        const char *want = dex_type_desc(d, type_idx);
        if (want) {
            uint32_t h = 2166136261u;
            for (const char *q = want; *q; q++)
                h = (h ^ (uint8_t)*q) * 16777619u;
            h &= g_gdefs_cap - 1;
            for (uint32_t step = 0; step < g_gdefs_cap; step++, h = (h + 1) & (g_gdefs_cap - 1)) {
                if (!g_gdefs[h].desc)
                    break;
                if (!strcmp(g_gdefs[h].desc, want)) {
                    *owner = g_gdefs[h].owner;
                    return g_gdefs[h].def;
                }
            }
        }
    }
    *owner = NULL;
    return NO_INDEX;
}

/* Returns the proto index of the parent's first constructor, or NO_INDEX. */
static uint32_t class_first_ctor_proto(Dex *d, uint32_t class_def_idx)
{
    const DexClassData *cd = dex_class_data(d, class_def_idx);
    if (!cd)
        return NO_INDEX;
    /* Prefer a constructor the subclass can actually call; a private one is
     * invisible to it and javac rejects the resulting super(...) call. */
    uint32_t fallback = NO_INDEX;
    for (uint32_t i = 0; i < cd->direct_count; i++) {
        uint32_t mi = cd->direct_methods[i].method_idx;
        if (mi >= d->hdr.method_ids_size || strcmp(dex_method_name(d, mi), "<init>"))
            continue;
        if (cd->direct_methods[i].access_flags & DEX_ACC_PRIVATE) {
            if (fallback == NO_INDEX)
                fallback = d->methods[mi].proto_idx;
            continue;
        }
        return d->methods[mi].proto_idx;
    }
    return fallback;
}

/* ---------------------------------------------------------------- */
/* members                                                           */
/* ---------------------------------------------------------------- */

static void emit_method(Emitter *e, uint32_t method_idx, uint32_t access, ClassFacts *facts,
                        SigSet *seen, MethodWinner *winners, uint32_t nwin,
                        uint32_t class_def_idx, int conflicting)
{
    Dex *d = e->dex;
    /* Package-private members of a class that was moved out of the default
     * package must be reachable from the code that used to share its package. */
    if (class_def_idx < d->hdr.class_defs_size &&
        remap_is_relocated_default(dex_type_desc(d, d->classes[class_def_idx].class_idx)) &&
        !(access & (DEX_ACC_PUBLIC | DEX_ACC_PRIVATE | DEX_ACC_PROTECTED)))
        access |= DEX_ACC_PUBLIC;
    if (method_idx >= d->hdr.method_ids_size)
        return;
    const DexMethodId *m = &d->methods[method_idx];
    if (m->proto_idx >= d->hdr.proto_ids_size)
        return;
    const char *name = java_member_name(d, m->class_idx, method_idx, 1);

    /* Class initialisers carry the real initialisation logic; without a body
     * pass they would only produce an empty block, so omit them. */
    if (!strcmp(name, "<clinit>"))
        return;

    /* Covariant overrides: when two methods share a name and parameter list,
     * keep the one with the most specific return type (the one javac needs to
     * satisfy the interface), not whichever came first. */
    char key[1200];
    proto_key(d, m->proto_idx, key, sizeof(key));
    uint32_t h = sig_hash(name, key);

    /* The winner check must run before the duplicate filter: DEX lists the
     * compiler's wider bridges alongside the real override, and whichever comes
     * first would otherwise claim the signature. That left the losing bridge
     * dropped for its return type while the real method was rejected as a
     * duplicate, so neither was emitted. */
    MethodWinner *w = winner_find(winners, nwin, h);
    if (getenv("TACHYON_DBG_M") && !strcmp(facts->name, "uc1") && !strcmp(name, "a"))
        fprintf(stderr, "[m] uc1.a own=%s w=%s drop=%d\n",
                dex_type_desc(d, d->protos[m->proto_idx].return_type_idx),
                w ? dex_type_desc(d, w->ret_type) : "none", w ? w->drop : -1);
    if (w) {
        if (w->drop)
            return;
        int this_bridge = (access & DEX_ACC_BRIDGE) != 0;
        if (!w->is_bridge && this_bridge)
            return;
        if (m->proto_idx < d->hdr.proto_ids_size &&
            d->protos[m->proto_idx].return_type_idx != w->ret_type)
            return;
    }
    if (platform_method_conflict(d, class_def_idx, name, key,
                                 d->protos[m->proto_idx].return_type_idx))
        return;
    if (!sigset_add(seen, h))
        return;

    int is_ctor = !strcmp(name, "<init>");
    int iface_default = 0;

    /* Bridge methods are compiler-generated forwarders. They are kept only when
     * no real implementation shares their signature, because a class may rely
     * on the bridge to satisfy an interface it never implements directly. */
    int is_bridge = (access & DEX_ACC_BRIDGE) != 0;
    /* javac synthesises values() and valueOf(String) for every enum, so
     * declaring them again is a duplicate-method error. R8's $values helper has
     * no source-level equivalent either. */
    if (facts->is_enum && !is_ctor) {
        DexParamList *pl0 = dex_proto_params(d, m->proto_idx);
        if (!strcmp(name, "values") && (!pl0 || pl0->param_count == 0))
            return;
        if (!strcmp(name, "valueOf") && pl0 && pl0->param_count == 1 &&
            !strcmp(dex_type_desc(d, pl0->type_idx[0]), "Ljava/lang/String;"))
            return;
        if (!strcmp(name, "$values"))
            return;
    }

    if (conflicting) {
        /* In a class that mixes java.* and j$.* interfaces, a method whose
         * return type is spelled the JDK way can never match the j$ declaration
         * it is supposed to implement. Emitting it would be a compile error, and
         * the interface default (or the inherited one) already covers callers. */
        const char *rd = dex_type_desc(d, d->protos[m->proto_idx].return_type_idx);
        if (rd && !strncmp(rd, "Ljava/", 6))
            return;
    }
    (void)0;

    char ret[512];
    remap_java_type(dex_type_desc(d, d->protos[m->proto_idx].return_type_idx), ret, sizeof(ret));

    indent(e);
    if (!is_ctor) {
        /* Interface methods with real code are default methods; ones without code
         * are plain declarations and must not carry the keyword. */
        int this_has_code = 0;
        {
            const DexClassData *cd2 = dex_class_data(d, class_def_idx);
            if (cd2) {
                for (uint32_t q = 0; q < cd2->direct_count && !this_has_code; q++)
                    if (cd2->direct_methods[q].method_idx == method_idx &&
                        cd2->direct_methods[q].code_off)
                        this_has_code = 1;
                for (uint32_t q = 0; q < cd2->virtual_count && !this_has_code; q++)
                    if (cd2->virtual_methods[q].method_idx == method_idx &&
                        cd2->virtual_methods[q].code_off)
                        this_has_code = 1;
            }
        }

        uint32_t mflags = access;
        if (facts->is_interface) {
            mflags &= ~DEX_ACC_ABSTRACT;
            if (!(access & DEX_ACC_STATIC))
                mflags &= ~(DEX_ACC_PUBLIC | DEX_ACC_PRIVATE | DEX_ACC_PROTECTED);
            if (!(access & DEX_ACC_STATIC) && this_has_code)
                iface_default = 1;
        }
        buf_puts(e->out, dex_access_string_for(mflags, 1));
        if (iface_default)
            buf_puts(e->out, "default ");
        buf_printf(e->out, "%s %s", ret, name);
    } else {
        /* Enum constructors are implicitly private and may not carry an access
         * modifier, but they must still be emitted: the constant list binds to
         * them by arity and type. */
        /* A package-private constructor is unreachable from a subclass in another
         * package, which is the shape R8 leaves behind after splitting a class
         * hierarchy across packages. protected keeps it non-public but callable. */
        uint32_t cacc = access;
        if (!(cacc & (DEX_ACC_PUBLIC | DEX_ACC_PRIVATE | DEX_ACC_PROTECTED)))
            cacc |= DEX_ACC_PROTECTED;
        if (!facts->is_enum)
            buf_puts(e->out, dex_access_string_for(cacc, 1));
        buf_puts(e->out, facts->name);
    }

    buf_puts(e->out, "(");
    DexParamList *pl = dex_proto_params(d, m->proto_idx);
    for (uint32_t i = 0; pl && i < pl->param_count; i++) {
        if (i)
            buf_puts(e->out, ", ");
        char pbuf[512];
        remap_java_type(dex_type_desc(d, pl->type_idx[i]), pbuf, sizeof(pbuf));
        buf_printf(e->out, "%s p%u", pbuf, i);
    }
    (void)0;
    buf_puts(e->out, ")");

    /* An interface method is a declaration unless the dex actually gives it
     * code (a default method). Writing "return null;" inside a declaration is a
     * compile error, so check for real code before emitting a body. */
    int has_code = 0;
    {
        const DexClassData *cdata = dex_class_data(d, class_def_idx);
        if (cdata) {
            for (uint32_t q = 0; q < cdata->direct_count && !has_code; q++)
                if (cdata->direct_methods[q].method_idx == method_idx &&
                    cdata->direct_methods[q].code_off)
                    has_code = 1;
            for (uint32_t q = 0; q < cdata->virtual_count && !has_code; q++)
                if (cdata->virtual_methods[q].method_idx == method_idx &&
                    cdata->virtual_methods[q].code_off)
                    has_code = 1;
        }
    }
    if ((access & (DEX_ACC_ABSTRACT | DEX_ACC_NATIVE)) ||
        (facts->is_interface && !has_code && !iface_default)) {
        buf_puts(e->out, ";\n");
        return;
    }

    buf_puts(e->out, " {\n");
    e->indent++;

    /* Try a real body first; the stub below is only the fallback. Bodies are
     * opt-in because a partially recovered method may not compile. */
    if (g_emit_bodies) {
        Arena *arena = java_body_arena();
        if (arena) {
        const DexEncodedMethod *em = NULL;
        for (uint32_t q = 0; q < 2 && !em; q++) {
            const DexClassData *cdata = dex_class_data(e->dex, class_def_idx);
            if (!cdata)
                break;
            uint32_t cnt = q ? cdata->virtual_count : cdata->direct_count;
            const DexEncodedMethod *arr = q ? cdata->virtual_methods : cdata->direct_methods;
            for (uint32_t k = 0; k < cnt; k++) {
                if (arr[k].method_idx == method_idx) {
                    em = &arr[k];
                    break;
                }
            }
        }
        if (em && em->code_off) {
            int rc = body_decompile(e->dex, class_def_idx, em, e->indent, e->out, arena);
            if (rc == 0) {
                e->indent--;
                indent(e);
                buf_puts(e->out, "}\n");
                return;
            }
        }
        }
    }

    if (is_ctor) {
        if (getenv("TACHYON_DBG_CTOR") && !strcmp(facts->name, "ttb"))
            fprintf(stderr, "[ctor] ttb known=%d noarg=%d pcount=%d pctor_cnt=%u ctor_cnt=%u\n",
                    facts->parent_known, facts->parent_has_noarg_ctor, facts->parent_param_count,
                    facts->parent_ctor_param_count, facts->ctor_param_count);
        if (!facts->is_enum && !facts->parent_known && facts->parent_param_count > 0) {
            indent(e);
            buf_puts(e->out, "super(");
            for (int k = 0; k < facts->parent_param_count; k++) {
                if (k)
                    buf_puts(e->out, ", ");
                char pbuf[512];
                remap_java_type(facts->parent_params[k], pbuf, sizeof(pbuf));
                buf_printf(e->out, "(%s) %s", pbuf, java_default_value(pbuf));
            }
            buf_puts(e->out, ");\n");
            goto ctor_done;
        }
        if (!facts->is_enum && !facts->parent_known && facts->parent_ctor_param_count > 0 &&
            facts->ctor_param_count >= facts->parent_ctor_param_count) {
            /* The parent is a platform class whose constructors cannot be read
             * here. Forwarding this constructor's own arguments is the only shape
             * that can type-check; a bare super() fails whenever the platform
             * class has no no-arg constructor (FrameLayout, ViewGroup, View). */
            indent(e);
            buf_puts(e->out, "super(");
            for (uint32_t k = 0; k < facts->parent_ctor_param_count; k++) {
                if (k)
                    buf_puts(e->out, ", ");
                buf_printf(e->out, "p%u", k);
            }
            buf_puts(e->out, ");\n");
            goto ctor_done;
        }
        if (facts->is_enum) {
            /* The implicit Enum(String,int) call is inserted by javac and any
             * explicit super() here is rejected. */
        } else if (facts->parent_has_noarg_ctor) {
            indent(e);
            buf_puts(e->out, "super();\n");
        } else if (!facts->parent_ctor_known && facts->parent_param_count > 0) {
            /* Platform parent with known parameter descriptors: typed defaults
             * match the real signature exactly. */
            indent(e);
            buf_puts(e->out, "super(");
            for (int k = 0; k < facts->parent_param_count; k++) {
                if (k)
                    buf_puts(e->out, ", ");
                char pbuf[512];
                remap_java_type(facts->parent_params[k], pbuf, sizeof(pbuf));
                buf_printf(e->out, "(%s) %s", pbuf, java_default_value(pbuf));
            }
            buf_puts(e->out, ");\n");
        } else if (facts->parent_ctor_known) {
            /* The parent exposes no no-arg constructor, so the body must chain to
             * one of its declared constructors; its arguments are unknown here
             * and are filled with defaults so the call type-checks. */
            indent(e);
            buf_puts(e->out, "super(");
            Dex *pd = facts->parent_dex ? facts->parent_dex : d;
            DexParamList *ppl = dex_proto_params(pd, facts->parent_ctor_proto);
            for (uint32_t k = 0; ppl && k < ppl->param_count; k++) {
                if (k)
                    buf_puts(e->out, ", ");
                char pbuf[512];
                remap_java_type(dex_type_desc(pd, ppl->type_idx[k]), pbuf, sizeof(pbuf));
                /* Cast the default: the parent may overload its constructors and a
                 * bare null would be ambiguous. */
                buf_printf(e->out, "(%s) %s", pbuf, java_default_value(pbuf));
            }
            buf_puts(e->out, ");\n");
        }
ctor_done:
        ;
    } else if (strcmp(ret, "void")) {
        indent(e);
        buf_printf(e->out, "return %s;\n", java_default_value(ret));
    } else {
        indent(e);
        buf_puts(e->out, "throw new RuntimeException(\"tachyon: body not decompiled\");\n");
    }
    e->indent--;
    indent(e);
    buf_puts(e->out, "}\n");
}

/* Renders a static field's encoded initial value, or NULL when there is none or
 * when the encoding does not fit the declared type. */
static const char *static_value_literal(Emitter *e, const DexValue *v, char *buf, size_t cap,
                                        const char *field_desc)
{
    Dex *d = e->dex;
    if (!v)
        return NULL;

    /* The encoded array is positional: when a field has no entry the compiler
     * still emits one for a later field, so a value can land on the wrong type.
     * Only accept an encoding that matches the declared descriptor. */
    char want = field_desc && field_desc[0] ? field_desc[0] : '?';
    char got = 0;
    switch (v->value_type) {
    case 0x17: got = 'L'; break;               /* string -> String */
    case 0x00: got = 'B'; break;               /* byte */
    case 0x02: got = 'S'; break;               /* short */
    case 0x03: got = 'K'; break;               /* char */
    case 0x04: got = 'I'; break;               /* int */
    case 0x1f: got = 'Z'; break;               /* boolean */
    case 0x06: got = 'J'; break;               /* long */
    case 0x10: got = 'F'; break;
    case 0x11: got = 'D'; break;
    case 0x18: got = 'C'; break;               /* Class */
    case 0x1e: got = 'N'; break;               /* null */
    default: got = '?'; break;
    }
    if (got == 'N') {
        /* null only makes sense for a reference field; a primitive has to keep
         * its default value instead. */
        if (want != 'L' && want != '[')
            return NULL;
    } else if (want == 'L' && got == 'L') {
        /* A String literal can only initialise a field whose type is String or
         * Object; R8 sometimes leaves a string on an unrelated reference field,
         * which javac rejects. */
        const char *fd = field_desc;
        if (fd && strcmp(fd, "Ljava/lang/String;") && strcmp(fd, "Ljava/lang/Object;") &&
            strcmp(fd, "Ljava/lang/CharSequence;"))
            return NULL;
    } else if (want != got) {
        /* A boolean cannot initialise an int field or vice versa, and a char
         * cannot take an int literal without a cast. Dropping the initialiser
         * keeps the declaration valid. */
        if ((want == 'I' || want == 'C') && (got == 'Z' || got == 'K' || got == 'B' || got == 'S'))
            return NULL;
        if (want == 'Z' && got != 'Z')
            return NULL;
        /* An int field carrying a value that only fits a long: R8 leaves these
         * behind, and dropping the initialiser would silently change the
         * constant. Keep it -- the literal below is emitted with an L suffix. */
        if (want == 'I' && got == 'J') {
            /* The field is an int but the encoded value is a long. Truncating to
             * 32 bits reproduces what the runtime actually stores in an int
             * field, which is the value the program observes. */
            snprintf(buf, cap, "%d", (int32_t)(uint32_t)(uint64_t)v->v.s);
            return buf;
        }
        return NULL;
    }

    switch (v->value_type) {
    case 0x17: { /* string */
        char esc[1024];
        java_escape_string(dex_string(d, (uint32_t)v->v.u), esc, sizeof(esc));
        snprintf(buf, cap, "\"%s\"", esc);
        return buf;
    }
    case 0x06: /* long: the L suffix is mandatory or javac reads it as an int */
        snprintf(buf, cap, "%lldL", (long long)v->v.s);
        return buf;
    case 0x00: case 0x02: case 0x04: { /* byte/short/int */
        /* R8 sometimes leaves a value that does not fit an int; javac rejects
         * the literal outright, so widen it and add the L suffix. */
        long long sv = (long long)v->v.s;
        if (sv > 2147483647LL || sv < -2147483648LL)
            snprintf(buf, cap, "%lldL", sv);
        else
            snprintf(buf, cap, "%lld", sv);
        return buf;
    }
    case 0x10: { /* float */
        float f;
        uint32_t bits = (uint32_t)v->v.u;
        memcpy(&f, &bits, 4);
        snprintf(buf, cap, "%gf", (double)f);
        return buf;
    }
    case 0x11: { /* double */
        uint64_t bits = v->v.u;
        double dv;
        memcpy(&dv, &bits, 8);
        snprintf(buf, cap, "%g", dv);
        return buf;
    }
    case 0x03: /* char */
        snprintf(buf, cap, "%u", (unsigned)v->v.u);
        return buf;
    case 0x1f: /* boolean */
        snprintf(buf, cap, "%s", v->v.u ? "true" : "false");
        return buf;
    case 0x1e: /* null */
        snprintf(buf, cap, "null");
        return buf;
    case 0x18: /* type */
        snprintf(buf, cap, "%s.class", dex_type_name(d, (uint32_t)v->v.u));
        return buf;
    default:
        return NULL;
    }
}

static void emit_field(Emitter *e, uint32_t field_idx, uint32_t access, const ClassFacts *facts,
                       const DexValue *init)
{
    Dex *d = e->dex;
    if (remap_is_relocated_default(dex_type_desc(d, d->fields[field_idx].class_idx)) &&
        !(access & (DEX_ACC_PUBLIC | DEX_ACC_PRIVATE | DEX_ACC_PROTECTED)))
        access |= DEX_ACC_PUBLIC;
    char tbuf[512];
    memset(tbuf, 0, sizeof(tbuf));
    remap_java_type(dex_type_desc(d, d->fields[field_idx].type_idx), tbuf, sizeof(tbuf));
    const char *name = java_member_name(d, d->fields[field_idx].class_idx, field_idx, 0);

    uint32_t flags = access;
    if (facts->is_interface)
        flags |= DEX_ACC_PUBLIC | DEX_ACC_STATIC | DEX_ACC_FINAL;


    int needs_init = (flags & DEX_ACC_FINAL) || (flags & DEX_ACC_STATIC) || facts->is_interface;

    indent(e);
    buf_printf(e->out, "%s%s %s", dex_access_string_for(flags, 0), tbuf, name);
    if (needs_init) {
        char lit[1200];
        const char *lit_s = static_value_literal(e, init, lit, sizeof(lit),
                                                 dex_type_desc(d, d->fields[field_idx].type_idx));
        buf_printf(e->out, " = %s", lit_s ? lit_s : java_default_value(tbuf));
    }
    buf_puts(e->out, ";\n");
}

/* ---------------------------------------------------------------- */
/* method preselection                                               */
/* ---------------------------------------------------------------- */

static int type_depth(Dex *d, uint32_t type_idx)
{
    int depth = 0;
    uint32_t cur = type_idx;
    for (int guard = 0; guard < 32; guard++) {
        uint32_t cdef = class_def_of_type(d, cur);
        if (cdef == NO_INDEX)
            break;
        uint32_t sup = d->classes[cdef].superclass_idx;
        if (sup == NO_INDEX)
            break;
        depth++;
        cur = sup;
    }
    return depth;
}

/* True when `a` is `b` or a transitive supertype of `b`, through the
 * superclass chain *and* implemented interfaces. Checking only the class chain
 * misses the common case where a narrower return type is an interface that the
 * wider one does not extend. */
static int is_supertype(Dex *d, uint32_t a, uint32_t b)
{
    if (a == b)
        return 1;

    uint32_t stack[256];
    uint32_t *seen = calloc(512, sizeof(uint32_t));
    if (!seen)
        return 0;
    uint32_t sn = 0, nseen = 0, sp = 0;
    stack[sp++] = b;
    seen[nseen++] = b;

    int found = 0;
    while (sp) {
        uint32_t cur = stack[--sp];
        uint32_t cdef = class_def_of_type(d, cur);
        if (cdef == NO_INDEX)
            continue;
        const DexClassDef *cd = &d->classes[cdef];

        uint32_t next[512];
        uint32_t nn = 0;
        if (cd->superclass_idx != NO_INDEX && cd->superclass_idx != cur)
            next[nn++] = cd->superclass_idx;
        if (cd->interfaces_off && cd->interfaces_off < d->size) {
            uint32_t ic = 0;
            memcpy(&ic, d->base + cd->interfaces_off, 4);
            if (ic < 0x1000) {
                for (uint32_t i = 0; i < ic && nn < 512; i++) {
                    uint16_t ti;
                    memcpy(&ti, d->base + cd->interfaces_off + 4 + (size_t)i * 2, 2);
                    next[nn++] = ti;
                }
            }
        }

        for (uint32_t i = 0; i < nn; i++) {
            uint32_t t = next[i];
            if (t == a) {
                found = 1;
                break;
            }
            int dup = 0;
            for (uint32_t k = 0; k < nseen; k++)
                if (seen[k] == t) {
                    dup = 1;
                    break;
                }
            if (dup)
                continue;
            if (nseen < 512)
                seen[nseen++] = t;
            if (sp < 256)
                stack[sp++] = t;
        }
        if (found)
            break;
    }
    free(seen);
    (void)sn;
    return found;
}

/* Gathers every supertype (superclasses and interfaces) of `type_idx` into
 * `out`, returning the count. Used to look for narrower return types declared
 * by a parent. */
static uint32_t collect_supertypes(Dex *d, uint32_t type_idx, uint32_t *out, uint32_t max)
{
    /* Breadth-first over the whole type hierarchy: superclass chain plus every
     * interface reachable from it, transitively. A one-level walk misses the
     * constraint when the declaration sits on an interface several levels up
     * (Stream -> BaseStream -> ...). */
    uint32_t n = 0;
    /* A ring buffer instead of memmove-per-pop: the previous version was O(n^2)
     * in the queue length and dominated the whole run on deep hierarchies. */
    /* Each queue entry carries the dex that owns the type index: type indices are
     * per-dex, so a bare index cannot be interpreted without knowing its file. */
    uint32_t cap2 = max * 2;
    typedef struct { Dex *d; uint32_t t; } QEnt;
    QEnt *queue = malloc((size_t)cap2 * sizeof(QEnt));
    /* Membership is a bitmap over type indices: a linear `seen` array made each
     * push O(visited) and the whole walk quadratic. */
    uint32_t nbits = (d->hdr.type_ids_size / 32) + 2;
    uint32_t *seen = calloc(nbits, sizeof(uint32_t));
    if (!queue || !seen) {
        free(queue);
        free(seen);
        return 0;
    }
    uint32_t qn = 0, sn = 0, qhead = 0;
    queue[qn].d = d;
    queue[qn].t = type_idx;
    qn++;
    if (type_idx / 32 < nbits)
        seen[type_idx / 32] |= 1u << (type_idx % 32);
    sn = 1;
    /* qn counts elements currently queued, qhead is the read cursor; a push must
     * therefore write at qhead+qn, not at qn. */

    while (qn && n < max) {
        Dex *cdx = queue[qhead % cap2].d;
        uint32_t cur = queue[qhead % cap2].t;
        qhead++;
        qn--;

        /* A supertype may live in a sibling dex. Its class_def index is only
         * meaningful together with the owning dex, so both come from the lookup. */
        /* Only this dex: a type index from another file names a different class,
         * and the resulting supertype list is wrong in ways that make far more
         * files uncompilable than it fixes. */
        Dex *owner = cdx;
        uint32_t cdef = dex_class_def_of_type(cdx, cur);
        if (cdef == NO_INDEX || cdef >= cdx->hdr.class_defs_size)
            continue;
        const DexClassDef *cd = &cdx->classes[cdef];

        uint32_t next[1024];
        uint32_t nn = 0;
        if (cd->superclass_idx != NO_INDEX && cd->superclass_idx != cur)
            next[nn++] = cd->superclass_idx;
        if (cd->interfaces_off && cd->interfaces_off < owner->size) {
            uint32_t ic = 0;
            memcpy(&ic, owner->base + cd->interfaces_off, 4);
            if (ic < 0x1000) {
                for (uint32_t i = 0; i < ic && nn < 1024; i++) {
                    uint16_t ti;
                    memcpy(&ti, owner->base + cd->interfaces_off + 4 + (size_t)i * 2, 2);
                    next[nn++] = ti;
                }
            }
        }

        for (uint32_t i = 0; i < nn && n < max; i++) {
            uint32_t t = next[i];
            if (t / 32 >= nbits)
                continue;
            uint32_t bit = 1u << (t % 32);
            if (seen[t / 32] & bit)
                continue;
            seen[t / 32] |= bit;
            sn++;
            if (qn < cap2) {
                /* Children of a cross-dex parent belong to that parent's file. */
                queue[(qhead + qn) % cap2].d = owner;
                queue[(qhead + qn) % cap2].t = t;
                qn++;
            }
            out[n++] = t;
        }
    }
    free(queue);
    free(seen);
    return n;
}

/* ---------------------------------------------------------------- */
/* class                                                             */
/* ---------------------------------------------------------------- */

Arena *java_body_arena(void)
{
    return g_body_arena;
}

int java_body_arena_valid(void)
{
    uintptr_t p = (uintptr_t)g_body_arena;
    return p > 0x10000 && p < 0x7fffffffffffULL;
}

void java_set_body_arena(Arena *a)
{
    g_body_arena = a;
    g_member_arena = a;
}

void java_set_accurate_mode(int on)
{
    g_accurate_mode = on;
}

void java_set_emit_bodies(int on)
{
    g_emit_bodies = on;
}

void java_set_skip_conflicts(int on)
{
    g_skip_conflicts = on;
}

int java_skip_conflicts(void)
{
    return g_skip_conflicts;
}

int java_emit_bodies(void)
{
    return g_emit_bodies;
}

/* Returns 1 when the class lists an interface whose JDK spelling and desugared
 * spelling are both present. Those two declarations disagree on every method
 * that mentions the type, and no single implementation can satisfy both, so the
 * class cannot be rendered as compilable Java at all. */
static int class_has_conflicting_interfaces(Dex *dex, const DexClassDef *cd)
{
    if (!cd->interfaces_off || cd->interfaces_off >= dex->size)
        return 0;
    uint32_t n = 0;
    memcpy(&n, dex->base + cd->interfaces_off, 4);
    if (n >= 0x1000 || cd->interfaces_off + 4 + (size_t)n * 2 > dex->size)
        return 0;

    for (uint32_t i = 0; i < n; i++) {
        uint16_t ti;
        memcpy(&ti, dex->base + cd->interfaces_off + 4 + (size_t)i * 2, 2);
        const char *a = dex_type_desc(dex, ti);
        if (!a || strncmp(a, "Ljava/", 6))
            continue;
        char alt[1024];
        snprintf(alt, sizeof(alt), "Lj$/%s", a + 6);
        for (uint32_t k = 0; k < n; k++) {
            uint16_t tk;
            memcpy(&tk, dex->base + cd->interfaces_off + 4 + (size_t)k * 2, 2);
            const char *b = dex_type_desc(dex, tk);
            if (b && !strcmp(b, alt))
                return 1;
        }
    }

    /* A class living in the j$ tree that implements a plain java.* interface has
     * the same problem one level down: its methods are declared with j$ types
     * while the interface spells them java.*, so nothing it declares can match.
     * Treat that as conflicting too. */
    const char *self = dex_type_desc(dex, cd->class_idx);
    if (self && !strncmp(self, "Lj$/", 4)) {
        for (uint32_t i = 0; i < n; i++) {
            uint16_t ti;
            memcpy(&ti, dex->base + cd->interfaces_off + 4 + (size_t)i * 2, 2);
            const char *a = dex_type_desc(dex, ti);
            if (a && !strncmp(a, "Ljava/", 6) && !remap_needed(a))
                return 1;
        }
    }
    return 0;
}

/* Returns 1 when an inherited final method has the same name and parameters as
 * a method the class's interfaces require, but a different return type. Java
 * forbids overriding a final method, so such a class cannot satisfy the
 * interface at all and the interface has to be dropped. */
static int has_final_override_conflict(Dex *dex, const DexClassDef *cd)
{
    uint32_t sup[256];
    uint32_t nsup = collect_supertypes(dex, cd->class_idx, sup, 256);


    for (uint32_t s = 0; s < nsup; s++) {
        uint32_t sdef = dex_class_def_of_type(dex, sup[s]);
        if (sdef == DEX_NO_INDEX)
            continue;
        if (dex->classes[sdef].access_flags & DEX_ACC_INTERFACE)
            continue; /* interface methods are not final in this sense */
        const DexClassData *sdata = dex_class_data(dex, sdef);
        if (!sdata)
            continue;
        for (uint32_t i = 0; i < sdata->virtual_count; i++) {
            uint32_t mi = sdata->virtual_methods[i].method_idx;
            if (mi >= dex->hdr.method_ids_size)
                continue;
            if (!(sdata->virtual_methods[i].access_flags & DEX_ACC_FINAL))
                continue;
            const char *fname = dex_method_name(dex, mi);
            uint32_t fproto = dex->methods[mi].proto_idx;
            if (fproto >= dex->hdr.proto_ids_size)
                continue;
            uint32_t fret = dex->protos[fproto].return_type_idx;

            /* Does any interface in the hierarchy declare the same signature
             * with a different return type? */
            for (uint32_t t = 0; t < nsup; t++) {
                uint32_t idef = dex_class_def_of_type(dex, sup[t]);
                if (idef == DEX_NO_INDEX)
                    continue;
                if (!(dex->classes[idef].access_flags & DEX_ACC_INTERFACE))
                    continue;
                const DexClassData *idata = dex_class_data(dex, idef);
                if (!idata)
                    continue;
                for (uint32_t k = 0; k < idata->virtual_count; k++) {
                    uint32_t imi = idata->virtual_methods[k].method_idx;
                    if (imi >= dex->hdr.method_ids_size)
                        continue;
                    if (strcmp(dex_method_name(dex, imi), fname))
                        continue;
                    uint32_t iproto = dex->methods[imi].proto_idx;
                    if (iproto >= dex->hdr.proto_ids_size)
                        continue;
                    char ka[1200], kb[1200];
                    proto_key(dex, fproto, ka, sizeof(ka));
                    proto_key(dex, iproto, kb, sizeof(kb));
                    if (strcmp(ka, kb))
                        continue;
                    uint32_t iret = dex->protos[iproto].return_type_idx;
                    if (iret != fret)
                        return 1;
                }
            }
        }
    }
    return 0;
}

/* Broader than has_final_override_conflict: any method whose signature matches
 * an interface requirement but whose return type differs makes the class
 * impossible to finish, because Java overloads ignore return types and the
 * inherited requirement cannot be satisfied. Such classes are emitted as
 * abstract so they still compile. */
static int has_unresolvable_override(Dex *dex, const DexClassDef *cd, uint32_t class_def_idx)
{
    const DexClassData *data = dex_class_data(dex, class_def_idx);
    if (!data)
        return 0;

    uint32_t sup[256];
    uint32_t nsup = collect_supertypes(dex, cd->class_idx, sup, 256);


    for (uint32_t i = 0; i < data->virtual_count + data->direct_count; i++) {
        uint32_t mi = i < data->virtual_count
                          ? data->virtual_methods[i].method_idx
                          : data->direct_methods[i - data->virtual_count].method_idx;
        if (mi >= dex->hdr.method_ids_size)
            continue;
        uint32_t proto = dex->methods[mi].proto_idx;
        if (proto >= dex->hdr.proto_ids_size)
            continue;
        uint32_t ret = dex->protos[proto].return_type_idx;
        const char *nm = dex_method_name(dex, mi);
        if (!nm || !strcmp(nm, "<init>") || !strcmp(nm, "<clinit>"))
            continue;
        char key[1200];
        proto_key(dex, proto, key, sizeof(key));

        for (uint32_t t = 0; t < nsup; t++) {
            uint32_t idef = dex_class_def_of_type(dex, sup[t]);
            if (idef == DEX_NO_INDEX)
                continue;
            if (!(dex->classes[idef].access_flags & DEX_ACC_INTERFACE))
                continue;
            const DexClassData *idata = dex_class_data(dex, idef);
            if (!idata)
                continue;
            for (uint32_t k = 0; k < idata->virtual_count; k++) {
                uint32_t imi = idata->virtual_methods[k].method_idx;
                if (imi >= dex->hdr.method_ids_size)
                    continue;
                if (strcmp(dex_method_name(dex, imi), nm))
                    continue;
                uint32_t iproto = dex->methods[imi].proto_idx;
                if (iproto >= dex->hdr.proto_ids_size)
                    continue;
                char ikey[1200];
                proto_key(dex, iproto, ikey, sizeof(ikey));
                if (strcmp(key, ikey))
                    continue;
                uint32_t iret = dex->protos[iproto].return_type_idx;
                if (iret != ret && !is_supertype(dex, iret, ret))
                    return 1;
            }
        }
    }
    return 0;
}

/* True when a supertype declares an abstract method that this class does not
 * implement. Such a class cannot be concrete, whatever the flags say: the
 * decompiler may have dropped the implementation while resolving a conflict. */
/* Result cache: the check walks the whole supertype graph, and every class is
 * emitted exactly once, so a single bit per class_def is enough. */
static uint8_t *g_missing_bitmap;
static uint32_t *g_missing_offsets;

/* One slot per (dex, class_def) pair: class_def indices repeat across the dex
 * files of an APK, so a plain index would return another file's answer. */
void java_prepare_missing_bitmap(Dex *dex, Arena *arena)
{
    if (g_missing_bitmap || !dex)
        return;
    uint64_t total = 0;
    for (uint32_t i = 0; i < g_all_dex_count; i++)
        total += g_all_dex[i]->hdr.class_defs_size;
    if (total == 0)
        total = dex->hdr.class_defs_size;
    g_missing_bitmap = arena_zalloc(arena, (size_t)total + 1);
    g_missing_offsets = arena_zalloc(arena, ((size_t)g_all_dex_count + 1) * sizeof(uint32_t));
    if (g_missing_offsets) {
        uint32_t off = 0;
        for (uint32_t i = 0; i < g_all_dex_count; i++) {
            g_missing_offsets[i] = off;
            off += g_all_dex[i]->hdr.class_defs_size + 1;
        }
    }
}

/* Base offset of a dex in the cache, or 0 when it is not part of the input. */
static uint32_t missing_offset(Dex *dex)
{
    if (!g_missing_offsets)
        return 0;
    for (uint32_t i = 0; i < g_all_dex_count; i++)
        if (g_all_dex[i] == dex)
            return g_missing_offsets[i];
    return 0;
}

static int missing_abstract_impl_uncached(Dex *dex, const DexClassDef *cd,
                                          uint32_t class_def_idx);

static int missing_abstract_impl(Dex *dex, const DexClassDef *cd, uint32_t class_def_idx)
{
    if (g_missing_bitmap && class_def_idx < dex->hdr.class_defs_size) {
        uint32_t slot = missing_offset(dex) + class_def_idx;
        uint8_t v = g_missing_bitmap[slot];
        if (v)
            return v == 2 ? 0 : 1;
        int r = missing_abstract_impl_uncached(dex, cd, class_def_idx);
        g_missing_bitmap[slot] = r ? 1 : 2;
        return r;
    }
    return missing_abstract_impl_uncached(dex, cd, class_def_idx);
}

static int missing_abstract_impl_uncached(Dex *dex, const DexClassDef *cd,
                                          uint32_t class_def_idx)
{
    const DexClassData *data = dex_class_data(dex, class_def_idx);
    uint32_t sup[256];
    uint32_t nsup = collect_supertypes(dex, cd->class_idx, sup, 256);


    for (uint32_t t = 0; t < nsup; t++) {
        /* Resolve across dexes: a supertype defined in a sibling file still
         * contributes abstract methods, and skipping it left classes concrete
         * while they were missing implementations. */
        uint32_t sdef = class_def_of_type(dex, sup[t]);
        Dex *sowner = g_last_owner ? g_last_owner : dex;
        if (sdef == DEX_NO_INDEX || sdef >= sowner->hdr.class_defs_size)
            continue;
        const DexClassData *sdata = dex_class_data(sowner, sdef);
        if (!sdata)
            continue;
        int is_iface = (sowner->classes[sdef].access_flags & DEX_ACC_INTERFACE) != 0;

        for (uint32_t k = 0; k < sdata->virtual_count + sdata->direct_count; k++) {
            uint32_t mi = k < sdata->virtual_count
                              ? sdata->virtual_methods[k].method_idx
                              : sdata->direct_methods[k - sdata->virtual_count].method_idx;
            uint32_t acc = k < sdata->virtual_count
                               ? sdata->virtual_methods[k].access_flags
                               : sdata->direct_methods[k - sdata->virtual_count].access_flags;
            if (mi >= sowner->hdr.method_ids_size)
                continue;
            /* An interface method without code is abstract; a class method is
             * abstract only when flagged so. */
            int is_abstract = is_iface || (acc & DEX_ACC_ABSTRACT);
            if (!is_abstract)
                continue;
            const char *nm = dex_method_name(sowner, mi);
            if (!nm || !strcmp(nm, "<init>") || !strcmp(nm, "<clinit>"))
                continue;
            uint32_t proto = sowner->methods[mi].proto_idx;
            if (proto >= sowner->hdr.proto_ids_size)
                continue;
            char key[1200];
            proto_key(sowner, proto, key, sizeof(key));
            const char *sret_desc = dex_type_desc(sowner, sowner->protos[proto].return_type_idx);

            int implemented = 0;
            for (uint32_t m = 0; data && m < data->virtual_count && !implemented; m++) {
                uint32_t cmi = data->virtual_methods[m].method_idx;
                if (cmi >= dex->hdr.method_ids_size)
                    continue;
                if (strcmp(dex_method_name(dex, cmi), nm))
                    continue;
                char ckey[1200];
                proto_key(dex, dex->methods[cmi].proto_idx, ckey, sizeof(ckey));
                const char *cret =
                    dex_type_desc(dex, dex->protos[dex->methods[cmi].proto_idx].return_type_idx);
                if (!strcmp(ckey, key) && cret && sret_desc && !strcmp(cret, sret_desc))
                    implemented = 1;
            }
            if (!implemented)
                return 1;
        }
    }
    return 0;
}

/* Java resolves a simple name against types in the current package before
 * packages, so a class called "cn" inside package "cn.fly.verify" makes every
 * "cn.fly.verify.X" reference resolve to that class instead of the package.
 * Such shadowing classes get a suffix. */
static int class_shadows_own_package_root(Dex *dex, const char *desc, const char *simple)
{
    const char *p = desc;
    if (!p || p[0] != 'L')
        return 0;
    p++;
    const char *slash = strchr(p, '/');
    if (!slash)
        return 0; /* default package: handled separately */

    /* first path segment of this class's own package */
    size_t n = (size_t)(slash - p);
    return n == strlen(simple) && !strncmp(p, simple, n);
}

/* A class in the default package whose name equals a top-level package name
 * ("cn" next to "cn/") makes every reference to that package ambiguous: javac
 * reports "symbol: class cn" and the whole tree fails. Such classes get a suffix
 * so the package keeps the name. */
static int g_shadow_building;

static int class_shadows_package(Dex *dex, const char *simple)
{
    /* While the table is being built the scan must run; afterwards the table is
     * authoritative and makes this a handful of comparisons. */
    if (g_shadow_names && !g_shadow_building) {
        for (uint32_t i = 0; i < g_shadow_count; i++)
            if (!strcmp(g_shadow_names[i], simple))
                return 1;
        return 0;
    }
    /* Only default-package classes can shadow, and there are few of them, so the
     * caller filters first. This still walks the class list, so cache the answer
     * per name: without it every one of the ~12k classes rescans the table. */
    static _Thread_local const Dex *cached_dex;
    static _Thread_local char cached_simple[256];
    static _Thread_local int cached_result;

    if (cached_dex == dex && !strcmp(cached_simple, simple))
        return cached_result;

    int found = 0;
    for (uint32_t i = 0; i < dex->hdr.class_defs_size && !found; i++) {
        const char *d = dex_type_desc(dex, dex->classes[i].class_idx);
        if (!d || d[0] != 'L')
            continue;
        const char *slash = strchr(d + 1, '/');
        if (!slash)
            continue; /* itself is in the default package */
        size_t n = (size_t)(slash - (d + 1));
        if (n == strlen(simple) && !strncmp(d + 1, simple, n))
            found = 1;
    }
    cached_dex = dex;
    snprintf(cached_simple, sizeof(cached_simple), "%s", simple);
    cached_result = found;
    return found;
}

/* Exposed to the remap layer: a class renamed to avoid a clash (reserved word or
 * package shadowing) must keep that name in every reference, including the bare
 * ones used inside its own package. */
/* Names that need a suffix because they shadow a package. Built once per dex so
 * the check is a hash lookup instead of a scan: without this the per-reference
 * cost is O(classes) and a 15k-class input takes minutes. */


static int cmp_cstr(const void *a, const void *b)
{
    return strcmp(*(const char *const *)a, *(const char *const *)b);
}

static void build_shadow_table(Dex *dex)
{
    if (g_shadow_names || !dex)
        return;
    g_shadow_building = 1;

    /* Collect every package root and every default-package class name. */
    uint32_t n = dex->hdr.class_defs_size;
    char **roots = arena_zalloc(dex->arena, (size_t)(n + 1) * sizeof(char *));
    uint32_t nroots = 0;
    if (!roots)
        return;

    for (uint32_t i = 0; i < n; i++) {
        const char *d = dex_type_desc(dex, dex->classes[i].class_idx);
        if (!d || d[0] != 'L')
            continue;
        const char *slash = strchr(d + 1, '/');
        if (!slash)
            continue;
        size_t len = (size_t)(slash - (d + 1));
        char root[128];
        if (len >= sizeof(root))
            continue;
        memcpy(root, d + 1, len);
        root[len] = '\0';
        int dup = 0;
        for (uint32_t k = 0; k < nroots; k++)
            if (!strcmp(roots[k], root)) {
                dup = 1;
                break;
            }
        if (!dup && nroots < n)
            roots[nroots++] = arena_strdup(dex->arena, root);
    }

    g_shadow_cap = n + 16;
    g_shadow_names = arena_zalloc(dex->arena, (size_t)g_shadow_cap * sizeof(char *));
    if (!g_shadow_names)
        return;

    /* Every class path, sorted once. A class is a package prefix when some other
     * path continues past it with '/'. Binary search makes this O(n log n)
     * instead of the O(n^2) string compare that cost 60+ seconds on 15k classes. */
    char **paths = arena_zalloc(dex->arena, (size_t)(n + 1) * sizeof(char *));
    uint32_t npaths = 0;
    if (paths) {
        for (uint32_t i = 0; i < n; i++) {
            const char *d = dex_type_desc(dex, dex->classes[i].class_idx);
            if (!d || d[0] != 'L')
                continue;
            const char *semi = strchr(d, ';');
            size_t l = semi ? (size_t)(semi - d - 1) : strlen(d + 1);
            char *copy = arena_alloc(dex->arena, l + 1);
            if (!copy)
                break;
            memcpy(copy, d + 1, l);
            copy[l] = '\0';
            paths[npaths++] = copy;
        }
        qsort(paths, npaths, sizeof(char *), cmp_cstr);
    }

    /* A class whose full path equals a package prefix ("com/a/b/A" vs the package
     * "com/a/b/A") cannot coexist with that package either. Mark those too. */
    for (uint32_t i = 0; i < n; i++) {
        const char *d = dex_type_desc(dex, dex->classes[i].class_idx);
        if (!d || d[0] != 'L')
            continue;
        const char *semi = strchr(d, ';');
        size_t len = semi ? (size_t)(semi - d - 1) : strlen(d + 1);
        const char *start = d + 1;
        for (size_t k = 0; k < len; k++) {
            if (start[k] == '/') {
                start += k + 1;
                len -= k + 1;
                break;
            }
        }
        char simple[128];
        if (len >= sizeof(simple) || len == 0)
            continue;
        memcpy(simple, start, len);
        simple[len] = '\0';
        char *star = strchr(simple, '$');
        if (star)
            *star = '\0';

        int shadow = 0;
        for (uint32_t k = 0; k < nroots && !shadow; k++)
            if (!strcmp(roots[k], simple))
                shadow = 1;

        /* A class whose full path is used as a package prefix by another class
         * cannot coexist with that package: "com/apm/log/a" as a class next to
         * "com/apm/log/a/b" makes the latter unresolvable. The prefix scan below
         * is a simple linear pass over the class table, done once at startup. */
        if (!shadow && paths) {
            size_t plen = len + (size_t)(start - (d + 1));
            /* The class's own path is its prefix candidate. */
            uint32_t lo = 0, hi = npaths;
            while (lo < hi) {
                uint32_t mid = lo + (hi - lo) / 2;
                if (strncmp(paths[mid], d + 1, plen) < 0)
                    lo = mid + 1;
                else
                    hi = mid;
            }
            for (uint32_t k = lo; k < npaths; k++) {
                int c = strncmp(paths[k], d + 1, plen);
                if (c > 0)
                    break;
                if (c == 0 && paths[k][plen] == '/') {
                    shadow = 1;
                    break;
                }
            }
        }
        if (shadow && g_shadow_count < g_shadow_cap) {
            g_shadow_names[g_shadow_count++] = arena_strdup(dex->arena, simple);
            uint32_t h = 0;
            for (const char *q = simple; *q; q++)
                h = h * 131u + (unsigned char)*q;
            g_shadow_bits |= 1ull << (h & 63u);
        }
    }
    g_shadow_building = 0;
}

void java_prepare_shadow_table(Dex *dex)
{
    /* Called once per dex before the pool starts. The guard is not just an
     * optimisation: a second build would reallocate the name table while workers
     * are reading it. */
    if (!g_shadow_names)
        build_shadow_table(dex);
}

void java_reset_shadow_table(void)
{
    g_shadow_names = NULL;
    g_shadow_count = 0;
    g_shadow_cap = 0;
    g_shadow_bits = 0;
    g_shadow_building = 0;
}

int java_simple_name_shadowed(Dex *dex, const char *simple)
{
    if (!dex || !simple || !*simple)
        return 0;

    /* Primitive type names are keywords but are emitted verbatim as the type
     * itself; renaming them to "int_" would break every reference. */
    static const char *prims[] = {"void", "boolean", "byte", "short", "char",
                                  "int", "long", "float", "double"};
    for (size_t i = 0; i < sizeof(prims) / sizeof(prims[0]); i++)
        if (!strcmp(simple, prims[i]))
            return 0;

    if (is_java_keyword(simple))
        return 1;

    /* The table is built once before the pool starts (see java_prepare_shadow_table);
     * building it lazily here would race between workers. */
    if (!g_shadow_names)
        return 0;

    /* The table is small (only names that collide), but this call happens for
     * every type reference, so use a bloom-style first-byte filter before the
     * string compares. */
    uint32_t h = 0;
    for (const char *q = simple; *q; q++)
        h = h * 131u + (unsigned char)*q;
    h &= 63u;
    if (!(g_shadow_bits & (1ull << h)))
        return 0;

    for (uint32_t i = 0; i < g_shadow_count; i++)
        if (!strcmp(g_shadow_names[i], simple))
            return 1;
    return 0;
}

/* Every emitted source carries this header. It is written before the package
 * declaration so the file stays valid Java. */
static void emit_watermark(Buf *out)
{
    buf_puts(out,
             "//TachYon An incredibly fast decompilation tool\n"
             "//No dependencies\n"
             "//TachYon CN AI Agent DeepSeekv4.1flash\n");
}

int java_emit_class(Dex *dex, uint32_t class_def_idx, Buf *out)
{
    if (class_def_idx >= dex->hdr.class_defs_size)
        return -1;
    emit_watermark(out);

    const DexClassDef *cd = &dex->classes[class_def_idx];

    /* A class that lists both java.util.X and j$.util.X cannot be written as
     * compilable Java: the two interfaces disagree on every method that mentions
     * X, and no single implementation satisfies both. Skipping keeps the
     * guarantee that every emitted file compiles. */
    /* Conflicts are resolved by dropping the JDK spelling from the interface
     * list rather than by skipping the class: the class and all its methods are
     * still emitted, only the unusable declaration is removed. */
    int conflicting = class_has_conflicting_interfaces(dex, cd) ||
                      has_final_override_conflict(dex, cd) ||
                      has_unresolvable_override(dex, cd, class_def_idx);
    if (g_skip_conflicts && conflicting)
        return -2;
    /* A conflicting class keeps every member but is emitted as abstract: the
     * interfaces it can no longer claim leave abstract methods behind, and an
     * abstract class is allowed to leave them unimplemented. This keeps the
     * class in the output and keeps the file compilable. */

    const DexClassData *data = dex_class_data(dex, class_def_idx);
    Emitter e = { dex, out, 0, NULL };
    ClassFacts facts;
    memset(&facts, 0, sizeof(facts));

    const char *desc = dex_type_desc(dex, cd->class_idx);
    char fqcn[1024];
    if (remap_needed(desc))
        remap_java_type(desc, fqcn, sizeof(fqcn));
    else
        snprintf(fqcn, sizeof(fqcn), "%s", java_class_name(dex, cd->class_idx));

    /* When a deobfuscation map renamed the class, the declared name must follow
     * the mapped fully-qualified name; otherwise it comes from the descriptor so
     * that nested classes keep their '$' spelling and match the file name. */
    const char *last_slash = strrchr(fqcn, '.');
    char simple_raw[512];
    if (g_renamer) {
        snprintf(simple_raw, sizeof(simple_raw), "%s", last_slash ? last_slash + 1 : fqcn);
    } else {
        const char *last = strrchr(desc, '/');
        last = last ? last + 1 : desc + 1;
        size_t n = 0;
        for (const char *q = last; *q && *q != ';' && n + 1 < sizeof(simple_raw); q++)
            simple_raw[n++] = *q;
        simple_raw[n] = '\0';
    }
    java_ident(simple_raw, facts.name, sizeof(facts.name));
    /* A class that collides with a package directory is renamed in every
     * reference; the declaration must use the same spelling. */
    {
        char suffixed[512];
        if (remap_conflict_name(desc, suffixed, sizeof(suffixed)))
            snprintf(facts.name, sizeof(facts.name), "%s", suffixed);
    }
    /* The inferred name must win over the obfuscated one here too, or the
     * declaration and the file path derived from java_class_fqname disagree.
     * A class that shadows a package keeps the '_' suffix, because
     * remap_java_type adds it to every reference. */
    if (g_heur) {
        const char *guessed = heuristic_name(g_heur, desc);
        if (guessed) {
            char cf[512];
            int shadows_pkg = remap_conflict_name(desc, cf, sizeof(cf));
            snprintf(facts.name, sizeof(facts.name), "%s%s", guessed,
                     shadows_pkg ? "_" : "");
        }
    }

    {
        const char *d0 = desc;
        /* Two shadowing shapes need a suffix: a default-package class named like
         * a top-level package, and a class named like the first segment of its
         * own package (cn.fly.verify.cn). */
        int shadow = 0;
        if (d0 && d0[0] == 'L' && !strchr(d0 + 1, '/'))
            shadow = class_shadows_package(dex, facts.name);
        else
            shadow = class_shadows_own_package_root(dex, d0, facts.name);
        if (shadow) {
            {
                size_t l = strlen(facts.name);
                if (l + 2 < sizeof(facts.name)) {
                    facts.name[l] = '_';
                    facts.name[l + 1] = '\0';
                }
            }
        }
    }

    {
        /* The package is everything before the last '.' that precedes the class
         * name. Deriving it from the descriptor keeps nested classes
         * (Foo$Bar) from turning their outer name into a package. */
        char pkg[512];
        pkg[0] = '\0';
        const char *b = desc;
        while (*b == '[')
            b++;
        if (*b == 'L')
            b++;
        const char *semi = strchr(b, ';');
        size_t blen = semi ? (size_t)(semi - b) : strlen(b);
        size_t last_sl = 0;
        int found = 0;
        for (size_t i = 0; i < blen; i++)
            if (b[i] == '/') {
                last_sl = i;
                found = 1;
            }

        if (!found && g_relocate_default_pkg) {
            line(&e, "package %s;", "defpkg");
            buf_putc(out, '\n');
        } else if (found && last_sl < sizeof(pkg)) {
            char raw[512];
            memcpy(raw, b, last_sl);
            raw[last_sl] = '\0';
            /* Apply the relocation to the package prefix, then convert every
             * remaining '/' to '.'. */
            if (!strncmp(raw, "j$/", 3))
                snprintf(pkg, sizeof(pkg), "jdruntime.%s", raw + 3);
            else if (!strncmp(raw, "java/", 5) && remap_needed(desc))
                snprintf(pkg, sizeof(pkg), "j$.%s", raw + 5);
            else
                snprintf(pkg, sizeof(pkg), "%s", raw);

            for (char *q = pkg; *q; q++)
                if (*q == '/')
                    *q = '.';
            line(&e, "package %s;", pkg);
            buf_putc(out, '\n');
        }
    }

    facts.is_interface = (cd->access_flags & DEX_ACC_INTERFACE) != 0;

    /* Extending java.lang.Enum is conclusive: only an enum declaration may do
     * that, and R8 sometimes drops the ACC_ENUM flag while keeping the shape. */
    if (!facts.is_interface && cd->superclass_idx != NO_INDEX) {
        const char *sd = dex_type_desc(dex, cd->superclass_idx);
        if (sd && !strcmp(sd, "Ljava/lang/Enum;"))
            facts.is_enum = 1;
    }

    /* An enum declaration needs at least one constant *and* nothing else before
     * them: extra static fields (CREATOR, caches) cannot be written before the
     * constant list, which javac rejects. jadx degrades to a plain class in that
     * case, and doing the same is what keeps these files compilable. */
    if (facts.is_enum) {
        int has_const = 0, has_stray_static = 0;
        if (data) {
            for (uint32_t i = 0; i < data->static_count; i++) {
                uint32_t fi = data->static_fields[i].field_idx;
                if (fi >= dex->hdr.field_ids_size)
                    continue;
                if (dex->fields[fi].type_idx == cd->class_idx)
                    has_const++;
                else
                    has_stray_static++;
            }
        }
        if (!has_const || has_stray_static)
            facts.is_enum = 0;
    }

    if (!facts.is_enum && !facts.is_interface && (cd->access_flags & DEX_ACC_ENUM) && data) {
        for (uint32_t i = 0; i < data->static_count; i++) {
            uint32_t fi = data->static_fields[i].field_idx;
            if (fi < dex->hdr.field_ids_size && dex->fields[fi].type_idx == cd->class_idx) {
                facts.is_enum = 1;
                break;
            }
        }
        /* Constant-specific class bodies are real subclasses, and Java forbids
         * extending an enum: emit the base as a plain abstract class instead. */
        if (facts.is_enum && dex_class_has_subclass(dex, cd->class_idx))
            facts.is_enum = 0;
    }

    if (data) {
        for (uint32_t i = 0; i < data->direct_count; i++) {
            uint32_t mi = data->direct_methods[i].method_idx;
            if (mi < dex->hdr.method_ids_size && !strcmp(dex_method_name(dex, mi), "<init>")) {
                facts.has_ctor = 1;
                facts.first_ctor_proto = dex->methods[mi].proto_idx;
                DexParamList *cp = dex_proto_params(dex, facts.first_ctor_proto);
                facts.ctor_param_count = cp ? cp->param_count : 0;
                break;
            }
        }
    }

    /* Default to "the parent has a no-arg constructor" only when the parent is
     * java.lang.Object or not present in this input at all -- in the latter case
     * a bare super() is the only call that can be written. */
    facts.parent_has_noarg_ctor = 1;
    facts.parent_known = 0;
    if (cd->superclass_idx != NO_INDEX && !facts.is_interface && !facts.is_enum) {
        Dex *powner = NULL;
        /* Only this dex: a type index from another file names an unrelated class,
         * and using it produces super() calls with the wrong parameter types. */
        /* The parent may be defined in a sibling dex of the same APK. Resolve it
         * by descriptor there, which is safe for constructor lookup: the result is
         * used only to read that class's own <init> descriptors. */
        uint32_t pdef = dex_class_def_of_type(dex, cd->superclass_idx);
        if (pdef != NO_INDEX) {
            powner = dex;
        } else {
            const char *pd = dex_type_desc(dex, cd->superclass_idx);
            Dex *other = NULL;
            uint32_t od = pd ? java_lookup_dex_by_name(pd, dex, &other) : NO_INDEX;
            if (od != NO_INDEX && other && !strcmp(dex_type_desc(other, other->classes[od].class_idx), pd)) {
                pdef = od;
                powner = other;
            }
        }
        if (pdef != NO_INDEX && powner) {
            facts.parent_known = 1;
            facts.parent_dex = powner;
            facts.parent_has_noarg_ctor = class_has_noarg_ctor(powner, pdef);
            if (!facts.parent_has_noarg_ctor) {
                facts.parent_ctor_proto = class_first_ctor_proto(powner, pdef);
                facts.parent_ctor_known = (facts.parent_ctor_proto != NO_INDEX);
            }
        } else {
            /* The parent is a platform class whose constructors are not in this
             * input. Its real parameter descriptors come from the SDK when
             * available, and a default literal of each parameter's type makes the
             * call type-check exactly. Without the SDK a plain super() is used,
             * which the great majority of these classes declare. */
            const char *pdesc = dex_type_desc(dex, cd->superclass_idx);
            int np = pdesc ? platform_ctor_params_of(pdesc, facts.parent_params, 8) : -1;
            if (np > 0) {
                facts.parent_has_noarg_ctor = 0;
                facts.parent_param_count = np;
                facts.parent_ctor_param_count = (uint32_t)np;
            } else {
                facts.parent_has_noarg_ctor = 1;
                facts.parent_param_count = 0;
                facts.parent_ctor_param_count = 0;
            }
            facts.parent_ctor_forward = 0;
        }
    }

name_done:
    ;
    /* A downgraded enum no longer extends java.lang.Enum in the emitted code, so
     * the constructor recorded from Enum(String,int) must not be used. */
    if (!facts.is_enum && cd->superclass_idx != NO_INDEX) {
        const char *sd0 = dex_type_desc(dex, cd->superclass_idx);
        if (sd0 && !strcmp(sd0, "Ljava/lang/Enum;")) {
            facts.parent_has_noarg_ctor = 1;
            facts.parent_ctor_known = 0;
            facts.parent_ctor_param_count = 0;
            facts.parent_ctor_forward = 0;
            facts.parent_param_count = 0;
        }
    }

    const char *kind = facts.is_interface ? "interface" : (facts.is_enum ? "enum" : "class");

    uint32_t cls_flags = cd->access_flags &
                         (DEX_ACC_PUBLIC | DEX_ACC_PRIVATE | DEX_ACC_PROTECTED |
                          DEX_ACC_STATIC | DEX_ACC_FINAL | DEX_ACC_ABSTRACT | DEX_ACC_STRICT);
    if (facts.is_enum)
        cls_flags &= ~(DEX_ACC_FINAL | DEX_ACC_ABSTRACT);
    if (dex_class_has_subclass(dex, cd->class_idx))
        cls_flags &= ~DEX_ACC_FINAL;
    if (conflicting && !facts.is_enum && !facts.is_interface) {
        cls_flags |= DEX_ACC_ABSTRACT;
        cls_flags &= ~DEX_ACC_FINAL;
    }
    /* A concrete class that does not implement every inherited abstract method
     * cannot be emitted as concrete: javac rejects it. Marking it abstract keeps
     * the file compilable and preserves the inherited contract. */
    /* A concrete class whose superclass lives in a sibling dex cannot be checked
     * for unimplemented abstract methods. Declaring it abstract always compiles
     * and preserves every member, so that is the safe shape. */
    if (!facts.is_interface && !facts.is_enum && !(cls_flags & DEX_ACC_ABSTRACT) &&
        cd->superclass_idx != NO_INDEX) {
        const char *sd = dex_type_desc(dex, cd->superclass_idx);
        Dex *own = NULL;
        if (sd && dex_class_def_of_type(dex, cd->superclass_idx) == NO_INDEX &&
            java_lookup_dex_by_name(sd, dex, &own) != NO_INDEX && own && own != dex) {
            cls_flags |= DEX_ACC_ABSTRACT;
            cls_flags &= ~DEX_ACC_FINAL;
        }
    }
    if (getenv("TACHYON_DBG_ABS") && strstr(facts.name, "uc1"))
        fprintf(stderr, "[abs] %s accurate=%d iface=%d enum=%d abstract=%d missing=%d\n",
                facts.name, g_accurate_mode, facts.is_interface, facts.is_enum,
                (cls_flags & DEX_ACC_ABSTRACT) != 0,
                missing_abstract_impl(dex, cd, class_def_idx));
    if (g_accurate_mode && !facts.is_interface && !facts.is_enum &&
        !(cls_flags & DEX_ACC_ABSTRACT) && missing_abstract_impl(dex, cd, class_def_idx)) {
        cls_flags |= DEX_ACC_ABSTRACT;
        cls_flags &= ~DEX_ACC_FINAL;
    }

    indent(&e);
    buf_puts(out, dex_access_string(cls_flags));
    buf_printf(out, "%s %s", kind, facts.name);

    if (cd->superclass_idx != NO_INDEX && !facts.is_interface && !facts.is_enum) {
        char sbuf[512];
        remap_java_type(dex_type_desc(dex, cd->superclass_idx), sbuf, sizeof(sbuf));
        /* A class that used to be an enum but was downgraded here cannot extend
         * java.lang.Enum directly: only the enum declaration may. */
        if (strcmp(sbuf, "java.lang.Object") && strcmp(sbuf, "java.lang.Enum"))
            buf_printf(out, " extends %s", sbuf);
    }

    if (cd->interfaces_off && cd->interfaces_off < dex->size) {
        uint32_t n = 0;
        memcpy(&n, dex->base + cd->interfaces_off, 4);
        if (n < 0x1000 && cd->interfaces_off + 4 + (size_t)n * 2 <= dex->size) {
            /* A class can implement both java.util.X and its relocated copy
             * j$.util.X. Their signatures disagree after rewriting, and no
             * single method can satisfy both, so the JDK spelling is dropped and
             * the relocated one (the one this dex actually defines) wins. */
            uint16_t keep[1024];
            uint32_t nkeep = 0;
            for (uint32_t i = 0; i < n && nkeep < 1024; i++) {
                uint16_t ti;
                memcpy(&ti, dex->base + cd->interfaces_off + 4 + (size_t)i * 2, 2);
                /* A conflicting class cannot honour any of its interface
                 * contracts: the inherited final methods return the wrong types
                 * and Java forbids overriding them. Emitting the interfaces
                 * would make the file uncompilable, so they are dropped and the
                 * class is declared abstract instead. */
                if (conflicting)
                    continue;
                const char *d2 = dex_type_desc(dex, ti);
                if (d2 && !strncmp(d2, "Ljava/", 6))
                    continue;
                if (d2 && !strncmp(d2, "Ljava/", 6)) {
                    /* A class may list both java.util.X and j$.util.X. They are
                     * genuinely different types in this dex (j$ is the real
                     * package, not a rewrite), and their method signatures
                     * disagree, so no single implementation can satisfy both.
                     * Keep the j$ one: it is the type the rest of the dex
                     * actually references. */
                    const char *tail = strchr(d2 + 6, '\0');
                    const char *slash = strchr(d2 + 6, '/');
                    const char *cmp = slash ? slash + 1 : d2 + 6;
                    int has_twin = 0;
                    for (uint32_t k = 0; k < n && !has_twin; k++) {
                        uint16_t tk;
                        memcpy(&tk, dex->base + cd->interfaces_off + 4 + (size_t)k * 2, 2);
                        const char *dk = dex_type_desc(dex, tk);
                        if (!dk || strncmp(dk, "Lj$/", 4))
                            continue;
                        const char *kslash = strchr(dk + 4, '/');
                        const char *kcmp = kslash ? kslash + 1 : dk + 4;
                        if (!strcmp(kcmp, cmp))
                            has_twin = 1;
                    }
                    (void)tail;
                    if (has_twin)
                        continue;
                }
                /* R8 occasionally lists a class (not an interface) in the
                 * interface table; Dalvik accepts that shape but Java has no way
                 * to write it, so such entries are dropped here. */
                uint32_t idef = dex_class_def_of_type(dex, ti);
                if (idef != NO_INDEX && !(dex->classes[idef].access_flags & DEX_ACC_INTERFACE))
                    continue;
                if (!facts.is_interface && g_accurate_mode && iface_conflicts(dex, cd, ti))
                    continue;
                keep[nkeep++] = ti;
            }
            if (nkeep) {
                buf_puts(out, facts.is_interface ? " extends " : " implements ");
                for (uint32_t i = 0; i < nkeep; i++) {
                    if (i)
                        buf_puts(out, ", ");
                    char ibuf[512];
                    remap_java_type(dex_type_desc(dex, keep[i]), ibuf, sizeof(ibuf));
                    buf_puts(out, ibuf);
                }
            }
        }
    }

    buf_puts(out, " {\n");
    e.indent = 1;

    if (data) {
        uint32_t enum_written = 0;
        if (facts.is_enum) {
            DexParamList *cpl =
                facts.has_ctor ? dex_proto_params(dex, facts.first_ctor_proto) : NULL;
            for (uint32_t i = 0; i < data->static_count; i++) {
                uint32_t fi = data->static_fields[i].field_idx;
                if (fi >= dex->hdr.field_ids_size || dex->fields[fi].type_idx != cd->class_idx)
                    continue;
                indent(&e);
                buf_puts(out, dex_field_name(dex, fi));
                if (cpl && cpl->param_count) {
                    buf_puts(out, "(");
                    for (uint32_t k = 0; k < cpl->param_count; k++) {
                        if (k)
                            buf_puts(out, ", ");
                        char pbuf[512];
                        remap_java_type(dex_type_desc(dex, cpl->type_idx[k]), pbuf, sizeof(pbuf));
                        /* A bare 0 is an int literal, and char/short/byte
                         * parameters reject it as a lossy conversion. */
                        buf_printf(out, "(%s) %s", pbuf, java_default_value(pbuf));
                    }
                    buf_puts(out, ")");
                }
                buf_puts(out, ",\n");
                enum_written++;
            }
            if (enum_written) {
                indent(&e);
                buf_puts(out, ";\n");
            }
        }

        /* Static initial values live in an encoded array whose entries line up
         * with the static fields in declaration order. */
        DexValue *svals = NULL;
        uint32_t nsvals = 0;
        if (cd->static_values_off)
            nsvals = dex_static_values(dex, cd->static_values_off, &svals);

        for (uint32_t i = 0; i < data->static_count; i++) {
            uint32_t fi = data->static_fields[i].field_idx;
            if (facts.is_enum && fi < dex->hdr.field_ids_size &&
                dex->fields[fi].type_idx == cd->class_idx)
                continue;
            emit_field(&e, fi, data->static_fields[i].access_flags, &facts,
                       i < nsvals ? &svals[i] : NULL);
        }
        for (uint32_t i = 0; i < data->instance_count; i++)
            emit_field(&e, data->instance_fields[i].field_idx,
                       data->instance_fields[i].access_flags, &facts, NULL);
    } /* end of data-dependent emission */

    {
        /* A class with no class_data still needs a constructor: subclasses call
         * super() and javac rejects a concrete class whose parent has only
         * parameterised constructors. */
        if (!facts.is_enum && !facts.has_ctor && !facts.is_interface) {
            /* A platform parent whose constructors are all parameterised leaves
             * parent_has_noarg_ctor and parent_ctor_known both false, but the
             * class still needs an explicit constructor: Java's implicit one calls
             * super() and javac rejects it. parent_param_count carries the
             * signature to chain to in that case. */
            if (facts.parent_has_noarg_ctor || facts.parent_ctor_known ||
                facts.parent_param_count > 0) {
                buf_putc(out, '\n');
                indent(&e);
                /* The synthetic constructor must be reachable from the subclasses
                 * in other packages, which a package-private one is not. */
                int reloc = class_def_idx < dex->hdr.class_defs_size &&
                            remap_is_relocated_default(
                                dex_type_desc(dex, dex->classes[class_def_idx].class_idx));
                /* A package-private synthetic constructor cannot be called from a
                 * subclass in another package; protected keeps the API surface
                 * small while remaining callable. */
                (void)reloc;
                const char *pdesc_io =
                    cd->superclass_idx != NO_INDEX ? dex_type_desc(dex, cd->superclass_idx) : NULL;
                if (platform_builtin_ctor_throws_io(pdesc_io))
                    buf_printf(out, "protected %s() throws java.io.IOException {\n", facts.name);
                else
                    buf_printf(out, "protected %s() {\n", facts.name);
                e.indent++;
                indent(&e);
                if (facts.parent_has_noarg_ctor) {
                    buf_puts(out, "super();\n");
                } else if (facts.parent_ctor_known) {
                    buf_puts(out, "super(");
                    Dex *pd = facts.parent_dex ? facts.parent_dex : dex;
                    DexParamList *ppl = dex_proto_params(pd, facts.parent_ctor_proto);
                    for (uint32_t k = 0; ppl && k < ppl->param_count; k++) {
                        if (k)
                            buf_puts(out, ", ");
                        char pbuf[512];
                        remap_java_type(dex_type_desc(pd, ppl->type_idx[k]), pbuf, sizeof(pbuf));
                        buf_printf(out, "(%s) %s", pbuf, java_default_value(pbuf));
                    }
                    buf_puts(out, ");\n");
                } else {
                    buf_puts(out, "super(");
                    for (int k = 0; k < facts.parent_param_count; k++) {
                        if (k)
                            buf_puts(out, ", ");
                        char pbuf[512];
                        remap_java_type(facts.parent_params[k], pbuf, sizeof(pbuf));
                        buf_printf(out, "(%s) %s", pbuf, java_default_value(pbuf));
                    }
                    buf_puts(out, ");\n");
                }
                e.indent--;
                indent(&e);
                buf_puts(out, "}\n");
            }
        }


        /* Pass 1: pick the most specific return type per signature.
         *
         * R8 clears ACC_BRIDGE, so the bridge flag cannot decide this. The
         * reliable signal is the class's own chain: a covariant override narrows
         * the return type towards the class itself, so the candidate that is this
         * class or one of its ancestors is the real method, and the rest are the
         * compiler's wider bridges. */
        uint32_t sup[256];
        uint32_t nsup = collect_supertypes(dex, cd->class_idx, sup, 256);
        uint32_t total = data ? data->direct_count + data->virtual_count : 0;
        MethodWinner *winners = calloc(total ? total : 1, sizeof(MethodWinner));
        uint32_t nwin = 0;
        if (winners) {
            for (uint32_t i = 0; i < total; i++) {
                uint32_t mi = i < data->direct_count
                                  ? data->direct_methods[i].method_idx
                                  : data->virtual_methods[i - data->direct_count].method_idx;
                if (mi >= dex->hdr.method_ids_size)
                    continue;
                const DexMethodId *mm = &dex->methods[mi];
                if (mm->proto_idx >= dex->hdr.proto_ids_size)
                    continue;
                char k[1200];
                proto_key(dex, mm->proto_idx, k, sizeof(k));
                uint32_t hh = sig_hash(dex_method_name(dex, mi), k);
                uint32_t acc = i < data->direct_count
                                   ? data->direct_methods[i].access_flags
                                   : data->virtual_methods[i - data->direct_count].access_flags;
                int br = (acc & DEX_ACC_BRIDGE) != 0;
                uint32_t rt = dex->protos[mm->proto_idx].return_type_idx;
                int dep = type_depth(dex, rt);
                int near = (rt == cd->class_idx);
                for (uint32_t ci = 0; ci < nsup && !near; ci++)
                    if (sup[ci] == rt)
                        near = 1;
                MethodWinner *ex = winner_find(winners, nwin, hh);
                if (!ex) {
                    winners[nwin].h = hh;
                    winners[nwin].ret_type = rt;
                    winners[nwin].depth = dep;
                    winners[nwin].is_bridge = br;
                    winners[nwin].in_chain = near;
                    nwin++;
                } else if (ex->is_bridge != br ? !br
                                               : (near != ex->in_chain ? near : dep > ex->depth)) {
                    ex->ret_type = rt;
                    ex->depth = dep;
                    ex->is_bridge = br;
                    ex->in_chain = near;
                }
            }

            /* Pass 2: Java requires an override's return type to be a subtype of
             * the parent's. DEX keeps the compiler's wider binary signature, so
             * when a parent declares a narrower return type for the same name
             * and parameters, adopt the parent's. This is what makes the
             * Stream/Spliterator families compile. */
            (void)nsup;
            for (uint32_t si = 0; si < nsup; si++) {
                /* class_def_of_type resolves across dexes and reports which file
                 * owns the definition. Every read below must go through that
                 * owner: a class_def index from a sibling dex names an unrelated
                 * class here, which made interfaces look like classes with final
                 * methods and dropped overrides that were actually required. */
                uint32_t sdef = class_def_of_type(dex, sup[si]);
                Dex *sowner = g_last_owner ? g_last_owner : dex;
                if (sdef == NO_INDEX || sdef >= sowner->hdr.class_defs_size)
                    continue;
                const DexClassData *sdata = dex_class_data(sowner, sdef);
                if (!sdata)
                    continue;
                for (uint32_t m2 = 0; m2 < sdata->virtual_count + sdata->direct_count; m2++) {
                    uint32_t smi = m2 < sdata->virtual_count
                                       ? sdata->virtual_methods[m2].method_idx
                                       : sdata->direct_methods[m2 - sdata->virtual_count].method_idx;
                    uint32_t sacc = m2 < sdata->virtual_count
                                        ? sdata->virtual_methods[m2].access_flags
                                        : sdata->direct_methods[m2 - sdata->virtual_count].access_flags;
                    if (smi >= sowner->hdr.method_ids_size)
                        continue;
                    const DexMethodId *sm = &sowner->methods[smi];
                    if (sm->proto_idx >= sowner->hdr.proto_ids_size)
                        continue;
                    char sk[1200];
                    proto_key(sowner, sm->proto_idx, sk, sizeof(sk));
                    uint32_t sh = sig_hash(dex_method_name(sowner, smi), sk);
                    MethodWinner *ex = winner_find(winners, nwin, sh);
                    if (!ex)
                        continue;
                    uint32_t sret = sowner->protos[sm->proto_idx].return_type_idx;
                    /* sret is an index in the owner dex, ex->ret_type in this one,
                     * so they are compared by descriptor. The subtype walk only
                     * runs when both indices belong to the same dex. */
                    const char *sret_desc = dex_type_desc(sowner, sret);
                    const char *oret_desc = dex_type_desc(dex, ex->ret_type);
                    int ret_same = sret_desc && oret_desc && !strcmp(sret_desc, oret_desc);
                    int ret_narrower =
                        !ret_same && sowner == dex && is_supertype(dex, ex->ret_type, sret);
                    /* Java only allows an override to narrow its return type.
                     * DEX keeps the compiler's wider binary signature, so when a
                     * parent already declares the same method with a narrower
                     * type, emitting ours would be an illegal widening. Such a
                     * method is redundant: the inherited one already satisfies
                     * every caller, so skip it. */
                    if (ret_narrower)
                        ex->drop = 1;

                    /* An inherited final *class* method cannot be overridden.
                     * Interface methods are never final in this sense, and
                     * dropping ours there would leave the class abstract. */
                    int s_is_interface =
                        (sowner->classes[sdef].access_flags & DEX_ACC_INTERFACE) != 0;
                    if (!s_is_interface && (sacc & DEX_ACC_FINAL))
                        ex->drop = 1;

                    if (!ret_same) {
                        const char *a_desc = sret_desc;
                        const char *b_desc = oret_desc;
                        if (a_desc && b_desc && !strncmp(a_desc, "Ljava/", 6) &&
                            !remap_needed(a_desc) && !strncmp(b_desc, "Lj$/", 4)) {
                            /* Compare the tails: java/util/Spliterator vs
                             * j$/util/Spliterator describe the same class under
                             * two naming schemes, so neither can override the
                             * other and ours must go. */
                            const char *at = strchr(a_desc + 6, '/');
                            const char *bt = strchr(b_desc + 4, '/');
                            if (at && bt && !strcmp(at, bt))
                                ex->drop = 1;
                        }
                    }
                    /* A relocated type (j$.util.Spliterator) can never satisfy a
                     * signature that a real JDK interface spells
                     * java.util.Spliterator: they are unrelated types after the
                     * rewrite. Dropping our override lets the JDK one win. */
                    if (!ret_same) {
                        const char *a_desc = sret_desc;
                        const char *b_desc = oret_desc;
                        /* When our return type gets relocated but the inherited
                         * declaration points at the real JDK type, the two are
                         * unrelated after rewriting: the override cannot type
                         * check no matter which side we pick. Drop ours. */
                        if (a_desc && b_desc && remap_needed(b_desc)) {
                            /* Does the parent's descriptor name the same class
                             * that ours maps to, minus the relocation? */
                            char plain[1024];
                            remap_java_type(b_desc, plain, sizeof(plain));
                            const char *dot = strstr(plain, "j$.");
                            const char *b_plain = dot ? dot + 3 : plain;
                            char a_plain[1024];
                            snprintf(a_plain, sizeof(a_plain), "%s", a_desc);
                            if (strstr(a_plain, b_plain))
                                ex->drop = 1;
                        }
                    }
                }
            }
        }

        SigSet seen = { NULL, 0, 0 };
        if (data) {
            for (uint32_t i = 0; i < data->direct_count; i++)
                emit_method(&e, data->direct_methods[i].method_idx,
                            data->direct_methods[i].access_flags, &facts, &seen, winners, nwin,
                            class_def_idx, conflicting);
            for (uint32_t i = 0; i < data->virtual_count; i++)
                emit_method(&e, data->virtual_methods[i].method_idx,
                            data->virtual_methods[i].access_flags, &facts, &seen, winners, nwin,
                            class_def_idx, conflicting);
        }
        free(seen.hashes);
        free(winners);
    }

    /* A framework base class may declare abstract methods that the dex cannot
     * show. Synthesising a stub keeps the subclass concrete: marking it abstract
     * would compile too, but an abstract Android component can never be the class
     * the manifest names. */
    if (cd->superclass_idx != NO_INDEX && !facts.is_interface && !facts.is_enum) {
        const char *pdesc = dex_type_desc(dex, cd->superclass_idx);
        int nabs = 0;
        const PlatformAbstract *abs = platform_builtin_abstracts(pdesc, &nabs);
        for (int ai = 0; ai < nabs; ai++) {
            int have = 0;
            for (uint32_t m = 0; data && m < data->virtual_count && !have; m++) {
                uint32_t mi = data->virtual_methods[m].method_idx;
                if (mi < dex->hdr.method_ids_size &&
                    !strcmp(dex_method_name(dex, mi), abs[ai].name))
                    have = 1;
            }
            if (have)
                continue;
            char rbuf[512];
            remap_java_type(abs[ai].ret, rbuf, sizeof(rbuf));
            char pbufs[8][128];
            int np = platform_builtin_split_params(abs[ai].params, pbufs, 8);
            buf_putc(out, '\n');
            indent(&e);
            buf_printf(out, "public %s %s(", rbuf, abs[ai].name);
            for (int k = 0; k < np; k++) {
                char pb[512];
                remap_java_type(pbufs[k], pb, sizeof(pb));
                buf_printf(out, "%s%s p%d", k ? ", " : "", pb, k);
            }
            buf_puts(out, ") {\n");
            e.indent++;
            if (strcmp(rbuf, "void")) {
                indent(&e);
                buf_printf(out, "return %s;\n", java_default_value(rbuf));
            }
            e.indent--;
            indent(&e);
            buf_puts(out, "}\n");
        }
    }

    e.indent = 0;
    buf_puts(out, "}\n");
    return 0;
}

/* Produces the fully-qualified Java name for a class, applying exactly the same
 * decisions as java_emit_class: relocation, deobfuscation, reserved words and
 * package shadowing. The file path is derived from this, which guarantees the
 * file name always matches the emitted declaration. */
/* Must agree exactly with the name java_emit_class declares, so the file lands
 * where javac expects it. The declaration takes the package from the descriptor
 * (remapped for relocated packages) and the simple name through java_ident,
 * which folds '$' and appends '_' for reserved words or shadowed names. */
static int path_is_package_dir(const char *path);


/* True when this method cannot coexist with a framework declaration of the same
 * erased signature: either the return types are unrelated, or the framework
 * hierarchy already declares competing versions (AdapterView's generic
 * setAdapter and Spinner's concrete one erase to the same thing).
 *
 * The declaration is dropped instead of emitted, because javac rejects both
 * directions and the inherited one already satisfies every caller. */
static int platform_method_conflict(Dex *d, uint32_t class_def_idx, const char *name,
                                    const char *params_key, uint32_t ret_type)
{
    if (class_def_idx >= d->hdr.class_defs_size)
        return 0;
    const DexClassDef *cd = &d->classes[class_def_idx];
    const char *desc = cd->superclass_idx != NO_INDEX ? dex_type_desc(d, cd->superclass_idx) : NULL;
    const char *our_ret = dex_type_desc(d, ret_type);
    /* Walk the framework chain by descriptor: every hop after the first is a
     * type the dex does not contain, so the built-in table supplies it. */
    for (int guard = 0; guard < 16 && desc; guard++) {
        const PlatformMethod *pm = platform_builtin_method(desc, name, params_key);
        if (pm) {
            if (pm->drop_always)
                return 1;
            if (pm->ret && our_ret && strcmp(pm->ret, our_ret))
                return 1;
        }
        desc = platform_builtin_parent(desc);
    }
    return 0;
}

/* True when implementing `iface_ti` would leave the class in a position Java
 * cannot express: the interface (transitively) declares a method whose return
 * type is unrelated to a method with the same name and parameters already
 * inherited from the superclass chain. R8 merges unrelated hierarchies into one
 * class, and the result has no legal Java spelling.
 *
 * The superclass chain is indexed by signature first, so the cost is linear in
 * the number of methods rather than the product of the two hierarchies. */
typedef struct {
    uint32_t key;
    uint32_t ret;
} ChainSlot;

static int iface_conflicts(Dex *dex, const DexClassDef *cd, uint32_t iface_ti)
{
    if (cd->superclass_idx == NO_INDEX)
        return 0;

    /* Signature -> return type for everything reachable through the superclass. */
    enum { CHAIN_CAP = 1024 };
    ChainSlot *tbl = calloc(CHAIN_CAP, sizeof(ChainSlot));
    if (!tbl)
        return 0;
    uint32_t used = 0;

    uint32_t cur = cd->superclass_idx;
    for (int guard = 0; guard < 32; guard++) {
        uint32_t def = dex_class_def_of_type(dex, cur);
        if (def == NO_INDEX)
            break;
        const DexClassData *data = dex_class_data(dex, def);
        if (data) {
            for (uint32_t i = 0; i < data->virtual_count + data->direct_count; i++) {
                uint32_t mi = i < data->virtual_count
                                  ? data->virtual_methods[i].method_idx
                                  : data->direct_methods[i - data->virtual_count].method_idx;
                if (mi >= dex->hdr.method_ids_size)
                    continue;
                const char *nm = dex_method_name(dex, mi);
                if (!nm || !strcmp(nm, "<init>") || !strcmp(nm, "<clinit>"))
                    continue;
                char key[1200];
                proto_key(dex, dex->methods[mi].proto_idx, key, sizeof(key));
                uint32_t h = sig_hash(nm, key);
                uint32_t p = h & (CHAIN_CAP - 1);
                for (uint32_t step = 0; step < CHAIN_CAP && tbl[p].key; step++, p = (p + 1) & (CHAIN_CAP - 1))
                    if (tbl[p].key == h)
                        break;
                if (tbl[p].key == h)
                    continue; /* an override closer to the class wins */
                tbl[p].key = h ? h : 1u;
                tbl[p].ret = dex->protos[dex->methods[mi].proto_idx].return_type_idx;
                used++;
                if (used >= CHAIN_CAP)
                    break;
            }
        }
        cur = dex->classes[def].superclass_idx;
        if (cur == NO_INDEX)
            break;
    }
    /* An empty table is not ``no conflict'': the superclass may be a framework
     * type that declares the method without being in this dex, and that case is
     * handled by the built-in table below. */

    /* Every interface reachable from `iface_ti`, plus itself: the starting type
     * is not part of collect_supertypes' output, and a leaf interface's own
     * methods are exactly the ones that conflict. */
    uint32_t icl[257];
    uint32_t nic = collect_supertypes(dex, iface_ti, icl + 1, 256);
    icl[0] = iface_ti;
    nic++;

    for (uint32_t a = 0; a < nic; a++) {
        uint32_t idef = dex_class_def_of_type(dex, icl[a]);
        if (idef == NO_INDEX)
            continue;
        const DexClassData *idata = dex_class_data(dex, idef);
        if (!idata)
            continue;
        for (uint32_t im = 0; im < idata->virtual_count + idata->direct_count; im++) {
            uint32_t imi = im < idata->virtual_count
                               ? idata->virtual_methods[im].method_idx
                               : idata->direct_methods[im - idata->virtual_count].method_idx;
            if (imi >= dex->hdr.method_ids_size)
                continue;
            const char *inm = dex_method_name(dex, imi);
            if (!inm || !strcmp(inm, "<init>") || !strcmp(inm, "<clinit>"))
                continue;
            char ikey[1200];
            proto_key(dex, dex->methods[imi].proto_idx, ikey, sizeof(ikey));
            uint32_t h = sig_hash(inm, ikey);
            uint32_t p = h & (CHAIN_CAP - 1);
            for (uint32_t step = 0; step < CHAIN_CAP && tbl[p].key; step++, p = (p + 1) & (CHAIN_CAP - 1))
                if (tbl[p].key == h)
                    break;
            uint32_t iret = dex->protos[dex->methods[imi].proto_idx].return_type_idx;
            if (used && tbl[p].key == h) {
                if (iret == tbl[p].ret || is_supertype(dex, iret, tbl[p].ret))
                    continue;
                free(tbl);
                return 1;
            }
            /* Not inherited inside this dex, but a framework ancestor may declare
             * the same method. View.getLayoutDirection() returning int cannot
             * coexist with an app interface returning a wrapper type. */
            {
                const char *pdesc = cd->superclass_idx != NO_INDEX
                                        ? dex_type_desc(dex, cd->superclass_idx)
                                        : NULL;
                const char *iret_desc = dex_type_desc(dex, iret);
                for (int guard = 0; guard < 16 && pdesc; guard++) {
                    const PlatformMethod *pm = platform_builtin_method(pdesc, inm, ikey);
                    if (pm && pm->ret && iret_desc && strcmp(pm->ret, iret_desc)) {
                        free(tbl);
                        return 1;
                    }
                    pdesc = platform_builtin_parent(pdesc);
                }
            }
        }
    }
    free(tbl);
    return 0;
}

void java_class_fqname(Dex *dex, uint32_t class_def_idx, char *out, size_t cap)
{
    if (class_def_idx >= dex->hdr.class_defs_size) {
        out[0] = '\0';
        return;
    }
    const char *desc = dex_type_desc(dex, dex->classes[class_def_idx].class_idx);

    const char *renamed = g_renamer ? renamer_class(g_renamer, desc) : NULL;
    if (renamed) {
        snprintf(out, cap, "%s", renamed);
        return;
    }
    if (g_heur && heuristic_name(g_heur, desc)) {
        /* remap_java_type already applies the inferred name, the relocation and
         * the package-shadow suffix, so its result is exactly what both the
         * declaration and the file path must use. */
        char full[768];
        remap_java_type(desc, full, sizeof(full));
        snprintf(out, cap, "%s", full);
        return;
    }

    char pkg[768];
    char simple_override[512];
    simple_override[0] = '\0';
    if (remap_conflict_name(desc, simple_override, sizeof(simple_override))) {
        /* The package part is unchanged; only the class name gains the suffix. */
        const char *slash = strrchr(desc, '/');
        if (slash) {
            size_t n = (size_t)(slash - (desc + 1));
            if (n >= sizeof(pkg))
                n = sizeof(pkg) - 1;
            for (size_t i = 0; i < n; i++)
                pkg[i] = desc[1 + i] == '/' ? '.' : desc[1 + i];
            pkg[n] = '\0';
        } else {
            pkg[0] = '\0';
        }
    } else if (remap_needed(desc)) {
        /* Relocated package (dex runtime, embedded JDK, default package). */
        char mapped[1024];
        remap_java_type(desc, mapped, sizeof(mapped));
        char *last = strrchr(mapped, '.');
        /* Only a lower-case component can be part of the package. */
        while (last && !(last[1] >= 'a' && last[1] <= 'z')) {
            char *prev = last;
            while (prev > mapped && prev[-1] != '.')
                prev--;
            if (prev == mapped)
                break;
            last = prev - 1;
        }
        if (last) {
            size_t n = (size_t)(last - mapped);
            if (n >= sizeof(pkg))
                n = sizeof(pkg) - 1;
            memcpy(pkg, mapped, n);
            pkg[n] = '\0';
        } else {
            pkg[0] = '\0';
        }
    } else if (g_relocate_default_pkg && desc[0] == 'L' && !strchr(desc + 1, '/')) {
        /* A default-package class cannot be referenced from a named package at
         * all, so it moves into the synthetic one; remap_java_type applies the
         * same relocation to every reference. */
        snprintf(pkg, sizeof(pkg), "%s", "defpkg");
    } else {
        const char *slash = strrchr(desc, '/');
        if (slash) {
            size_t n = (size_t)(slash - (desc + 1));
            if (n >= sizeof(pkg))
                n = sizeof(pkg) - 1;
            for (size_t i = 0; i < n; i++)
                pkg[i] = desc[1 + i] == '/' ? '.' : desc[1 + i];
            pkg[n] = '\0';
        } else {
            pkg[0] = '\0';
        }
    }

    /* Simple name: exactly what the declaration uses. */
    const char *last = strrchr(desc, '/');
    last = last ? last + 1 : desc + 1;
    char simple_raw[512];
    size_t n = 0;
    for (const char *q = last; *q && *q != ';' && n + 1 < sizeof(simple_raw); q++)
        simple_raw[n++] = *q;
    simple_raw[n] = '\0';

    char simple[512];
    if (simple_override[0])
        snprintf(simple, sizeof(simple), "%s", simple_override);
    else
        java_ident(simple_raw, simple, sizeof(simple));
    if (java_simple_name_shadowed(dex, simple)) {
        size_t l = strlen(simple);
        if (l + 2 < sizeof(simple)) {
            simple[l] = '_';
            simple[l + 1] = '\0';
        }
    }

    if (pkg[0])
        snprintf(out, cap, "%s.%s", pkg, simple);
    else
        snprintf(out, cap, "%s", simple);
}

/* A class whose file path is also used as a package directory cannot coexist
 * with that directory: "log/a.java" and "log/a/b.java" both claim the name "a"
 * and javac rejects the second with "package ... clashes with class of same
 * name". The colliding class gets a '_' suffix so both names exist.
 *
 * Built once per dex from the emitted paths; a sorted array plus binary search
 * keeps it linear-log even for 15k classes. */
static char **g_pkg_prefixes;
static uint32_t g_pkg_prefix_count;

static int cmp_str_ptr(const void *a, const void *b)
{
    return strcmp(*(const char *const *)a, *(const char *const *)b);
}

/* Returns 1 when `path` (without extension) is a directory of another class. */
static int path_is_package_dir(const char *path)
{
    if (!g_pkg_prefixes || !g_pkg_prefix_count)
        return 0;
    uint32_t lo = 0, hi = g_pkg_prefix_count;
    while (lo < hi) {
        uint32_t mid = lo + (hi - lo) / 2;
        if (strcmp(g_pkg_prefixes[mid], path) < 0)
            lo = mid + 1;
        else
            hi = mid;
    }
    return lo < g_pkg_prefix_count && !strcmp(g_pkg_prefixes[lo], path);
}

void java_class_path(Dex *dex, uint32_t class_def_idx, char *out, size_t cap)
{
    char fq[1024];
    java_class_fqname(dex, class_def_idx, fq, sizeof(fq));
    if (!fq[0]) {
        out[0] = '\0';
        return;
    }

    /* Convert dots to slashes. A '$' inside a class name becomes '_' to match
     * java_ident: Java reads '$' as the nested-class separator, so a top-level
     * name using it could not be referenced. */
    size_t o = 0;
    for (size_t i = 0; fq[i] && o + 8 < cap; i++) {
        unsigned char c = (unsigned char)fq[i];
        if (c == '.')
            c = '/';
        /* '$' must fold to '_' here: java_ident already does that for the
         * declaration, so keeping it in the path would put the file under a
         * name that no class declares. */
        else if (c == '$')
            c = '_';
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') || c == '_' || c == '/';
        out[o++] = ok ? (char)c : '_';
    }

    snprintf(out + o, cap - o, ".java");
}

/* Collects every emitted path so a later call can tell whether a name is also a
 * directory. Runs once per dex, before the pool starts. */
void java_build_package_dirs(Dex *dex, Arena *arena)
{
    /* Must cover every dex in the input: a class in classes.dex can collide with
     * a package that only exists in classes3.dex, and the table is global. */
    uint32_t total = dex->hdr.class_defs_size;
    for (uint32_t i = 0; i < g_all_dex_count; i++)
        total += g_all_dex[i]->hdr.class_defs_size;
    char **all = arena_zalloc(arena, ((size_t)total + 1) * sizeof(char *));
    if (!all)
        return;

    uint32_t count = 0;
    for (uint32_t dj = 0; dj < g_all_dex_count; dj++) {
    Dex *dex = g_all_dex[dj];
    uint32_t n = dex->hdr.class_defs_size;
    for (uint32_t i = 0; i < n; i++) {
        /* Built straight from the descriptor: java_class_fqname consults this
         * table, so using it here would be circular. */
        const char *desc = dex_type_desc(dex, dex->classes[i].class_idx);
        if (!desc || desc[0] != 'L')
            continue;
        const char *semi = strchr(desc, ';');
        size_t dlen = semi ? (size_t)(semi - desc - 1) : strlen(desc + 1);
        size_t o = 0;
        char path[1024];
        for (size_t k = 0; k < dlen && o + 1 < sizeof(path); k++) {
            unsigned char c = (unsigned char)desc[1 + k];
            if (c == '$')
                c = '_';
            int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                     (c >= '0' && c <= '9') || c == '_' || c == '/';
            path[o++] = ok ? (char)c : '_';
        }
        path[o] = '\0';
        char *copy = arena_strdup(arena, path);
        if (copy)
            all[count++] = copy;
    }
    }

    /* Every directory that appears in any path. A class whose own path equals
     * one of these cannot be emitted as a file named after itself, because the
     * directory already claims that name. Extracting directory prefixes (rather
     * than only class paths that prefix another path) is what catches the
     * "class a next to package a/" shape: the class a$b becomes a_b, so nothing
     * prefixes a/, yet a/ still occupies the name "a". */
    qsort(all, count, sizeof(char *), cmp_str_ptr);
    size_t cap = (size_t)count * 8 + 16;
    g_pkg_prefixes = arena_zalloc(arena, cap * sizeof(char *));
    if (!g_pkg_prefixes)
        return;
    g_pkg_prefix_count = 0;
    for (uint32_t i = 0; i < count; i++) {
        for (char *q = all[i]; *q; q++) {
            if (*q != '/')
                continue;
            size_t l = (size_t)(q - all[i]);
            if (l == 0 || l + 1 >= 1024)
                continue;
            char *dir = arena_alloc(arena, l + 1);
            if (!dir)
                break;
            memcpy(dir, all[i], l);
            dir[l] = '\0';
            if (g_pkg_prefix_count < cap)
                g_pkg_prefixes[g_pkg_prefix_count++] = dir;
        }
    }

    /* Collected in path order, not sorted order: sort before the binary search
     * and collapse duplicates so lookups are exact. */
    qsort(g_pkg_prefixes, g_pkg_prefix_count, sizeof(char *), cmp_str_ptr);
    if (g_pkg_prefix_count) {
        uint32_t w = 1;
        for (uint32_t i = 1; i < g_pkg_prefix_count; i++)
            if (strcmp(g_pkg_prefixes[i], g_pkg_prefixes[w - 1]))
                g_pkg_prefixes[w++] = g_pkg_prefixes[i];
        g_pkg_prefix_count = w;
    }

    /* Publish which classes collide with a directory so remap_java_type can
     * apply the same suffix the declaration will use. */
    {
        char **conflicts = arena_zalloc(arena, ((size_t)count + 1) * sizeof(char *));
        uint32_t nc = 0;
        if (conflicts) {
            for (uint32_t dj = 0; dj < g_all_dex_count; dj++) {
                Dex *dx = g_all_dex[dj];
                for (uint32_t i = 0; i < dx->hdr.class_defs_size; i++) {
                    const char *desc = dex_type_desc(dx, dx->classes[i].class_idx);
                    if (!desc || desc[0] != 'L')
                        continue;
                    char stem[1024];
                    size_t o = 0;
                    for (const char *q = desc + 1; *q && *q != ';' && o + 1 < sizeof(stem); q++)
                        stem[o++] = (*q == '$') ? '_' : *q;
                    stem[o] = '\0';
                    if (path_is_package_dir(stem))
                        conflicts[nc++] = (char *)desc;
                }
            }
            remap_set_package_conflicts(conflicts, nc);
        }
    }
}
