#include "emit/java_type.h"

#include <stdio.h>
#include <string.h>

static const char *primitive_name(char c)
{
    switch (c) {
    case 'V': return "void";
    case 'Z': return "boolean";
    case 'B': return "byte";
    case 'S': return "short";
    case 'C': return "char";
    case 'I': return "int";
    case 'J': return "long";
    case 'F': return "float";
    case 'D': return "double";
    default: return NULL;
    }
}

int java_is_primitive(const char *desc)
{
    return desc && desc[0] && !desc[1] && primitive_name(desc[0]) != NULL;
}

/* Types under android/, java/, javax/, kotlin/ come from the platform: their
 * nested classes must keep the dotted spelling because the decompiler never
 * emits a flattened copy of them. */
static int is_external_type(const char *descriptor)
{
    const char *p = descriptor;
    while (*p == '[')
        p++;
    if (*p == 'L')
        p++;
    return !strncmp(p, "android/", 8) || !strncmp(p, "java/", 5) ||
           !strncmp(p, "javax/", 6) || !strncmp(p, "kotlin/", 7) ||
           !strncmp(p, "dalvik/", 7) || !strncmp(p, "org/json/", 9);
}

/* Placeholder: the dex is not reachable from this translation unit, so the
 * nested-class decision falls back to the naming shape. */
static int dex_has_nested(const char *descriptor)
{
    (void)descriptor;
    return 0;
}

const char *java_type_of(const char *desc, char *out, size_t cap)
{
    if (!desc || !*desc) {
        snprintf(out, cap, "java.lang.Object");
        return out;
    }

    int dims = 0;
    while (desc[dims] == '[')
        dims++;

    const char *base = desc + dims;
    char body[384];

    const char *prim = base[0] ? primitive_name(base[0]) : NULL;
    if (prim && !base[1]) {
        snprintf(body, sizeof(body), "%s", prim);
    } else if (base[0] == 'L') {
        const char *end = strrchr(base, ';');
        size_t n = end ? (size_t)(end - base - 1) : strlen(base + 1);
        if (n >= sizeof(body))
            n = sizeof(body) - 1;
        /* DEX separates package components with '/'. '$' marks a nested class in
         * source, but it is also a legal identifier byte and appears in package
         * names too ("j$/..."), so only convert it when the component after it
         * looks like a nested class name (starts with an upper-case letter or a
         * digit, as in "Map$Entry" / "Foo$1"). */
        size_t o = 0;
        for (size_t i = 0; i < n; i++) {
            char c = base[i + 1];
            if (c == '/') {
                body[o++] = '.';
            } else if (c == '$') {
                char next = base[i + 2];
                /* '$' means different things depending on position:
                 *   - inside a package component ("j$.time") it is literal;
                 *   - before an upper-case letter it introduces a nested class
                 *     ("Map$Entry" -> "Map.Entry");
                 *   - otherwise it marks an anonymous/synthetic class ("ch$b",
                 *     "Foo$1"), where a top-level Java name cannot carry '$'
                 *     because javac reads it as nesting, so it becomes '_'. */
                int in_package = 0;
                for (size_t k = i + 2; k < n; k++) {
                    if (base[k + 1] == '/') {
                        in_package = 1;
                        break;
                    }
                }
                /* Inside a package component ('j$') the '$' is literal.
                 *
                 * In a class name it depends on what the suffix looks like:
                 * "Parcelable$Creator" is a real nested class and becomes
                 * "Parcelable.Creator", while "ch$b"/"Foo$1" are top-level names
                 * the decompiler already flattens to '_' so that declaration and
                 * reference agree. */
                if (in_package || next == '/') {
                    body[o++] = '$';
                } else if (next >= 'A' && next <= 'Z' &&
                           (is_external_type(base) || dex_has_nested(base))) {
                    /* A real nested class of a platform or application type. */
                    body[o++] = '.';
                } else {
                    body[o++] = '_';
                }
            } else {
                body[o++] = c;
            }
        }
        body[o] = '\0';

        /* A type reference must match its declaration. java_ident appends '_' to
         * a reserved word, so mirror that for the type's own simple name only
         * (the last segment), leaving package components untouched. */
        char *last_dot = strrchr(body, '.');
        char *simple = last_dot ? last_dot + 1 : body;
        static const char *reserved[] = {
            "abstract","assert","boolean","break","byte","case","catch","char",
            "class","const","continue","default","do","double","else","enum",
            "extends","final","finally","float","for","goto","if","implements",
            "import","instanceof","int","interface","long","native","new",
            "package","private","protected","public","return","short","static",
            "strictfp","super","switch","synchronized","this","throw","throws",
            "transient","try","void","volatile","while","true","false","null","_",
        };
        size_t slen = strlen(simple);
        for (size_t k = 0; k < sizeof(reserved) / sizeof(reserved[0]); k++) {
            if (slen == strlen(reserved[k]) && !strcmp(simple, reserved[k])) {
                size_t blen = strlen(body);
                if (blen + 2 < sizeof(body)) {
                    body[blen] = '_';
                    body[blen + 1] = '\0';
                }
                break;
            }
        }
    } else {
        snprintf(body, sizeof(body), "java.lang.Object");
    }

    size_t len = strlen(body);
    for (int i = 0; i < dims && len + 2 < cap; i++) {
        body[len++] = '[';
        body[len++] = ']';
        body[len] = '\0';
    }
    snprintf(out, cap, "%s", body);
    return out;
}

const char *java_default_value(const char *java_type)
{
    if (!java_type)
        return "null";
    if (!strcmp(java_type, "boolean"))
        return "false";
    if (!strcmp(java_type, "int") || !strcmp(java_type, "byte") || !strcmp(java_type, "short") ||
        !strcmp(java_type, "char"))
        return "0";
    if (!strcmp(java_type, "long"))
        return "0L";
    if (!strcmp(java_type, "float"))
        return "0.0f";
    if (!strcmp(java_type, "double"))
        return "0.0";
    return "null";
}

void java_escape_string(const char *s, char *out, size_t cap)
{
    size_t o = 0;
    if (!s)
        s = "";
    for (size_t i = 0; s[i] && o + 8 < cap; i++) {
        unsigned char c = (unsigned char)s[i];
        switch (c) {
        case '\\': out[o++] = '\\'; out[o++] = '\\'; break;
        case '"': out[o++] = '\\'; out[o++] = '"'; break;
        case '\n': out[o++] = '\\'; out[o++] = 'n'; break;
        case '\r': out[o++] = '\\'; out[o++] = 'r'; break;
        case '\t': out[o++] = '\\'; out[o++] = 't'; break;
        case '\b': out[o++] = '\\'; out[o++] = 'b'; break;
        case '\f': out[o++] = '\\'; out[o++] = 'f'; break;
        default:
            if (c < 0x20 || c == 0x7f) {
                o += (size_t)snprintf(out + o, cap - o, "\\u%04x", c);
            } else {
                out[o++] = (char)c;
            }
        }
    }
    out[o] = '\0';
}

void java_source_path(const char *class_desc, char *out, size_t cap)
{
    char type[512];
    java_type_of(class_desc, type, sizeof(type));

    /* An inner class descriptor uses '$'; javac accepts the flat file name, so
     * keep it as-is but drop array/primitive markers defensively. */
    size_t o = 0;
    for (size_t i = 0; type[i] && o + 6 < cap; i++) {
        char c = type[i];
        if (c == '.')
            c = '/';
        out[o++] = c;
    }
    snprintf(out + o, cap - o, ".java");
}
