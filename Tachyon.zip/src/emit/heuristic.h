#ifndef TACHYON_HEURISTIC_H
#define TACHYON_HEURISTIC_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "dex/dex.h"

/* Heuristic renaming for obfuscated classes.
 *
 * R8 leaves classes called `a`, `b`, `a$b` and so on. The original names are
 * gone, but a class's own contents usually still say what it is: a View
 * subclass, a Retrofit interface, a singleton, an event bus. This module derives
 * a stable, descriptive name from those signals so the output is navigable.
 *
 * Nothing is invented from thin air: every prefix below comes from a fact that
 * is present in the dex (a superclass, an interface, a string constant, an
 * annotation, a field shape). */

typedef struct {
    char **old_desc;   /* DEX descriptor, e.g. "La;" */
    char **new_name;   /* Java simple name, e.g. "Impl_Activity" */
    uint32_t count;    /* entries actually renamed */
    uint32_t cap;      /* hash table capacity, a power of two */
    uint32_t mask;     /* cap - 1 */
} HeurNames;

/* Builds names for every obfuscated class in the given dex set.
 * `is_obfuscated` decides which names count as noise; the same predicate the
 * emitter uses for `renamer` lookups. */
HeurNames *heuristic_build(Dex **dexs, uint32_t count, Arena *arena);

/* Looks up a descriptor. Returns NULL when the class keeps its own name. */
const char *heuristic_name(const HeurNames *h, const char *desc);

/* True when a simple name looks machine-generated rather than authored. */
int heuristic_is_obfuscated(const char *simple);

#endif
