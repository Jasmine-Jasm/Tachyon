#include "emit/stubs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common/writer.h"
#include "common/io.h"
#include "emit/java.h"
#include "emit/remap.h"

/* Packages the JDK and the Android SDK always provide. A type here is never
 * stubbed: android.jar supplies it at compile time, and a stub would shadow the
 * real declaration. */
static const char *const kPlatformPkgs[] = {
    "java/", "javax/", "kotlin/", "kotlinx/", "dalvik/",
    "org/w3c/", "org/xml/", "org/xmlpull/", "org/json/", "junit/",
    "sun/", "jdk/", "com/sun/",
};

/* android.* is provided by android.jar, with these exceptions: they are @hide in
 * the platform, so the app could only reference them through a hidden-API build. */
static const char *const kHiddenAndroid[] = {
    "Landroid/view/RenderNode;",
    "Landroid/view/ScrollFeedbackProvider;",
    "Landroid/view/ScrollFeedbackProvider$ScrollEvent;",
    "Landroid/hardware/camera2/CameraDevice$CameraDeviceSetup;",
};

static int in_platform_pkg(const char *desc)
{
    const char *p = desc + 1; /* skip 'L' */
    for (size_t i = 0; i < sizeof(kPlatformPkgs) / sizeof(kPlatformPkgs[0]); i++) {
        size_t n = strlen(kPlatformPkgs[i]);
        if (!strncmp(p, kPlatformPkgs[i], n))
            return 1;
    }
    return 0;
}

static int is_hidden_android(const char *desc)
{
    for (size_t i = 0; i < sizeof(kHiddenAndroid) / sizeof(kHiddenAndroid[0]); i++)
        if (!strcmp(kHiddenAndroid[i], desc))
            return 1;
    return 0;
}

/* android.* is supplied by the SDK, so only the @hide cases above are stubbed.
 * Every other package (androidx.*, com.*, org.*) is bundled in the APK when it is
 * needed at runtime; if it is absent here it was compile-only. */
static int skip_package(const char *desc)
{
    if (in_platform_pkg(desc))
        return 1;
    /* android.support.* is the old support library, which apps bundle rather
     * than receive from the platform: treat it like any other third-party
     * package instead of assuming android.jar supplies it. */
    if (!strncmp(desc + 1, "android/support/", 16))
        return 0;
    if (!strncmp(desc + 1, "android/", 8) && !is_hidden_android(desc))
        return 1;
    return 0;
}

/* Open-addressing index over the collected descriptors. A linear membership scan
 * made collection quadratic, which dominated the run on large multi-dex apps. */
typedef struct {
    char **items;    /* descriptor, or NULL for an empty slot */
    uint8_t *iface;
    uint32_t *slot;  /* index into Builder.items, so a later mark can update it */
    uint32_t mask;
} Dedup;

typedef struct {
    char **items;
    uint8_t *iface;
    uint32_t count;
    uint32_t cap;
    Arena *arena;
    Dedup set;
} Builder;

static uint32_t desc_hash(const char *s)
{
    uint32_t h = 2166136261u;
    for (const char *p = s; *p; p++)
        h = (h ^ (uint8_t)*p) * 16777619u;
    return h;
}

static void b_add(Builder *b, const char *desc, int iface)
{
    if (!desc || desc[0] != 'L')
        return;
    if (!b->set.mask) {
        uint32_t cap = b->cap ? b->cap : (1 << 16);
        b->set.items = arena_zalloc(b->arena, (size_t)cap * sizeof(char *));
        b->set.iface = arena_zalloc(b->arena, cap);
        b->set.slot = arena_zalloc(b->arena, (size_t)cap * sizeof(uint32_t));
        if (!b->set.items || !b->set.iface || !b->set.slot) {
            b->set.mask = 0;
            return;
        }
        b->set.mask = cap - 1;
    }
    uint32_t h = desc_hash(desc) & b->set.mask;
    for (uint32_t step = 0; step <= b->set.mask; step++, h = (h + 1) & b->set.mask) {
        if (!b->set.items[h]) {
            char *copy = arena_strdup(b->arena, desc);
            if (!copy)
                return;
            b->set.items[h] = copy;
            b->set.iface[h] = (uint8_t)(iface != 0);
            if (b->count == b->cap) {
                uint32_t nc = b->cap ? b->cap * 2 : 512;
                char **ni = arena_zalloc(b->arena, (size_t)nc * sizeof(char *));
                uint8_t *nf = arena_zalloc(b->arena, nc);
                if (!ni || !nf)
                    return;
                if (b->items) {
                    memcpy(ni, b->items, (size_t)b->count * sizeof(char *));
                    memcpy(nf, b->iface, b->count);
                }
                b->items = ni;
                b->iface = nf;
                b->cap = nc;
            }
            b->items[b->count] = copy;
            b->iface[b->count] = (uint8_t)(iface != 0);
            b->set.slot[h] = b->count;
            b->count++;
            return;
        }
        if (!strcmp(b->set.items[h], desc)) {
            /* The same type can appear first as a parameter and later in an
             * implements clause; the interface flag has to reach the stored item,
             * not just the hash entry, or the stub is emitted as a class and
             * "interface expected" follows. */
            if (iface) {
                b->set.iface[h] = 1;
                b->iface[b->set.slot[h]] = 1;
            }
            return;
        }
    }
}

/* Adds every type a proto mentions. */
static void add_proto(Builder *b, Dex *d, uint32_t proto_idx)
{
    if (proto_idx >= d->hdr.proto_ids_size)
        return;
    b_add(b, dex_type_desc(d, d->protos[proto_idx].return_type_idx), 0);
    DexParamList *pl = dex_proto_params(d, proto_idx);
    for (uint32_t i = 0; pl && i < pl->param_count; i++)
        b_add(b, dex_type_desc(d, pl->type_idx[i]), 0);
}

StubSet *stub_collect(Dex **dexs, uint32_t count, Arena *arena)
{
    if (!dexs || !count || !arena)
        return NULL;
    Builder b = {0};
    b.arena = arena;

    /* Size the dedup table from the input: roughly four distinct descriptors per
     * class, rounded up to a power of two so the mask works. */
    uint64_t classes = 0;
    for (uint32_t i = 0; i < count; i++)
        classes += dexs[i]->hdr.class_defs_size;
    uint32_t want = 1 << 12;
    while ((uint64_t)want < classes * 8 && want < (1u << 22))
        want <<= 1;
    b.cap = want;
    b.items = arena_zalloc(arena, (size_t)want * sizeof(char *));
    b.iface = arena_zalloc(arena, want);

    for (uint32_t di = 0; di < count; di++) {
        Dex *d = dexs[di];
        for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
            const DexClassDef *cd = &d->classes[i];
            if (cd->superclass_idx != DEX_NO_INDEX)
                b_add(&b, dex_type_desc(d, cd->superclass_idx), 0);
            if (cd->interfaces_off) {
                uint32_t n = 0;
                memcpy(&n, d->base + cd->interfaces_off, 4);
                for (uint32_t k = 0; k < n && k < 256; k++) {
                    uint16_t ti;
                    memcpy(&ti, d->base + cd->interfaces_off + 4 + k * 2, 2);
                    b_add(&b, dex_type_desc(d, ti), 1);
                }
            }
            const DexClassData *data = dex_class_data(d, i);
            if (!data)
                continue;
            for (uint32_t k = 0; k < data->static_count + data->instance_count; k++) {
                uint32_t fi = k < data->static_count ? data->static_fields[k].field_idx
                                                     : data->instance_fields[k - data->static_count].field_idx;
                if (fi < d->hdr.field_ids_size)
                    b_add(&b, dex_type_desc(d, d->fields[fi].type_idx), 0);
            }
            for (uint32_t k = 0; k < data->direct_count + data->virtual_count; k++) {
                uint32_t mi = k < data->direct_count
                                  ? data->direct_methods[k].method_idx
                                  : data->virtual_methods[k - data->direct_count].method_idx;
                if (mi < d->hdr.method_ids_size)
                    add_proto(&b, d, d->methods[mi].proto_idx);
            }
        }
    }

    /* Keep only what nothing in the APK defines and no SDK package supplies. */
    StubSet *out = arena_zalloc(arena, sizeof(*out));
    if (!out)
        return NULL;
    out->descs = arena_zalloc(arena, (size_t)(b.count + 1) * sizeof(char *));
    out->is_iface = arena_zalloc(arena, b.count + 1);
    if (!out->descs || !out->is_iface)
        return NULL;

    for (uint32_t i = 0; i < b.count; i++) {
        const char *desc = b.items[i];
        if (skip_package(desc))
            continue;
        Dex *owner = NULL;
        if (java_lookup_dex_by_name(desc, dexs[0], &owner) != DEX_NO_INDEX)
            continue; /* defined in the APK */
        out->descs[out->count] = (char *)desc;
        out->is_iface[out->count] = b.iface[i];
        out->count++;
    }
    return out;
}

uint32_t stub_write(const StubSet *s, const char *outdir)
{
    if (!s || !outdir)
        return 0;
    uint32_t written = 0;
    for (uint32_t i = 0; i < s->count; i++) {
        char jname[1024];
        remap_java_type(s->descs[i], jname, sizeof(jname));
        if (!jname[0])
            continue;
        char path[1200];
        size_t o = 0;
        for (const char *p = jname; *p && o + 1 < sizeof(path); p++)
            path[o++] = (*p == '.') ? '/' : *p;
        path[o] = '\0';
        /* The last '.' became '/', so the file name needs restoring. */
        char *slash = strrchr(path, '/');
        char rel[1300];
        if (slash) {
            *slash = '\0';
            snprintf(rel, sizeof(rel), "%s/%s.java", path, slash + 1);
        } else {
            snprintf(rel, sizeof(rel), "%s.java", path);
        }
        const char *simple = strrchr(jname, '.');
        simple = simple ? simple + 1 : jname;
        const char *pkg_end = strrchr(jname, '.');
        char body[1400];
        if (pkg_end)
            snprintf(body, sizeof(body),
                     "package %.*s;\n\n/* Placeholder for a type the APK references but does "
                     "not contain. */\npublic %s %s {\n}\n",
                     (int)(pkg_end - jname), jname, s->is_iface[i] ? "interface" : "class", simple);
        else
            snprintf(body, sizeof(body),
                     "/* Placeholder for a type the APK references but does not contain. */\n"
                     "public %s %s {\n}\n",
                     s->is_iface[i] ? "interface" : "class", simple);
        if (writer_mkdirs_for(outdir, rel) == 0 &&
            writer_write(outdir, rel, body, strlen(body)) == 0)
            written++;
    }
    return written;
}
