#ifndef TACHYON_JAVA_TYPE_H
#define TACHYON_JAVA_TYPE_H

#include <stddef.h>

/* Converts a DEX type descriptor into a Java source type, e.g.
 * "Ljava/lang/String;" -> "java.lang.String", "[I" -> "int[]".
 * The result is written into out (which must hold at least 512 bytes) and a
 * pointer to it is returned. Generic signatures are ignored: erasure only. */
const char *java_type_of(const char *desc, char *out, size_t cap);

/* Default value literal for a Java type: "null", "0", "false", etc. */
const char *java_default_value(const char *java_type);

/* Escapes a DEX string into a valid Java string literal body (no quotes). */
void java_escape_string(const char *s, char *out, size_t cap);

/* Maps a class descriptor to a relative output path ("a/b/C.java"). */
void java_source_path(const char *class_desc, char *out, size_t cap);

/* Returns 1 when the descriptor names a primitive or void. */
int java_is_primitive(const char *desc);

#endif
