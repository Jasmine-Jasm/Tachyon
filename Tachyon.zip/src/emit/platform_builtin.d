src/emit/platform_builtin.o: src/emit/platform_builtin.c \
 src/emit/platform_builtin.h

src/emit/platform_builtin.h:
