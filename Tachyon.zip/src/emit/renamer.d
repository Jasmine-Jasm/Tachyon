src/emit/renamer.o: src/emit/renamer.c src/emit/renamer.h \
 src/common/arena.h src/common/io.h

src/emit/renamer.h:

src/common/arena.h:

src/common/io.h:
