#ifndef TACHYON_PLATFORM_BUILTIN_H
#define TACHYON_PLATFORM_BUILTIN_H

/* Built-in constructor signatures for framework classes, so the emitter can
 * produce a type-correct super(...) call without an android.jar on disk.
 *
 * Returns the parameter descriptors of the class's smallest constructor
 * (comma-separated, "" meaning no-arg), or NULL when the class is not covered. */
const char *platform_builtin_params(const char *desc);

#endif

/* Abstract methods declared by framework base classes. An app subclass must
 * implement them, but they are not visible in the dex, so the emitter has to
 * synthesise stubs or the class fails to compile. */
typedef struct {
    const char *owner;  /* class descriptor, e.g. "Landroid/app/Service;" */
    const char *name;
    const char *ret;    /* return type descriptor */
    const char *params; /* compact parameter descriptors, "" for none */
} PlatformAbstract;

/* True when the framework constructor this type exposes declares
 * `throws IOException`. A synthesised constructor chaining to it must repeat the
 * clause, because a super(...) call cannot be wrapped in a try block. */
int platform_builtin_ctor_throws_io(const char *desc);

/* Splits a compact descriptor list into individual parameter descriptors. */
int platform_builtin_split_params(const char *params, char out[][128], int max);

/* Returns the abstract methods declared by `owner_desc`, or NULL. */
const PlatformAbstract *platform_builtin_abstracts(const char *owner_desc, int *count);

/* A method a framework type declares, keyed by its erased signature. */
typedef struct {
    const char *owner;
    const char *name;
    const char *params; /* compact descriptors, "" for none */
    const char *ret;
    /* 1 when the framework hierarchy declares competing versions of this method,
     * so a subclass declaration can never coexist with the inherited one. */
    int drop_always;
} PlatformMethod;

/* Finds a method on a framework type by erased signature, or NULL. */
const PlatformMethod *platform_builtin_method(const char *owner, const char *name,
                                              const char *params);

/* The framework superclass of `desc`, or NULL when unknown. Lets the emitter walk
 * an app class's platform ancestry without an android.jar on disk. */
const char *platform_builtin_parent(const char *desc);
