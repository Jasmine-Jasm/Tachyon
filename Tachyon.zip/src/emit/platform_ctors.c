#include "emit/platform_ctors.h"
#include "emit/platform_builtin.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* A minimal class-file reader: enough of the constant pool and method table to
 * recover constructor descriptors. Full verification is not needed here. */

typedef struct {
    const uint8_t *p;
    size_t len;
    size_t pos;
    int bad;
} Rd;

static uint8_t u1(Rd *r)
{
    if (r->pos + 1 > r->len) {
        r->bad = 1;
        return 0;
    }
    return r->p[r->pos++];
}

static uint16_t u2(Rd *r)
{
    if (r->pos + 2 > r->len) {
        r->bad = 1;
        return 0;
    }
    uint16_t v = (uint16_t)((r->p[r->pos] << 8) | r->p[r->pos + 1]);
    r->pos += 2;
    return v;
}

static uint32_t u4(Rd *r)
{
    if (r->pos + 4 > r->len) {
        r->bad = 1;
        return 0;
    }
    uint32_t v = ((uint32_t)r->p[r->pos] << 24) | ((uint32_t)r->p[r->pos + 1] << 16) |
                 ((uint32_t)r->p[r->pos + 2] << 8) | (uint32_t)r->p[r->pos + 3];
    r->pos += 4;
    return v;
}

static void skip(Rd *r, size_t n)
{
    if (r->pos + n > r->len) {
        r->bad = 1;
        r->pos = r->len;
        return;
    }
    r->pos += n;
}

/* Constant pool entries needed to resolve descriptors: Utf8 (1) and Class (7). */
typedef struct {
    char **utf8;
    uint16_t *class_name_idx;
    uint16_t count;
} Pool;

static int read_pool(Rd *r, Pool *pool)
{
    uint16_t n = u2(r);
    if (r->bad || n == 0)
        return -1;
    pool->count = n;
    pool->utf8 = calloc(n, sizeof(char *));
    pool->class_name_idx = calloc(n, sizeof(uint16_t));
    if (!pool->utf8 || !pool->class_name_idx)
        return -1;

    for (uint16_t i = 1; i < n; i++) {
        uint8_t tag = u1(r);
        if (r->bad)
            return -1;
        switch (tag) {
        case 1: { /* Utf8 */
            uint16_t len = u2(r);
            if (r->bad || r->pos + len > r->len)
                return -1;
            char *s = malloc((size_t)len + 1);
            if (!s)
                return -1;
            memcpy(s, r->p + r->pos, len);
            s[len] = '\0';
            r->pos += len;
            pool->utf8[i] = s;
            break;
        }
        case 7: pool->class_name_idx[i] = u2(r); break;    /* Class */
        case 8: case 16: case 19: case 20: skip(r, 2); break; /* String/MethodType/Module/Package */
        case 15: skip(r, 3); break;                        /* MethodHandle */
        case 3: case 4: case 9: case 10: case 11: case 12:
        case 17: case 18: skip(r, 4); break;
        case 5: case 6: skip(r, 8); i++; break;             /* Long/Double take two slots */
        default: return -1;
        }
        if (r->bad)
            return -1;
    }
    return 0;
}

static void free_pool(Pool *pool)
{
    for (uint16_t i = 1; i < pool->count; i++)
        free(pool->utf8[i]);
    free(pool->utf8);
    free(pool->class_name_idx);
}

/* Counts the parameters in a method descriptor "(IILjava/lang/String;)V". */
static int descriptor_param_count(const char *desc)
{
    if (!desc || desc[0] != '(')
        return -1;
    int n = 0;
    const char *p = desc + 1;
    while (*p && *p != ')') {
        while (*p == '[')
            p++;
        if (*p == 'L') {
            while (*p && *p != ';')
                p++;
            if (*p)
                p++;
        } else if (*p) {
            p++;
        }
        n++;
    }
    return n;
}

int platform_ctor_param_counts(const char *path, int *counts, int max)
{
    FILE *f = fopen(path, "rb");
    if (!f)
        return -1;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0 || sz > 64 * 1024 * 1024) {
        fclose(f);
        return -1;
    }
    uint8_t *buf = malloc((size_t)sz);
    if (!buf) {
        fclose(f);
        return -1;
    }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    if (got != (size_t)sz) {
        free(buf);
        return -1;
    }

    Rd r = { buf, (size_t)sz, 0, 0 };
    if (u4(&r) != 0xCAFEBABE) {
        free(buf);
        return -1;
    }
    skip(&r, 4); /* minor, major */

    Pool pool = {0};
    if (read_pool(&r, &pool) != 0) {
        free_pool(&pool);
        free(buf);
        return -1;
    }

    skip(&r, 6); /* access, this, super */
    uint16_t icount = u2(&r);
    skip(&r, (size_t)icount * 2);
    uint16_t fcount = u2(&r);
    for (uint16_t i = 0; i < fcount && !r.bad; i++) {
        skip(&r, 6);
        uint16_t acount = u2(&r);
        for (uint16_t a = 0; a < acount && !r.bad; a++) {
            skip(&r, 2);
            uint32_t alen = u4(&r);
            skip(&r, alen);
        }
    }

    int n = 0;
    uint16_t mcount = u2(&r);
    for (uint16_t i = 0; i < mcount && !r.bad && n < max; i++) {
        skip(&r, 2); /* access */
        uint16_t name_idx = u2(&r);
        uint16_t desc_idx = u2(&r);
        uint16_t acount = u2(&r);
        for (uint16_t a = 0; a < acount && !r.bad; a++) {
            skip(&r, 2);
            uint32_t alen = u4(&r);
            skip(&r, alen);
        }
        const char *name = name_idx < pool.count ? pool.utf8[name_idx] : NULL;
        const char *desc = desc_idx < pool.count ? pool.utf8[desc_idx] : NULL;
        if (name && !strcmp(name, "<init>")) {
            int pc = descriptor_param_count(desc);
            if (pc >= 0)
                counts[n++] = pc;
        }
    }

    free_pool(&pool);
    free(buf);
    return n;
}

int platform_has_noarg_ctor(const char *jar_path, const char *class_path)
{
    /* Reading the whole jar for every class would be far too slow; callers pass a
     * pre-extracted file. */
    int counts[64];
    int n = platform_ctor_param_counts(jar_path, counts, 64);
    if (n <= 0)
        return -1;
    for (int i = 0; i < n; i++)
        if (counts[i] == 0)
            return 1;
    return 0;
}

/* ---- SDK lookup ------------------------------------------------------- */

/* The Android SDK ships android.jar as a plain zip. Building an index of every
 * class would take seconds, so entries are extracted on first use and cached by
 * descriptor. Only a few hundred distinct platform superclasses appear in a
 * typical APK. */

#define PLAT_MAX 4096

typedef struct {
    char *desc;
    int arity; /* -1 unknown, 0 has no-arg ctor, >0 smallest param count */
} PlatEntry;

static PlatEntry g_plat[PLAT_MAX];
static int g_plat_count;
static char g_plat_dir[512];
static int g_plat_ready;

void platform_set_sdk(const char *class_dir)
{
    snprintf(g_plat_dir, sizeof(g_plat_dir), "%s", class_dir ? class_dir : "");
    g_plat_ready = 1;
}

static PlatEntry *plat_find(const char *desc)
{
    for (int i = 0; i < g_plat_count; i++)
        if (!strcmp(g_plat[i].desc, desc))
            return &g_plat[i];
    return NULL;
}

/* Descriptor "Landroid/view/View$BaseSavedState;" maps to the file
 * "<dir>/android/view/View$BaseSavedState.class". */
static int plat_lookup(const char *desc)
{
    if (!g_plat_ready || !g_plat_dir[0] || !desc || desc[0] != 'L')
        return -1;

    PlatEntry *hit = plat_find(desc);
    if (hit)
        return hit->arity;

    char path[1024];
    size_t n = 0;
    n += (size_t)snprintf(path + n, sizeof(path) - n, "%s/", g_plat_dir);
    for (const char *q = desc + 1; *q && *q != ';' && n + 1 < sizeof(path); q++)
        path[n++] = *q;
    path[n] = '\0';
    snprintf(path + n, sizeof(path) - n, ".class");

    int counts[64];
    int nc = platform_ctor_param_counts(path, counts, 64);
    int arity = -1;
    if (nc > 0) {
        arity = counts[0];
        for (int i = 1; i < nc; i++)
            if (counts[i] < arity)
                arity = counts[i];
    }

    if (g_plat_count < PLAT_MAX) {
        char *copy = malloc(strlen(desc) + 1);
        if (copy) {
            strcpy(copy, desc);
            g_plat[g_plat_count].desc = copy;
            g_plat[g_plat_count].arity = arity;
            g_plat_count++;
        }
    }
    return arity;
}

int platform_ctor_arity(const char *desc)
{
    return plat_lookup(desc);
}

/* ---- constructor descriptors ---------------------------------------- */

/* Copies the parameter descriptor list of the smallest-arity constructor into
 * `out`. Each entry is one descriptor such as "Landroid/content/Context;" or
 * "I". Returns the parameter count, or -1. */
int platform_ctor_params(const char *path, char out[][128], int max)
{
    FILE *f = fopen(path, "rb");
    if (!f)
        return -1;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0 || sz > 64 * 1024 * 1024) {
        fclose(f);
        return -1;
    }
    uint8_t *buf = malloc((size_t)sz);
    if (!buf) {
        fclose(f);
        return -1;
    }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    if (got != (size_t)sz) {
        free(buf);
        return -1;
    }

    Rd r = { buf, (size_t)sz, 0, 0 };
    if (u4(&r) != 0xCAFEBABE) {
        free(buf);
        return -1;
    }
    skip(&r, 4);
    Pool pool = {0};
    if (read_pool(&r, &pool) != 0) {
        free_pool(&pool);
        free(buf);
        return -1;
    }
    skip(&r, 6);
    uint16_t icount = u2(&r);
    skip(&r, (size_t)icount * 2);
    uint16_t fcount = u2(&r);
    for (uint16_t i = 0; i < fcount && !r.bad; i++) {
        skip(&r, 6);
        uint16_t acount = u2(&r);
        for (uint16_t a = 0; a < acount && !r.bad; a++) {
            skip(&r, 2);
            uint32_t alen = u4(&r);
            skip(&r, alen);
        }
    }

    const char *best = NULL;
    int best_n = 0x7fffffff;
    uint16_t mcount = u2(&r);
    for (uint16_t i = 0; i < mcount && !r.bad; i++) {
        skip(&r, 2);
        uint16_t name_idx = u2(&r);
        uint16_t desc_idx = u2(&r);
        uint16_t acount = u2(&r);
        for (uint16_t a = 0; a < acount && !r.bad; a++) {
            skip(&r, 2);
            uint32_t alen = u4(&r);
            skip(&r, alen);
        }
        const char *nm = name_idx < pool.count ? pool.utf8[name_idx] : NULL;
        const char *ds = desc_idx < pool.count ? pool.utf8[desc_idx] : NULL;
        if (nm && ds && !strcmp(nm, "<init>")) {
            int pc = descriptor_param_count(ds);
            if (pc >= 0 && pc < best_n) {
                best_n = pc;
                best = ds;
            }
        }
    }

    int n = 0;
    if (best && best[0] == '(') {
        const char *p = best + 1;
        while (*p && *p != ')' && n < max) {
            const char *start = p;
            while (*p == '[')
                p++;
            if (*p == 'L') {
                while (*p && *p != ';')
                    p++;
                if (*p)
                    p++;
            } else if (*p) {
                p++;
            }
            size_t len = (size_t)(p - start);
            if (len > 0 && len < 128) {
                memcpy(out[n], start, len);
                out[n][len] = '\0';
                n++;
            }
        }
    }

    free_pool(&pool);
    free(buf);
    return n;
}

/* Cache of parameter lists keyed by descriptor: the same handful of platform
 * superclasses is looked up thousands of times. */
typedef struct {
    char *desc;
    int n;
    char params[8][128];
} PlatParams;
#define PLAT_PARAM_MAX 512
static PlatParams g_pp[PLAT_PARAM_MAX];
static int g_pp_count;

int platform_ctor_params_of(const char *desc, char out[][128], int max)
{
    if (!desc || desc[0] != 'L')
        return -1;

    /* The built-in table comes first: it works with no SDK unpacked, and it is
     * the only source for classes an installed android.jar happens to omit. */
    {
        const char *bi = platform_builtin_params(desc);
        if (bi)
            return platform_builtin_split_params(bi, out, max);
    }

    if (!g_plat_ready || !g_plat_dir[0])
        return -1;
    for (int i = 0; i < g_pp_count; i++)
        if (!strcmp(g_pp[i].desc, desc)) {
            int n = g_pp[i].n < max ? g_pp[i].n : max;
            for (int k = 0; k < n; k++)
                memcpy(out[k], g_pp[i].params[k], 128);
            return g_pp[i].n;
        }
    char path[1024];
    size_t n = 0;
    n += (size_t)snprintf(path + n, sizeof(path) - n, "%s/", g_plat_dir);
    for (const char *q = desc + 1; *q && *q != ';' && n + 1 < sizeof(path); q++)
        path[n++] = *q;
    path[n] = '\0';
    snprintf(path + n, sizeof(path) - n, ".class");
    int got = platform_ctor_params(path, out, max);
    if (got >= 0 && g_pp_count < PLAT_PARAM_MAX) {
        char *copy = malloc(strlen(desc) + 1);
        if (copy) {
            strcpy(copy, desc);
            g_pp[g_pp_count].desc = copy;
            g_pp[g_pp_count].n = got;
            int lim = got < 8 ? got : 8;
            for (int k = 0; k < lim; k++)
                memcpy(g_pp[g_pp_count].params[k], out[k], 128);
            g_pp_count++;
        }
    }
    return got;
}
