src/emit/stubs.o: src/emit/stubs.c src/emit/stubs.h src/common/arena.h \
 src/dex/dex.h src/common/buf.h src/common/io.h src/common/writer.h \
 src/emit/java.h src/emit/renamer.h src/emit/heuristic.h src/emit/remap.h

src/emit/stubs.h:

src/common/arena.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/common/writer.h:

src/emit/java.h:

src/emit/renamer.h:

src/emit/heuristic.h:

src/emit/remap.h:
