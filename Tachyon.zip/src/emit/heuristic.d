src/emit/heuristic.o: src/emit/heuristic.c src/emit/heuristic.h \
 src/common/arena.h src/dex/dex.h src/common/buf.h src/common/io.h

src/emit/heuristic.h:

src/common/arena.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:
