#ifndef TACHYON_STUBS_H
#define TACHYON_STUBS_H

#include <stdint.h>

#include "common/arena.h"
#include "dex/dex.h"

/* Placeholder declarations for types the app references but does not contain.
 *
 * An APK routinely names classes that live in the platform (hidden APIs such as
 * android.view.RenderNode) or in libraries the build marked compile-only
 * (androidx.window.*). Those references are real, so a decompiled tree that
 * mentions them cannot compile on its own.
 *
 * This module collects exactly those descriptors and writes a minimal
 * declaration for each, so the tree stands alone. Nothing is invented beyond the
 * type's existence: a stub has no members, and a stub that anything actually
 * calls would still fail, which keeps the result honest.
 */

typedef struct {
    char **descs;   /* DEX descriptors, "Lpkg/Name;" */
    uint8_t *is_iface;
    uint32_t count;
} StubSet;

/* Walks every class in the set and collects referenced-but-undefined types. */
StubSet *stub_collect(Dex **dexs, uint32_t count, Arena *arena);

/* Writes the stub sources under `outdir`. Returns the number written. */
uint32_t stub_write(const StubSet *s, const char *outdir);

#endif
