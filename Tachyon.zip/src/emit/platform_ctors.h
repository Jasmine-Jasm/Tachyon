#ifndef TACHYON_PLATFORM_CTORS_H
#define TACHYON_PLATFORM_CTORS_H

/* Reads the constructor parameter counts of a class file on disk.
 * Returns the number of constructors written to `counts`, or -1 on failure. */
int platform_ctor_param_counts(const char *path, int *counts, int max);

/* 1 when the class at `path` declares a no-arg constructor, 0 when it declares
 * constructors but none takes zero parameters, -1 when it cannot be read. */
int platform_has_noarg_ctor(const char *path, const char *class_path);

/* Points the lookup at a directory holding an extracted android.jar class tree.
 * Pass NULL or "" to disable SDK lookups. */
void platform_set_sdk(const char *class_dir);

/* Smallest constructor parameter count for a class descriptor, 0 when it has a
 * no-arg constructor, -1 when unknown. */
int platform_ctor_arity(const char *desc);

/* Parameter descriptors of the smallest-arity constructor of a class. */
int platform_ctor_params(const char *path, char out[][128], int max);
int platform_ctor_params_of(const char *desc, char out[][128], int max);

#endif
