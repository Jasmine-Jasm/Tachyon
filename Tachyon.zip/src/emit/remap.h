#ifndef TACHYON_EMIT_REMAP_H
#define TACHYON_EMIT_REMAP_H

#include <stddef.h>
#include <stdint.h>

/* Java 9+ forbids user code from declaring classes in java.* (the package is
 * owned by java.base), and an APK desugared by an older toolchain can ship its
 * own copies of java.lang / java.util members. Emitting those verbatim makes
 * javac reject the whole compilation, so they are relocated to this package.
 *
 * Only descriptors that the dex actually DEFINES are relocated: a reference to
 * java.lang.String must keep pointing at the real JDK class. */
extern const char *g_remap_prefix;

struct Dex;

/* Builds the set of java-namespace descriptors defined by `dex`. Call once
 * before emitting. */
void remap_init(struct Dex *dex);
void remap_free(void);

/* Returns 1 when `desc` names a java.* type that this dex defines. */
int remap_needed(const char *desc);

/* Writes the Java type name for `desc` into out, relocating it if needed. */
void remap_java_type(const char *desc, char *out, size_t cap);
/* The dex currently being emitted, used to resolve whether a class name had to
 * be renamed. Set once per input file. */
struct Dex;
extern struct Dex *g_current_dex;

/* When set, default-package classes are relocated into a synthetic package so
 * named-package classes can reference them at all. */
extern int g_relocate_default_pkg;

/* Descriptors of classes whose path collides with a package directory. Every
 * reference to them gains a '_' suffix, matching the declaration. */
void remap_set_package_conflicts(char **descs, uint32_t count);

/* Returns the suffixed simple name for a class that collides with a directory. */
int remap_conflict_name(const char *desc, char *out, size_t cap);

/* True when this class was moved out of the default package, in which case its
 * members must be reachable from other packages. */
int remap_is_relocated_default(const char *desc);

#endif

