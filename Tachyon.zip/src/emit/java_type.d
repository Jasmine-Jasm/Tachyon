src/emit/java_type.o: src/emit/java_type.c src/emit/java_type.h

src/emit/java_type.h:
