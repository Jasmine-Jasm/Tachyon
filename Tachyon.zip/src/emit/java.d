src/emit/java.o: src/emit/java.c src/emit/java.h src/common/arena.h \
 src/common/buf.h src/dex/dex.h src/common/io.h src/emit/renamer.h \
 src/emit/heuristic.h src/emit/platform_builtin.h \
 src/emit/platform_ctors.h src/emit/java_type.h src/emit/remap.h \
 src/ir/body.h src/ir/cfg.h src/ir/opcode.h

src/emit/java.h:

src/common/arena.h:

src/common/buf.h:

src/dex/dex.h:

src/common/io.h:

src/emit/renamer.h:

src/emit/heuristic.h:

src/emit/platform_builtin.h:

src/emit/platform_ctors.h:

src/emit/java_type.h:

src/emit/remap.h:

src/ir/body.h:

src/ir/cfg.h:

src/ir/opcode.h:
