#include "emit/renamer.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common/io.h"

/* Mapping files use dotted class names without a descriptor wrapper; dex
 * descriptors look like "La/b/C;". Normalise both to "a.b.C". */
static void normalize_class(const char *in, char *out, size_t cap)
{
    size_t o = 0;
    const char *p = in;
    if (*p == 'L')
        p++;
    for (; *p && *p != ';' && o + 1 < cap; p++)
        out[o++] = (*p == '/') ? '.' : *p;
    out[o] = '\0';
}

static uint32_t hash_str(const char *s)
{
    uint32_t h = 2166136261u;
    while (*s)
        h = (h ^ (uint8_t)*s++) * 16777619u;
    return h;
}

/* Trims trailing whitespace in place and returns the start of the trimmed text. */
static char *trim(char *s)
{
    while (*s == ' ' || *s == '\t')
        s++;
    size_t n = strlen(s);
    while (n && (s[n - 1] == ' ' || s[n - 1] == '\t' || s[n - 1] == '\r' || s[n - 1] == '\n'))
        s[--n] = '\0';
    return s;
}

static void renamer_index(Renamer *r)
{
    uint32_t cap = 64;
    while (cap < r->count * 2)
        cap <<= 1;
    r->slot_cap = cap;
    r->slots = arena_zalloc(r->arena, (size_t)cap * sizeof(uint32_t));
    if (!r->slots)
        return;
    for (uint32_t i = 0; i < r->count; i++) {
        uint32_t k = hash_str(r->classes[i].from_class) & (cap - 1);
        while (r->slots[k])
            k = (k + 1) & (cap - 1);
        r->slots[k] = i + 1;
    }
}

Renamer *renamer_load(const char *path, Arena *arena)
{
    MappedFile *mf = malloc(sizeof(*mf));
    if (!mf)
        return NULL;
    if (io_map(path, mf) < 0) {
        free(mf);
        return NULL;
    }

    /* The mapping is a text file, but a stray NUL would truncate it; copy into a
     * mutable arena buffer and parse line by line. */
    char *text = arena_memdup(arena, mf->data, mf->len);
    io_unmap(mf);
    free(mf);
    if (!text)
        return NULL;

    Renamer *r = arena_zalloc(arena, sizeof(*r));
    if (!r)
        return NULL;
    r->arena = arena;

    uint32_t cap = 256;
    r->classes = arena_zalloc(arena, (size_t)cap * sizeof(MapClass));
    if (!r->classes)
        return NULL;

    MapClass *cur = NULL;
    uint32_t member_cap = 0;

    char *line = text;
    while (line && *line) {
        char *nl = strchr(line, '\n');
        if (nl)
            *nl = '\0';

        /* Member lines are indented; the check must happen before trimming
         * removes the leading spaces that distinguish them. */
        int indented = (line[0] == ' ' || line[0] == '\t');
        char *s = trim(line);

        if (*s == '\0' || *s == '#') {
            /* blank / comment */
        } else if (indented) {
            /* member line, belongs to the current class */
            if (cur) {
                char *arrow = strstr(s, " -> ");
                if (arrow) {
                    *arrow = '\0';
                    char *to = trim(arrow + 4);
                    /* Strip the return type and argument list: keep the name only. */
                    char *from = trim(s);
                    char *paren = strchr(from, '(');
                    if (paren)
                        *paren = '\0';
                    char *sp = strrchr(from, ' ');
                    char *from_name = sp ? sp + 1 : from;
                    /* A field line looks like "int name"; a method line like
                     * "12:34:void name". Both end with the bare identifier
                     * before any colon-separated prefix. */
                    char *colon = strrchr(from_name, ':');
                    if (colon)
                        from_name = colon + 1;

                    size_t n = 0;
                    while (to[n] && to[n] != '(' && to[n] != ' ')
                        n++;
                    char *to_name = arena_memdup(arena, to, n);

                    if (cur->member_count == member_cap) {
                        member_cap = member_cap ? member_cap * 2 : 16;
                        char **nf = arena_alloc(arena, (size_t)member_cap * sizeof(char *));
                        char **nt = arena_alloc(arena, (size_t)member_cap * sizeof(char *));
                        if (!nf || !nt)
                            break;
                        if (cur->member_count) {
                            memcpy(nf, cur->from_member, (size_t)cur->member_count * sizeof(char *));
                            memcpy(nt, cur->to_member, (size_t)cur->member_count * sizeof(char *));
                        }
                        cur->from_member = nf;
                        cur->to_member = nt;
                    }
                    /* Mapping lines read "original -> obfuscated", so the left
                     * side is the readable name and the right side is what
                     * appears in the dex. Store them the other way round to make
                     * lookups by obfuscated name direct. */
                    cur->from_member[cur->member_count] = to_name;
                    cur->to_member[cur->member_count] = arena_strdup(arena, from_name);
                    cur->member_count++;
                }
            }
        } else {
            /* class line: "original -> obfuscated:" */
            char *arrow = strstr(s, " -> ");
            if (arrow) {
                *arrow = '\0';
                char *to = trim(arrow + 4);
                size_t n = strlen(to);
                if (n && to[n - 1] == ':')
                    to[n - 1] = '\0';

                if (r->count == cap) {
                    cap *= 2;
                    MapClass *nc = arena_zalloc(arena, (size_t)cap * sizeof(MapClass));
                    if (!nc)
                        break;
                    memcpy(nc, r->classes, (size_t)r->count * sizeof(MapClass));
                    r->classes = nc;
                }
                cur = &r->classes[r->count++];
                cur->to_class = arena_strdup(arena, trim(s));
                {
                    char norm[512];
                    normalize_class(to, norm, sizeof(norm));
                    cur->from_class = arena_strdup(arena, norm);
                }
                cur->from_member = NULL;
                cur->to_member = NULL;
                cur->member_count = 0;
                member_cap = 0;
            }
        }

        if (!nl)
            break;
        line = nl + 1;
    }

    renamer_index(r);
    return r;
}

const char *renamer_class(Renamer *r, const char *obf_class)
{
    if (!r || !r->slots || !obf_class)
        return NULL;
    char buf[512];
    normalize_class(obf_class, buf, sizeof(buf));

    uint32_t k = hash_str(buf) & (r->slot_cap - 1);
    for (uint32_t probe = 0; probe < r->slot_cap; probe++) {
        if (!r->slots[k])
            return NULL;
        MapClass *c = &r->classes[r->slots[k] - 1];
        if (!strcmp(c->from_class, buf))
            return c->to_class;
        k = (k + 1) & (r->slot_cap - 1);
    }
    return NULL;
}

const char *renamer_member(Renamer *r, const char *obf_class, const char *obf_member)
{
    if (!r || !r->slots || !obf_class || !obf_member)
        return NULL;
    char buf[512];
    normalize_class(obf_class, buf, sizeof(buf));

    uint32_t k = hash_str(buf) & (r->slot_cap - 1);
    for (uint32_t probe = 0; probe < r->slot_cap; probe++) {
        if (!r->slots[k])
            return NULL;
        MapClass *c = &r->classes[r->slots[k] - 1];
        if (!strcmp(c->from_class, buf)) {
            for (uint32_t m = 0; m < c->member_count; m++)
                if (!strcmp(c->from_member[m], obf_member))
                    return c->to_member[m];
            return NULL;
        }
        k = (k + 1) & (r->slot_cap - 1);
    }
    return NULL;
}

uint32_t renamer_class_count(Renamer *r)
{
    return r ? r->count : 0;
}
