src/emit/remap.o: src/emit/remap.c src/emit/remap.h src/dex/dex.h \
 src/common/arena.h src/common/buf.h src/common/io.h src/emit/java.h \
 src/emit/renamer.h src/emit/heuristic.h src/emit/java_type.h

src/emit/remap.h:

src/dex/dex.h:

src/common/arena.h:

src/common/buf.h:

src/common/io.h:

src/emit/java.h:

src/emit/renamer.h:

src/emit/heuristic.h:

src/emit/java_type.h:
