src/emit/platform_ctors.o: src/emit/platform_ctors.c \
 src/emit/platform_ctors.h src/emit/platform_builtin.h

src/emit/platform_ctors.h:

src/emit/platform_builtin.h:
