#ifndef TACHYON_RENAMER_H
#define TACHYON_RENAMER_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"

/* ProGuard / R8 mapping.txt support.
 *
 * Format:
 *   com.original.Name -> a.b.c:
 *       int originalField -> a
 *       12:34:void originalMethod(int) -> b
 *
 * The compiler emits obfuscated names, so recovering readable identifiers is a
 * pure lookup once the mapping is available. */
typedef struct {
    char *from_class;   /* obfuscated: "a.b.c" */
    char *to_class;     /* original:   "com.original.Name" */
    char **from_member;
    char **to_member;
    uint32_t member_count;
} MapClass;

typedef struct {
    MapClass *classes;
    uint32_t count;
    Arena *arena;
    /* open-addressing index on from_class for O(1) lookups */
    uint32_t *slots;
    uint32_t slot_cap;
} Renamer;

/* Parses a mapping file. Returns NULL on failure. */
Renamer *renamer_load(const char *path, Arena *arena);

/* Returns the original class name for an obfuscated one, or NULL. */
const char *renamer_class(Renamer *r, const char *obf_class);

/* Returns the original member name within a class, or NULL. */
const char *renamer_member(Renamer *r, const char *obf_class, const char *obf_member);

/* Number of parsed classes, for reporting. */
uint32_t renamer_class_count(Renamer *r);

#endif
