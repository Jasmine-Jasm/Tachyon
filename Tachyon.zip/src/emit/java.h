#ifndef TACHYON_EMIT_JAVA_H
#define TACHYON_EMIT_JAVA_H

#include "common/arena.h"
#include "common/buf.h"
#include "dex/dex.h"
#include "emit/renamer.h"

/* Renders one class into Java source. Returns 0 on success.
 * The emitted class always compiles: methods that we cannot yet decompile are
 * emitted as stubs that either throw or return a default value. */
int java_emit_class(Dex *dex, uint32_t class_def_idx, Buf *out);

/* Chooses the file path (relative to the output root) for a class. */
void java_class_path(Dex *dex, uint32_t class_def_idx, char *out, size_t cap);

/* The single authority on a class's Java name. Declarations, file paths and type
 * references must all agree, so they all derive from this. */
void java_class_fqname(Dex *dex, uint32_t class_def_idx, char *out, size_t cap);

/* Builds the cross-dex class index once, before any worker starts. */
void java_build_global_defs(Dex **dexs, uint32_t count, Arena *arena);

/* Computes which emitted paths are also package directories. Must run before
 * any worker asks for a class path. */
void java_build_package_dirs(Dex *dex, Arena *arena);

/* Allocates the per-class cache used by the abstract-method check. */
void java_prepare_missing_bitmap(Dex *dex, Arena *arena);

/* Enables the supertype walks that catch rare shapes at some CPU cost. */
void java_set_accurate_mode(int on);

/* Resolves a type index defined in another dex of the same input. Returns the
 * class_def index within *owner, or NO_INDEX when the type has no definition. */
uint32_t java_lookup_dex(uint32_t type_idx, Dex *from, Dex **owner);

/* Same, but keyed on the descriptor string; required across dex files because
 * type indices are per-dex. */
uint32_t java_lookup_dex_by_name(const char *desc, Dex *from, Dex **owner);

/* Arena used for per-method decompilation scratch space. Set once before
 * emitting; the emitter does not own it. */
void java_set_body_arena(Arena *a);
#include "emit/heuristic.h"

Arena *java_body_arena(void);
void java_set_heuristic(HeurNames *h);
HeurNames *java_heur(void);

/* Descriptors that will be emitted as placeholder declarations. References to
 * them must use the same '$'-folded spelling as the file that gets written. */
void java_set_stub_descs(char **descs, uint32_t count);
int java_is_stub_desc(const char *desc);

/* Enables experimental method-body decompilation. Off by default: the fallback
 * stub is guaranteed to compile, whereas a partially recovered body may not. */
/* When on (the default), classes that cannot be expressed as compilable Java
 * because they implement both a JDK interface and its desugared copy are
 * skipped and reported, so every emitted file compiles. */
void java_set_skip_conflicts(int on);
int java_skip_conflicts(void);

void java_set_emit_bodies(int on);
int java_emit_bodies(void);

/* Installs the deobfuscation map applied to every emitted identifier. */
void java_set_renamer(Renamer *r);
Renamer *java_renamer(void);

/* Resolved names honouring the renamer; return the input when unmapped. */
const char *java_class_name(Dex *dex, uint32_t type_idx);
const char *java_member_name(Dex *dex, uint32_t class_type_idx, uint32_t member_idx,
                             int is_method);

/* Clears the memoised "class name shadows a package" table; call once per input
 * file before emitting. */
void java_reset_shadow_table(void);
void java_prepare_shadow_table(Dex *dex);

/* Every dex in the current input, so cross-dex superclass lookups can fall back
 * to a global search (an APK splits one type universe across several files). */
extern Dex **g_all_dex;
extern uint32_t g_all_dex_count;

#endif
