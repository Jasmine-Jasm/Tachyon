#include "emit/heuristic.h"

#include <stdio.h>
#include <string.h>

/* A name is machine-generated when it is a single letter with an optional digit
 * ("a", "b2", "a0_b"). Anything with a real word shape is left untouched. */
int heuristic_is_obfuscated(const char *simple)
{
    if (!simple || !*simple)
        return 0;
    size_t n = strlen(simple);
    if (n > 3)
        return 0;
    for (size_t i = 0; i < n; i++) {
        char c = simple[i];
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '_'))
            return 0;
    }
    return 1;
}

static void simple_of(const char *desc, char *out, size_t cap)
{
    out[0] = '\0';
    if (!desc || desc[0] != 'L')
        return;
    const char *slash = strrchr(desc, '/');
    const char *p = slash ? slash + 1 : desc + 1;
    size_t o = 0;
    while (*p && *p != ';' && o + 1 < cap) {
        char c = *p++;
        out[o++] = (c == '$') ? '_' : c;
    }
    out[o] = '\0';
}

/* Last component of a class descriptor, with '$' folded. */
static int stem_of(const char *desc, char *out, size_t cap)
{
    if (!desc || desc[0] != 'L')
        return 0;
    simple_of(desc, out, cap);
    if (!out[0])
        return 0;
    /* A stem that is itself obfuscated carries no information. */
    if (heuristic_is_obfuscated(out))
        return 0;
    return 1;
}

/* A string constant is the strongest signal: R8 keeps literals like "GET" or
 * "login" that name what the class is for. */
static int stem_from_constants(Dex *d, uint32_t class_def, char *out, size_t cap)
{
    if (!d->classes[class_def].static_values_off)
        return 0;
    DexValue *vals = NULL;
    uint32_t n = dex_static_values(d, d->classes[class_def].static_values_off, &vals);
    for (uint32_t i = 0; i < n; i++) {
        if (vals[i].value_type != 0x17) /* string */
            continue;
        const char *s = dex_string(d, (uint32_t)vals[i].v.u);
        if (!s)
            continue;
        size_t len = strlen(s);
        if (len < 4 || len > 20)
            continue;
        char buf[24];
        size_t o = 0;
        for (const char *p = s; *p && o + 1 < sizeof(buf); p++) {
            char c = *p;
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                (c >= '0' && c <= '9') || c == '_')
                buf[o++] = c;
            else
                break;
        }
        buf[o] = '\0';
        if (o < 4)
            continue;
        snprintf(out, cap, "%s", buf);
        return 1;
    }
    return 0;
}

/* Derived from the class's own shape. Returns 0 when nothing informative is
 * available, which leaves the original obfuscated name in place. */
static int derive_name(Dex *d, uint32_t class_def, char *out, size_t cap)
{
    const DexClassDef *cd = &d->classes[class_def];
    uint32_t flags = cd->access_flags;
    int is_iface = (flags & DEX_ACC_INTERFACE) != 0;
    char stem[256];

    if (is_iface) {
        /* An interface's purpose usually shows in its methods; without an
         * implementor or a literal there is nothing to name it after. */
        return 0;
    }

    if (stem_from_constants(d, class_def, stem, sizeof(stem))) {
        snprintf(out, cap, "%s_%s", (flags & DEX_ACC_ABSTRACT) ? "Abstract" : "Impl", stem);
        return 1;
    }

    if (cd->superclass_idx != DEX_NO_INDEX) {
        const char *sd = dex_type_desc(d, cd->superclass_idx);
        if (sd && strcmp(sd, "Ljava/lang/Object;") != 0) {
            char base[256];
            if (stem_of(sd, base, sizeof(base))) {
                snprintf(out, cap, "%s_%s", (flags & DEX_ACC_ABSTRACT) ? "Abstract" : "Sub",
                         base);
                return 1;
            }
        }
    }

    if (cd->interfaces_off) {
        uint32_t n = 0;
        memcpy(&n, d->base + cd->interfaces_off, 4);
        if (n == 1) {
            uint16_t ti;
            memcpy(&ti, d->base + cd->interfaces_off + 4, 2);
            char base[256];
            if (stem_of(dex_type_desc(d, ti), base, sizeof(base))) {
                snprintf(out, cap, "Impl_%s", base);
                return 1;
            }
        }
    }
    return 0;
}

HeurNames *heuristic_build(Dex **dexs, uint32_t count, Arena *arena)
{
    if (!dexs || !count || !arena)
        return NULL;

    uint64_t total = 0;
    for (uint32_t i = 0; i < count; i++)
        total += dexs[i]->hdr.class_defs_size;

    HeurNames *h = arena_zalloc(arena, sizeof(*h));
    if (!h)
        return NULL;
    uint32_t cap = 1024;
    while ((uint64_t)cap < total * 4 && cap < (1u << 23))
        cap <<= 1;
    h->old_desc = arena_zalloc(arena, (size_t)cap * sizeof(char *));
    h->new_name = arena_zalloc(arena, (size_t)cap * sizeof(char *));
    if (!h->old_desc || !h->new_name)
        return NULL;
    h->cap = cap;
    h->mask = cap - 1;

    char name[300], uniq[320];
    for (uint32_t di = 0; di < count; di++) {
        Dex *d = dexs[di];
        for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
            const char *desc = dex_type_desc(d, d->classes[i].class_idx);
            if (!desc)
                continue;
            char self[256];
            simple_of(desc, self, sizeof(self));
            if (!heuristic_is_obfuscated(self))
                continue;
            if (!derive_name(d, i, name, sizeof(name)))
                continue; /* nothing to go on: keep the original name */

            /* Two classes in one package can derive the same stem, and the
             * original short name is unique within the package by construction,
             * so suffixing it keeps every output path distinct. */
            snprintf(uniq, sizeof(uniq), "%s_%s", name, self);

            uint32_t hash = 2166136261u;
            for (const char *q = desc; *q; q++)
                hash = (hash ^ (uint8_t)*q) * 16777619u;
            uint32_t k = hash & h->mask;
            while (h->old_desc[k]) {
                if (!strcmp(h->old_desc[k], desc))
                    break;
                k = (k + 1) & h->mask;
            }
            if (h->old_desc[k])
                continue;
            char *cd = arena_strdup(arena, desc);
            char *cn = arena_strdup(arena, uniq);
            if (!cd || !cn)
                continue;
            h->old_desc[k] = cd;
            h->new_name[k] = cn;
            h->count++;
        }
    }
    return h;
}

const char *heuristic_name(const HeurNames *h, const char *desc)
{
    if (!h || !desc || !h->mask)
        return NULL;
    /* Array types carry the element descriptor behind '[' prefixes. The map is
     * keyed on element descriptors, so a parameter declared as "a[]" has to look
     * up "a" or it keeps the obfuscated spelling while the class itself is
     * renamed. */
    while (*desc == '[')
        desc++;
    if (desc[0] != 'L')
        return NULL;
    uint32_t hash = 2166136261u;
    for (const char *q = desc; *q; q++)
        hash = (hash ^ (uint8_t)*q) * 16777619u;
    uint32_t k = hash & h->mask;
    for (uint32_t step = 0; step <= h->mask; step++, k = (k + 1) & h->mask) {
        if (!h->old_desc[k])
            return NULL;
        if (!strcmp(h->old_desc[k], desc))
            return h->new_name[k];
    }
    return NULL;
}
