#ifndef TACHYON_EMULATE_H
#define TACHYON_EMULATE_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"
#include "dex/dex.h"
#include "ir/opcode.h"

/* A small Dalvik interpreter, used to evaluate string-decryption helpers at
 * decompile time.
 *
 * Commercial obfuscators (DexGuard, DashO, Allatori) replace literals with a
 * call to a generated helper:
 *
 *     String url = ooo.o("8f2a...");
 *
 * The helper is ordinary bytecode with no side effects beyond building the
 * result, so running it on the encrypted literal recovers the plaintext. The
 * interpreter here covers the instruction set those helpers use: moves, array
 * access, arithmetic, string construction, and the few java.lang.String /
 * StringBuilder methods they reach through.
 *
 * Anything outside that subset makes the call return UNKNOWN, never a wrong
 * value -- a decryption helper that cannot be evaluated is left as-is. */

typedef enum {
    EMU_UNKNOWN = 0,
    EMU_INT,
    EMU_CHAR,    /* int produced by int-to-char: appended as a character */
    EMU_LONG,
    EMU_FLOAT,
    EMU_DOUBLE,
    EMU_OBJ,     /* String, StringBuilder, or an array */
    EMU_NULL
} EmuKind;

typedef struct EmuObj EmuObj;

typedef struct {
    EmuKind kind;
    union {
        int32_t i;
        int64_t j;
        float f;
        double d;
        EmuObj *o;
    } v;
} EmuValue;

struct EmuObj {
    /* 'S' = String, 'B' = StringBuilder, '[' = array */
    char tag;
    EmuValue *elems;   /* array elements */
    uint32_t len;
    char *chars;       /* String contents, UTF-8 */
    size_t chars_len;
    size_t chars_cap;
    Arena *arena;
};

/* Result of an evaluation. `kind == EMU_UNKNOWN` means "could not evaluate". */
typedef struct {
    EmuKind kind;
    char *string;   /* set when the call produced a String */
} EmuResult;

/* Evaluates a static method with the given constant arguments. Only String,
 * int and byte[] arguments are supported; pass kind EMU_UNKNOWN to stop.
 * The returned string is allocated from `arena`. */
EmuResult emu_call_static(Dex *d, uint32_t method_idx, const EmuValue *args, uint32_t nargs,
                          Arena *arena, uint32_t max_steps);

/* Convenience: evaluate a static String->String helper. Returns NULL when the
 * helper cannot be evaluated or does not return a string. */
char *emu_decrypt_string(Dex *d, uint32_t method_idx, const char *input, Arena *arena);

/* Builds a String value from a C string. */
EmuValue emu_make_string(Arena *arena, const char *s);

#endif
