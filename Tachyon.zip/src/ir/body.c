#include "ir/body.h"
#include "ir/emulate.h"
#include "ir/ssa.h"
#include "ir/type_infer.h"
#include "ir/body_emit.h"
#include <stdlib.h>

#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "emit/java.h"
#include "emit/java_type.h"
#include "emit/remap.h"
#include "ir/opcode.h"

/*
 * Register-state symbolic execution.
 *
 * Dalvik is a register machine, so a decompiler keeps one expression slot per
 * register and rewrites that slot as instructions execute. Control flow is
 * rendered by walking the CFG in address order: forward branches become `if`
 * blocks, backward branches become `while` loops. Anything the walker cannot
 * place becomes a labelled block plus a goto, which keeps the output compilable.
 */

#define MAX_REG 256

typedef struct {
    Dex *dex;
    CfgMethod *m;
    uint32_t class_def_idx;
    Arena *arena;

    int *reg_written;

    Buf *out;
    int indent;

    /* labels already emitted */
    uint8_t *label_emitted;
    /* blocks already rendered (avoid double emission) */
    uint8_t *block_done;
    /* source line counter for generated labels */
    int label_seq;
    int uses_goto;
    int uses_bodies;
    int in_ctor;        /* true when decompiling <init> */
    int has_this;       /* true for instance methods (receiver in a register) */
    int writing_receiver; /* set while emitting an assignment target */
    /* DEX reuses one register for values of different types. Java cannot, so a
     * register is versioned: every type change bumps the version and gets a new
     * local name. reg_type/reg_version are indexed by register. */
    const char **reg_type;
    /* Versioned view of reg_type, filled by emit_locals and read when an
     * instruction needs the type a register had at its current version. */
    const char ***ver_type;
    int *ver_count;
    int *reg_version;
    int pending_new_reg; /* register holding a not-yet-constructed object */
    uint32_t pending_new_type;
    int pending_new;     /* 1 when the last emitted statement was new-instance */
    /* Register holding a string literal that was just loaded, and the index of
     * that literal. Used to evaluate string-decryption helpers at compile time. */
    int pending_str_reg;
    uint32_t pending_str_idx;
    const char *last_invoke_type; /* return descriptor of the last invoke */
    int unpaired_init;   /* saw an <init> call that could not become `new` */
} Body;

static void emit_indent(Body *b)
{
    for (int i = 0; i < b->indent; i++)
        buf_putc(b->out, '\t');
}

static void emit_line(Body *b, const char *fmt, ...)
{
    emit_indent(b);
    va_list ap;
    va_start(ap, fmt);
    char tmp[2048];
    vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    buf_puts(b->out, tmp);
    buf_putc(b->out, '\n');
}

/* Renders a register as a Java expression. Parameters keep their original
 * register index (pN); locals are named vN. */
static const char *field_value_desc(Dex *dex, uint32_t field_idx);
static const char *invoke_result_desc(Dex *d, uint32_t method_idx);

/* Type written to a register by an instruction, or NULL when it writes none.
 * Shared by the locals pass and the emitter so both agree on versions. */
static const char *insn_written_type(Body *b, Insn *in, uint32_t *reg_out)
{
    Dex *d = b->dex;
    uint8_t op = in->opcode;
    *reg_out = 0xffffffffu;

    if (op >= 0x12 && op <= 0x15) { *reg_out = in->aa; return "I"; }
    if (op >= 0x16 && op <= 0x19) { *reg_out = in->aa; return "J"; }
    if (op == 0x1a || op == 0x1b) { *reg_out = in->aa; return "Ljava/lang/String;"; }
    if (op == 0x1c) { *reg_out = in->aa; return "Ljava/lang/Class;"; }
    if (op == 0x22) { *reg_out = in->aa; return dex_type_desc(d, in->idx); }
    if (op == 0x23) { *reg_out = in->a; return "Ljava/lang/Object;"; }
    if (op >= 0x52 && op <= 0x58) { *reg_out = in->a; return field_value_desc(d, in->idx); }
    if (op >= 0x60 && op <= 0x66) { *reg_out = in->aa; return field_value_desc(d, in->idx); }
    if (op >= 0x44 && op <= 0x4a) { *reg_out = in->aa; return "I"; }
    if (op == 0x21) { *reg_out = in->a; return "I"; }
    if (op == 0x20) { *reg_out = in->a; return "Z"; }
    if (op >= OP_IF_EQ && op <= OP_IF_LEZ) return NULL;
    if (insn_is_binop(op)) { *reg_out = in->aa; return insn_arith_type(op); }
    if (op >= 0xb0 && op <= 0xcf) { *reg_out = in->a; return insn_arith_type(op); }
    if (op >= 0xd0 && op <= 0xe2) { *reg_out = in->a; return "I"; }
    if (insn_is_unop(op)) { *reg_out = in->a; return insn_arith_type(op); }
    if ((op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) ||
        (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE) ||
        (op >= OP_INVOKE_STATIC && op <= OP_INVOKE_INTERFACE) ||
        op == OP_INVOKE_DIRECT || op == OP_INVOKE_DIRECT_RANGE ||
        op == OP_INVOKE_SUPER || op == OP_INVOKE_SUPER_RANGE) {
        /* An invoke does not name a destination register: the result lands in
         * the register of the move-result that follows it. */
        return NULL;
    }
    if (op == 0x0a || op == 0x0b || op == 0x0c)
        return NULL; /* version bumped when the preceding invoke is processed */
    if (op == 0x01 || op == 0x02 || op == 0x03 || op == 0x07 ||
        op == 0x08 || op == 0x09 || op == 0x04 || op == 0x05 || op == 0x06) {
        *reg_out = (op <= 0x03) ? in->a : (op <= 0x06 ? in->a : in->a);
        return NULL; /* handled by the move case which copies the source type */
    }
    return NULL;
}

/* True when the instruction's destination register is not also a source. */
/* True when the instruction reads `reg` as an operand (not as its destination). */
static int insn_reads_reg(Body *b, Insn *in, uint32_t reg)
{
    uint8_t op = in->opcode;
    /* iget/iput family: vA is the destination or value, vB the receiver. */
    if ((op >= 0x52 && op <= 0x58) || (op >= 0x59 && op <= 0x5f))
        return in->b == reg;
    /* aget family: vAA dest, vBB array, vCC index. */
    if (op >= 0x44 && op <= 0x4a)
        return in->regs[0] == reg || in->regs[1] == reg;
    /* move family: vA dst, vB src. */
    if (op <= 0x09)
        return in->b == reg;
    /* binops (12x/23x) read their source registers. */
    if (insn_is_binop(op) || (op >= 0xb0 && op <= 0xcf))
        return in->regs[0] == reg || in->regs[1] == reg;
    if (insn_is_unop(op))
        return in->regs[0] == reg;
    /* invoke: every operand register is read. */
    if ((op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) ||
        op == OP_INVOKE_STATIC || op == OP_INVOKE_DIRECT || op == OP_INVOKE_SUPER ||
        (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE)) {
        for (uint32_t i = 0; i < in->reg_count; i++)
            if (in->regs[i] == reg)
                return 1;
        return 0;
    }
    (void)b;
    return 0;
}

static int wreg_is_pure_write(uint8_t op)
{
    if (op >= 0x12 && op <= 0x1c) /* const family incl. const-string/class */
        return 1;
    if (op >= 0x52 && op <= 0x58) /* iget family */
        return 1;
    if (op >= 0x60 && op <= 0x66) /* sget family */
        return 1;
    if (op >= 0x44 && op <= 0x4a) /* aget family */
        return 1;
    if (op == 0x22 || op == 0x23) /* new-instance / new-array */
        return 1;
    if (op == 0x21 || op == 0x20) /* array-length / instance-of */
        return 1;
    return 0;
}

/* Unified write-site resolution: returns the register an instruction writes and
 * the descriptor of the value, including the invoke→move-result pairing. */
static const char *insn_write_site(Body *b, Insn *in, Insn *next, uint32_t *reg_out)
{
    *reg_out = 0xffffffffu;
    const char *t = insn_written_type(b, in, reg_out);
    if (t)
        return t;

    /* invoke + move-result: the result lands in the move-result register.
     * A constructor returns void, so skipping it is not just an optimisation:
     * `new X()` followed by `X.<init>` leaves the object in the register, and
     * treating the void result as a write would erase that type and make every
     * later use of the object render as an int. */
    if (next && (in->opcode >= OP_INVOKE_VIRTUAL && in->opcode <= OP_INVOKE_INTERFACE) &&
        (next->opcode == OP_MOVE_RESULT || next->opcode == OP_MOVE_RESULT_WIDE ||
         next->opcode == OP_MOVE_RESULT_OBJECT)) {
        const char *name = dex_method_name(b->dex, in->idx);
        if (name && !strcmp(name, "<init>"))
            return NULL;
        const char *rt = invoke_result_desc(b->dex, in->idx);
        if (rt && strcmp(rt, "V")) {
            *reg_out = next->aa;
            return rt;
        }
    }
    return NULL;
}

/* Called before a register is written with a value of type `desc`. When the
 * register already held a different type, bump its version so the new value
 * gets a fresh local instead of reassigning a variable of the wrong type. */
static void reg_begin_write(Body *b, uint32_t reg, const char *desc)
{
    if (!b->reg_type || reg >= MAX_REG || !desc)
        return;
    uint32_t ins = b->m->code ? b->m->code->ins_size : 0;
    uint32_t regs = b->m->code ? b->m->code->registers_size : 0;
    uint32_t param_base = regs - ins;

    const char *prev = b->reg_type[reg];
    int is_param_slot = (ins && reg >= param_base);

    if (prev && strcmp(prev, desc)) {
        b->reg_version[reg]++;
    } else if (!prev && is_param_slot) {
        /* First overwrite of a parameter register: the parameter value is gone,
         * so give the new value its own local. */
        b->reg_version[reg]++;
    }
    b->reg_type[reg] = desc;
    if (b->ver_type && b->ver_count && reg < MAX_REG &&
        b->reg_version[reg] < 64 && b->ver_count[reg] <= b->reg_version[reg]) {
        b->ver_type[reg][b->reg_version[reg]] = desc;
        b->ver_count[reg] = b->reg_version[reg] + 1;
    }
}

/* Current Java name for a register, taking versioning into account. */
/* True when `reg` is the receiver slot. Java has no writable form of `this`, so
 * any store into it must be dropped rather than emitted. */
static int reg_is_receiver(Body *b, uint32_t reg)
{
    if (!b->has_this || !b->m->code)
        return 0;
    uint32_t ins = b->m->code->ins_size;
    uint32_t regs = b->m->code->registers_size;
    if (ins < 1 || regs < ins)
        return 0;
    return reg == regs - ins;
}

static void reg_name(Body *b, uint32_t reg, char *out, size_t cap)
{
    uint32_t ins = b->m->code ? b->m->code->ins_size : 0;
    uint32_t regs = b->m->code ? b->m->code->registers_size : 0;
    uint32_t param_base = regs - ins;

    int v = (b->reg_version && reg < MAX_REG) ? b->reg_version[reg] : 0;

    /* A parameter register keeps its parameter name only until something
     * overwrites it; after that it is an ordinary versioned local. regs and ins
     * are always consistent here, so a register below param_base is a local. */
    if (b->has_this && ins && regs >= ins && reg == param_base && v == 0 &&
        !b->writing_receiver) {
        snprintf(out, cap, "this");
        return;
    }
    if (ins && regs >= ins && reg >= param_base && v == 0) {
        uint32_t slot = reg - param_base;
        if (b->has_this && slot > 0)
            slot--;
        snprintf(out, cap, "p%u", slot);
        return;
    }
    if (v > 0)
        snprintf(out, cap, "v%u_%d", reg, v);
    else
        snprintf(out, cap, "v%u", reg);
}

/* True when a write to this register would target the receiver, which Java
 * forbids assigning to. */
static int reg_is_this(Body *b, uint32_t reg)
{
    if (!b->has_this || !b->m->code)
        return 0;
    uint32_t ins = b->m->code->ins_size;
    uint32_t regs = b->m->code->registers_size;
    return ins >= 1 && regs >= ins && reg == regs - ins;
}

static void render_reg(Body *b, uint32_t reg)
{
    uint32_t ins = b->m->code ? b->m->code->ins_size : 0;
    uint32_t regs = b->m->code ? b->m->code->registers_size : 0;
    uint32_t param_base = regs - ins;

    /* The receiver register holds `this`. It sits at param_base in every
     * instance method, not just constructors; static methods have no receiver
     * so the caller sets has_this accordingly. */
    /* ins_size counts the receiver for instance methods, so param_base is
     * exactly where `this` lives. A local register can never reach it. */
    if (b->has_this && ins >= 1 && regs >= ins && reg == param_base) {
        /* Java has no writable form of `this`. An assignment to the receiver
         * register means the original code copied an object into the `this` slot
         * for a later virtual call; that shape cannot be expressed, so the write
         * is emitted to a scratch name that the enclosing statement discards. */
        if (b->writing_receiver) {
            /* Writing the receiver slot means the code reuses it as a scratch
             * variable. Address it by its ordinary local name so the declaration
             * emitted for that version matches. */
            char nm[32];
            reg_name(b, reg, nm, sizeof(nm));
            buf_puts(b->out, nm);
        } else {
            buf_puts(b->out, "this");
        }
        return;
    }
    {
        char nm[32];
        reg_name(b, reg, nm, sizeof(nm));
        buf_puts(b->out, nm);
    }
}

/* R8 emits synthetic names containing '-' (e.g. "List$-CC"); those bytes are
 * illegal in a Java identifier, so fold them to '_' the same way the class file
 * path does. */
static void sanitize_name(const char *in, char *out, size_t cap)
{
    size_t o = 0;
    for (size_t i = 0; in[i] && o + 1 < cap; i++) {
        unsigned char c = (unsigned char)in[i];
        int ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                 (c >= '0' && c <= '9') || c == '_' || c == '$' || c == '.';
        out[o++] = ok ? (char)c : '_';
    }
    out[o] = '\0';
}

static void render_type(Body *b, uint32_t type_idx)
{
    char buf[512], clean[512];
    remap_java_type(dex_type_desc(b->dex, type_idx), buf, sizeof(buf));
    sanitize_name(buf, clean, sizeof(clean));
    buf_puts(b->out, clean);
}

/* ---------------------------------------------------------------- */
/* constant rendering                                                */
/* ---------------------------------------------------------------- */

static void render_literal_int(Body *b, int32_t v)
{
    if (v == (int32_t)0x80000000)
        buf_printf(b->out, "Integer.MIN_VALUE");
    else
        buf_printf(b->out, "%d", v);
}

static void render_literal_long(Body *b, int64_t v)
{
    if (v == INT64_MIN)
        buf_printf(b->out, "Long.MIN_VALUE");
    else
        buf_printf(b->out, "%lldL", (long long)v);
}

static void render_literal_float(Body *b, uint32_t bits)
{
    float f;
    memcpy(&f, &bits, 4);
    if (f != f)
        buf_printf(b->out, "Float.NaN");
    else if (f == 0.0f && (bits >> 31))
        buf_printf(b->out, "-0.0f");
    else if (f > 3.402823e38f || f < -3.402823e38f)
        buf_printf(b->out, "Float.POSITIVE_INFINITY");
    else
        buf_printf(b->out, "%gf", (double)f);
}

/* ---------------------------------------------------------------- */
/* instruction rendering                                             */
/* ---------------------------------------------------------------- */

/* Descriptor of the value produced by an iget/sget variant. */
static const char *field_value_desc(Dex *dex, uint32_t field_idx)
{
    if (field_idx >= dex->hdr.field_ids_size)
        return NULL;
    return dex_type_desc(dex, dex->fields[field_idx].type_idx);
}

static void render_field_ref(Body *b, uint32_t field_idx, int is_static, int is_get)
{
    if (field_idx >= b->dex->hdr.field_ids_size) {
        buf_puts(b->out, "/*bad-field*/");
        return;
    }
    const DexFieldId *f = &b->dex->fields[field_idx];
    const char *name = dex_field_name(b->dex, field_idx);

    if (is_static) {
        buf_puts(b->out, dex_type_name(b->dex, f->class_idx));
        buf_printf(b->out, ".%s", name);
    } else {
        buf_puts(b->out, name);
    }
    (void)is_get;
}

static int render_invoke(Body *b, const Insn *in)
{
    Dex *d = b->dex;
    uint32_t mi = in->idx;
    if (mi >= d->hdr.method_ids_size) {
        buf_puts(b->out, "/*bad-method*/");
        return 1;
    }
    const DexMethodId *mm = &d->methods[mi];
    const char *raw_name = dex_method_name(d, mi);
    char clean_name[512];
    const char *name = raw_name;
    if (raw_name && raw_name[0] != '<') {
        sanitize_name(raw_name, clean_name, sizeof(clean_name));
        name = clean_name;
    }

    int is_static = (in->opcode == OP_INVOKE_STATIC || in->opcode == OP_INVOKE_STATIC_RANGE);
    int is_direct = (in->opcode == OP_INVOKE_DIRECT || in->opcode == OP_INVOKE_DIRECT_RANGE);

    uint32_t first = 0;
    if (!is_static && in->reg_count > 0)
        first = 1; /* first register is the receiver */

    /* Java has no way to call a class initialiser: <clinit> runs automatically
     * on first use. R8 emits explicit invoke-static calls to it, which must be
     * dropped rather than rendered as a (syntactically invalid) method call. */
    if (!strcmp(name, "<clinit>"))
        return 0; /* Java cannot call a class initialiser explicitly. */

    /* String-decryption helper: a literal passed straight to a static method that
     * returns String. Evaluating it here turns the call into its plaintext
     * result, which is what the original source contained. */
    if (is_static && b->pending_str_reg >= 0 && in->reg_count == 1) {
        const char *lit = dex_string(b->dex, b->pending_str_idx);
        const char *rtd = invoke_result_desc(b->dex, in->idx);
        if (lit && rtd && !strcmp(rtd, "Ljava/lang/String;")) {
            Arena *ba = java_body_arena();
            char *plain = ba ? emu_decrypt_string(b->dex, in->idx, lit, ba) : NULL;
            if (plain) {
                char esc[1024];
                java_escape_string(plain, esc, sizeof(esc));
                if (b->writing_receiver == 0) {
                    /* Caller already emitted "vX = " when it saw a String return. */
                }
                buf_printf(b->out, "\"%s\" /* decrypted */", esc);
                b->pending_str_reg = -1;
                return 1;
            }
        }
        b->pending_str_reg = -1;
    }

    if (!strcmp(name, "<init>") && !b->in_ctor) {
        /* An unpaired <init> call (allocation happened in another block or the
         * pairing was broken) cannot be written as a method call in Java. Emit a
         * constructor invocation on a fresh instance instead. */
        b->unpaired_init = 1;
        buf_puts(b->out, "new ");
        render_type(b, mm->class_idx);
        buf_putc(b->out, '(');
        for (uint32_t i = 1; i < in->reg_count; i++) {
            if (i > 1)
                buf_puts(b->out, ", ");
            render_reg(b, in->regs[i]);
        }
        buf_putc(b->out, ')');
        return 1;
    }

    if (!strcmp(name, "<init>") && b->pending_new &&
        (int)in->regs[0] == b->pending_new_reg) {
        /* The object allocated by the preceding new-instance is being
         * constructed: fold both into one Java expression. */
        b->pending_new = 0;
        buf_puts(b->out, "new ");
        render_type(b, b->pending_new_type);
        buf_putc(b->out, '(');
        for (uint32_t i = 1; i < in->reg_count; i++) {
            if (i > 1)
                buf_puts(b->out, ", ");
            render_reg(b, in->regs[i]);
        }
        buf_putc(b->out, ')');
        return 1;
    }

    if (!strcmp(name, "<init>") && b->in_ctor) {
        /* The chaining call is emitted once at the top of the constructor, so the
         * instruction itself renders as nothing. */
        return 1;
    }

    {
        if (!is_static) {
            if (in->reg_count > 0)
                render_reg(b, in->regs[0]);
            else
                buf_puts(b->out, "this");
            buf_putc(b->out, '.');
        } else {
            /* Through remap_java_type, not dex_type_name: the latter drops the
             * reserved-word suffix that the class declaration carries. */
            render_type(b, mm->class_idx);
            buf_putc(b->out, '.');
        }
        buf_puts(b->out, name);
        buf_putc(b->out, '(');
    }

    for (uint32_t i = first; i < in->reg_count; i++) {
        if (i > first)
            buf_puts(b->out, ", ");
        render_reg(b, in->regs[i]);
    }
    buf_putc(b->out, ')');
    (void)is_direct;
    return 1;
}

/* Returns the DEX descriptor of the value an invoke produces. */
static const char *invoke_result_desc(Dex *d, uint32_t method_idx)
{
    if (method_idx >= d->hdr.method_ids_size)
        return NULL;
    uint32_t proto = d->methods[method_idx].proto_idx;
    if (proto >= d->hdr.proto_ids_size)
        return NULL;
    return dex_type_desc(d, d->protos[proto].return_type_idx);
}

/* ---------------------------------------------------------------- */
/* local variable declarations                                       */
/* ---------------------------------------------------------------- */

/* Infers a Java type for each local register by looking at how it is first
 * written, then emits declarations at the top of the body. Registers that are
 * only ever written from primitives stay int; object registers get the declared
 * type where one can be recovered, otherwise Object. */

/* Emits the constructor chaining call. The parent's constructor is looked up so
 * that the argument list has the right arity; a bare super() does not compile
 * when the parent only declares parameterised constructors. */
static void emit_ctor_chain(Body *b, uint32_t class_def_idx)
{
    Dex *d = b->dex;
    const DexClassDef *cd = &d->classes[class_def_idx];
    /* The parent may live in a sibling dex, where this file has no class_def
     * entry. Fall back to the global index so the chain call is generated from
     * the parent's real signature instead of a wild read. */
    /* An enum's superclass is java.lang.Enum, and the compiler writes that call
     * itself; emitting one here is a hard error. */
    if (cd->superclass_idx != DEX_NO_INDEX) {
        const char *sd = dex_type_desc(d, cd->superclass_idx);
        if (getenv("TACHYON_DEBUG_EC") && sd && strstr(sd, "Enum"))
            fprintf(stderr, "[ec] enum parent, skipping super\n");
        if (sd && !strcmp(sd, "Ljava/lang/Enum;"))
            return;
    }

    Dex *powner = d;
    uint32_t pdef = dex_class_def_of_type(d, cd->superclass_idx);
    if (pdef == DEX_NO_INDEX) {
        uint32_t od = java_lookup_dex(cd->superclass_idx, d, &powner);
        pdef = od;
    }
    uint32_t proto = DEX_NO_INDEX;
    if (pdef != DEX_NO_INDEX && pdef < powner->hdr.class_defs_size) {
        const DexClassData *pdata = dex_class_data(powner, pdef);
        if (pdata) {
            for (uint32_t i = 0; i < pdata->direct_count; i++) {
                uint32_t mi = pdata->direct_methods[i].method_idx;
                if (mi < powner->hdr.method_ids_size &&
                    !strcmp(dex_method_name(powner, mi), "<init>")) {
                    proto = powner->methods[mi].proto_idx;
                    break;
                }
            }
        }
    }

    if (proto == DEX_NO_INDEX || proto >= powner->hdr.proto_ids_size) {
        emit_line(b, "super();");
        return;
    }

    DexParamList *pl = dex_proto_params(powner, proto);
    if (getenv("TACHYON_DEBUG_SUPER"))
        fprintf(stderr, "[super] class=%u proto=%u nparams=%u\n", class_def_idx, proto,
                pl ? pl->param_count : 0);
    emit_indent(b);
    buf_puts(b->out, "super(");
    for (uint32_t i = 0; pl && i < pl->param_count; i++) {
        if (i)
            buf_puts(b->out, ", ");
        char pt[512];
        remap_java_type(dex_type_desc(powner, pl->type_idx[i]), pt, sizeof(pt));
        /* Cast every argument: the parent may have several constructors and a
         * bare null (or 0) would make the call ambiguous. */
        buf_printf(b->out, "(%s) %s", pt, java_default_value(pt));
    }
    buf_puts(b->out, ");\n");
}

static void seed_param_types(Body *b, Dex *dex, uint32_t class_def_idx,
                             const DexEncodedMethod *enc)
{
    if (!b->reg_type || !b->m->code)
        return;
    uint32_t ins = b->m->code->ins_size;
    uint32_t regs = b->m->code->registers_size;
    uint32_t base = regs >= ins ? regs - ins : 0;
    uint32_t slot = 0;
    for (uint32_t r = base; r < regs && r < MAX_REG; r++) {
        const char *ty = NULL;
        if (b->has_this && slot == 0) {
            if (class_def_idx < dex->hdr.class_defs_size)
                ty = dex_type_desc(dex, dex->classes[class_def_idx].class_idx);
        } else {
            uint32_t pi = b->has_this ? slot - 1 : slot;
            DexParamList *pl = dex_proto_params(dex, dex->methods[enc->method_idx].proto_idx);
            if (pl && pi < pl->param_count)
                ty = dex_type_desc(dex, pl->type_idx[pi]);
        }
        if (ty)
            b->reg_type[r] = ty;
        slot++;
    }
}

static void emit_locals(Body *b)
{
    CfgMethod *m = b->m;
    Dex *d = b->dex;
    uint32_t regs = m->code->registers_size;
    uint32_t ins = m->code->ins_size;
    uint32_t param_base = regs - ins;
    if (regs > MAX_REG)
        regs = MAX_REG;

    const char **types = arena_zalloc(b->arena, regs * sizeof(char *));
    if (!types)
        return;

    for (uint32_t i = 0; i < m->block_count; i++) {
        CfgBlock *blk = &m->blocks[i];
        for (uint32_t k = 0; k < blk->insn_count; k++) {
            Insn *in = &m->insns[blk->insn_start + k];
            uint8_t op = in->opcode;
            uint32_t dst = 0xffffffffu;
            const char *t = NULL;

            if (op == 0x01 || op == 0x07) { /* move / move-object */
                dst = in->a;
                uint32_t src = in->b;
                if ((int)src < (int)param_base && types[src])
                    t = types[src];
            } else if (op >= 0x12 && op <= 0x19) {
                dst = in->aa;
                t = (op >= 0x16) ? "J" : "I";
            } else if (op == 0x1a || op == 0x1b) {
                dst = in->aa;
                t = "Ljava/lang/String;";
            } else if (op == 0x1c) {
                dst = in->aa;
                t = "Ljava/lang/Class;";
            } else if (op == 0x22) {
                dst = in->aa;
                t = dex_type_desc(d, in->idx);
            } else if (op == 0x23) {
                dst = in->a;
                t = "Ljava/lang/Object;";
            } else if (op >= 0x52 && op <= 0x58) {
                dst = in->a;
                t = field_value_desc(d, in->idx);
            } else if (op >= 0x60 && op <= 0x66) {
                dst = in->aa;
                t = field_value_desc(d, in->idx);
            } else if (op >= 0x44 && op <= 0x4a) {
                dst = in->aa;
                t = "I";
            } else if (op == 0x21) {
                dst = in->a;
                t = "I";
            } else if (op == 0x20) {
                dst = in->a;
                t = "Z";
            } else if (insn_is_binop(op)) {
                dst = in->aa;
                t = insn_arith_type(op);
            } else if (op >= 0xb0 && op <= 0xcf) {
                dst = in->a;
                const char *at = insn_arith_type(op);
                t = at ? at : "I";
            } else if (op >= 0xd0 && op <= 0xe2) {
                dst = in->a;
                t = "I";
            } else if (insn_is_unop(op)) {
                dst = in->a;
                const char *at = insn_arith_type(op);
                t = at ? at : "I";
            } else if (op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) {
                dst = in->aa;
                t = invoke_result_desc(d, in->idx);
                if (t && !strcmp(t, "V"))
                    t = NULL;
            } else if (op == 0x0a || op == 0x0b || op == 0x0c) {
                dst = in->aa;
                t = "I";
            }

            if (dst != 0xffffffffu && dst < regs && !types[dst] && t)
                types[dst] = t;
        }
    }

    /* Replay the writes in address order to discover every register version and
     * its type, then declare one local per version. */
    /* These tables are heap-allocated: several KB of stack per method would
     * overflow with deeply nested bodies and many worker threads. */
    const char ***ver_type = arena_zalloc(b->arena, MAX_REG * sizeof(char **));
    int *ver_count = arena_zalloc(b->arena, MAX_REG * sizeof(int));
    const char **cur = arena_zalloc(b->arena, MAX_REG * sizeof(char *));
    /* Publish for the renderer: an instruction that needs the type a register
     * had at its current version reads these instead of reg_type, which only
     * remembers the last write. Only the body pass reads them; stub emission
     * (the default) gains nothing from the extra indirection. */
    if (b->uses_bodies) {
        b->ver_type = ver_type;
        b->ver_count = ver_count;
    }
    if (!ver_type || !ver_count || !cur)
        return;
    for (uint32_t r = 0; r < MAX_REG; r++) {
        ver_type[r] = arena_zalloc(b->arena, 64 * sizeof(char *));
        ver_count[r] = 0;
    }

    /* Parameter slots start with the type they arrive with. A parameter that is
     * never overwritten gets no entry from the scan below at all, so its
     * declaration would be missing and every use would render as an int. */
    for (uint32_t r = 0; r < regs && r < MAX_REG; r++) {
        if (!ins || r < param_base)
            continue;
        const char *ty = b->reg_type ? b->reg_type[r] : NULL;
        if (!ty)
            continue;
        ver_type[r][ver_count[r]++] = ty;
        cur[r] = ty;
    }

    for (uint32_t i = 0; i < m->block_count; i++) {
        CfgBlock *blk = &m->blocks[i];
        for (uint32_t k = 0; k < blk->insn_count; k++) {
            Insn *in = &m->insns[blk->insn_start + k];
            Insn *next_in = (k + 1 < blk->insn_count) ? &m->insns[blk->insn_start + k + 1] : NULL;
            uint32_t dst = 0xffffffffu;
            const char *t = insn_write_site(b, in, next_in, &dst);

            if (dst == 0xffffffffu || dst >= regs || !t)
                continue;

            int is_param_slot = (ins && dst >= param_base);
            int bump = 0;
            if (cur[dst] && strcmp(cur[dst], t))
                bump = 1;
            else if (!cur[dst] && is_param_slot)
                bump = 1; /* parameter slot overwritten: needs its own local */

            if (!bump) {
                if (!cur[dst] && ver_count[dst] == 0) {
                    ver_type[dst][ver_count[dst]++] = t;
                    cur[dst] = t;
                }
                continue;
            }
            if (ver_count[dst] < 64)
                ver_type[dst][ver_count[dst]++] = t;
            cur[dst] = t;
        }
    }

    int declared = 0;
    uint32_t decl_from = 0;
    (void)decl_from;
    for (uint32_t r = 0; r < regs && r < MAX_REG; r++) {
        int is_param = (ins && r >= param_base);
        for (int v = 0; v < ver_count[r]; v++) {
            const char *ty = ver_type[r][v];
            if (!ty || !strcmp(ty, "V"))
                continue;
            /* Version 0 of a parameter slot is the parameter itself, rendered as
             * pN. Declaring a local for it would shadow the parameter, and the
             * next version would then collide with that local's name. */
            if (is_param && v == 0)
                continue;
            /* Must match reg_name exactly: version 0 of a parameter slot is the
             * parameter itself (rendered as pN, declared nowhere), so the first
             * local version is v{r}_1. */
            int name_ver = v;
            char jt[512];
            remap_java_type(ty, jt, sizeof(jt));
            emit_indent(b);
            if (name_ver == 0)
                buf_printf(b->out, "%s v%u = %s;\n", jt, r, java_default_value(jt));
            else
                buf_printf(b->out, "%s v%u_%d = %s;\n", jt, r, name_ver, java_default_value(jt));
            declared++;
        }
    }
    if (declared)
        emit_line(b, "");
}

/* ---------------------------------------------------------------- */
/* block walker                                                      */
/* ---------------------------------------------------------------- */

typedef enum { FLOW_FALL, FLOW_GOTO, FLOW_RET, FLOW_THROW, FLOW_BRANCH } Flow;

static Flow walk_block(Body *b, uint32_t bid);

/* Emits `if (cond) {` style block for a two-target branch. Returns the address
 * of the fall-through block, or 0 when not applicable. */
static uint32_t block_by_addr(Body *b, uint32_t addr)
{
    if (addr >= b->m->code->insns_size)
        return 0xffffffffu;
    return b->m->addr_to_block[addr];
}

/* Java has no goto. Irreducible control flow is expressed as a small dispatch
 * loop: a state variable selects the block, and each transfer assigns the next
 * state. This keeps the method compilable without inventing structure that the
 * bytecode does not have. */
static void emit_goto(Body *b, uint32_t target)
{
    b->uses_goto = 1;
    emit_line(b, "state = %u; continue dispatch;", target);
}

static Flow walk_block(Body *b, uint32_t bid)
{
    if (bid >= b->m->block_count || b->block_done[bid])
        return FLOW_FALL;
    b->block_done[bid] = 1;

    CfgBlock *blk = &b->m->blocks[bid];
    for (uint32_t i = 0; i < blk->insn_count; i++) {
        uint32_t ii = blk->insn_start + i;
        Insn *in = &b->m->insns[ii];
        uint8_t op = in->opcode;

        /* The version bump for this instruction's destination happens after it
         * is rendered, because reads inside the instruction still see the old
         * value (e.g. the invoke argument list). */
        uint32_t wr_reg = 0xffffffffu;
        const char *wr_type = NULL;
        int wr_before = 0;
        {
            Insn *next_in = (i + 1 < blk->insn_count)
                                ? &b->m->insns[blk->insn_start + i + 1]
                                : NULL;
            wr_type = insn_write_site(b, in, next_in, &wr_reg);
            /* When the destination is reached through a following move-result,
             * the bump must precede rendering so the assignment target is the
             * new version, not the parameter being overwritten. */
            if (wr_reg != 0xffffffffu && next_in &&
                (next_in->opcode == OP_MOVE_RESULT || next_in->opcode == OP_MOVE_RESULT_WIDE ||
                 next_in->opcode == OP_MOVE_RESULT_OBJECT) &&
                (in->opcode >= OP_INVOKE_VIRTUAL && in->opcode <= OP_INVOKE_INTERFACE))
                wr_before = 1;

            /* Instructions that only write their destination (constants, field
             * and array loads, allocations) do not read it, so the new version
             * can be installed before rendering. Read-modify-write forms keep the
             * old version until after. */
            uint8_t wop = in->opcode;
            /* A field load reads its receiver, so the new version must not be
             * installed before the instruction renders: `iget v0, v0` would then
             * read the receiver as the field's type. It is handled explicitly in
             * the iget case instead. */
            if (wreg_is_pure_write(wop) && !(wop >= 0x52 && wop <= 0x58))
                wr_before = 1;
        }
        /* Installing the new version early is only safe when the destination is
         * not also read by this instruction. `iget v0, v0` reads the receiver in
         * the same register it writes, so bumping first would render the source
         * with the result's type and produce `v0_2 = v0_2.field`. */
        /* When the destination is also read by this instruction (`iget v0, v0`),
         * the source must render with the old version, so the bump is deferred
         * until after the instruction is emitted rather than skipped: skipping it
         * would write the result into a variable of the wrong type. */
        if (wr_before && wr_reg != 0xffffffffu && wr_type)
            reg_begin_write(b, wr_reg, wr_type);

        switch (op) {
        case OP_NOP:
            break;

        case OP_MOVE:
        case OP_MOVE_FROM16:
        case OP_MOVE_16:
        case OP_MOVE_WIDE:
        case OP_MOVE_WIDE_FROM16:
        case OP_MOVE_WIDE_16:
        case OP_MOVE_OBJECT:
        case OP_MOVE_OBJECT_FROM16:
        case OP_MOVE_OBJECT_16: {
            uint32_t dst = in->aa;
            uint32_t src = in->first_reg;
            if (reg_is_receiver(b, dst))
                break;
            emit_indent(b);
            render_reg(b, dst);
            buf_puts(b->out, " = ");
            render_reg(b, src);
            buf_puts(b->out, ";\n");
            break;
        }

        case OP_CONST_4:
        case OP_CONST_16:
        case OP_CONST:
        case OP_CONST_HIGH16:
            if (reg_is_receiver(b, in->aa))
                break;
            emit_indent(b);
            render_reg(b, in->aa);
            buf_puts(b->out, " = ");
            render_literal_int(b, in->literal);
            buf_puts(b->out, ";\n");
            break;

        case OP_CONST_WIDE_16:
        case OP_CONST_WIDE_32:
        case OP_CONST_WIDE:
        case OP_CONST_WIDE_HIGH16:
            emit_indent(b);
            render_reg(b, in->aa);
            buf_puts(b->out, " = ");
            render_literal_long(b, (int64_t)in->wide_literal);
            buf_puts(b->out, ";\n");
            break;

        case OP_CONST_STRING:
        case OP_CONST_STRING_JUMBO: {
            b->pending_str_reg = (int)in->aa;
            b->pending_str_idx = in->idx;
            char esc[1024];
            java_escape_string(dex_string(b->dex, in->idx), esc, sizeof(esc));
            emit_indent(b);
            render_reg(b, in->aa);
            buf_printf(b->out, " = \"%s\";\n", esc);
            break;
        }

        case OP_CONST_CLASS:
            emit_indent(b);
            render_reg(b, in->aa);
            buf_puts(b->out, " = ");
            render_type(b, in->idx);
            buf_puts(b->out, ".class;\n");
            break;

        case OP_MOVE_RESULT:
        case OP_MOVE_RESULT_WIDE:
        case OP_MOVE_RESULT_OBJECT:
            /* The invoke already produced the value; bind its type to this
             * register so later reads see the right variable. Without this the
             * register keeps the type it had as the receiver or argument, so
             * `int n = s.length()` renders as a String and every later use of the
             * result fails to compile. */
            {
                const char *rt = b->last_invoke_type;
                /* Fall back to the preceding instruction: in the dispatch
                 * rendering the invoke may sit in the previous block. */
                if (!rt && in->addr > 0 && b->m->addr_to_insn &&
                    in->addr <= b->m->code->insns_size) {
                    uint32_t pi = b->m->addr_to_insn[in->addr - 1];
                    if (pi < b->m->code->insns_size) {
                        Insn *p = &b->m->insns[pi];
                        if ((p->opcode >= OP_INVOKE_VIRTUAL && p->opcode <= OP_INVOKE_INTERFACE) ||
                            p->opcode == OP_INVOKE_STATIC || p->opcode == OP_INVOKE_DIRECT ||
                            p->opcode == OP_INVOKE_SUPER)
                            rt = invoke_result_desc(b->dex, p->idx);
                    }
                }
                if (rt && strcmp(rt, "V"))
                    reg_begin_write(b, in->aa, rt);
            }
            b->pending_new = 0;
            break;

        case OP_MOVE_EXCEPTION:
            emit_indent(b);
            render_reg(b, in->aa);
            buf_puts(b->out, " = caughtException;\n");
            break;

        case OP_IGET: case OP_IGET_WIDE: case OP_IGET_OBJECT: case OP_IGET_BOOLEAN:
        case OP_IGET_BYTE: case OP_IGET_CHAR: case OP_IGET_SHORT: {
            /* The receiver renders with the type it has *before* this write.
             * `iget v0, v0` reads the object and writes the field value into the
             * same register, so the destination must become a fresh variable:
             * otherwise an int result is assigned to the object variable. */
            char lhs[64], rhs[64];
            reg_name(b, in->b, rhs, sizeof(rhs));
            const char *fdesc = field_value_desc(b->dex, in->idx);
            if (fdesc)
                reg_begin_write(b, in->a, fdesc);
            reg_name(b, in->a, lhs, sizeof(lhs));
            emit_indent(b);
            buf_puts(b->out, lhs);
            buf_puts(b->out, " = ");
            buf_puts(b->out, rhs);
            buf_putc(b->out, '.');
            render_field_ref(b, in->idx, 0, 1);
            buf_puts(b->out, ";\n");
            break;
        }

        case OP_IPUT: case OP_IPUT_WIDE: case OP_IPUT_OBJECT: case OP_IPUT_BOOLEAN:
        case OP_IPUT_BYTE: case OP_IPUT_CHAR: case OP_IPUT_SHORT:
            emit_indent(b);
            render_reg(b, in->b);
            buf_putc(b->out, '.');
            render_field_ref(b, in->idx, 0, 0);
            buf_puts(b->out, " = ");
            render_reg(b, in->a);
            buf_puts(b->out, ";\n");
            break;

        case OP_SGET: case OP_SGET_WIDE: case OP_SGET_OBJECT: case OP_SGET_BOOLEAN:
        case OP_SGET_BYTE: case OP_SGET_CHAR: case OP_SGET_SHORT:
            emit_indent(b);
            render_reg(b, in->aa);
            buf_puts(b->out, " = ");
            render_field_ref(b, in->idx, 1, 1);
            buf_puts(b->out, ";\n");
            break;

        case OP_SPUT: case OP_SPUT_WIDE: case OP_SPUT_OBJECT: case OP_SPUT_BOOLEAN:
        case OP_SPUT_BYTE: case OP_SPUT_CHAR: case OP_SPUT_SHORT:
            emit_indent(b);
            render_field_ref(b, in->idx, 1, 0);
            buf_puts(b->out, " = ");
            render_reg(b, in->aa);
            buf_puts(b->out, ";\n");
            break;

        case OP_AGET: case OP_AGET_WIDE: case OP_AGET_OBJECT: case OP_AGET_BOOLEAN:
        case OP_AGET_BYTE: case OP_AGET_CHAR: case OP_AGET_SHORT:
            emit_indent(b);
            render_reg(b, in->aa);
            buf_puts(b->out, " = ");
            render_reg(b, in->regs[0]);
            buf_putc(b->out, '[');
            render_reg(b, in->regs[1]);
            buf_puts(b->out, "];\n");
            break;

        case OP_APUT: case OP_APUT_WIDE: case OP_APUT_OBJECT: case OP_APUT_BOOLEAN:
        case OP_APUT_BYTE: case OP_APUT_CHAR: case OP_APUT_SHORT:
            emit_indent(b);
            render_reg(b, in->regs[0]);
            buf_putc(b->out, '[');
            render_reg(b, in->regs[1]);
            buf_puts(b->out, "] = ");
            render_reg(b, in->aa);
            buf_puts(b->out, ";\n");
            break;

        case OP_ARRAY_LENGTH:
            emit_indent(b);
            b->writing_receiver = 1;
            render_reg(b, in->a);
            b->writing_receiver = 0;
            buf_puts(b->out, " = ");
            render_reg(b, in->b);
            buf_puts(b->out, ".length;\n");
            break;

        case OP_NEW_INSTANCE:
            /* Defer: the following invoke-direct <init> folds into `new X(...)`. */
            b->pending_new = 1;
            b->pending_new_reg = (int)in->aa;
            b->pending_new_type = in->idx;
            break;

        case OP_NEW_ARRAY: {
            char array_type[512];
            const char *desc = dex_type_desc(b->dex, in->idx);
            int dims = 0;
            if (desc) {
                while (desc[dims] == '[')
                    dims++;
            }
            if (dims <= 0 || !desc) {
                emit_indent(b);
                render_reg(b, in->a);
                buf_puts(b->out, " = new ");
                render_type(b, in->idx);
                buf_putc(b->out, '[');
                render_reg(b, in->b);
                buf_puts(b->out, "];\n");
                break;
            }
            java_type_of(desc, array_type, sizeof(array_type));
            char *br = strchr(array_type, '[');
            if (br) *br = '\0';
            emit_indent(b);
            render_reg(b, in->a);
            buf_printf(b->out, " = new %s[", array_type);
            render_reg(b, in->b);
            buf_putc(b->out, ']');
            for (int i = 1; i < dims; i++)
                buf_puts(b->out, "[]");
            buf_puts(b->out, ";\n");
            break;
        }

        case OP_CHECK_CAST:
            /* A cast to the erased type would need a temporary; the erased type
             * already matches, so the check is elided. */
            break;

        case OP_INSTANCE_OF:
            emit_indent(b);
            b->writing_receiver = 1;
            render_reg(b, in->a);
            b->writing_receiver = 0;
            buf_puts(b->out, " = ");
            render_reg(b, in->b);
            buf_puts(b->out, " instanceof ");
            render_type(b, in->idx);
            buf_puts(b->out, ";\n");
            break;

        case OP_THROW:
            emit_indent(b);
            buf_puts(b->out, "throw ");
            render_reg(b, in->aa);
            buf_puts(b->out, ";\n");
            return FLOW_THROW;

        case OP_RETURN_VOID: {
            /* The trailing return of a void method is implicit in Java; emitting
             * it is legal but noisy, so suppress it when it ends the block and
             * nothing follows. */
            uint32_t last_insn = blk->insn_start + blk->insn_count - 1;
            int is_last_in_block = (ii == last_insn);
            int is_last_block = (bid + 1 >= b->m->block_count);
            if (!(is_last_in_block && is_last_block)) {
                emit_indent(b);
                buf_puts(b->out, "return;\n");
            }
            return FLOW_RET;
        }

        case OP_RETURN:
        case OP_RETURN_WIDE:
        case OP_RETURN_OBJECT:
            emit_indent(b);
            buf_puts(b->out, "return ");
            render_reg(b, in->aa);
            buf_puts(b->out, ";\n");
            return FLOW_RET;

        case OP_MONITOR_ENTER:
            emit_indent(b);
            buf_puts(b->out, "synchronized (");
            render_reg(b, in->aa);
            buf_puts(b->out, ") { /* body elided */ }\n");
            break;

        case OP_MONITOR_EXIT:
            break;

        case OP_GOTO:
        case OP_GOTO_16:
        case OP_GOTO_32: {
            uint32_t tgt = block_by_addr(b, (uint32_t)in->target);
            if (tgt == 0xffffffffu)
                return FLOW_FALL;
            /* A backward edge that closes a loop body becomes a `continue` when
             * the target is the loop header we are currently inside. */
            if (in->target <= (int32_t)in->addr && b->m->blocks[tgt].is_loop_header &&
                tgt == bid) {
                emit_line(b, "continue;");
                return FLOW_GOTO;
            }
            emit_goto(b, tgt);
            return FLOW_GOTO;
        }

        case OP_IF_EQ: case OP_IF_NE: case OP_IF_LT: case OP_IF_GE:
        case OP_IF_GT: case OP_IF_LE: {
            static const char *ops[] = { "==", "!=", "<", ">=", ">", "<=" };
            const char *o = ops[op - OP_IF_EQ];
            uint32_t tgt = block_by_addr(b, (uint32_t)in->target);
            uint32_t fall = (bid + 1 < b->m->block_count) ? bid + 1 : 0xffffffffu;
            if (tgt == 0xffffffffu || fall == 0xffffffffu) {
                emit_indent(b);
                buf_puts(b->out, "if (");
                render_reg(b, in->a);
                buf_printf(b->out, " %s ", o);
                render_reg(b, in->b);
                buf_printf(b->out, ") break L%u;\n", tgt);
                return FLOW_BRANCH;
            }
            /* Forward branch: render as if(...) { <target> } then continue. */
            emit_indent(b);
            buf_puts(b->out, "if (");
            render_reg(b, in->a);
            buf_printf(b->out, " %s ", o);
            render_reg(b, in->b);
            buf_puts(b->out, ") {\n");
            b->indent++;
            if (in->target > (int32_t)in->addr) {
                walk_block(b, tgt);
            } else {
                emit_goto(b, tgt);
            }
            b->indent--;
            emit_line(b, "}");
            return FLOW_FALL;
        }

        case OP_IF_EQZ: case OP_IF_NEZ: case OP_IF_LTZ: case OP_IF_GEZ:
        case OP_IF_GTZ: case OP_IF_LEZ: {
            static const char *ops[] = { "==", "!=", "<", ">=", ">", "<=" };
            const char *o = ops[op - OP_IF_EQZ];
            /* Only eqz/nez can appear on a reference. An object register compared
             * with 0 is a null check; rendering the literal 0 makes javac reject
             * the comparison. */
            int is_ref = 0;
            if ((op == OP_IF_EQZ || op == OP_IF_NEZ) && in->aa < MAX_REG) {
                /* The type of the register *at its current version* decides the
                 * comparison: reg_type alone is the last type written anywhere,
                 * which is wrong once the register holds several versions. */
                const char *ty = NULL;
                if (b->ver_type && b->ver_count && b->reg_version &&
                    b->reg_version[in->aa] < b->ver_count[in->aa])
                    ty = b->ver_type[in->aa][b->reg_version[in->aa]];
                else if (b->reg_type)
                    ty = b->reg_type[in->aa];
                is_ref = ty && ty[0] == 'L';
            }
            const char *rhs = is_ref ? "null" : "0";
            uint32_t tgt = block_by_addr(b, (uint32_t)in->target);
            uint32_t fall = (bid + 1 < b->m->block_count) ? bid + 1 : 0xffffffffu;
            if (tgt == 0xffffffffu || fall == 0xffffffffu) {
                emit_indent(b);
                buf_puts(b->out, "if (");
                render_reg(b, in->aa);
                buf_printf(b->out, " %s %s) break L%u;\n", o, rhs, tgt);
                return FLOW_BRANCH;
            }
            emit_indent(b);
            buf_puts(b->out, "if (");
            render_reg(b, in->aa);
            buf_printf(b->out, " %s %s) {\n", o, rhs);
            b->indent++;
            if (in->target > (int32_t)in->addr) {
                walk_block(b, tgt);
            } else {
                emit_goto(b, tgt);
            }
            b->indent--;
            emit_line(b, "}");
            return FLOW_FALL;
        }

        case OP_PACKED_SWITCH:
        case OP_SPARSE_SWITCH: {
            emit_indent(b);
            buf_printf(b->out, "switch (v%u) {\n", in->aa);
            b->indent++;
            emit_line(b, "default: break;");
            b->indent--;
            emit_line(b, "}");
            /* Case bodies are emitted as labelled blocks by the surrounding
             * walker; without full switch recovery this stays a stub. */
            return FLOW_FALL;
        }

        case OP_FILL_ARRAY_DATA:
            emit_indent(b);
            buf_puts(b->out, "/* fill-array-data */\n");
            break;

        default:
            if (insn_is_binop(op)) {
                const char *sym = insn_binop_symbol(op);
                emit_indent(b);
                render_reg(b, in->aa);
                buf_puts(b->out, " = ");
                render_reg(b, in->regs[0]);
                buf_printf(b->out, " %s ", sym);
                render_reg(b, in->regs[1]);
                buf_puts(b->out, ";\n");
            } else if (op >= 0xb0 && op <= 0xcf) {
                /* /2addr */
                const char *sym = insn_binop_symbol((uint8_t)(op & 0x0f));
                emit_indent(b);
                b->writing_receiver = 1;
                render_reg(b, in->a);
                b->writing_receiver = 0;
                buf_puts(b->out, " = ");
                render_reg(b, in->a);
                buf_printf(b->out, " %s ", sym);
                render_reg(b, in->b);
                buf_puts(b->out, ";\n");
            } else if (op >= 0xd0 && op <= 0xd7) {
                emit_indent(b);
                b->writing_receiver = 1;
                render_reg(b, in->a);
                b->writing_receiver = 0;
                buf_puts(b->out, " = ");
                render_reg(b, in->b);
                buf_printf(b->out, " %s %d;\n", insn_binop_symbol(op), in->literal);
            } else if (op >= 0xd8 && op <= 0xe2) {
                emit_indent(b);
                b->writing_receiver = 1;
                render_reg(b, in->a);
                b->writing_receiver = 0;
                buf_puts(b->out, " = ");
                render_reg(b, in->b);
                buf_printf(b->out, " %s %d;\n", insn_binop_symbol(op), in->literal);
            } else if (insn_is_unop(op)) {
                emit_indent(b);
                render_reg(b, in->a);
                buf_printf(b->out, " = /*unop 0x%02x*/ ", op);
                render_reg(b, in->b);
                buf_puts(b->out, ";\n");
            } else if (op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) {
                emit_indent(b);
                /* The destination is the register of the following move-result,
                 * not aa (which is unused for invoke in 35c form). */
                const char *rt = invoke_result_desc(b->dex, in->idx);
                if (rt && strcmp(rt, "V")) {
                    uint32_t dst_reg = 0xffffffffu;
                    uint32_t next_i = ii + 1;
                    if (next_i < blk->insn_start + blk->insn_count) {
                        Insn *nx = &b->m->insns[next_i];
                        if (nx->opcode == OP_MOVE_RESULT || nx->opcode == OP_MOVE_RESULT_WIDE ||
                            nx->opcode == OP_MOVE_RESULT_OBJECT)
                            dst_reg = nx->aa;
                    }
                    if (dst_reg != 0xffffffffu) {
                        char nm[32];
                        reg_name(b, dst_reg, nm, sizeof(nm));
                        buf_printf(b->out, "%s = ", nm);
                    }
                }
                if (render_invoke(b, in))
                    buf_puts(b->out, ";\n");
            } else if (op == OP_INVOKE_DIRECT || op == OP_INVOKE_DIRECT_RANGE ||
                       op == OP_INVOKE_STATIC || op == OP_INVOKE_STATIC_RANGE ||
                       op == OP_INVOKE_SUPER || op == OP_INVOKE_SUPER_RANGE) {
                int chain_call = b->in_ctor &&
                                 !strcmp(dex_method_name(b->dex, in->idx), "<init>") &&
                                 !b->pending_new;
                if (chain_call)
                    break; /* already emitted at the top of the constructor */

                /* A string literal immediately fed to a static method is very
                 * often the ciphertext of a decryption helper. Evaluating the
                 * helper here replaces the call with its plaintext result. */
                if (op == OP_INVOKE_STATIC || op == OP_INVOKE_STATIC_RANGE) {
                    /* Register numbering shifts with versioning, so match on the
                     * literal itself rather than on the register that held it. */
                    if (b->pending_str_reg >= 0 && in->reg_count == 1) {
                        const char *lit = dex_string(b->dex, b->pending_str_idx);
                        const char *rtd = invoke_result_desc(b->dex, in->idx);
                        if (lit && rtd && !strcmp(rtd, "Ljava/lang/String;")) {
                            Arena *ba = java_body_arena();
                            char *plain = ba ? emu_decrypt_string(b->dex, in->idx, lit, ba) : NULL;
                            if (plain) {
                                char esc[1024];
                                java_escape_string(plain, esc, sizeof(esc));
                                emit_indent(b);
                                render_reg(b, in->aa);
                                buf_printf(b->out, " = \"%s\"; /* decrypted */\n", esc);
                                b->last_invoke_type = rtd;
                                b->pending_str_reg = -1;
                                break;
                            }
                        }
                    }
                    b->pending_str_reg = -1;
                }
                int merging_new = b->pending_new &&
                                  (int)in->regs[0] == b->pending_new_reg &&
                                  !strcmp(dex_method_name(b->dex, in->idx), "<init>");
                if (merging_new) {
                    /* Only a fresh object whose result is actually consumed gets
                     * an assignment; otherwise the expression stands alone. */
                    emit_indent(b);
                    buf_printf(b->out, "v%u = ", b->pending_new_reg);
                } else {
                    emit_indent(b);
                    const char *rt2 = invoke_result_desc(b->dex, in->idx);
                    if (rt2 && strcmp(rt2, "V"))
                        buf_printf(b->out, "v%u = ", in->aa);
                }
                if (render_invoke(b, in))
                    buf_puts(b->out, ";\n");
                b->last_invoke_type = invoke_result_desc(b->dex, in->idx);
            } else if (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE) {
                emit_indent(b);
                if (render_invoke(b, in))
                    buf_puts(b->out, ";\n");
            } else {
                char txt[128];
                insn_format(in, txt, sizeof(txt));
                emit_line(b, "/* %s */", txt);
            }
            break;
        }
        if (!wr_before && wr_reg != 0xffffffffu && wr_type)
            reg_begin_write(b, wr_reg, wr_type);
    }
    return FLOW_FALL;
}

/* Renders every block as a `case` of a dispatch loop. Always compilable, at the
 * cost of being closer to bytecode than to source. */
static int body_dispatch_render(Dex *dex, uint32_t class_def_idx,
                                const DexEncodedMethod *enc, int indent, Buf *out,
                                Arena *arena)
{
    CfgMethod *m = cfg_build(dex, class_def_idx, enc, arena);
    if (!m)
        return -1;

    Body b;
    memset(&b, 0, sizeof(b));
    b.dex = dex;
    b.m = m;
    b.class_def_idx = class_def_idx;
    b.arena = arena;
    b.out = out;
    b.indent = indent;
    b.uses_goto = 1;
    b.uses_bodies = 1;
    {
        const char *mn = dex_method_name(dex, enc->method_idx);
        b.in_ctor = (mn && !strcmp(mn, "<init>"));
        b.has_this = (enc->access_flags & DEX_ACC_STATIC) == 0;
    }
    b.pending_str_reg = -1;

    if (b.in_ctor)
        emit_ctor_chain(&b, class_def_idx);
    b.reg_type = arena_zalloc(arena, MAX_REG * sizeof(char *));
    b.reg_version = arena_zalloc(arena, MAX_REG * sizeof(int));
    seed_param_types(&b, dex, class_def_idx, enc);

    emit_locals(&b);
    emit_line(&b, "int state = %u;", m->entry);
    emit_line(&b, "dispatch: while (true) {");
    b.indent++;
    emit_line(&b, "switch (state) {");
    b.indent++;

    b.block_done = arena_zalloc(arena, m->block_count);
    /* Render in block-id order but *trace* in execution order: the register
     * version a block sees must be the one its predecessor left, so the blocks
     * are visited by walking from the entry block the way execution flows.
     * Rendering by id alone made a later-addressed block bump a version before
     * an earlier-addressed block read it, producing `v1_1.length()` where the
     * receiver was still a String. */
    {
        uint32_t *order = arena_zalloc(arena, m->block_count * sizeof(uint32_t));
        uint8_t *visited = arena_zalloc(arena, m->block_count);
        uint32_t n = 0;
        if (order && visited) {
            /* Work list seeded with the entry block, then a linear sweep for any
             * block execution cannot reach (exception handlers). */
            order[n++] = m->entry < m->block_count ? m->entry : 0;
            visited[order[0]] = 1;
            for (uint32_t w = 0; w < n; w++) {
                uint32_t bi = order[w];
                CfgBlock *blk = &m->blocks[bi];
                for (uint32_t s = 0; s < blk->succ_count && n < m->block_count; s++) {
                    uint32_t nx = blk->succ[s];
                    if (nx < m->block_count && !visited[nx]) {
                        visited[nx] = 1;
                        order[n++] = nx;
                    }
                }
            }
            for (uint32_t bi = 0; bi < m->block_count; bi++)
                if (!visited[bi])
                    order[n++] = bi;
        } else {
            for (uint32_t bi = 0; bi < m->block_count; bi++)
                order[bi] = bi;
            n = m->block_count;
        }
        for (uint32_t oi = 0; oi < n; oi++) {
            uint32_t i = order[oi];
            b.block_done[i] = 0;
            emit_line(&b, "case %u: {", i);
            b.indent++;
            walk_block(&b, i);
        /* Every case must leave the dispatch loop or pick the next state;
         * falling through to the next case is a compile error. */
        CfgBlock *blk = &m->blocks[i];
        int terminated = blk->insn_count > 0 &&
                         insn_is_terminator(&m->insns[blk->insn_start + blk->insn_count - 1]);
        if (!terminated) {
            uint32_t next = (i + 1 < m->block_count) ? i + 1 : m->block_count;
            if (next == m->block_count)
                emit_line(&b, "return;");
            else
                emit_line(&b, "state = %u; continue dispatch;", next);
        }
        b.indent--;
        emit_line(&b, "}");
        }
    }

    b.indent--;
    emit_line(&b, "}");
    b.indent--;
    emit_line(&b, "}");
    return 0;
}

/* Returns 1 when every vN / vN_M referenced in the body was also declared.
 * A mismatch means the register model lost track of a value, and shipping such
 * a body would produce code that does not compile. */
static int body_registers_consistent(const char *body)
{
    int declared[512];
    memset(declared, 0, sizeof(declared));

    /* Declarations look like "int v12 = 0;" or "Object v3_1 = null;". */
    for (const char *p = body; (p = strstr(p, " v")) != NULL; p++) {
        const char *q = p + 2;
        if (*q < '0' || *q > '9')
            continue;
        int reg = 0;
        while (*q >= '0' && *q <= '9' && reg < 1000)
            reg = reg * 10 + (*q++ - '0');
        /* A declaration is followed by '=' before any ';'. */
        const char *scan = q;
        while (*scan && *scan != ';' && *scan != '\n') {
            if (*scan == '=' && scan > q) {
                if (reg < 512)
                    declared[reg] = 1;
                break;
            }
            scan++;
        }
    }

    /* Every use must be declared, unless it is a parameter name (pN). */
    for (const char *p = body; (p = strstr(p, "v")) != NULL; p++) {
        if (p > body && (p[-1] >= 'a' && p[-1] <= 'z'))
            continue;
        const char *q = p + 1;
        if (*q < '0' || *q > '9')
            continue;
        int reg = 0;
        while (*q >= '0' && *q <= '9' && reg < 1000)
            reg = reg * 10 + (*q++ - '0');
        if (reg >= 512)
            continue;
        if (!declared[reg])
            return 0;
    }
    return 1;
}

int body_decompile(Dex *dex, uint32_t class_def_idx, const DexEncodedMethod *enc, int indent,
                   Buf *out, Arena *arena)
{
    size_t body_start = out->len;
    CfgMethod *m = cfg_build(dex, class_def_idx, enc, arena);
    if (!m)
        return -1;
    if (!getenv("TACHYON_LEGACY_BODIES")) {
        if (!m->code || m->code->registers_size > 64 || m->code->insns_size > 1024 ||
            m->block_count > 16)
            return -1;
        SsaMethod *ssa = ssa_build(m, arena);
        if (!ssa || ssa_validate(ssa) != 0)
            return -1;
        TypeInfer *types = type_infer_build(ssa, arena);
        if (!types || type_infer_validate(types) != 0)
            return -1;
        const char *mname = dex_method_name(dex, enc->method_idx);
        if (mname && !strcmp(mname, "<init>"))
            body_decompile_ctor_chain(dex, class_def_idx, indent, out, arena);
        if (body_emit_ssa(dex, class_def_idx, enc, indent, out, ssa, types, arena) == 0)
            return 0;
        out->len = body_start;
        if (out->data)
            out->data[body_start] = '\0';
        return -1;
    }
    cfg_compute_dominators(m, arena);
    cfg_find_loops(m, arena);

    Body b;
    memset(&b, 0, sizeof(b));
    b.dex = dex;
    b.m = m;
    b.class_def_idx = class_def_idx;
    b.arena = arena;
    b.out = out;
    b.indent = indent;
    {
        const char *mname = dex_method_name(dex, enc->method_idx);
        b.in_ctor = (mname && !strcmp(mname, "<init>"));
        b.has_this = (enc->access_flags & DEX_ACC_STATIC) == 0;
    }
    b.pending_str_reg = -1;

    b.reg_type = arena_zalloc(arena, MAX_REG * sizeof(char *));
    b.reg_version = arena_zalloc(arena, MAX_REG * sizeof(int));
    b.block_done = arena_zalloc(arena, m->block_count);
    b.label_emitted = arena_zalloc(arena, m->block_count);
    if (!b.block_done || !b.label_emitted)
        return -1;

    seed_param_types(&b, dex, class_def_idx, enc);

    /* A constructor must start with super()/this(); locals come after. */
    if (b.in_ctor) {
        emit_ctor_chain(&b, class_def_idx);
    }
    emit_locals(&b);
    /* First pass renders the structured part. If any transfer needed a goto, the
     * whole body is re-rendered as a dispatch loop, because a partial mix of
     * structured code and jumps cannot compile. */
    for (uint32_t i = 0; i < m->block_count; i++) {
        if (b.block_done[i])
            continue;
        walk_block(&b, i);
    }
    /* Cheap self-check: a body that still contains bytecode artefacts would not
     * compile, so signal the caller to emit the stub instead. */
    /* Self-checks: a body that references a register it never declared, or that
     * still carries bytecode artefacts, would not compile. Falling back to the
     * stub is better than shipping code that does not build. */
    if (!body_registers_consistent(out->data + body_start)) {
        out->len = body_start;
        out->data[body_start] = '\0';
        return -1;
    }
    if (b.unpaired_init) {
        out->len = body_start;
        out->data[body_start] = '\0';
        return -1;
    }

    if (b.uses_goto) {
        /* A mixed body cannot compile; drop everything this method produced and
         * re-render it in the dispatch form. */
        out->len = body_start;
        out->data[body_start] = '\0';
        return body_dispatch_render(dex, class_def_idx, enc, indent, out, arena);
    }
    return 0;
}

/* Emits a constructor that only chains to the parent, using the parent's real
 * descriptor. Kept separate from body_decompile: no instructions are recovered,
 * so this cannot produce the type errors a partial body would. */
int body_decompile_ctor_chain(Dex *dex, uint32_t class_def_idx, int indent, Buf *out,
                              Arena *arena)
{
    if (!dex || !out || class_def_idx >= dex->hdr.class_defs_size)
        return -1;

    const DexClassDef *cd = &dex->classes[class_def_idx];
    if (cd->superclass_idx == DEX_NO_INDEX)
        return -1;
    const char *sd = dex_type_desc(dex, cd->superclass_idx);
    if (sd && (!strcmp(sd, "Ljava/lang/Object;") || !strcmp(sd, "Ljava/lang/Enum;")))
        return -1;

    Body b;
    memset(&b, 0, sizeof(b));
    b.dex = dex;
    b.out = out;
    b.indent = indent;
    b.arena = arena;

    emit_ctor_chain(&b, class_def_idx);
    return 0;
}
