src/ir/opcode.o: src/ir/opcode.c src/ir/opcode.h

src/ir/opcode.h:
