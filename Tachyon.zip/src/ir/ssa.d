src/ir/ssa.o: src/ir/ssa.c src/ir/ssa.h src/common/arena.h src/ir/cfg.h \
 src/dex/dex.h src/common/buf.h src/common/io.h src/ir/opcode.h

src/ir/ssa.h:

src/common/arena.h:

src/ir/cfg.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/ir/opcode.h:
