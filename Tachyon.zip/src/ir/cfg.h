#ifndef TACHYON_IR_CFG_H
#define TACHYON_IR_CFG_H

#include <stdint.h>

#include "common/arena.h"
#include "dex/dex.h"
#include "ir/opcode.h"

#define CFG_NO_BLOCK 0xffffffffu

typedef struct CfgBlock {
    uint32_t id;
    uint32_t start;      /* first code-unit address */
    uint32_t end;        /* one past the last code unit */
    uint32_t insn_start; /* index into CfgMethod.insns */
    uint32_t insn_count;

    uint32_t *succ;
    uint32_t succ_count;
    uint32_t *pred;
    uint32_t pred_count;

    /* dominator tree */
    uint32_t idom;

    /* loop header bookkeeping */
    int is_loop_header;
    uint32_t *loop_body;  /* natural-loop body (header included) */
    uint32_t loop_size;
} CfgBlock;

typedef struct {
    uint32_t start;
    uint32_t end;
    const char *type;   /* NULL for catch-all */
    uint32_t handler;   /* block id */
} CfgHandler;

typedef struct {
    Dex *dex;
    uint32_t method_idx;
    uint32_t class_def_idx;
    const DexEncodedMethod *enc;
    DexCode *code;

    Insn *insns;         /* decoded instructions */
    uint32_t *addr_to_block; /* code-unit -> block id map, size = insns_size */
    uint32_t *addr_to_insn;  /* code-unit -> insn index map */

    CfgBlock *blocks;
    uint32_t block_count;

    CfgHandler *handlers;
    uint32_t handler_count;

    uint32_t entry;
    uint32_t exit;       /* synthetic exit block collecting all returns */
} CfgMethod;

/* Builds the CFG for a method. Returns NULL when the code cannot be decoded. */
CfgMethod *cfg_build(Dex *dex, uint32_t class_def_idx, const DexEncodedMethod *enc,
                     Arena *arena);

/* Computes the dominator tree (idom for every block). */
void cfg_compute_dominators(CfgMethod *m, Arena *arena);

/* Marks natural loops reachable from back edges. */
void cfg_find_loops(CfgMethod *m, Arena *arena);

/* Returns switch case keys and absolute target addresses for one switch
 * instruction. Arrays are arena-owned and have `count` entries. */
uint32_t cfg_switch_cases(const CfgMethod *m, const Insn *in, int32_t **keys,
                          int32_t **targets, Arena *arena);

/* Debug dump in DOT format. */
void cfg_dump_dot(const CfgMethod *m, void *fp);

#endif
