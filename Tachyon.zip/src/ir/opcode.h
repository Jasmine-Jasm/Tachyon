#ifndef TACHYON_OPCODE_H
#define TACHYON_OPCODE_H

#include <stddef.h>
#include <stdint.h>

/* Dalvik instruction formats. Only the shapes that occur in real dex files are
 * listed; the odex/quick variants are decoded as their base form. */
typedef enum {
    FMT_10x, FMT_12x, FMT_11n, FMT_11x, FMT_10t,
    FMT_20t, FMT_22x, FMT_21t, FMT_21s, FMT_21h, FMT_21c,
    FMT_23x, FMT_22b, FMT_22t, FMT_22s, FMT_22c,
    FMT_32x, FMT_30t, FMT_31i, FMT_31t, FMT_31c,
    FMT_35c, FMT_3rc, FMT_45cc, FMT_4rcc, FMT_51l,
    FMT_INVALID
} InsnFormat;

/* Opcodes that the decompiler reasons about symbolically. Everything else is
 * handled by range (arithmetic) or by format (generic moves). */
enum {
    OP_NOP = 0x00,
    OP_MOVE_FROM16 = 0x02,
    OP_MOVE_16 = 0x03,
    OP_MOVE_WIDE = 0x04,
    OP_MOVE_WIDE_FROM16 = 0x05,
    OP_MOVE_WIDE_16 = 0x06,
    OP_MOVE_OBJECT = 0x07,
    OP_MOVE_OBJECT_FROM16 = 0x08,
    OP_MOVE_OBJECT_16 = 0x09,
    OP_MOVE = 0x01,
    OP_MOVE_RESULT = 0x0a,
    OP_MOVE_RESULT_WIDE = 0x0b,
    OP_MOVE_RESULT_OBJECT = 0x0c,
    OP_MOVE_EXCEPTION = 0x0d,
    OP_RETURN_VOID = 0x0e,
    OP_RETURN = 0x0f,
    OP_RETURN_WIDE = 0x10,
    OP_RETURN_OBJECT = 0x11,
    OP_CONST_4 = 0x12,
    OP_CONST_16 = 0x13,
    OP_CONST = 0x14,
    OP_CONST_HIGH16 = 0x15,
    OP_CONST_WIDE_16 = 0x16,
    OP_CONST_WIDE_32 = 0x17,
    OP_CONST_WIDE = 0x18,
    OP_CONST_WIDE_HIGH16 = 0x19,
    OP_CONST_STRING = 0x1a,
    OP_CONST_STRING_JUMBO = 0x1b,
    OP_CONST_CLASS = 0x1c,
    OP_MONITOR_ENTER = 0x1d,
    OP_MONITOR_EXIT = 0x1e,
    OP_CHECK_CAST = 0x1f,
    OP_INSTANCE_OF = 0x20,
    OP_ARRAY_LENGTH = 0x21,
    OP_NEW_INSTANCE = 0x22,
    OP_NEW_ARRAY = 0x23,
    OP_FILLED_NEW_ARRAY = 0x24,
    OP_FILLED_NEW_ARRAY_RANGE = 0x25,
    OP_FILL_ARRAY_DATA = 0x26,
    OP_THROW = 0x27,
    OP_GOTO = 0x28,
    OP_GOTO_16 = 0x29,
    OP_GOTO_32 = 0x2a,
    OP_PACKED_SWITCH = 0x2b,
    OP_SPARSE_SWITCH = 0x2c,
    OP_CMPL_FLOAT = 0x2d,
    OP_CMPG_FLOAT = 0x2e,
    OP_CMPL_DOUBLE = 0x2f,
    OP_CMPG_DOUBLE = 0x30,
    OP_CMP_LONG = 0x31,
    OP_IF_EQ = 0x32,
    OP_IF_NE = 0x33,
    OP_IF_LT = 0x34,
    OP_IF_GE = 0x35,
    OP_IF_GT = 0x36,
    OP_IF_LE = 0x37,
    OP_IF_EQZ = 0x38,
    OP_IF_NEZ = 0x39,
    OP_IF_LTZ = 0x3a,
    OP_IF_GEZ = 0x3b,
    OP_IF_GTZ = 0x3c,
    OP_IF_LEZ = 0x3d,
    OP_AGET = 0x44,
    OP_AGET_WIDE = 0x45,
    OP_AGET_OBJECT = 0x46,
    OP_AGET_BOOLEAN = 0x47,
    OP_AGET_BYTE = 0x48,
    OP_AGET_CHAR = 0x49,
    OP_AGET_SHORT = 0x4a,
    OP_APUT = 0x4b,
    OP_APUT_WIDE = 0x4c,
    OP_APUT_OBJECT = 0x4d,
    OP_APUT_BOOLEAN = 0x4e,
    OP_APUT_BYTE = 0x4f,
    OP_APUT_CHAR = 0x50,
    OP_APUT_SHORT = 0x51,
    OP_IGET = 0x52,
    OP_IGET_WIDE = 0x53,
    OP_IGET_OBJECT = 0x54,
    OP_IGET_BOOLEAN = 0x55,
    OP_IGET_BYTE = 0x56,
    OP_IGET_CHAR = 0x57,
    OP_IGET_SHORT = 0x58,
    OP_IPUT = 0x59,
    OP_IPUT_WIDE = 0x5a,
    OP_IPUT_OBJECT = 0x5b,
    OP_IPUT_BOOLEAN = 0x5c,
    OP_IPUT_BYTE = 0x5d,
    OP_IPUT_CHAR = 0x5e,
    OP_IPUT_SHORT = 0x5f,
    OP_SGET = 0x60,
    OP_SGET_WIDE = 0x61,
    OP_SGET_OBJECT = 0x62,
    OP_SGET_BOOLEAN = 0x63,
    OP_SGET_BYTE = 0x64,
    OP_SGET_CHAR = 0x65,
    OP_SGET_SHORT = 0x66,
    OP_SPUT = 0x67,
    OP_SPUT_WIDE = 0x68,
    OP_SPUT_OBJECT = 0x69,
    OP_SPUT_BOOLEAN = 0x6a,
    OP_SPUT_BYTE = 0x6b,
    OP_SPUT_CHAR = 0x6c,
    OP_SPUT_SHORT = 0x6d,
    OP_INVOKE_VIRTUAL = 0x6e,
    OP_INVOKE_SUPER = 0x6f,
    OP_INVOKE_DIRECT = 0x70,
    OP_INVOKE_STATIC = 0x71,
    OP_INVOKE_INTERFACE = 0x72,
    OP_INVOKE_VIRTUAL_RANGE = 0x74,
    OP_INVOKE_SUPER_RANGE = 0x75,
    OP_INVOKE_DIRECT_RANGE = 0x76,
    OP_INVOKE_STATIC_RANGE = 0x77,
    OP_INVOKE_INTERFACE_RANGE = 0x78,
    OP_NEG_INT = 0x7b,
    OP_INT_TO_SHORT = 0x8f,
    OP_ADD_INT = 0x90,
    OP_REM_DOUBLE = 0xaf,
    OP_ADD_INT_LIT16 = 0xb0,
    OP_USHR_INT_LIT16 = 0xba,
    OP_ADD_INT_LIT8 = 0xd0,
    OP_USHR_INT_LIT8 = 0xda,
    OP_INVOKE_POLYMORPHIC = 0xfa,
    OP_INVOKE_POLYMORPHIC_RANGE = 0xfb,
    OP_INVOKE_CUSTOM = 0xfc,
    OP_INVOKE_CUSTOM_RANGE = 0xfd,
    OP_CONST_METHOD_HANDLE = 0xfe,
    OP_CONST_METHOD_TYPE = 0xff,
};

typedef struct {
    uint16_t addr;      /* code-unit offset of this instruction */
    uint16_t len;       /* length in code units */
    uint8_t opcode;
    uint8_t fmt;

    uint8_t a;          /* 4-bit vA or arg count for 35c/3rc */
    uint8_t b;          /* 4-bit vB */
    uint16_t aa;        /* 8-bit vAA (register or index) */
    uint32_t first_reg; /* first register of the operand list, 35c/3rc */

    int32_t literal;    /* signed immediate */
    uint64_t wide_literal;
    uint32_t idx;       /* pool index: string / type / field / method / proto */
    int32_t target;     /* absolute branch target in code units */
    uint32_t payload;   /* absolute address of a switch/array payload */

    uint16_t regs[5];   /* operand registers for invoke / filled-new-array */
    uint8_t reg_count;
} Insn;

/* Returns instruction length in code units, 0 on error. */
uint32_t insn_decode(const uint16_t *code, uint32_t code_len, uint32_t addr, Insn *out);

const char *insn_name(uint8_t opcode);

/* Human-readable operand rendering, used by the disassembler command. */
void insn_format(const Insn *in, char *out, size_t cap);

/* True when the instruction ends a basic block. */
int insn_is_terminator(const Insn *in);

/* True when control flow always leaves the method (return/throw/goto). */
int insn_is_exit(const Insn *in);

/* Branch targets; returns count (0, 1, or 2 for switches which are handled
 * separately by the caller walking the payload). */
int insn_target(const Insn *in, int32_t *targets, int max);

/* True for the arithmetic ranges handled generically. */
int insn_is_unop(uint8_t op);
int insn_is_binop(uint8_t op);
int insn_is_binop_lit(uint8_t op);

/* Java operator text for an arithmetic opcode (e.g. "+", "<<", ">>>"). */
const char *insn_binop_symbol(uint8_t opcode);

/* Cast target type for int-to-* and *-to-* opcodes, or NULL. */
const char *insn_convert_type(uint8_t opcode);

/* Result type descriptor of an arithmetic opcode ("I", "J", "F", "D"), or NULL. */
const char *insn_arith_type(uint8_t opcode);

#endif
