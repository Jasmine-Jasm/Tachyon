#include "ir/opcode.h"

#include <stdio.h>
#include <string.h>

/* ---------------------------------------------------------------- */
/* format table                                                      */
/* ---------------------------------------------------------------- */

static uint8_t g_fmt[256];
static int g_fmt_ready;

static void set_fmt(uint8_t lo, uint8_t hi, InsnFormat f)
{
    for (unsigned i = lo; i <= hi; i++)
        g_fmt[i] = (uint8_t)f;
}

static void build_formats(void)
{
    if (g_fmt_ready)
        return;
    for (int i = 0; i < 256; i++)
        g_fmt[i] = FMT_INVALID;

    set_fmt(0x00, 0x00, FMT_10x); /* nop */
    set_fmt(0x01, 0x01, FMT_12x); /* move */
    set_fmt(0x02, 0x02, FMT_22x); /* move/from16 */
    set_fmt(0x03, 0x03, FMT_32x); /* move/16 */
    set_fmt(0x04, 0x04, FMT_12x); /* move-wide */
    set_fmt(0x05, 0x05, FMT_22x);
    set_fmt(0x06, 0x06, FMT_32x);
    set_fmt(0x07, 0x07, FMT_12x); /* move-object */
    set_fmt(0x08, 0x08, FMT_22x);
    set_fmt(0x09, 0x09, FMT_32x);
    set_fmt(0x0a, 0x0a, FMT_11x); /* move-result */
    set_fmt(0x0b, 0x0b, FMT_11x);
    set_fmt(0x0c, 0x0c, FMT_11x);
    set_fmt(0x0d, 0x0d, FMT_11x); /* move-exception */
    set_fmt(0x0e, 0x0e, FMT_10x); /* return-void */
    set_fmt(0x0f, 0x11, FMT_11x); /* return / return-wide / return-object */
    set_fmt(0x12, 0x12, FMT_11n); /* const/4 */
    set_fmt(0x13, 0x13, FMT_21s); /* const/16 */
    set_fmt(0x14, 0x14, FMT_31i); /* const */
    set_fmt(0x15, 0x15, FMT_21h); /* const/high16 */
    set_fmt(0x16, 0x16, FMT_21s); /* const-wide/16 */
    set_fmt(0x17, 0x17, FMT_31i); /* const-wide/32 */
    set_fmt(0x18, 0x18, FMT_51l); /* const-wide */
    set_fmt(0x19, 0x19, FMT_21h); /* const-wide/high16 */
    set_fmt(0x1a, 0x1a, FMT_21c); /* const-string */
    set_fmt(0x1b, 0x1b, FMT_31c); /* const-string/jumbo */
    set_fmt(0x1c, 0x1c, FMT_21c); /* const-class */
    set_fmt(0x1d, 0x1e, FMT_11x); /* monitor-enter/exit */
    set_fmt(0x1f, 0x20, FMT_21c); /* check-cast / instance-of */
    set_fmt(0x21, 0x21, FMT_12x); /* array-length */
    set_fmt(0x22, 0x22, FMT_21c); /* new-instance */
    set_fmt(0x23, 0x23, FMT_22c); /* new-array */
    set_fmt(0x24, 0x24, FMT_35c); /* filled-new-array */
    set_fmt(0x25, 0x25, FMT_3rc);
    set_fmt(0x26, 0x26, FMT_31t); /* fill-array-data */
    set_fmt(0x27, 0x27, FMT_11x); /* throw */
    set_fmt(0x28, 0x28, FMT_10t); /* goto */
    set_fmt(0x29, 0x29, FMT_20t);
    set_fmt(0x2a, 0x2a, FMT_30t);
    set_fmt(0x2b, 0x2b, FMT_31t); /* packed-switch */
    set_fmt(0x2c, 0x2c, FMT_31t); /* sparse-switch */
    set_fmt(0x2d, 0x31, FMT_23x); /* cmpl/cmpg/cmp-long */
    set_fmt(0x32, 0x37, FMT_22t); /* if-* */
    set_fmt(0x38, 0x3d, FMT_21t); /* if-*z */
    set_fmt(0x44, 0x51, FMT_23x); /* aget/aput family */
    set_fmt(0x52, 0x5f, FMT_22c); /* iget/iput family */
    set_fmt(0x60, 0x6d, FMT_21c); /* sget/sput family */
    set_fmt(0x6e, 0x72, FMT_35c); /* invoke-* */
    set_fmt(0x74, 0x78, FMT_3rc); /* invoke-family range variants */
    set_fmt(0x7b, 0x8f, FMT_12x); /* unops */
    set_fmt(0x90, 0xaf, FMT_23x); /* binops (vAA, vBB, vCC) */
    set_fmt(0xb0, 0xcf, FMT_12x); /* /2addr variants (vA, vB): one unit */
    set_fmt(0xd0, 0xd7, FMT_22s); /* /lit16 (vA, vB, #lit16): two units */
    set_fmt(0xd8, 0xe2, FMT_22b); /* /lit8 (vA, vB, #lit8): two units */
    set_fmt(0xfa, 0xfa, FMT_45cc);
    set_fmt(0xfb, 0xfb, FMT_4rcc);
    set_fmt(0xfc, 0xfc, FMT_35c); /* invoke-custom */
    set_fmt(0xfd, 0xfd, FMT_3rc);
    set_fmt(0xfe, 0xfe, FMT_21c); /* const-method-handle */
    set_fmt(0xff, 0xff, FMT_21c); /* const-method-type */

    g_fmt_ready = 1;
}

static const char *g_names[256] = {
    [0x00] = "nop", [0x01] = "move", [0x02] = "move/from16", [0x03] = "move/16",
    [0x04] = "move-wide", [0x05] = "move-wide/from16", [0x06] = "move-wide/16",
    [0x07] = "move-object", [0x08] = "move-object/from16", [0x09] = "move-object/16",
    [0x0a] = "move-result", [0x0b] = "move-result-wide", [0x0c] = "move-result-object",
    [0x0d] = "move-exception", [0x0e] = "return-void", [0x0f] = "return",
    [0x10] = "return-wide", [0x11] = "return-object", [0x12] = "const/4",
    [0x13] = "const/16", [0x14] = "const", [0x15] = "const/high16",
    [0x16] = "const-wide/16", [0x17] = "const-wide/32", [0x18] = "const-wide",
    [0x19] = "const-wide/high16", [0x1a] = "const-string", [0x1b] = "const-string/jumbo",
    [0x1c] = "const-class", [0x1d] = "monitor-enter", [0x1e] = "monitor-exit",
    [0x1f] = "check-cast", [0x20] = "instance-of", [0x21] = "array-length",
    [0x22] = "new-instance", [0x23] = "new-array", [0x24] = "filled-new-array",
    [0x25] = "filled-new-array/range", [0x26] = "fill-array-data", [0x27] = "throw",
    [0x28] = "goto", [0x29] = "goto/16", [0x2a] = "goto/32",
    [0x2b] = "packed-switch", [0x2c] = "sparse-switch",
    [0x2d] = "cmpl-float", [0x2e] = "cmpg-float", [0x2f] = "cmpl-double",
    [0x30] = "cmpg-double", [0x31] = "cmp-long",
    [0x32] = "if-eq", [0x33] = "if-ne", [0x34] = "if-lt", [0x35] = "if-ge",
    [0x36] = "if-gt", [0x37] = "if-le", [0x38] = "if-eqz", [0x39] = "if-nez",
    [0x3a] = "if-ltz", [0x3b] = "if-gez", [0x3c] = "if-gtz", [0x3d] = "if-lez",
    [0x44] = "aget", [0x45] = "aget-wide", [0x46] = "aget-object", [0x47] = "aget-boolean",
    [0x48] = "aget-byte", [0x49] = "aget-char", [0x4a] = "aget-short",
    [0x4b] = "aput", [0x4c] = "aput-wide", [0x4d] = "aput-object",
    [0x4e] = "aput-boolean", [0x4f] = "aput-byte", [0x50] = "aput-char",
    [0x51] = "aput-short",
    [0x52] = "iget", [0x53] = "iget-wide", [0x54] = "iget-object",
    [0x55] = "iget-boolean", [0x56] = "iget-byte", [0x57] = "iget-char",
    [0x58] = "iget-short",
    [0x59] = "iput", [0x5a] = "iput-wide", [0x5b] = "iput-object",
    [0x5c] = "iput-boolean", [0x5d] = "iput-byte", [0x5e] = "iput-char",
    [0x5f] = "iput-short",
    [0x60] = "sget", [0x61] = "sget-wide", [0x62] = "sget-object",
    [0x63] = "sget-boolean", [0x64] = "sget-byte", [0x65] = "sget-char",
    [0x66] = "sget-short",
    [0x67] = "sput", [0x68] = "sput-wide", [0x69] = "sput-object",
    [0x6a] = "sput-boolean", [0x6b] = "sput-byte", [0x6c] = "sput-char",
    [0x6d] = "sput-short",
    [0x6e] = "invoke-virtual", [0x6f] = "invoke-super", [0x70] = "invoke-direct",
    [0x71] = "invoke-static", [0x72] = "invoke-interface",
    [0x74] = "invoke-virtual/range", [0x75] = "invoke-super/range",
    [0x76] = "invoke-direct/range", [0x77] = "invoke-static/range",
    [0x78] = "invoke-interface/range",
    [0x7b] = "neg-int", [0x7c] = "not-int", [0x7d] = "neg-long", [0x7e] = "not-long",
    [0x7f] = "neg-float", [0x80] = "neg-double", [0x81] = "int-to-long",
    [0x82] = "int-to-float", [0x83] = "int-to-double", [0x84] = "long-to-int",
    [0x85] = "long-to-float", [0x86] = "long-to-double", [0x87] = "float-to-int",
    [0x88] = "float-to-long", [0x89] = "float-to-double", [0x8a] = "double-to-int",
    [0x8b] = "double-to-long", [0x8c] = "double-to-float", [0x8d] = "int-to-byte",
    [0x8e] = "int-to-char", [0x8f] = "int-to-short",
    [0x90] = "add-int", [0x91] = "sub-int", [0x92] = "mul-int", [0x93] = "div-int",
    [0x94] = "rem-int", [0x95] = "and-int", [0x96] = "or-int", [0x97] = "xor-int",
    [0x98] = "shl-int", [0x99] = "shr-int", [0x9a] = "ushr-int",
    [0x9b] = "add-long", [0x9c] = "sub-long", [0x9d] = "mul-long", [0x9e] = "div-long",
    [0x9f] = "rem-long", [0xa0] = "and-long", [0xa1] = "or-long", [0xa2] = "xor-long",
    [0xa3] = "shl-long", [0xa4] = "shr-long", [0xa5] = "ushr-long",
    [0xa6] = "add-float", [0xa7] = "sub-float", [0xa8] = "mul-float", [0xa9] = "div-float",
    [0xaa] = "rem-float", [0xab] = "add-double", [0xac] = "sub-double",
    [0xad] = "mul-double", [0xae] = "div-double", [0xaf] = "rem-double",
    [0xb0] = "add-int/2addr", [0xb1] = "sub-int/2addr", [0xb2] = "mul-int/2addr",
    [0xb3] = "div-int/2addr", [0xb4] = "rem-int/2addr", [0xb5] = "and-int/2addr",
    [0xb6] = "or-int/2addr", [0xb7] = "xor-int/2addr", [0xb8] = "shl-int/2addr",
    [0xb9] = "shr-int/2addr", [0xba] = "ushr-int/2addr",
    [0xbb] = "add-long/2addr", [0xbc] = "sub-long/2addr", [0xbd] = "mul-long/2addr",
    [0xbe] = "div-long/2addr", [0xbf] = "rem-long/2addr", [0xc0] = "and-long/2addr",
    [0xc1] = "or-long/2addr", [0xc2] = "xor-long/2addr", [0xc3] = "shl-long/2addr",
    [0xc4] = "shr-long/2addr", [0xc5] = "ushr-long/2addr",
    [0xc6] = "add-float/2addr", [0xc7] = "sub-float/2addr", [0xc8] = "mul-float/2addr",
    [0xc9] = "div-float/2addr", [0xca] = "rem-float/2addr",
    [0xcb] = "add-double/2addr", [0xcc] = "sub-double/2addr", [0xcd] = "mul-double/2addr",
    [0xce] = "div-double/2addr", [0xcf] = "rem-double/2addr",
    [0xd0] = "add-int/lit16", [0xd1] = "rsub-int", [0xd2] = "mul-int/lit16",
    [0xd3] = "div-int/lit16", [0xd4] = "rem-int/lit16", [0xd5] = "and-int/lit16",
    [0xd6] = "or-int/lit16", [0xd7] = "xor-int/lit16",
    [0xd8] = "add-int/lit8", [0xd9] = "rsub-int/lit8", [0xda] = "mul-int/lit8",
    [0xdb] = "div-int/lit8", [0xdc] = "rem-int/lit8", [0xdd] = "and-int/lit8",
    [0xde] = "or-int/lit8", [0xdf] = "xor-int/lit8", [0xe0] = "shl-int/lit8",
    [0xe1] = "shr-int/lit8", [0xe2] = "ushr-int/lit8",
    [0xfa] = "invoke-polymorphic", [0xfb] = "invoke-polymorphic/range",
    [0xfc] = "invoke-custom", [0xfd] = "invoke-custom/range",
    [0xfe] = "const-method-handle", [0xff] = "const-method-type",
};

const char *insn_name(uint8_t opcode)
{
    const char *n = g_names[opcode];
    return n ? n : "<unknown>";
}

/* ---------------------------------------------------------------- */
/* decoding                                                          */
/* ---------------------------------------------------------------- */

static inline uint16_t u16(const uint16_t *c, uint32_t i)
{
    return c[i];
}

uint32_t insn_decode(const uint16_t *code, uint32_t code_len, uint32_t addr, Insn *out)
{
    build_formats();
    if (addr >= code_len)
        return 0;

    memset(out, 0, sizeof(*out));
    uint16_t unit = code[addr];
    uint8_t op = (uint8_t)(unit & 0xff);
    out->opcode = op;
    out->addr = (uint16_t)addr;
    out->fmt = g_fmt[op];
    out->a = (uint8_t)((unit >> 8) & 0x0f);
    out->b = (uint8_t)((unit >> 12) & 0x0f);
    out->aa = 0;

    uint32_t need = 1;
    switch ((InsnFormat)out->fmt) {
    case FMT_10x:
    case FMT_12x:
    case FMT_11n:
    case FMT_11x:
    case FMT_10t:
        need = 1;
        break;
    case FMT_20t:
    case FMT_22x:
    case FMT_21t:
    case FMT_21s:
    case FMT_21h:
    case FMT_21c:
    case FMT_23x:
    case FMT_22b:
    case FMT_22t:
    case FMT_22s:
    case FMT_22c:
        need = 2;
        break;
    case FMT_32x:
    case FMT_30t:
    case FMT_31i:
    case FMT_31t:
    case FMT_31c:
    case FMT_35c:
    case FMT_3rc:
        need = 3;
        break;
    case FMT_45cc:
    case FMT_4rcc:
    case FMT_51l:
        need = 5;
        break;
    default:
        return 0; /* unknown opcode: caller must stop */
    }

    if (addr + need > code_len)
        return 0;

    out->len = (uint16_t)need;

    switch ((InsnFormat)out->fmt) {
    case FMT_10x:
        break;

    case FMT_12x:
        out->a = (uint8_t)((unit >> 8) & 0x0f);
        out->b = (uint8_t)((unit >> 12) & 0x0f);
        break;

    case FMT_11n: {
        /* const/4 vA, #+B : 4-bit register A, 4-bit signed literal B */
        out->a = (uint8_t)((unit >> 8) & 0x0f);
        int8_t lit = (int8_t)((unit >> 12) & 0x0f);
        if (lit & 0x8)
            lit = (int8_t)(lit | 0xf0);
        out->literal = lit;
        break;
    }

    case FMT_11x:
        out->aa = (uint8_t)(unit >> 8);
        break;

    case FMT_10t: {
        int8_t off = (int8_t)(unit >> 8);
        out->target = (int32_t)addr + off;
        break;
    }

    case FMT_20t: {
        int16_t off = (int16_t)u16(code, addr + 1);
        out->target = (int32_t)addr + off;
        break;
    }

    case FMT_22x:
        out->aa = (uint8_t)(unit >> 8);
        out->first_reg = u16(code, addr + 1);
        break;

    case FMT_21t: {
        out->aa = (uint8_t)(unit >> 8);
        int16_t off = (int16_t)u16(code, addr + 1);
        out->target = (int32_t)addr + off;
        break;
    }

    case FMT_21s:
        out->aa = (uint8_t)(unit >> 8);
        out->literal = (int16_t)u16(code, addr + 1);
        break;

    case FMT_21h: {
        out->aa = (uint8_t)(unit >> 8);
        int16_t hi = (int16_t)u16(code, addr + 1);
        out->literal = (int32_t)hi << 16;
        break;
    }

    case FMT_21c:
        out->aa = (uint8_t)(unit >> 8);
        out->idx = u16(code, addr + 1);
        break;

    case FMT_23x:
        out->aa = (uint8_t)(unit >> 8);
        out->b = (uint8_t)(u16(code, addr + 1) & 0xff);
        out->a = (uint8_t)(u16(code, addr + 1) >> 8);
        out->first_reg = 0;
        /* third register is the low byte of the second unit's high half */
        out->literal = 0;
        out->regs[0] = (uint16_t)(u16(code, addr + 1) & 0xff);
        out->regs[1] = (uint16_t)(u16(code, addr + 1) >> 8);
        break;

    case FMT_22b:
        out->aa = (uint8_t)(unit >> 8);
        out->b = (uint8_t)(u16(code, addr + 1) & 0xff);
        out->literal = (int8_t)(u16(code, addr + 1) >> 8);
        break;

    case FMT_22t:
        out->a = (uint8_t)((unit >> 8) & 0x0f);
        out->b = (uint8_t)((unit >> 12) & 0x0f);
        out->target = (int32_t)addr + (int16_t)u16(code, addr + 1);
        break;

    case FMT_22s:
        out->a = (uint8_t)((unit >> 8) & 0x0f);
        out->b = (uint8_t)((unit >> 12) & 0x0f);
        out->literal = (int16_t)u16(code, addr + 1);
        break;

    case FMT_22c:
        out->a = (uint8_t)((unit >> 8) & 0x0f);
        out->b = (uint8_t)((unit >> 12) & 0x0f);
        out->idx = u16(code, addr + 1);
        break;

    case FMT_32x:
        out->aa = (uint8_t)(unit >> 8);
        out->first_reg = u16(code, addr + 1);
        break;

    case FMT_30t: {
        int32_t off = (int32_t)((uint32_t)u16(code, addr + 1) |
                                ((uint32_t)u16(code, addr + 2) << 16));
        out->target = (int32_t)addr + off;
        break;
    }

    case FMT_31i:
        out->aa = (uint8_t)(unit >> 8);
        out->literal = (int32_t)((uint32_t)u16(code, addr + 1) |
                                 ((uint32_t)u16(code, addr + 2) << 16));
        break;

    case FMT_31t:
        out->aa = (uint8_t)(unit >> 8);
        out->payload = (uint32_t)((uint32_t)u16(code, addr + 1) |
                                  ((uint32_t)u16(code, addr + 2) << 16));
        break;

    case FMT_31c:
        out->aa = (uint8_t)(unit >> 8);
        out->idx = (uint32_t)u16(code, addr + 1) | ((uint32_t)u16(code, addr + 2) << 16);
        break;

    case FMT_35c: {
        /* Layout: [op | A(count) | G] [idx] [CDEF]. The index is the second unit
         * and the four 4-bit registers live in the third. */
        out->reg_count = (uint8_t)((unit >> 12) & 0x0f);
        out->idx = u16(code, addr + 1);
        uint16_t r = u16(code, addr + 2);
        out->regs[0] = (uint16_t)(r & 0x0f);
        out->regs[1] = (uint16_t)((r >> 4) & 0x0f);
        out->regs[2] = (uint16_t)((r >> 8) & 0x0f);
        out->regs[3] = (uint16_t)((r >> 12) & 0x0f);
        out->regs[4] = (uint16_t)((unit >> 8) & 0x0f);
        break;
    }

    case FMT_3rc:
        out->reg_count = (uint8_t)(unit >> 8);
        out->first_reg = u16(code, addr + 1);
        out->idx = u16(code, addr + 2);
        break;

    case FMT_51l: {
        out->aa = (uint8_t)(unit >> 8);
        uint64_t lo = (uint64_t)u16(code, addr + 1) | ((uint64_t)u16(code, addr + 2) << 16);
        uint64_t hi = (uint64_t)u16(code, addr + 3) | ((uint64_t)u16(code, addr + 4) << 16);
        out->wide_literal = lo | (hi << 32);
        out->literal = (int32_t)(int64_t)out->wide_literal;
        break;
    }

    case FMT_45cc:
    case FMT_4rcc: {
        /* 5 units: [op|count|G] [CDEF] [idx] [proto]. Same register layout as 35c,
         * with the index one unit earlier and a trailing proto reference. */
        out->reg_count = (uint8_t)((unit >> 12) & 0x0f);
        out->idx = u16(code, addr + 2);
        uint16_t r = u16(code, addr + 1);
        out->regs[0] = (uint16_t)(r & 0x0f);
        out->regs[1] = (uint16_t)((r >> 4) & 0x0f);
        out->regs[2] = (uint16_t)((r >> 8) & 0x0f);
        out->regs[3] = (uint16_t)((r >> 12) & 0x0f);
        out->regs[4] = (uint16_t)((unit >> 8) & 0x0f);
        out->first_reg = u16(code, addr + 1);
        break;
    }

    default:
        return 0;
    }

    return need;
}

/* ---------------------------------------------------------------- */
/* classification                                                    */
/* ---------------------------------------------------------------- */

int insn_is_terminator(const Insn *in)
{
    uint8_t op = in->opcode;
    if (op == OP_GOTO || op == OP_GOTO_16 || op == OP_GOTO_32)
        return 1;
    if (op == OP_RETURN_VOID || op == OP_RETURN || op == OP_RETURN_WIDE ||
        op == OP_RETURN_OBJECT)
        return 1;
    if (op == OP_THROW)
        return 1;
    if (op >= OP_IF_EQ && op <= OP_IF_LEZ)
        return 1;
    if (op == OP_PACKED_SWITCH || op == OP_SPARSE_SWITCH)
        return 1;
    return 0;
}

int insn_is_exit(const Insn *in)
{
    uint8_t op = in->opcode;
    if (op == OP_GOTO || op == OP_GOTO_16 || op == OP_GOTO_32)
        return 1;
    if (op == OP_RETURN_VOID || op == OP_RETURN || op == OP_RETURN_WIDE ||
        op == OP_RETURN_OBJECT)
        return 1;
    if (op == OP_THROW)
        return 1;
    return 0;
}

int insn_target(const Insn *in, int32_t *targets, int max)
{
    uint8_t op = in->opcode;
    if (max < 1)
        return 0;
    if ((op >= OP_IF_EQ && op <= OP_IF_LEZ) ||
        op == OP_GOTO || op == OP_GOTO_16 || op == OP_GOTO_32) {
        targets[0] = in->target;
        return 1;
    }
    return 0;
}

int insn_is_unop(uint8_t op)
{
    return op >= 0x7b && op <= 0x8f;
}

int insn_is_binop(uint8_t op)
{
    return op >= 0x90 && op <= 0xaf;
}

int insn_is_binop_lit(uint8_t op)
{
    return (op >= 0xb0 && op <= 0xcf) || (op >= 0xd0 && op <= 0xe2);
}

const char *insn_binop_symbol(uint8_t opcode)
{
    /* Each arithmetic family is a run of ten opcodes in the same order
     * (add, sub, mul, div, rem, and, or, xor, shl, shr, ushr). Normalise the
     * opcode to its offset within the family before indexing. */
    unsigned idx;
    if (opcode >= 0x90 && opcode <= 0xaf)
        idx = (unsigned)(opcode - 0x90) % 11u;
    else if (opcode >= 0xb0 && opcode <= 0xcf)
        idx = (unsigned)(opcode - 0xb0) % 11u;
    else if (opcode >= 0xd0 && opcode <= 0xd7)
        idx = (unsigned)(opcode - 0xd0);        /* lit16 family */
    else if (opcode >= 0xd8 && opcode <= 0xe2)
        idx = (unsigned)(opcode - 0xd8);        /* lit8 family */
    else
        idx = (unsigned)(opcode & 0x0f);

    switch (idx) {
    case 0x0: return "+";
    case 0x1: return "-";
    case 0x2: return "*";
    case 0x3: return "/";
    case 0x4: return "%";
    case 0x5: return "&";
    case 0x6: return "|";
    case 0x7: return "^";
    case 0x8: return "<<";
    case 0x9: return ">>";
    case 0xa: return ">>>";
    default: return "+";
    }
}

const char *insn_convert_type(uint8_t opcode)
{
    switch (opcode) {
    case 0x81: case 0x82: case 0x83: case 0x8d: case 0x8e: case 0x8f:
        return "int";
    case 0x84: case 0x87: case 0x8a:
        return "int";
    case 0x85: case 0x88: case 0x8b:
        return "long";
    case 0x86: case 0x89: case 0x8c:
        return "float";
    default:
        return NULL;
    }
}

const char *insn_arith_type(uint8_t opcode)
{
    if (opcode >= 0x90 && opcode <= 0x9a)
        return "I";
    if (opcode >= 0x9b && opcode <= 0xa5)
        return "J";
    if (opcode >= 0xa6 && opcode <= 0xaa)
        return "F";
    if (opcode >= 0xab && opcode <= 0xaf)
        return "D";
    if (opcode >= 0xb0 && opcode <= 0xcf)
        return "I";
    if (opcode >= 0xd0 && opcode <= 0xe2)
        return "I";
    return NULL;
}

void insn_format(const Insn *in, char *out, size_t cap)
{
    switch ((InsnFormat)in->fmt) {
    case FMT_10x:
        snprintf(out, cap, "%s", insn_name(in->opcode));
        break;
    case FMT_12x:
        snprintf(out, cap, "%s v%u, v%u", insn_name(in->opcode), in->a, in->b);
        break;
    case FMT_11n:
        snprintf(out, cap, "%s v%u, #%d", insn_name(in->opcode), in->a, in->literal);
        break;
    case FMT_11x:
        snprintf(out, cap, "%s v%u", insn_name(in->opcode), in->aa);
        break;
    case FMT_10t:
        snprintf(out, cap, "%s %04x", insn_name(in->opcode), in->target);
        break;
    case FMT_20t:
        snprintf(out, cap, "%s %04x", insn_name(in->opcode), in->target);
        break;
    case FMT_22x:
        snprintf(out, cap, "%s v%u, v%u", insn_name(in->opcode), in->aa, in->first_reg);
        break;
    case FMT_21t:
        snprintf(out, cap, "%s v%u, %04x", insn_name(in->opcode), in->aa, in->target);
        break;
    case FMT_21s:
        snprintf(out, cap, "%s v%u, #%d", insn_name(in->opcode), in->aa, in->literal);
        break;
    case FMT_21h:
        snprintf(out, cap, "%s v%u, #%d", insn_name(in->opcode), in->aa, in->literal);
        break;
    case FMT_21c:
        snprintf(out, cap, "%s v%u, @%u", insn_name(in->opcode), in->aa, in->idx);
        break;
    case FMT_23x:
        snprintf(out, cap, "%s v%u, v%u, v%u", insn_name(in->opcode), in->aa, in->regs[0],
                 in->regs[1]);
        break;
    case FMT_22b:
        snprintf(out, cap, "%s v%u, v%u, #%d", insn_name(in->opcode), in->aa, in->b,
                 in->literal);
        break;
    case FMT_22t:
        snprintf(out, cap, "%s v%u, v%u, %04x", insn_name(in->opcode), in->a, in->b,
                 in->target);
        break;
    case FMT_22s:
        snprintf(out, cap, "%s v%u, v%u, #%d", insn_name(in->opcode), in->a, in->b,
                 in->literal);
        break;
    case FMT_22c:
        snprintf(out, cap, "%s v%u, v%u, @%u", insn_name(in->opcode), in->a, in->b, in->idx);
        break;
    case FMT_32x:
        snprintf(out, cap, "%s v%u, v%u", insn_name(in->opcode), in->aa, in->first_reg);
        break;
    case FMT_30t:
        snprintf(out, cap, "%s %04x", insn_name(in->opcode), in->target);
        break;
    case FMT_31i:
        snprintf(out, cap, "%s v%u, #%d", insn_name(in->opcode), in->aa, in->literal);
        break;
    case FMT_31t:
        snprintf(out, cap, "%s v%u, %04x", insn_name(in->opcode), in->aa, in->payload);
        break;
    case FMT_31c:
        snprintf(out, cap, "%s v%u, @%u", insn_name(in->opcode), in->aa, in->idx);
        break;
    case FMT_35c: {
        char regs[64];
        int o = 0;
        for (uint8_t i = 0; i < in->reg_count && o < 60; i++)
            o += snprintf(regs + o, sizeof(regs) - (size_t)o, i ? ", v%u" : "v%u", in->regs[i]);
        snprintf(out, cap, "%s {%s}, @%u", insn_name(in->opcode), regs, in->idx);
        break;
    }
    case FMT_3rc:
        snprintf(out, cap, "%s {v%u .. v%u}, @%u", insn_name(in->opcode), in->first_reg,
                 in->first_reg + in->reg_count - 1, in->idx);
        break;
    case FMT_51l:
        snprintf(out, cap, "%s v%u, #%lld", insn_name(in->opcode), in->aa,
                 (long long)in->wide_literal);
        break;
    case FMT_45cc:
    case FMT_4rcc:
        snprintf(out, cap, "%s {%u regs}, @%u", insn_name(in->opcode), in->reg_count, in->idx);
        break;
    default:
        snprintf(out, cap, "<invalid>");
        break;
    }
}
