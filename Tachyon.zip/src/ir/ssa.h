#ifndef TACHYON_IR_SSA_H
#define TACHYON_IR_SSA_H

#include <stdint.h>

#include "common/arena.h"
#include "ir/cfg.h"

#define SSA_INLINE_USES 8
#define SSA_NO_INDEX 0xffffffffu
#define SSA_NO_VALUE 0xffffffffu

typedef struct {
    uint16_t reg;
    uint8_t width;
} SsaRegRef;

typedef enum {
    SSA_VALUE_INITIAL,
    SSA_VALUE_DEF,
    SSA_VALUE_PHI
} SsaValueKind;

typedef struct {
    uint32_t id;
    uint32_t reg;
    uint32_t block_id;
    uint32_t instr_index;
    SsaValueKind kind;
    uint8_t width;
} SsaValue;

typedef struct {
    uint32_t id;
    uint32_t block_id;
    uint32_t reg;
    uint8_t width;
    uint32_t value_id;
    uint32_t input_count;
    uint32_t *inputs; /* one value per CFG predecessor, in pred-list order */
} SsaPhi;

typedef struct {
    uint32_t index;
    uint32_t raw_index;
    uint32_t block_id;
    uint32_t addr;
    uint32_t end_addr;
    uint8_t opcode;
    uint8_t result_opcode;
    uint8_t has_result;
    uint8_t def_count;
    uint8_t malformed;
    uint8_t reserved;
    SsaRegRef def[1];
    uint32_t def_value;
    SsaRegRef *use;
    uint32_t *use_values;
    uint32_t use_count;
    uint32_t use_capacity;
    const Insn *raw;
    const Insn *result;
} SsaInstr;

typedef struct {
    CfgMethod *cfg;
    SsaInstr *insns;
    uint32_t count;
    uint32_t raw_count;

    uint32_t reg_count;
    uint32_t *initial_values;
    SsaValue *values;
    uint32_t value_count;
    uint32_t value_capacity;

    SsaPhi *phis;
    uint32_t phi_count;
    uint32_t phi_capacity;
    uint32_t **block_phis;
    uint32_t *block_phi_count;
    uint32_t *block_phi_capacity;

    uint32_t *raw_to_norm;
    uint8_t malformed;
} SsaMethod;

/* Builds a normalized instruction stream, places phi nodes at dominance
 * frontiers, and renames register definitions into SSA values. */
SsaMethod *ssa_build(CfgMethod *cfg, Arena *arena);

/* Checks normalized instructions, phi inputs, and value references. */
int ssa_validate(const SsaMethod *method);

#endif
