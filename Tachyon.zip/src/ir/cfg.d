src/ir/cfg.o: src/ir/cfg.c src/ir/cfg.h src/common/arena.h src/dex/dex.h \
 src/common/buf.h src/common/io.h src/ir/opcode.h

src/ir/cfg.h:

src/common/arena.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/ir/opcode.h:
