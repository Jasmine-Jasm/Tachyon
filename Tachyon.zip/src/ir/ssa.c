#include "ir/ssa.h"

#include <string.h>

static int is_invoke(uint8_t op)
{
    return (op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) ||
           (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE) ||
           op == OP_INVOKE_POLYMORPHIC || op == OP_INVOKE_POLYMORPHIC_RANGE ||
           op == OP_INVOKE_CUSTOM || op == OP_INVOKE_CUSTOM_RANGE;
}

static int is_move_result(uint8_t op)
{
    return op == OP_MOVE_RESULT || op == OP_MOVE_RESULT_WIDE ||
           op == OP_MOVE_RESULT_OBJECT;
}

static int is_move(uint8_t op)
{
    return op == OP_MOVE || op == OP_MOVE_FROM16 || op == OP_MOVE_16 ||
           op == OP_MOVE_WIDE || op == OP_MOVE_WIDE_FROM16 || op == OP_MOVE_WIDE_16 ||
           op == OP_MOVE_OBJECT || op == OP_MOVE_OBJECT_FROM16 || op == OP_MOVE_OBJECT_16;
}

static int is_const(uint8_t op)
{
    return op >= OP_CONST_4 && op <= OP_CONST_CLASS;
}

static int is_field_get(uint8_t op)
{
    return (op >= OP_IGET && op <= OP_IGET_SHORT) ||
           (op >= OP_SGET && op <= OP_SGET_SHORT);
}

static int is_array_get(uint8_t op)
{
    return op >= OP_AGET && op <= OP_AGET_SHORT;
}

static int is_arithmetic(uint8_t op)
{
    return insn_is_unop(op) || insn_is_binop(op) || insn_is_binop_lit(op);
}

static uint8_t unop_def_width(uint8_t op)
{
    switch (op) {
    case 0x7d: case 0x7e: case 0x80:
    case 0x81: case 0x83: case 0x86: case 0x88: case 0x89: case 0x8b:
        return 2;
    default:
        return 1;
    }
}

static uint8_t unop_use_width(uint8_t op)
{
    switch (op) {
    case 0x7d: case 0x7e: case 0x80:
    case 0x84: case 0x85: case 0x86:
    case 0x8a: case 0x8b: case 0x8c:
        return 2;
    default:
        return 1;
    }
}

static int is_wide_binop(uint8_t op)
{
    return (op >= 0x9b && op <= 0xa5) ||
           (op >= 0xab && op <= 0xaf) ||
           (op >= 0xbb && op <= 0xc5) ||
           (op >= 0xcb && op <= 0xcf);
}

static int is_invoke_like(uint8_t op)
{
    return is_invoke(op) || op == OP_FILLED_NEW_ARRAY || op == OP_FILLED_NEW_ARRAY_RANGE;
}

static int is_range_invoke(uint8_t op)
{
    return (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE) ||
           op == OP_INVOKE_POLYMORPHIC_RANGE || op == OP_INVOKE_CUSTOM_RANGE ||
           op == OP_FILLED_NEW_ARRAY_RANGE;
}

static int add_use(SsaInstr *out, Arena *arena, uint32_t reg, uint8_t width)
{
    if (reg > UINT16_MAX) {
        out->malformed = 1;
        return 0;
    }
    if (out->use_count == out->use_capacity) {
        uint32_t next = out->use_capacity ? out->use_capacity * 2 : SSA_INLINE_USES;
        SsaRegRef *refs = arena_alloc(arena, (size_t)next * sizeof(*refs));
        uint32_t *values = arena_alloc(arena, (size_t)next * sizeof(*values));
        if (!refs || !values) {
            out->malformed = 1;
            return 0;
        }
        if (out->use_count) {
            memcpy(refs, out->use, (size_t)out->use_count * sizeof(*refs));
            memcpy(values, out->use_values, (size_t)out->use_count * sizeof(*values));
        }
        out->use = refs;
        out->use_values = values;
        out->use_capacity = next;
    }
    out->use[out->use_count].reg = (uint16_t)reg;
    out->use[out->use_count].width = width;
    out->use_values[out->use_count] = SSA_NO_VALUE;
    out->use_count++;
    return 1;
}

static int add_def(SsaInstr *out, uint32_t reg, uint8_t width)
{
    if (out->def_count >= 1 || reg > UINT16_MAX) {
        out->malformed = 1;
        return 0;
    }
    out->def[0].reg = (uint16_t)reg;
    out->def[0].width = width;
    out->def_count = 1;
    out->def_value = SSA_NO_VALUE;
    return 1;
}

static void fill_regs(const Insn *in, SsaInstr *out, Arena *arena)
{
    uint8_t op = in->opcode;

    if (is_move(op)) {
        int wide = op >= OP_MOVE_WIDE && op <= OP_MOVE_WIDE_16;
        uint32_t dst = (in->fmt == FMT_12x) ? in->a : in->aa;
        uint32_t src = (in->fmt == FMT_12x) ? in->b : in->first_reg;
        add_def(out, dst, wide ? 2 : 1);
        add_use(out, arena, src, wide ? 2 : 1);
        return;
    }
    if (is_const(op)) {
        uint32_t dst = op == OP_CONST_4 ? in->a : in->aa;
        add_def(out, dst, (op >= OP_CONST_WIDE_16 && op <= OP_CONST_WIDE_HIGH16) ? 2 : 1);
        return;
    }
    if (op == OP_MOVE_EXCEPTION || op == OP_CONST_METHOD_HANDLE || op == OP_CONST_METHOD_TYPE) {
        add_def(out, in->aa, 1);
        return;
    }
    if (is_field_get(op)) {
        if (op >= OP_SGET && op <= OP_SGET_SHORT)
            add_def(out, in->aa, op == OP_SGET_WIDE ? 2 : 1);
        else {
            add_def(out, in->a, op == OP_IGET_WIDE ? 2 : 1);
            add_use(out, arena, in->b, 1);
        }
        return;
    }
    if (op >= OP_IPUT && op <= OP_IPUT_SHORT) {
        add_use(out, arena, in->a, op == OP_IPUT_WIDE ? 2 : 1);
        add_use(out, arena, in->b, 1);
        return;
    }
    if (op >= OP_SPUT && op <= OP_SPUT_SHORT) {
        add_use(out, arena, in->aa, op == OP_SPUT_WIDE ? 2 : 1);
        return;
    }
    if (is_array_get(op)) {
        add_def(out, in->aa, op == OP_AGET_WIDE ? 2 : 1);
        add_use(out, arena, in->regs[0], 1);
        add_use(out, arena, in->regs[1], 1);
        return;
    }
    if (op >= OP_APUT && op <= OP_APUT_SHORT) {
        add_use(out, arena, in->aa, op == OP_APUT_WIDE ? 2 : 1);
        add_use(out, arena, in->regs[0], 1);
        add_use(out, arena, in->regs[1], 1);
        return;
    }
    if (op == OP_ARRAY_LENGTH) {
        add_def(out, in->a, 1);
        add_use(out, arena, in->b, 1);
        return;
    }
    if (op == OP_NEW_INSTANCE || op == OP_NEW_ARRAY) {
        add_def(out, op == OP_NEW_ARRAY ? in->a : in->aa, 1);
        if (op == OP_NEW_ARRAY)
            add_use(out, arena, in->b, 1);
        return;
    }
    if (op == OP_FILLED_NEW_ARRAY || op == OP_FILLED_NEW_ARRAY_RANGE) {
        for (uint32_t i = 0; i < in->reg_count; i++) {
            uint32_t reg = op == OP_FILLED_NEW_ARRAY_RANGE
                               ? (uint32_t)in->first_reg + i
                               : in->regs[i];
            add_use(out, arena, reg, 1);
        }
        return;
    }
    if (op == OP_CHECK_CAST) {
        add_def(out, in->aa, 1);
        add_use(out, arena, in->aa, 1);
        return;
    }
    if (op == OP_INSTANCE_OF) {
        add_def(out, in->a, 1);
        add_use(out, arena, in->b, 1);
        return;
    }
    if (op == OP_THROW || op == OP_RETURN || op == OP_RETURN_WIDE ||
        op == OP_RETURN_OBJECT || op == OP_MONITOR_ENTER || op == OP_MONITOR_EXIT) {
        add_use(out, arena, in->aa, op == OP_RETURN_WIDE ? 2 : 1);
        return;
    }
    if (op >= OP_CMPL_FLOAT && op <= OP_CMP_LONG) {
        uint8_t width = op >= OP_CMPL_DOUBLE ? 2 : 1;
        add_def(out, in->aa, 1);
        add_use(out, arena, in->regs[0], width);
        add_use(out, arena, in->regs[1], width);
        return;
    }
    if (op == OP_PACKED_SWITCH || op == OP_SPARSE_SWITCH || op == OP_FILL_ARRAY_DATA) {
        add_use(out, arena, in->aa, 1);
        return;
    }
    if (op >= OP_IF_EQ && op <= OP_IF_LE) {
        add_use(out, arena, in->a, 1);
        add_use(out, arena, in->b, 1);
        return;
    }
    if (op >= OP_IF_EQZ && op <= OP_IF_LEZ) {
        add_use(out, arena, in->aa, 1);
        return;
    }
    if (is_arithmetic(op)) {
        if (op >= 0xb0 && op <= 0xcf) {
            int wide = is_wide_binop(op);
            add_def(out, in->a, wide ? 2 : 1);
            add_use(out, arena, in->a, wide ? 2 : 1);
            add_use(out, arena, in->b, wide ? 2 : 1);
        } else if (op >= 0xd0 && op <= 0xe2) {
            add_def(out, in->aa, 1);
            add_use(out, arena, in->b, 1);
        } else if (insn_is_unop(op)) {
            add_def(out, in->a, unop_def_width(op));
            add_use(out, arena, in->b, unop_use_width(op));
        } else {
            int wide = is_wide_binop(op);
            add_def(out, in->aa, wide ? 2 : 1);
            add_use(out, arena, in->regs[0], wide ? 2 : 1);
            add_use(out, arena, in->regs[1], wide ? 2 : 1);
        }
        return;
    }
    if (is_invoke(op)) {
        for (uint32_t i = 0; i < in->reg_count; i++) {
            uint32_t reg = is_range_invoke(op) ? (uint32_t)in->first_reg + i : in->regs[i];
            add_use(out, arena, reg, 1);
        }
    }
}

static int raw_pair(const Insn *prev, const Insn *result)
{
    return prev && result && is_invoke_like(prev->opcode) &&
           is_move_result(result->opcode) &&
           prev->addr + prev->len == result->addr;
}

static uint32_t normalized_count(const CfgMethod *cfg)
{
    uint32_t count = 0;
    const Insn *prev = NULL;
    for (uint32_t bi = 0; bi < cfg->block_count; bi++) {
        const CfgBlock *block = &cfg->blocks[bi];
        for (uint32_t i = 0; i < block->insn_count; i++) {
            const Insn *in = &cfg->insns[block->insn_start + i];
            if (!raw_pair(prev, in))
                count++;
            prev = in;
        }
    }
    return count;
}

typedef struct {
    uint32_t reg;
    uint32_t block;
} DefSite;

static int vec_add(Arena *arena, uint32_t **items, uint32_t *count, uint32_t *cap, uint32_t value)
{
    for (uint32_t i = 0; i < *count; i++)
        if ((*items)[i] == value)
            return 1;
    if (*count == *cap) {
        uint32_t next = *cap ? *cap * 2 : 4;
        uint32_t *copy = arena_alloc(arena, (size_t)next * sizeof(*copy));
        if (!copy)
            return 0;
        if (*count)
            memcpy(copy, *items, (size_t)*count * sizeof(*copy));
        *items = copy;
        *cap = next;
    }
    (*items)[(*count)++] = value;
    return 1;
}

static int reserve_values(SsaMethod *m, Arena *arena, uint32_t need)
{
    if (m->value_capacity >= need)
        return 1;
    uint32_t cap = m->value_capacity ? m->value_capacity * 2 : 16;
    if (cap < need)
        cap = need;
    SsaValue *copy = arena_alloc(arena, (size_t)cap * sizeof(*copy));
    if (!copy)
        return 0;
    if (m->value_count)
        memcpy(copy, m->values, (size_t)m->value_count * sizeof(*copy));
    m->values = copy;
    m->value_capacity = cap;
    return 1;
}

static uint32_t add_value(SsaMethod *m, Arena *arena, uint32_t reg, uint32_t block,
                          uint32_t instr, SsaValueKind kind, uint8_t width)
{
    if (!reserve_values(m, arena, m->value_count + 1)) {
        m->malformed = 1;
        return SSA_NO_VALUE;
    }
    uint32_t id = m->value_count++;
    m->values[id] = (SsaValue){id, reg, block, instr, kind, width};
    return id;
}

static int add_phi(SsaMethod *m, Arena *arena, uint32_t block, uint32_t reg, uint8_t width)
{
    for (uint32_t i = 0; i < m->block_phi_count[block]; i++) {
        uint32_t id = m->block_phis[block][i];
        if (m->phis[id].reg == reg)
            return 1;
    }
    if (m->phi_count == m->phi_capacity) {
        uint32_t cap = m->phi_capacity ? m->phi_capacity * 2 : 16;
        SsaPhi *copy = arena_alloc(arena, (size_t)cap * sizeof(*copy));
        if (!copy)
            return 0;
        if (m->phi_count)
            memcpy(copy, m->phis, (size_t)m->phi_count * sizeof(*copy));
        m->phis = copy;
        m->phi_capacity = cap;
    }
    uint32_t id = m->phi_count++;
    SsaPhi *phi = &m->phis[id];
    memset(phi, 0, sizeof(*phi));
    phi->id = id;
    phi->block_id = block;
    phi->reg = reg;
    phi->width = width;
    phi->value_id = add_value(m, arena, reg, block, SSA_NO_INDEX, SSA_VALUE_PHI, width);
    if (phi->value_id == SSA_NO_VALUE)
        return 0;
    phi->input_count = m->cfg->blocks[block].pred_count;
    if (phi->input_count) {
        phi->inputs = arena_alloc(arena, (size_t)phi->input_count * sizeof(*phi->inputs));
        if (!phi->inputs)
            return 0;
        for (uint32_t i = 0; i < phi->input_count; i++)
            phi->inputs[i] = SSA_NO_VALUE;
    }
    if (!vec_add(arena, &m->block_phis[block], &m->block_phi_count[block],
                 &m->block_phi_capacity[block], id))
        return 0;
    return 1;
}

static int find_phi(const SsaMethod *m, uint32_t block, uint32_t reg, uint32_t *out)
{
    for (uint32_t i = 0; i < m->block_phi_count[block]; i++) {
        uint32_t id = m->block_phis[block][i];
        if (m->phis[id].reg == reg) {
            if (out)
                *out = id;
            return 1;
        }
    }
    return 0;
}

static void build_frontiers(CfgMethod *cfg, Arena *arena, uint32_t ***out_df,
                            uint32_t **out_count, uint32_t **out_cap)
{
    uint32_t n = cfg->block_count;
    uint32_t **df = arena_zalloc(arena, (size_t)n * sizeof(*df));
    uint32_t *counts = arena_zalloc(arena, (size_t)n * sizeof(*counts));
    uint32_t *caps = arena_zalloc(arena, (size_t)n * sizeof(*caps));
    if (!df || !counts || !caps) {
        *out_df = NULL;
        return;
    }
    for (uint32_t b = 0; b < n; b++) {
        if (cfg->blocks[b].pred_count < 2 || cfg->blocks[b].idom == CFG_NO_BLOCK)
            continue;
        for (uint32_t p = 0; p < cfg->blocks[b].pred_count; p++) {
            uint32_t runner = cfg->blocks[b].pred[p];
            while (runner != CFG_NO_BLOCK && runner != cfg->blocks[b].idom) {
                if (!vec_add(arena, &df[runner], &counts[runner], &caps[runner], b)) {
                    *out_df = NULL;
                    return;
                }
                runner = cfg->blocks[runner].idom;
            }
        }
    }
    *out_df = df;
    *out_count = counts;
    *out_cap = caps;
}

static int has_def_site(const DefSite *defs, uint32_t count, uint32_t reg, uint32_t block)
{
    for (uint32_t i = 0; i < count; i++)
        if (defs[i].reg == reg && defs[i].block == block)
            return 1;
    return 0;
}

static int insert_phis(SsaMethod *m, Arena *arena, const DefSite *defs, uint32_t def_count)
{
    uint32_t **df = NULL, *df_count = NULL, *df_cap = NULL;
    build_frontiers(m->cfg, arena, &df, &df_count, &df_cap);
    if (!df)
        return 0;
    size_t queue_capacity = (size_t)m->reg_count * m->cfg->block_count + def_count + 1;
    if (queue_capacity > SIZE_MAX / sizeof(uint32_t))
        return 0;
    uint32_t *queue = arena_alloc(arena, queue_capacity * sizeof(*queue));
    if (!queue)
        return 0;
    for (uint32_t reg = 0; reg < m->reg_count; reg++) {
        uint32_t head = 0, tail = 0;
        for (uint32_t i = 0; i < def_count; i++)
            if (defs[i].reg == reg && tail < queue_capacity)
                queue[tail++] = defs[i].block;
        while (head < tail) {
            uint32_t x = queue[head++];
            for (uint32_t i = 0; i < df_count[x]; i++) {
                uint32_t y = df[x][i];
                if (find_phi(m, y, reg, NULL))
                    continue;
                if (!add_phi(m, arena, y, reg, 1))
                    return 0;
                if (!has_def_site(defs, def_count, reg, y) && tail < queue_capacity)
                    queue[tail++] = y;
            }
        }
    }
    return 1;
}

typedef struct {
    uint32_t reg;
    uint32_t old_value;
} Change;

typedef struct {
    SsaMethod *method;
    Arena *arena;
    uint32_t *current;
} RenameCtx;

static uint32_t pred_index(const CfgBlock *block, uint32_t pred)
{
    for (uint32_t i = 0; i < block->pred_count; i++)
        if (block->pred[i] == pred)
            return i;
    return SSA_NO_INDEX;
}

static void rename_block(RenameCtx *ctx, uint32_t block_id)
{
    SsaMethod *m = ctx->method;
    CfgBlock *block = &m->cfg->blocks[block_id];
    uint32_t max_changes = m->block_phi_count[block_id] + block->insn_count + 1;
    Change *changes = arena_alloc(ctx->arena, (size_t)(max_changes + 1) * sizeof(*changes));
    uint32_t change_count = 0;
    if (!changes) {
        m->malformed = 1;
        return;
    }

    for (uint32_t i = 0; i < m->block_phi_count[block_id]; i++) {
        SsaPhi *phi = &m->phis[m->block_phis[block_id][i]];
        if (phi->reg >= m->reg_count || change_count > max_changes) {
            m->malformed = 1;
            continue;
        }
        changes[change_count++] = (Change){phi->reg, ctx->current[phi->reg]};
        ctx->current[phi->reg] = phi->value_id;
    }

    uint32_t last_norm = SSA_NO_INDEX;
    for (uint32_t i = 0; i < block->insn_count; i++) {
        uint32_t raw_index = block->insn_start + i;
        if (raw_index >= m->raw_count)
            break;
        uint32_t norm_index = m->raw_to_norm[raw_index];
        if (norm_index == SSA_NO_INDEX || norm_index == last_norm)
            continue;
        last_norm = norm_index;
        SsaInstr *in = &m->insns[norm_index];
        if (in->block_id != block_id)
            continue;
        for (uint32_t u = 0; u < in->use_count; u++) {
            uint32_t reg = in->use[u].reg;
            if (reg >= m->reg_count) {
                in->malformed = 1;
                m->malformed = 1;
            } else {
                in->use_values[u] = ctx->current[reg];
            }
        }
        if (in->def_count) {
            uint32_t reg = in->def[0].reg;
            if (reg >= m->reg_count || change_count > max_changes) {
                in->malformed = 1;
                m->malformed = 1;
            } else {
                changes[change_count++] = (Change){reg, ctx->current[reg]};
                in->def_value = add_value(m, ctx->arena, reg, block_id, in->index,
                                          SSA_VALUE_DEF, in->def[0].width);
                if (in->def_value == SSA_NO_VALUE)
                    m->malformed = 1;
                else
                    ctx->current[reg] = in->def_value;
            }
        }
    }

    for (uint32_t s = 0; s < block->succ_count; s++) {
        uint32_t succ_id = block->succ[s];
        if (succ_id >= m->cfg->block_count)
            continue;
        uint32_t pi = pred_index(&m->cfg->blocks[succ_id], block_id);
        if (pi == SSA_NO_INDEX)
            continue;
        for (uint32_t p = 0; p < m->block_phi_count[succ_id]; p++) {
            SsaPhi *phi = &m->phis[m->block_phis[succ_id][p]];
            phi->inputs[pi] = phi->reg < m->reg_count ? ctx->current[phi->reg] : SSA_NO_VALUE;
        }
    }

    for (uint32_t child = 0; child < m->cfg->block_count; child++)
        if (child != block_id && m->cfg->blocks[child].idom == block_id)
            rename_block(ctx, child);

    while (change_count) {
        Change change = changes[--change_count];
        ctx->current[change.reg] = change.old_value;
    }
}

SsaMethod *ssa_build(CfgMethod *cfg, Arena *arena)
{
    if (!cfg || !arena)
        return NULL;
    SsaMethod *m = arena_zalloc(arena, sizeof(*m));
    if (!m)
        return NULL;
    m->cfg = cfg;
    m->reg_count = cfg->code ? cfg->code->registers_size : 0;
    m->raw_count = 0;
    for (uint32_t b = 0; b < cfg->block_count; b++)
        m->raw_count += cfg->blocks[b].insn_count;
    m->count = normalized_count(cfg);
    m->insns = arena_zalloc(arena, (size_t)m->count * sizeof(*m->insns));
    m->raw_to_norm = arena_zalloc(arena, (size_t)m->raw_count * sizeof(*m->raw_to_norm));
    m->initial_values = arena_alloc(arena, (size_t)m->reg_count * sizeof(*m->initial_values));
    m->block_phis = arena_zalloc(arena, (size_t)cfg->block_count * sizeof(*m->block_phis));
    m->block_phi_count = arena_zalloc(arena, (size_t)cfg->block_count * sizeof(*m->block_phi_count));
    m->block_phi_capacity = arena_zalloc(arena, (size_t)cfg->block_count * sizeof(*m->block_phi_capacity));
    if ((m->count && !m->insns) || (m->raw_count && !m->raw_to_norm) ||
        (m->reg_count && !m->initial_values) || !m->block_phis ||
        !m->block_phi_count || !m->block_phi_capacity)
        return NULL;
    for (uint32_t i = 0; i < m->raw_count; i++)
        m->raw_to_norm[i] = SSA_NO_INDEX;

    uint32_t raw_index = 0, norm_index = 0;
    const Insn *prev = NULL;
    for (uint32_t bi = 0; bi < cfg->block_count; bi++) {
        CfgBlock *block = &cfg->blocks[bi];
        for (uint32_t i = 0; i < block->insn_count; i++, raw_index++) {
            const Insn *in = &cfg->insns[block->insn_start + i];
            if (raw_pair(prev, in)) {
                SsaInstr *logical = &m->insns[norm_index - 1];
                logical->result = in;
                logical->result_opcode = in->opcode;
                logical->has_result = 1;
                if (!add_def(logical, in->aa, in->opcode == OP_MOVE_RESULT_WIDE ? 2 : 1))
                    m->malformed = 1;
                m->raw_to_norm[raw_index] = norm_index - 1;
                logical->end_addr = in->addr + in->len;
                prev = in;
                continue;
            }
            SsaInstr *logical = &m->insns[norm_index];
            memset(logical, 0, sizeof(*logical));
            logical->index = norm_index;
            logical->raw_index = raw_index;
            logical->def_value = SSA_NO_VALUE;
            logical->block_id = bi;
            logical->addr = in->addr;
            logical->end_addr = in->addr + in->len;
            logical->opcode = in->opcode;
            logical->raw = in;
            fill_regs(in, logical, arena);
            if (is_move_result(in->opcode))
                logical->malformed = 1;
            m->raw_to_norm[raw_index] = norm_index++;
            prev = in;
        }
    }

    for (uint32_t r = 0; r < m->reg_count; r++) {
        m->initial_values[r] = add_value(m, arena, r, cfg->entry, SSA_NO_INDEX, SSA_VALUE_INITIAL, 1);
        if (m->initial_values[r] == SSA_NO_VALUE)
            m->malformed = 1;
    }

    DefSite *defs = arena_alloc(arena, (size_t)(m->count + 1) * sizeof(*defs));
    uint32_t def_count = 0;
    if (!defs)
        return NULL;
    for (uint32_t i = 0; i < m->count; i++)
        if (m->insns[i].def_count)
            defs[def_count++] = (DefSite){m->insns[i].def[0].reg, m->insns[i].block_id};

    cfg_compute_dominators(cfg, arena);
    if (!insert_phis(m, arena, defs, def_count))
        m->malformed = 1;
    RenameCtx ctx = {m, arena, arena_alloc(arena, (size_t)(m->reg_count + 1) * sizeof(uint32_t))};
    if (!ctx.current) {
        m->malformed = 1;
        return m;
    }
    for (uint32_t r = 0; r < m->reg_count; r++)
        ctx.current[r] = m->initial_values[r];
    rename_block(&ctx, cfg->entry);
    return m;
}

int ssa_validate(const SsaMethod *m)
{
    if (!m || !m->cfg || m->malformed || m->count > m->raw_count)
        return -1;
    for (uint32_t r = 0; r < m->reg_count; r++)
        if (m->initial_values[r] >= m->value_count)
            return -1;
    for (uint32_t i = 0; i < m->count; i++) {
        const SsaInstr *in = &m->insns[i];
        if (!in->raw || in->index != i || in->raw_index >= m->raw_count || in->malformed ||
            in->addr >= m->cfg->code->insns_size || in->end_addr <= in->addr)
            return -1;
        if (i && m->insns[i - 1].addr >= in->addr)
            return -1;
        if (in->def_count && in->def_value >= m->value_count)
            return -1;
        for (uint32_t u = 0; u < in->use_count; u++)
            if (!in->use[u].width || in->use_values[u] >= m->value_count)
                return -1;
    }
    for (uint32_t i = 0; i < m->phi_count; i++) {
        const SsaPhi *phi = &m->phis[i];
        if (phi->value_id >= m->value_count || phi->block_id >= m->cfg->block_count ||
            phi->input_count != m->cfg->blocks[phi->block_id].pred_count)
            return -1;
        for (uint32_t p = 0; p < phi->input_count; p++)
            if (phi->inputs[p] >= m->value_count)
                return -1;
    }
    for (uint32_t i = 0; i < m->raw_count; i++)
        if (m->raw_to_norm[i] == SSA_NO_INDEX || m->raw_to_norm[i] >= m->count)
            return -1;
    return 0;
}
