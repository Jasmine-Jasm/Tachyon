src/ir/type_infer.o: src/ir/type_infer.c src/ir/type_infer.h \
 src/common/arena.h src/ir/ssa.h src/ir/cfg.h src/dex/dex.h \
 src/common/buf.h src/common/io.h src/ir/opcode.h

src/ir/type_infer.h:

src/common/arena.h:

src/ir/ssa.h:

src/ir/cfg.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/ir/opcode.h:
