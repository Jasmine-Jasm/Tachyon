#include "ir/emulate.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* A register file plus a step budget. The interpreter is deliberately small: it
 * exists to run generated decryption helpers, not arbitrary code. Any opcode it
 * does not implement aborts the evaluation, and the caller then leaves the
 * original literal in place. */

typedef struct {
    EmuValue *regs;
    uint32_t nregs;
    EmuResult out;
    EmuValue last_result; /* what move-result reads */
    int aborted;
    Arena *arena;
    Dex *d;
} Frame;

static void set_unknown(Frame *f)
{
    f->aborted = 1;
}

static EmuObj *mk_obj(Frame *f, char tag, uint32_t n)
{
    EmuObj *o = arena_zalloc(f->arena, sizeof(*o));
    if (!o) {
        set_unknown(f);
        return NULL;
    }
    o->tag = tag;
    o->arena = f->arena;
    if (n) {
        o->elems = arena_zalloc(f->arena, (size_t)n * sizeof(EmuValue));
        if (!o->elems) {
            set_unknown(f);
            return NULL;
        }
    }
    o->len = n;
    return o;
}

static EmuObj *mk_string(Frame *f, const char *s)
{
    size_t n = strlen(s);
    EmuObj *o = mk_obj(f, 'S', 0);
    if (!o)
        return NULL;
    o->chars = arena_alloc(f->arena, n + 1);
    if (!o->chars) {
        set_unknown(f);
        return NULL;
    }
    memcpy(o->chars, s, n + 1);
    o->chars_len = n;
    o->chars_cap = n + 1;
    return o;
}

static EmuObj *mk_sb(Frame *f)
{
    EmuObj *o = mk_obj(f, 'B', 0);
    if (!o)
        return NULL;
    o->chars_cap = 32;
    o->chars = arena_alloc(f->arena, o->chars_cap);
    if (!o->chars) {
        set_unknown(f);
        return NULL;
    }
    o->chars[0] = '\0';
    o->chars_len = 0;
    return o;
}

static int sb_append(EmuObj *o, const char *s, size_t n)
{
    if (o->chars_len + n + 1 > o->chars_cap) {
        size_t cap = o->chars_cap ? o->chars_cap : 32;
        while (cap < o->chars_len + n + 1)
            cap *= 2;
        char *p = arena_alloc(o->arena, cap);
        if (!p)
            return 0;
        memcpy(p, o->chars, o->chars_len);
        o->chars = p;
        o->chars_cap = cap;
    }
    memcpy(o->chars + o->chars_len, s, n);
    o->chars_len += n;
    o->chars[o->chars_len] = '\0';
    return 1;
}

/* ------------------------------------------------------------------ */
/* tiny java.lang.String / StringBuilder shims                        */
/* ------------------------------------------------------------------ */

static int call_jdk(Frame *f, const char *cls, const char *name, const EmuValue *args,
                    uint32_t nargs, EmuValue *ret)
{
    ret->kind = EMU_NULL;

    if (!strcmp(cls, "java/lang/StringBuilder") || !strcmp(cls, "java/lang/StringBuffer")) {
        EmuObj *receiver = args[0].kind == EMU_OBJ ? args[0].v.o : NULL;
        if (!receiver)
            return 0;
        if (!strcmp(name, "<init>")) {
            /* Already a fresh builder; nothing to do. */
            ret->kind = EMU_OBJ;
            ret->v.o = receiver;
            return 1;
        }
        if (!strcmp(name, "append")) {
            if (nargs < 2)
                return 0;
            char buf[64];
            switch (args[1].kind) {
            case EMU_CHAR: {
                char cb = (char)(args[1].v.i & 0xff);
                sb_append(receiver, &cb, 1);
                break;
            }
            case EMU_INT:
                snprintf(buf, sizeof(buf), "%d", args[1].v.i);
                sb_append(receiver, buf, strlen(buf));
                break;
            case EMU_LONG:
                snprintf(buf, sizeof(buf), "%lld", (long long)args[1].v.j);
                sb_append(receiver, buf, strlen(buf));
                break;
            case EMU_OBJ:
                if (args[1].v.o && args[1].v.o->tag == 'S')
                    sb_append(receiver, args[1].v.o->chars, args[1].v.o->chars_len);
                else if (args[1].v.o == NULL) {
                    sb_append(receiver, "null", 4);
                } else {
                    return 0;
                }
                break;
            case EMU_NULL:
                sb_append(receiver, "null", 4);
                break;
            default:
                return 0;
            }
            ret->kind = EMU_OBJ;
            ret->v.o = receiver;
            return 1;
        }
        if (!strcmp(name, "toString")) {
            ret->kind = EMU_OBJ;
            ret->v.o = mk_string(f, receiver->chars);
            return 1;
        }
        return 0;
    }

    if (!strcmp(cls, "java/lang/String")) {
        if (!strcmp(name, "<init>")) {
            /* new String(char[]) / new String(byte[]) */
            if (nargs >= 2 && args[1].kind == EMU_OBJ && args[1].v.o &&
                args[1].v.o->tag == '[') {
                EmuObj *arr = args[1].v.o;
                char *buf = arena_alloc(f->arena, arr->len + 1);
                if (!buf) {
                    set_unknown(f);
                    return 0;
                }
                for (uint32_t i = 0; i < arr->len; i++) {
                    int c = 0;
                    if (arr->elems[i].kind == EMU_INT)
                        c = arr->elems[i].v.i;
                    else if (arr->elems[i].kind == EMU_LONG)
                        c = (int)arr->elems[i].v.j;
                    buf[i] = (char)(c & 0x7f);
                }
                buf[arr->len] = '\0';
                ret->kind = EMU_OBJ;
                ret->v.o = mk_string(f, buf);
                return 1;
            }
            ret->kind = EMU_OBJ;
            ret->v.o = mk_string(f, "");
            return 1;
        }
        if (!strcmp(name, "length") && nargs >= 1 && args[0].kind == EMU_OBJ) {
            ret->kind = EMU_INT;
            ret->v.i = (int32_t)args[0].v.o->chars_len;
            return 1;
        }
        if (!strcmp(name, "charAt")) {
            if (nargs >= 2 && args[0].kind == EMU_OBJ && args[0].v.o->tag == 'S' &&
                args[1].kind == EMU_INT) {
                int32_t k = args[1].v.i;
                if (k < 0 || (size_t)k >= args[0].v.o->chars_len) {
                    ret->kind = EMU_INT;
                    ret->v.i = 0;
                    return 1;
                }
                ret->kind = EMU_CHAR; /* appending it must emit the character */
                ret->v.i = (unsigned char)args[0].v.o->chars[k];
                return 1;
            }
            return 0;
        }
        if (!strcmp(name, "toString")) {
            if (nargs >= 1 && args[0].kind == EMU_OBJ) {
                ret->kind = EMU_OBJ;
                ret->v.o = args[0].v.o;
                return 1;
            }
        }
    }

    if (!strcmp(cls, "java/lang/Integer")) {
        if (!strcmp(name, "parseInt") || !strcmp(name, "valueOf")) {
            if (nargs >= 1 && args[0].kind == EMU_OBJ && args[0].v.o->tag == 'S') {
                ret->kind = EMU_INT;
                ret->v.i = (int32_t)strtol(args[0].v.o->chars, NULL, 10);
                return 1;
            }
            if (nargs >= 1 && args[0].kind == EMU_INT) {
                ret->kind = EMU_INT;
                ret->v.i = args[0].v.i;
                return 1;
            }
        }
    }

    if (!strcmp(cls, "java/lang/Character")) {
        if (!strcmp(name, "toString")) {
            if (nargs >= 1 && args[0].kind == EMU_INT) {
                char buf[8];
                snprintf(buf, sizeof(buf), "%c", (char)args[0].v.i);
                ret->kind = EMU_OBJ;
                ret->v.o = mk_string(f, buf);
                return 1;
            }
        }
    }

    return 0;
}

/* ------------------------------------------------------------------ */
/* method resolution                                                  */
/* ------------------------------------------------------------------ */

/* Finds a static method's code by index. Returns NULL when it is not in this
 * dex or not static. */
/* Returns the code offset of a static or direct method, or 0 when the method has
 * no body in this dex. Returning an offset instead of a DexEncodedMethod pointer
 * keeps the caller independent of the class-data cache's lifetime. */
/* One table for the whole dex: walking the class list once at startup is far
 * cheaper than scanning it per lookup, and a decryption pass touches thousands of
 * distinct methods. */
typedef struct {
    Dex *dex;
    uint32_t *off;    /* method_idx -> code_off, 0 when absent */
    uint32_t cap;
} OffTable;

static _Thread_local OffTable g_off;

static void build_off_table(Dex *d)
{
    if (g_off.dex == d)
        return;
    free(g_off.off);
    g_off.cap = d->hdr.method_ids_size;
    g_off.off = calloc(g_off.cap ? g_off.cap : 1, sizeof(uint32_t));
    g_off.dex = d;
    if (!g_off.off) {
        memset(&g_off, 0, sizeof(g_off));
        return;
    }
    for (uint32_t i = 0; i < d->hdr.class_defs_size; i++) {
        const DexClassData *data = dex_class_data(d, i);
        if (!data)
            continue;
        for (uint32_t k = 0; k < data->direct_count; k++) {
            uint32_t mi = data->direct_methods[k].method_idx;
            if (mi < g_off.cap && !g_off.off[mi])
                g_off.off[mi] = data->direct_methods[k].code_off;
        }
        for (uint32_t k = 0; k < data->virtual_count; k++) {
            uint32_t mi = data->virtual_methods[k].method_idx;
            if (mi < g_off.cap && !g_off.off[mi])
                g_off.off[mi] = data->virtual_methods[k].code_off;
        }
    }
}

static uint32_t find_static_code_off(Dex *d, uint32_t method_idx, int *is_direct)
{
    if (is_direct)
        *is_direct = 0;
    if (method_idx >= d->hdr.method_ids_size)
        return 0;
    build_off_table(d);
    if (!g_off.off || method_idx >= g_off.cap)
        return 0;
    return g_off.off[method_idx];
}

/* ------------------------------------------------------------------ */
/* interpreter                                                        */
/* ------------------------------------------------------------------ */

static int run(Dex *d, uint32_t code_off, Frame *f, const EmuValue *args,
               uint32_t nargs, uint32_t max_steps)
{
    DexCode *code = dex_code(d, code_off);
    if (!code || !code->insns)
        return 0;

    f->nregs = code->registers_size;
    f->regs = arena_zalloc(f->arena, ((size_t)f->nregs + 1) * sizeof(EmuValue));
    if (!f->regs)
        return 0;
    for (uint32_t i = 0; i < f->nregs; i++)
        f->regs[i].kind = EMU_NULL;
    f->last_result.kind = EMU_NULL;

    /* Arguments arrive in the last ins_size registers. */
    uint32_t base = f->nregs >= code->ins_size ? f->nregs - code->ins_size : 0;
    for (uint32_t i = 0; i < nargs && i < code->ins_size; i++)
        f->regs[base + i] = args[i];

    uint32_t pc = 0;
    uint32_t steps = 0;
    while (pc < code->insns_size && steps++ < max_steps && !f->aborted) {
        Insn in;
        uint32_t len = insn_decode(code->insns, code->insns_size, pc, &in);
        if (!len) {
            set_unknown(f);
            break;
        }
        uint32_t next = pc + len;

        switch (in.opcode) {
        case OP_NOP:
        case OP_RETURN_VOID:
            break;

        case OP_RETURN:
        case OP_RETURN_OBJECT:
        case OP_RETURN_WIDE: {
            EmuValue v = (in.aa < f->nregs) ? f->regs[in.aa] : (EmuValue){EMU_UNKNOWN, {0}};
            if (v.kind == EMU_OBJ && v.v.o && v.v.o->tag == 'S') {
                f->out.kind = EMU_OBJ;
                f->out.string = v.v.o->chars;
            } else if (v.kind == EMU_INT) {
                f->out.kind = EMU_INT;
            } else if (v.kind == EMU_NULL) {
                f->out.kind = EMU_NULL;
            }
            return 1;
        }

        case OP_MOVE:
        case OP_MOVE_OBJECT:
        case OP_MOVE_WIDE:
            if (in.a < f->nregs && in.aa < f->nregs)
                f->regs[in.a] = f->regs[in.aa];
            break;
        case OP_MOVE_FROM16:
        case OP_MOVE_OBJECT_FROM16:
        case OP_MOVE_WIDE_FROM16:
        case OP_MOVE_16:
        case OP_MOVE_OBJECT_16:
        case OP_MOVE_WIDE_16:
            if (in.aa < f->nregs && in.idx < f->nregs)
                f->regs[in.aa] = f->regs[in.idx];
            break;

        case OP_MOVE_RESULT:
        case OP_MOVE_RESULT_OBJECT:
        case OP_MOVE_RESULT_WIDE:
            if (in.aa < f->nregs) {
                f->regs[in.aa] = f->last_result;
            }
            break;

        case OP_CONST_4:
        case OP_CONST_16:
        case OP_CONST:
            if (in.a < f->nregs) {
                f->regs[in.a].kind = EMU_INT;
                f->regs[in.a].v.i = in.literal;
            }
            break;
        case OP_CONST_STRING:
        case OP_CONST_STRING_JUMBO:
            if (in.aa < f->nregs) {
                const char *s = dex_string(d, in.idx);
                if (!s) {
                    set_unknown(f);
                    break;
                }
                f->regs[in.aa].kind = EMU_OBJ;
                f->regs[in.aa].v.o = mk_string(f, s);
            }
            break;
        case OP_CONST_WIDE:
            if (in.aa < f->nregs) {
                f->regs[in.aa].kind = EMU_LONG;
                f->regs[in.aa].v.j = (int64_t)in.wide_literal;
            }
            break;

        case OP_ARRAY_LENGTH:
            if (in.b < f->nregs && in.aa < f->nregs && f->regs[in.b].kind == EMU_OBJ &&
                f->regs[in.b].v.o && f->regs[in.b].v.o->tag == '[') {
                f->regs[in.aa].kind = EMU_INT;
                f->regs[in.aa].v.i = (int32_t)f->regs[in.b].v.o->len;
            } else {
                set_unknown(f);
            }
            break;

        case OP_AGET:
        case OP_AGET_BYTE:
        case OP_AGET_CHAR:
        case OP_AGET_SHORT: {
            if (in.a >= f->nregs)
                break;
            EmuValue arr = f->regs[in.regs[0]];
            EmuValue idx = f->regs[in.regs[1]]; /* 23x: vAA=aa, vBB=regs[0], vCC=regs[1] */
            if (arr.kind != EMU_OBJ || !arr.v.o || arr.v.o->tag != '[' || idx.kind != EMU_INT ||
                idx.v.i < 0 || (uint32_t)idx.v.i >= arr.v.o->len) {
                set_unknown(f);
                break;
            }
            f->regs[in.a] = arr.v.o->elems[idx.v.i];
            break;
        }

        case OP_APUT:
        case OP_APUT_BYTE:
        case OP_APUT_CHAR:
        case OP_APUT_SHORT: {
            EmuValue arr = f->regs[in.regs[0]];
            EmuValue idx = f->regs[in.regs[1]]; /* 23x: vAA=aa, vBB=regs[0], vCC=regs[1] */
            if (arr.kind != EMU_OBJ || !arr.v.o || arr.v.o->tag != '[' || idx.kind != EMU_INT ||
                idx.v.i < 0 || (uint32_t)idx.v.i >= arr.v.o->len) {
                set_unknown(f);
                break;
            }
            arr.v.o->elems[idx.v.i] = f->regs[in.a];
            break;
        }

        case OP_NEW_INSTANCE: {
            const char *td = dex_type_desc(d, in.idx);
            if (!td) {
                set_unknown(f);
                break;
            }
            EmuValue v;
            v.kind = EMU_OBJ;
            if (strstr(td, "StringBuilder") || strstr(td, "StringBuffer"))
                v.v.o = mk_sb(f);
            else if (!strcmp(td, "Ljava/lang/String;"))
                v.v.o = mk_string(f, "");
            else {
                set_unknown(f);
                break;
            }
            if (!v.v.o)
                break;
            if (in.aa < f->nregs)
                f->regs[in.aa] = v;
            break;
        }

        case OP_NEW_ARRAY: {
            if (in.a >= f->nregs || f->regs[in.b].kind != EMU_INT) {
                set_unknown(f);
                break;
            }
            int32_t n = f->regs[in.b].v.i;
            if (n < 0 || n > 65536) {
                set_unknown(f);
                break;
            }
            EmuValue v;
            v.kind = EMU_OBJ;
            v.v.o = mk_obj(f, '[', (uint32_t)n);
            if (v.v.o)
                f->regs[in.a] = v;
            break;
        }

        /* int-to-char / int-to-byte / int-to-short: value-preserving for our
         * purposes because the helpers only use the low bits. */
        /* 12x conversions. Only int-to-char changes how the value is printed by
         * StringBuilder.append, so it gets its own kind. */
        case 0x8d: /* int-to-char */
        case 0x8e: /* int-to-short -- javac emits this for (char) casts too */
        case 0x8f: /* int-to-byte */
            if (in.a < f->nregs && in.b < f->nregs &&
                (f->regs[in.b].kind == EMU_INT || f->regs[in.b].kind == EMU_CHAR)) {
                f->regs[in.a].kind = EMU_CHAR;
                f->regs[in.a].v.i = f->regs[in.b].v.i & 0xffff;
            } else {
                set_unknown(f);
            }
            break;
        case 0x81: /* int-to-long */
        case 0x85: /* int-to-float */
        case 0x86: /* int-to-double */
            if (in.a < f->nregs && in.b < f->nregs && f->regs[in.b].kind == EMU_INT) {
                f->regs[in.a].kind = EMU_INT;
                f->regs[in.a].v.i = f->regs[in.b].v.i;
            } else {
                set_unknown(f);
            }
            break;

        /* Arithmetic with an 8-bit literal: 0xd8..0xe2 (add-int/lit8 through
         * xor-int/lit8; 0xd0..0xd7 are the 16-bit-lit forms with different
         * layout). The decryption helpers use xor heavily. */
        case 0xd8: case 0xd9: case 0xda: case 0xdb:
        case 0xdc: case 0xdd: case 0xde: case 0xdf: case 0xe0: case 0xe1:
        case 0xe2: {
            /* 22b: vAA is the target, vBB the source, then an 8-bit literal. */
            if (in.aa >= f->nregs || in.b >= f->nregs) {
                set_unknown(f);
                break;
            }
            if (f->regs[in.b].kind != EMU_INT && f->regs[in.b].kind != EMU_CHAR) {
                set_unknown(f);
                break;
            }
            int32_t x = f->regs[in.b].v.i;
            int32_t y = in.literal;
            int32_t r = 0;
            switch (in.opcode) {
            case 0xd8: r = x + y; break;
            case 0xd9: r = x - y; break;
            case 0xda: r = x * y; break;
            case 0xdb: r = y ? x / y : 0; break;
            case 0xdc: r = y ? x % y : 0; break;
            case 0xdd: r = x & y; break;
            case 0xde: r = x | y; break;
            case 0xdf: r = x ^ y; break;
            case 0xe0: r = (int32_t)((uint32_t)x << (y & 31)); break;
            case 0xe1: r = (int32_t)((uint32_t)x >> (y & 31)); break;
            default:   r = (int32_t)((uint32_t)x >> (y & 31)); break;
            }
            f->regs[in.aa].kind = f->regs[in.b].kind;
            f->regs[in.aa].v.i = r;
            break;
        }

        case OP_INVOKE_STATIC:
        case OP_INVOKE_STATIC_RANGE:
        case OP_INVOKE_DIRECT:
        case OP_INVOKE_DIRECT_RANGE:
        case OP_INVOKE_VIRTUAL:
        case OP_INVOKE_VIRTUAL_RANGE: {
            uint32_t mi = in.idx;
            if (mi >= d->hdr.method_ids_size) {
                set_unknown(f);
                break;
            }
            const char *mname = dex_method_name(d, mi);
            uint32_t cls = d->methods[mi].class_idx;
            const char *cdesc = dex_type_desc(d, cls);
            if (!mname || !cdesc) {
                set_unknown(f);
                break;
            }

            /* Collect arguments. */
            EmuValue av[8];
            uint32_t an = 0;
            for (uint32_t i = 0; i < in.reg_count && an < 8; i++) {
                uint32_t r = in.regs[i];
                if (r >= f->nregs) {
                    set_unknown(f);
                    break;
                }
                av[an++] = f->regs[r];
            }
            if (f->aborted)
                break;

            EmuValue ret;
            ret.kind = EMU_NULL;

            /* java.lang.String / StringBuilder first: they are the ones these
             * helpers actually reach. */
            char cls_dot[256];
            size_t o = 0;
            for (const char *p = cdesc + 1; *p && *p != ';' && o + 1 < sizeof(cls_dot); p++)
                cls_dot[o++] = *p;
            cls_dot[o] = '\0';

            /* append(char) writes a character; append(int) writes digits. The
             * descriptor decides, not the value's history. */
            if (!strcmp(mname, "append") && an >= 2) {
                uint32_t proto = d->methods[mi].proto_idx;
                DexParamList *pl = dex_proto_params(d, proto);
                if (pl && pl->param_count >= 1) {
                    const char *pt = dex_type_desc(d, pl->type_idx[0]);
                    if (pt && !strcmp(pt, "C") && av[1].kind == EMU_CHAR)
                        av[1].kind = EMU_CHAR;
                    else if (pt && !strcmp(pt, "C"))
                        av[1].kind = EMU_CHAR;
                    else if (pt && strcmp(pt, "C"))
                        av[1].kind = EMU_INT;
                }
            }
            if (call_jdk(f, cls_dot, mname, av, an, &ret)) {
                f->last_result = ret;
                break;
            }

            /* A call back into the app's own code: recurse. */
            uint32_t callee_off = find_static_code_off(d, mi, NULL);
            if (!callee_off) {
                set_unknown(f);
                break;
            }
            static _Thread_local int depth;
            if (depth > 12) {
                set_unknown(f);
                break;
            }
            Frame sub = {0};
            sub.arena = f->arena;
            sub.d = d;
            depth++;
            int ok = run(d, callee_off, &sub, av, an, max_steps / 2 ? max_steps / 2 : 1);
            depth--;
            if (!ok || sub.out.kind == EMU_UNKNOWN) {
                set_unknown(f);
                break;
            }
            if (sub.out.kind == EMU_OBJ && sub.out.string) {
                f->last_result.kind = EMU_OBJ;
                f->last_result.v.o = mk_string(f, sub.out.string);
            } else if (sub.out.kind == EMU_INT) {
                f->last_result.kind = EMU_INT;
                f->last_result.v.i = 0;
            } else {
                f->last_result.kind = EMU_NULL;
            }
            break;
        }

        case OP_GOTO:
        case OP_GOTO_16:
        case OP_GOTO_32:
            if (in.target < 0 || (uint32_t)in.target > code->insns_size) {
                set_unknown(f);
                break;
            }
            pc = (uint32_t)in.target;
            continue;

        case OP_IF_EQ: case OP_IF_NE: case OP_IF_LT: case OP_IF_GE:
        case OP_IF_GT: case OP_IF_LE: {
            /* 22t: vA and vB are the two 4-bit halves, not the operand list. */
            EmuValue x = f->regs[in.a];
            EmuValue y = f->regs[in.b];
            if (x.kind != EMU_INT || y.kind != EMU_INT) {
                set_unknown(f);
                break;
            }
            int take = 0;
            switch (in.opcode) {
            case OP_IF_EQ: take = x.v.i == y.v.i; break;
            case OP_IF_NE: take = x.v.i != y.v.i; break;
            case OP_IF_LT: take = x.v.i < y.v.i; break;
            case OP_IF_GE: take = x.v.i >= y.v.i; break;
            case OP_IF_GT: take = x.v.i > y.v.i; break;
            default:       take = x.v.i <= y.v.i; break;
            }
            if (take) {
                if (in.target < 0 || (uint32_t)in.target > code->insns_size) {
                    set_unknown(f);
                    break;
                }
                pc = (uint32_t)in.target;
                continue;
            }
            break;
        }

        case OP_IF_EQZ: case OP_IF_NEZ: case OP_IF_LTZ: case OP_IF_GEZ:
        case OP_IF_GTZ: case OP_IF_LEZ: {
            EmuValue x = f->regs[in.aa];
            if (x.kind != EMU_INT) {
                set_unknown(f);
                break;
            }
            int take = 0;
            switch (in.opcode) {
            case OP_IF_EQZ: take = x.v.i == 0; break;
            case OP_IF_NEZ: take = x.v.i != 0; break;
            case OP_IF_LTZ: take = x.v.i < 0; break;
            case OP_IF_GEZ: take = x.v.i >= 0; break;
            case OP_IF_GTZ: take = x.v.i > 0; break;
            default:        take = x.v.i <= 0; break;
            }
            if (take) {
                if (in.target < 0 || (uint32_t)in.target > code->insns_size) {
                    set_unknown(f);
                    break;
                }
                pc = (uint32_t)in.target;
                continue;
            }
            break;
        }

        default:
            (void)0;
            set_unknown(f);
            break;
        }

        pc = next;
    }
    return 0;
}

EmuResult emu_call_static(Dex *d, uint32_t method_idx, const EmuValue *args, uint32_t nargs,
                          Arena *arena, uint32_t max_steps)
{
    EmuResult r = {EMU_UNKNOWN, NULL};
    if (!d || !arena)
        return r;
    uint32_t code_off = find_static_code_off(d, method_idx, NULL);
    if (!code_off)
        return r;
    Frame f = {0};
    f.arena = arena;
    f.d = d;
    if (!run(d, code_off, &f, args, nargs, max_steps ? max_steps : 20000))
        return r;
    return f.out;
}

EmuValue emu_make_string(Arena *arena, const char *s)
{
    EmuValue v;
    v.kind = EMU_NULL;
    if (!arena)
        return v;
    Frame f = {0};
    f.arena = arena;
    EmuObj *o = mk_string(&f, s ? s : "");
    if (o) {
        v.kind = EMU_OBJ;
        v.v.o = o;
    }
    return v;
}

char *emu_decrypt_string(Dex *d, uint32_t method_idx, const char *input, Arena *arena)
{
    if (!d || !arena || !input)
        return NULL;
    EmuValue arg = emu_make_string(arena, input);
    if (arg.kind != EMU_OBJ)
        return NULL;
    EmuResult r = emu_call_static(d, method_idx, &arg, 1, arena, 20000);
    if (r.kind != EMU_OBJ || !r.string)
        return NULL;
    if (!strcmp(r.string, input))
        return NULL; /* no progress: not a decryption helper */
    return arena_strdup(arena, r.string);
}
