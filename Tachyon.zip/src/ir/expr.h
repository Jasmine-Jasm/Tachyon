#ifndef TACHYON_IR_EXPR_H
#define TACHYON_IR_EXPR_H

#include <stdint.h>

#include "common/buf.h"
#include "dex/dex.h"

/* Expression kinds produced by symbolic execution of Dalvik registers. */
typedef enum {
    EX_CONST_INT,
    EX_CONST_LONG,
    EX_CONST_FLOAT,
    EX_CONST_DOUBLE,
    EX_CONST_STRING,
    EX_CONST_CLASS,
    EX_CONST_NULL,
    EX_LOCAL,      /* vN */
    EX_FIELD_GET,
    EX_FIELD_SET,
    EX_ARRAY_GET,
    EX_ARRAY_SET,
    EX_ARRAY_LEN,
    EX_NEW,
    EX_NEW_ARRAY,
    EX_CAST,
    EX_INSTANCEOF,
    EX_INVOKE,
    EX_BINOP,
    EX_UNOP,
    EX_TERNARY,
    EX_COMPARE,
    EX_THIS,
    EX_PARAM,
    EX_UNKNOWN,
} ExprKind;

typedef struct Expr Expr;

struct Expr {
    ExprKind kind;
    const char *type;     /* DEX type descriptor of the value, or NULL */

    /* EX_CONST_* */
    int64_t i64;
    double f64;
    const char *str;      /* string literal / field / method / class name */

    /* EX_BINOP / EX_UNOP / EX_COMPARE */
    const char *op;

    /* children */
    Expr *a;
    Expr *b;
    Expr *c;

    /* EX_INVOKE */
    uint32_t method_idx;
    Expr **args;
    uint32_t arg_count;

    /* EX_FIELD_* */
    uint32_t field_idx;
    int is_static;

    /* parens needed? computed during rendering */
    int prec;
};

/* Renders an expression tree as Java source. */
void expr_render(const Expr *e, Buf *out);

/* Type descriptor helpers. */
const char *expr_java_type(const Expr *e, Dex *dex, char *buf, size_t cap);

#endif
