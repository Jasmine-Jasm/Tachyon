#include "ir/body_emit.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "emit/java.h"
#include "emit/java_type.h"
#include "emit/remap.h"
#include "ir/opcode.h"

static void indent(Buf *out, int level)
{
    for (int i = 0; i < level; i++)
        buf_putc(out, '\t');
}

static void line(Buf *out, int level, const char *fmt, ...)
{
    char text[2048];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(text, sizeof(text), fmt, ap);
    va_end(ap);
    indent(out, level);
    buf_puts(out, text);
    buf_putc(out, '\n');
}

static int is_move(uint8_t op)
{
    return op == OP_MOVE || op == OP_MOVE_FROM16 || op == OP_MOVE_16 ||
           op == OP_MOVE_WIDE || op == OP_MOVE_WIDE_FROM16 || op == OP_MOVE_WIDE_16 ||
           op == OP_MOVE_OBJECT || op == OP_MOVE_OBJECT_FROM16 || op == OP_MOVE_OBJECT_16;
}

static int is_field_get(uint8_t op)
{
    return (op >= OP_IGET && op <= OP_IGET_SHORT) ||
           (op >= OP_SGET && op <= OP_SGET_SHORT);
}

static int is_branch(uint8_t op)
{
    return op >= OP_IF_EQ && op <= OP_IF_LEZ;
}

static int is_branch_or_payload(uint8_t op)
{
    return (op >= OP_GOTO && op <= OP_SPARSE_SWITCH) || is_branch(op) ||
           op == OP_FILL_ARRAY_DATA;
}

static int is_invoke(uint8_t op)
{
    return (op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) ||
           (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE) ||
           op == OP_INVOKE_POLYMORPHIC || op == OP_INVOKE_POLYMORPHIC_RANGE ||
           op == OP_INVOKE_CUSTOM || op == OP_INVOKE_CUSTOM_RANGE;
}

static int is_static_invoke(uint8_t op)
{
    return op == OP_INVOKE_STATIC || op == OP_INVOKE_STATIC_RANGE;
}

static int is_normal_binop(uint8_t op)
{
    return op >= 0x90 && op <= 0xaf;
}

static int is_2addr(uint8_t op)
{
    return op >= 0xb0 && op <= 0xcf;
}

static int is_litop(uint8_t op)
{
    return op >= 0xd0 && op <= 0xe2;
}

static int is_wide_const(uint8_t op)
{
    return op >= OP_CONST_WIDE_16 && op <= OP_CONST_WIDE_HIGH16;
}

static int is_return(uint8_t op)
{
    return op == OP_RETURN_VOID || op == OP_RETURN || op == OP_RETURN_WIDE ||
           op == OP_RETURN_OBJECT;
}

static const char *value_type(const TypeInfer *types, uint32_t value)
{
    return type_infer_desc(types, value);
}

static int initial_parameter_index(const SsaMethod *ssa, const DexEncodedMethod *enc,
                                   uint32_t reg, uint32_t *out_index, int *out_receiver)
{
    DexCode *code = ssa->cfg->code;
    Dex *dex = ssa->cfg->dex;
    uint32_t base = code->registers_size >= code->ins_size
                        ? code->registers_size - code->ins_size : 0;
    int has_this = !(enc->access_flags & DEX_ACC_STATIC);
    if (has_this && reg == base) {
        if (out_receiver) *out_receiver = 1;
        return 1;
    }
    if (reg < base + (has_this ? 1u : 0u) || enc->method_idx >= dex->hdr.method_ids_size)
        return 0;
    DexParamList *params = dex_proto_params(dex, dex->methods[enc->method_idx].proto_idx);
    if (!params)
        return 0;
    uint32_t cursor = base + (has_this ? 1u : 0u);
    for (uint32_t i = 0; i < params->param_count; i++) {
        const char *desc = dex_type_desc(dex, params->type_idx[i]);
        uint32_t width = desc && (desc[0] == 'J' || desc[0] == 'D') ? 2u : 1u;
        if (reg == cursor || (width == 2 && reg == cursor + 1)) {
            if (out_index) *out_index = i;
            return 1;
        }
        cursor += width;
    }
    return 0;
}

static int value_name(const SsaMethod *ssa, const DexEncodedMethod *enc, uint32_t value,
                      char *out, size_t cap)
{
    if (value >= ssa->value_count)
        return 0;
    const SsaValue *v = &ssa->values[value];
    if (v->kind == SSA_VALUE_INITIAL) {
        uint32_t index = 0;
        int receiver = 0;
        if (initial_parameter_index(ssa, enc, v->reg, &index, &receiver)) {
            if (receiver) snprintf(out, cap, "this");
            else snprintf(out, cap, "p%u", index);
            return 1;
        }
    }
    snprintf(out, cap, "v%u", value);
    return 1;
}

static int type_name(const TypeInfer *types, uint32_t value, char *out, size_t cap)
{
    const char *desc = value_type(types, value);
    if (!desc)
        return 0;
    remap_java_type(desc, out, cap);
    return out[0] != '\0';
}

static int emit_value(Buf *out, const SsaMethod *ssa, const DexEncodedMethod *enc,
                      uint32_t value)
{
    char name[64];
    if (!value_name(ssa, enc, value, name, sizeof(name)))
        return 0;
    buf_puts(out, name);
    return 1;
}

static int emit_literal(Buf *out, const Insn *raw, Dex *dex)
{
    if (raw->opcode == OP_CONST_STRING || raw->opcode == OP_CONST_STRING_JUMBO) {
        char escaped[2048];
        java_escape_string(dex_string(dex, raw->idx), escaped, sizeof(escaped));
        buf_printf(out, "\"%s\"", escaped);
        return 1;
    }
    if (raw->opcode == OP_CONST_CLASS) {
        char type[512];
        remap_java_type(dex_type_desc(dex, raw->idx), type, sizeof(type));
        buf_printf(out, "%s.class", type);
        return 1;
    }
    if (is_wide_const(raw->opcode)) {
        buf_printf(out, "%lldL", (long long)(int64_t)raw->wide_literal);
        return 1;
    }
    if (raw->opcode >= OP_CONST_4 && raw->opcode <= OP_CONST_HIGH16) {
        if (raw->literal == INT32_MIN)
            buf_puts(out, "Integer.MIN_VALUE");
        else
            buf_printf(out, "%d", raw->literal);
        return 1;
    }
    return 0;
}

static int emit_field_name(Buf *out, Dex *dex, uint32_t field_idx)
{
    if (field_idx >= dex->hdr.field_ids_size)
        return 0;
    const DexFieldId *field = &dex->fields[field_idx];
    buf_puts(out, java_member_name(dex, field->class_idx, field_idx, 0));
    return 1;
}

static int emit_method_name(Buf *out, Dex *dex, uint32_t method_idx)
{
    if (method_idx >= dex->hdr.method_ids_size)
        return 0;
    const DexMethodId *method = &dex->methods[method_idx];
    const char *raw = java_member_name(dex, method->class_idx, method_idx, 1);
    char clean[512];
    size_t n = strlen(raw);
    if (n >= sizeof(clean)) n = sizeof(clean) - 1;
    for (size_t i = 0; i < n; i++) {
        char c = raw[i];
        clean[i] = ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                    (c >= '0' && c <= '9') || c == '_' || c == '$') ? c : '_';
    }
    clean[n] = '\0';
    buf_puts(out, clean);
    return 1;
}

static int emit_invoke_args(Buf *out, const SsaMethod *ssa, const DexEncodedMethod *enc,
                            const SsaInstr *in, uint32_t first)
{
    for (uint32_t i = first; i < in->use_count; i++) {
        if (i != first)
            buf_puts(out, ", ");
        if (!emit_value(out, ssa, enc, in->use_values[i]))
            return 0;
    }
    return 1;
}

static uint32_t invoke_proto(const Dex *dex, const Insn *raw)
{
    if (!dex || !raw)
        return SSA_NO_INDEX;
    if (raw->opcode == OP_INVOKE_POLYMORPHIC || raw->opcode == OP_INVOKE_POLYMORPHIC_RANGE)
        return raw->proto_idx < dex->hdr.proto_ids_size ? raw->proto_idx : SSA_NO_INDEX;
    if (raw->opcode >= OP_INVOKE_VIRTUAL && raw->opcode <= OP_INVOKE_INTERFACE &&
        raw->idx < dex->hdr.method_ids_size)
        return dex->methods[raw->idx].proto_idx;
    if (raw->opcode >= OP_INVOKE_VIRTUAL_RANGE && raw->opcode <= OP_INVOKE_INTERFACE_RANGE &&
        raw->idx < dex->hdr.method_ids_size)
        return dex->methods[raw->idx].proto_idx;
    return SSA_NO_INDEX;
}

static int emit_typed_value(Buf *out, const SsaMethod *ssa,
                            const DexEncodedMethod *enc, const TypeInfer *types,
                            uint32_t value, const char *expected)
{
    if (!expected || !expected[0])
        return emit_value(out, ssa, enc, value);
    const char *actual = type_infer_desc(types, value);
    if (expected[0] == 'Z' && actual && actual[0] != 'Z') {
        buf_putc(out, '(');
        if (!emit_value(out, ssa, enc, value)) return 0;
        buf_puts(out, " != 0)");
        return 1;
    }
    if (actual && actual[0] == 'Z' && expected[0] != 'Z') {
        buf_putc(out, '(');
        if (!emit_value(out, ssa, enc, value)) return 0;
        buf_puts(out, " ? 1 : 0)");
        return 1;
    }
    char target[512];
    remap_java_type(expected, target, sizeof(target));
    if (expected[0] == 'L' || expected[0] == '[') {
        buf_printf(out, "(%s) ", target);
        return emit_value(out, ssa, enc, value);
    }
    if (actual && actual[0] != expected[0]) {
        const char *name = target;
        buf_printf(out, "(%s) ", name);
    }
    return emit_value(out, ssa, enc, value);
}

static int emit_method_args(Buf *out, Dex *dex, const SsaMethod *ssa,
                            const DexEncodedMethod *enc, const TypeInfer *types,
                            const SsaInstr *in, uint32_t first)
{
    uint32_t proto = invoke_proto(dex, in->raw);
    DexParamList *params = proto == SSA_NO_INDEX ? NULL : dex_proto_params(dex, proto);
    if (!params) return emit_invoke_args(out, ssa, enc, in, first);
    uint32_t pos = first;
    for (uint32_t p = 0; p < params->param_count; p++) {
        if (pos >= in->use_count)
            return 0;
        if (p) buf_puts(out, ", ");
        const char *desc = dex_type_desc(dex, params->type_idx[p]);
        if (!emit_typed_value(out, ssa, enc, types, in->use_values[pos], desc))
            return 0;
        uint32_t width = desc && (desc[0] == 'J' || desc[0] == 'D') ? 2 : 1;
        pos += width;
    }
    return pos == in->use_count;
}

static int emit_binary(Buf *out, const SsaMethod *ssa, const DexEncodedMethod *enc,
                       const SsaInstr *in, const char *op)
{
    if (in->use_count < 2 || !emit_value(out, ssa, enc, in->use_values[0]))
        return 0;
    buf_printf(out, " %s ", op);
    return emit_value(out, ssa, enc, in->use_values[1]);
}

static int emit_linear_instruction(Buf *out, Dex *dex, const DexEncodedMethod *enc,
                                   SsaMethod *ssa, const TypeInfer *types,
                                   const SsaInstr *in, int indent_level,
                                   uint32_t *constructed_value, int declare_values)
{
    const Insn *raw = in->raw;
    char java_type[512];
    uint32_t def = in->def_value;
    int has_def = def != SSA_NO_VALUE;

    if (!raw)
        return 0;
    if (raw->opcode == OP_MOVE_EXCEPTION)
        return 1;
    if (raw->opcode == OP_THROW) {
        if (in->use_count < 1)
            return 0;
        indent(out, indent_level);
        buf_puts(out, "throw ");
        if (!emit_value(out, ssa, enc, in->use_values[0]))
            return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (is_branch_or_payload(raw->opcode) ||
        raw->opcode == OP_MONITOR_ENTER || raw->opcode == OP_MONITOR_EXIT)
        return 0;

    if (raw->opcode == OP_NOP)
        return 1;
    if (raw->opcode == OP_NEW_INSTANCE) {
        if (!has_def)
            return 0;
        *constructed_value = def;
        return 1;
    }
    if (raw->opcode == OP_RETURN_VOID) {
        line(out, indent_level, "return;");
        return 1;
    }
    if (is_return(raw->opcode)) {
        if (!in->use_count)
            return 0;
        indent(out, indent_level);
        buf_puts(out, "return ");
        const char *expected = NULL;
        if (enc->method_idx < dex->hdr.method_ids_size) {
            uint32_t proto = dex->methods[enc->method_idx].proto_idx;
            if (proto < dex->hdr.proto_ids_size)
                expected = dex_type_desc(dex, dex->protos[proto].return_type_idx);
        }
        if (!emit_typed_value(out, ssa, enc, types, in->use_values[0], expected))
            return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode >= OP_CONST_4 && raw->opcode <= OP_CONST_CLASS) {
        if (!has_def || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        if (!emit_literal(out, raw, dex)) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (is_move(raw->opcode)) {
        if (!has_def || in->use_count != 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        if (!emit_typed_value(out, ssa, enc, types, in->use_values[0],
                              type_infer_desc(types, def))) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode == OP_CHECK_CAST) {
        if (!has_def || in->use_count < 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        buf_putc(out, '(');
        char cast_type[512];
        remap_java_type(dex_type_desc(dex, raw->idx), cast_type, sizeof(cast_type));
        buf_printf(out, "%s) ", cast_type);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode == OP_ARRAY_LENGTH) {
        if (!has_def || in->use_count < 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_puts(out, ".length;\n");
        return 1;
    }
    if (raw->opcode == OP_INSTANCE_OF) {
        if (!has_def || in->use_count < 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        char check_type[512];
        remap_java_type(dex_type_desc(dex, raw->idx), check_type, sizeof(check_type));
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_printf(out, " instanceof %s ? 1 : 0;\n", check_type);
        return 1;
    }
    if (raw->opcode == OP_NEW_ARRAY) {
        if (!has_def || in->use_count < 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        char array_type[512];
        remap_java_type(dex_type_desc(dex, raw->idx), array_type, sizeof(array_type));
        size_t len = strlen(array_type);
        size_t dims = 0;
        while (len >= 2 && array_type[len - 2] == '[' && array_type[len - 1] == ']') {
            dims++;
            len -= 2;
        }
        if (!dims || !len)
            return 0;
        array_type[len] = '\0';
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        buf_printf(out, "new %s[", array_type);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_putc(out, ']');
        for (size_t i = 1; i < dims; i++)
            buf_puts(out, "[]");
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode >= OP_AGET && raw->opcode <= OP_AGET_SHORT) {
        const char *array_desc = in->use_count ? type_infer_desc(types, in->use_values[0]) : NULL;
        if (!array_desc || array_desc[0] != '[' || !has_def || in->use_count < 2 ||
            !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_putc(out, '[');
        if (!emit_value(out, ssa, enc, in->use_values[1])) return 0;
        buf_puts(out, "];\n");
        return 1;
    }
    if (raw->opcode >= OP_APUT && raw->opcode <= OP_APUT_SHORT) {
        if (in->use_count < 3) return 0;
        indent(out, indent_level);
        if (!emit_value(out, ssa, enc, in->use_values[1])) return 0;
        buf_putc(out, '[');
        if (!emit_value(out, ssa, enc, in->use_values[2])) return 0;
        buf_puts(out, "] = ");
        const char *array_desc = type_infer_desc(types, in->use_values[1]);
        const char *expected = array_desc && array_desc[0] == '[' ? array_desc + 1 : NULL;
        if (!emit_typed_value(out, ssa, enc, types, in->use_values[0], expected)) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode >= 0x81 && raw->opcode <= 0x8f) {
        if (!has_def || in->use_count < 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        const char *target = insn_convert_type(raw->opcode);
        if (!target) return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        buf_printf(out, "(%s) ", target);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (is_field_get(raw->opcode)) {
        if (!has_def || !type_name(types, def, java_type, sizeof(java_type))) return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        if (raw->opcode >= OP_SGET && raw->opcode <= OP_SGET_SHORT) {
            const DexFieldId *field = &dex->fields[raw->idx];
            char owner[512];
            remap_java_type(dex_type_desc(dex, field->class_idx), owner, sizeof(owner));
            buf_printf(out, "%s.", owner);
            if (!emit_field_name(out, dex, raw->idx)) return 0;
        } else {
            if (!in->use_count || !emit_value(out, ssa, enc, in->use_values[0])) return 0;
            buf_putc(out, '.');
            if (!emit_field_name(out, dex, raw->idx)) return 0;
        }
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode >= OP_IPUT && raw->opcode <= OP_IPUT_SHORT) {
        if (in->use_count < 2) return 0;
        indent(out, indent_level);
        if (!emit_value(out, ssa, enc, in->use_values[1])) return 0;
        buf_putc(out, '.');
        if (!emit_field_name(out, dex, raw->idx)) return 0;
        buf_puts(out, " = ");
        const char *expected = raw->idx < dex->hdr.field_ids_size
                                   ? dex_type_desc(dex, dex->fields[raw->idx].type_idx) : NULL;
        if (!emit_typed_value(out, ssa, enc, types, in->use_values[0], expected)) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode >= OP_SPUT && raw->opcode <= OP_SPUT_SHORT) {
        if (in->use_count < 1) return 0;
        const DexFieldId *field = &dex->fields[raw->idx];
        char owner[512];
        remap_java_type(dex_type_desc(dex, field->class_idx), owner, sizeof(owner));
        indent(out, indent_level);
        buf_printf(out, "%s.", owner);
        if (!emit_field_name(out, dex, raw->idx)) return 0;
        buf_puts(out, " = ");
        const char *expected = raw->idx < dex->hdr.field_ids_size
                                   ? dex_type_desc(dex, dex->fields[raw->idx].type_idx) : NULL;
        if (!emit_typed_value(out, ssa, enc, types, in->use_values[0], expected)) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (raw->opcode >= OP_NEG_INT && raw->opcode <= 0x80) {
        if (!has_def || in->use_count < 1 || !type_name(types, def, java_type, sizeof(java_type)))
            return 0;
        const char *symbol = (raw->opcode == 0x7c || raw->opcode == 0x7e) ? "~" : "-";
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        buf_puts(out, symbol);
        if (!emit_value(out, ssa, enc, in->use_values[0])) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (is_normal_binop(raw->opcode) || is_2addr(raw->opcode) || is_litop(raw->opcode)) {
        if (!has_def || !type_name(types, def, java_type, sizeof(java_type))) return 0;
        indent(out, indent_level);
        if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
        else buf_printf(out, "v%u = ", def);
        const char *symbol = insn_binop_symbol(raw->opcode);
        if (is_litop(raw->opcode)) {
            if (in->use_count != 1 || !emit_value(out, ssa, enc, in->use_values[0])) return 0;
            buf_printf(out, " %s %d", symbol, raw->literal);
        } else if (!emit_binary(out, ssa, enc, in, symbol)) return 0;
        buf_puts(out, ";\n");
        return 1;
    }
    if (is_invoke(raw->opcode) || raw->opcode == OP_FILLED_NEW_ARRAY ||
        raw->opcode == OP_FILLED_NEW_ARRAY_RANGE) {
        const char *name = raw->opcode == OP_FILLED_NEW_ARRAY || raw->opcode == OP_FILLED_NEW_ARRAY_RANGE
                               ? NULL : dex_method_name(dex, raw->idx);
        int is_ctor = name && !strcmp(name, "<init>");
        if (is_ctor && *constructed_value == SSA_NO_VALUE &&
            !(enc->access_flags & DEX_ACC_STATIC) && in->use_count > 0) {
            uint32_t base = ssa->cfg->code->registers_size >= ssa->cfg->code->ins_size
                                ? ssa->cfg->code->registers_size - ssa->cfg->code->ins_size : 0;
            uint32_t receiver_value = in->use_values[0];
            if (receiver_value < ssa->value_count &&
                ssa->values[receiver_value].kind == SSA_VALUE_INITIAL &&
                ssa->values[receiver_value].reg == base)
                return 1;
        }
        if (is_ctor) {
            if (!in->use_count || *constructed_value == SSA_NO_VALUE || in->use_values[0] != *constructed_value)
                return 0;
            indent(out, indent_level);
            const DexMethodId *method = &dex->methods[raw->idx];
            char owner[512];
            remap_java_type(dex_type_desc(dex, method->class_idx), owner, sizeof(owner));
            if (declare_values) buf_printf(out, "%s v%u = new %s(", owner, *constructed_value, owner);
            else buf_printf(out, "v%u = new %s(", *constructed_value, owner);
            if (!emit_method_args(out, dex, ssa, enc, types, in, 1)) return 0;
            buf_puts(out, ");\n");
            *constructed_value = SSA_NO_VALUE;
            return 1;
        }
        if (has_def && (!type_name(types, def, java_type, sizeof(java_type)) ||
                        (raw->opcode == OP_FILLED_NEW_ARRAY || raw->opcode == OP_FILLED_NEW_ARRAY_RANGE))) {
            if (raw->opcode == OP_FILLED_NEW_ARRAY || raw->opcode == OP_FILLED_NEW_ARRAY_RANGE)
                remap_java_type(dex_type_desc(dex, raw->idx), java_type, sizeof(java_type));
            else
                return 0;
        }
        indent(out, indent_level);
        if (has_def) {
            if (declare_values) buf_printf(out, "%s v%u = ", java_type, def);
            else buf_printf(out, "v%u = ", def);
        }
        if (raw->opcode == OP_FILLED_NEW_ARRAY || raw->opcode == OP_FILLED_NEW_ARRAY_RANGE) {
            char array_type[512];
            remap_java_type(dex_type_desc(dex, raw->idx), array_type, sizeof(array_type));
            size_t array_len = strlen(array_type);
            if (array_len < 2 || array_type[array_len - 2] != '[' || array_type[array_len - 1] != ']')
                return 0;
            array_type[array_len - 2] = '\0';
            buf_printf(out, "new %s[]{", array_type);
            if (!emit_invoke_args(out, ssa, enc, in, 0)) return 0;
            buf_putc(out, '}');
        } else if (is_static_invoke(raw->opcode)) {
            const DexMethodId *method = &dex->methods[raw->idx];
            char owner[512];
            remap_java_type(dex_type_desc(dex, method->class_idx), owner, sizeof(owner));
            buf_printf(out, "%s.", owner);
            if (!emit_method_name(out, dex, raw->idx)) return 0;
            buf_putc(out, '(');
            if (!emit_method_args(out, dex, ssa, enc, types, in, 0))
                return 0;
            buf_putc(out, ')');
        } else {
            if (!in->use_count || !emit_value(out, ssa, enc, in->use_values[0]))
                return 0;
            buf_putc(out, '.');
            if (!emit_method_name(out, dex, raw->idx))
                return 0;
            buf_putc(out, '(');
            if (!emit_method_args(out, dex, ssa, enc, types, in, 1))
                return 0;
            buf_putc(out, ')');
        }
        buf_puts(out, ";\n");
        return 1;
    }
    return 0;
}

static int block_norms(const SsaMethod *ssa, const CfgBlock *block, uint32_t *out, uint32_t cap)
{
    uint32_t n = 0, last = SSA_NO_INDEX;
    for (uint32_t i = 0; i < block->insn_count; i++) {
        uint32_t raw = block->insn_start + i;
        if (raw >= ssa->raw_count) break;
        uint32_t norm = ssa->raw_to_norm[raw];
        if (norm == SSA_NO_INDEX || norm == last) continue;
        if (norm >= ssa->count || ssa->insns[norm].block_id != block->id) {
            last = norm;
            continue;
        }
        if (n < cap) out[n++] = norm;
        last = norm;
    }
    return (int)n;
}

static uint32_t pred_index(const CfgBlock *block, uint32_t pred)
{
    for (uint32_t i = 0; i < block->pred_count; i++)
        if (block->pred[i] == pred) return i;
    return SSA_NO_INDEX;
}

static int emit_phi_edge(Buf *out, const SsaMethod *ssa, const DexEncodedMethod *enc,
                         uint32_t pred, uint32_t succ, int level)
{
    const CfgBlock *block = &ssa->cfg->blocks[succ];
    uint32_t pi = pred_index(block, pred);
    if (pi == SSA_NO_INDEX) return 0;
    for (uint32_t i = 0; i < ssa->block_phi_count[succ]; i++) {
        const SsaPhi *phi = &ssa->phis[ssa->block_phis[succ][i]];
        if (pi >= phi->input_count || phi->inputs[pi] == SSA_NO_VALUE) return 0;
        indent(out, level);
        buf_printf(out, "v%u = ", phi->value_id);
        if (!emit_value(out, ssa, enc, phi->inputs[pi])) return 0;
        buf_puts(out, ";\n");
    }
    return 1;
}

static int ssa_emitter_safe(const SsaMethod *ssa, const DexEncodedMethod *enc)
{
    if (!ssa || !enc || !ssa->cfg || !ssa->cfg->code)
        return 0;
    /* The structured emitter is deliberately bounded until region recovery is
     * complete. Larger methods use a marked stub rather than guessed Java. */
    if (ssa->count > 192 || ssa->cfg->block_count > 16 ||
        ssa->cfg->code->registers_size > 64)
        return 0;
    for (uint32_t i = 0; i < ssa->count; i++) {
        uint8_t op = ssa->insns[i].raw ? ssa->insns[i].raw->opcode : OP_NOP;
        if (op == OP_MONITOR_ENTER || op == OP_MONITOR_EXIT || op == OP_INVOKE_CUSTOM ||
            op == OP_INVOKE_CUSTOM_RANGE || op == OP_INVOKE_POLYMORPHIC ||
            op == OP_INVOKE_POLYMORPHIC_RANGE)
            return 0;
    }
    uint32_t regs = ssa->cfg->code->registers_size;
    uint32_t ins = ssa->cfg->code->ins_size;
    uint32_t base = regs >= ins ? regs - ins : 0;
    uint32_t receiver = base;
    for (uint32_t i = 0; i < ssa->count; i++) {
        const SsaInstr *in = &ssa->insns[i];
        for (uint32_t u = 0; u < in->use_count; u++) {
            uint32_t value = in->use_values[u];
            if (value >= ssa->value_count)
                return 0;
            const SsaValue *v = &ssa->values[value];
            if (v->kind == SSA_VALUE_INITIAL && v->reg < base)
                return 0;
        }
        if (in->def_count && in->def[0].reg == receiver &&
            !(enc->access_flags & DEX_ACC_STATIC))
            return 0;
    }
    return 1;
}

static int ssa_types_complete(const SsaMethod *ssa, const TypeInfer *types)
{
    for (uint32_t i = 0; i < ssa->count; i++) {
        const SsaInstr *in = &ssa->insns[i];
        if (in->def_count && !type_infer_desc(types, in->def_value))
            return 0;
        for (uint32_t u = 0; u < in->use_count; u++)
            if (!type_infer_desc(types, in->use_values[u]))
                return 0;
    }
    for (uint32_t i = 0; i < ssa->phi_count; i++) {
        const SsaPhi *phi = &ssa->phis[i];
        if (!type_infer_desc(types, phi->value_id))
            return 0;
        for (uint32_t p = 0; p < phi->input_count; p++) {
            if (phi->inputs[p] >= ssa->value_count || !type_infer_desc(types, phi->inputs[p]))
                return 0;
            const SsaValue *input = &ssa->values[phi->inputs[p]];
            uint32_t base = ssa->cfg->code->registers_size >= ssa->cfg->code->ins_size
                                ? ssa->cfg->code->registers_size - ssa->cfg->code->ins_size : 0;
            if (input->kind == SSA_VALUE_INITIAL && input->reg < base)
                return 0;
        }
    }
    return 1;
}

static int emit_declarations(Buf *out, const SsaMethod *ssa, const TypeInfer *types, int level)
{
    for (uint32_t i = 0; i < ssa->value_count; i++) {
        if (ssa->values[i].kind == SSA_VALUE_INITIAL) continue;
        char type[512];
        if (!type_name(types, i, type, sizeof(type))) return 0;
        line(out, level, "%s v%u = %s;", type, i, java_default_value(type));
    }
    return 1;
}

static uint32_t normal_successors(const CfgBlock *block, uint32_t handler_block,
                                  uint32_t *out, uint32_t cap)
{
    uint32_t n = 0;
    for (uint32_t i = 0; i < block->succ_count; i++) {
        if (block->succ[i] == handler_block)
            continue;
        if (n < cap)
            out[n++] = block->succ[i];
    }
    return n;
}

static int emit_dispatch(Buf *out, Dex *dex, const DexEncodedMethod *enc,
                         SsaMethod *ssa, const TypeInfer *types, int level, Arena *arena,
                         uint32_t handler_block, const char *handler_type)
{
    if (!emit_declarations(out, ssa, types, level)) return 0;
    if (handler_block != CFG_NO_BLOCK) {
        line(out, level, "try {");
        level++;
    }
    line(out, level, "int state = %u;", ssa->cfg->entry);
    line(out, level, "dispatch: while (true) {");
    line(out, level + 1, "switch (state) {");
    for (uint32_t bid = 0; bid < ssa->cfg->block_count; bid++) {
        const CfgBlock *block = &ssa->cfg->blocks[bid];
        if (bid == handler_block)
            continue;
        uint32_t local_norms[1024];
        int count = block_norms(ssa, block, local_norms, 1024);
        if (count < 0 || (uint32_t)count > 1024) return 0;
        line(out, level + 2, "case %u: {", bid);
        uint32_t constructed = SSA_NO_VALUE;
        for (int i = 0; i < count; i++) {
            const SsaInstr *in = &ssa->insns[local_norms[i]];
            if (is_branch(in->raw->opcode) || in->raw->opcode == OP_GOTO ||
                in->raw->opcode == OP_PACKED_SWITCH || in->raw->opcode == OP_SPARSE_SWITCH)
                continue;
            if (!emit_linear_instruction(out, dex, enc, ssa, types, in, level + 3, &constructed, 0))
                return 0;
        }
        if (constructed != SSA_NO_VALUE)
            return 0;
        uint32_t normal[4];
        uint32_t normal_count = normal_successors(block, handler_block, normal, 4);
        const SsaInstr *last = count ? &ssa->insns[local_norms[count - 1]] : NULL;
        uint8_t op = last ? last->raw->opcode : OP_NOP;
        if (last && (is_return(op) || op == OP_THROW)) {
            /* The terminal instruction was emitted by the common instruction path. */
        } else if (last && op == OP_GOTO) {
            uint32_t target = ssa->cfg->addr_to_block[last->raw->target];
            if (target == CFG_NO_BLOCK || !emit_phi_edge(out, ssa, enc, bid, target, level + 3)) return 0;
            line(out, level + 3, "state = %u; continue dispatch;", target);
        } else if (last && (op == OP_PACKED_SWITCH || op == OP_SPARSE_SWITCH)) {
            int32_t *keys = NULL;
            int32_t *targets = NULL;
            uint32_t case_count = cfg_switch_cases(ssa->cfg, last->raw, &keys, &targets,
                                                   arena);
            uint32_t fall_addr = last->raw->addr + last->raw->len;
            uint32_t fall = fall_addr < ssa->cfg->code->insns_size
                                ? ssa->cfg->addr_to_block[fall_addr] : CFG_NO_BLOCK;
            if (!case_count || fall == CFG_NO_BLOCK || last->use_count < 1)
                return 0;
            indent(out, level + 3);
            buf_puts(out, "switch (");
            if (!emit_value(out, ssa, enc, last->use_values[0])) return 0;
            buf_puts(out, ") {\n");
            for (uint32_t k = 0; k < case_count; k++) {
                if (targets[k] < 0 || (uint32_t)targets[k] >= ssa->cfg->code->insns_size)
                    return 0;
                uint32_t target = ssa->cfg->addr_to_block[(uint32_t)targets[k]];
                if (target == CFG_NO_BLOCK)
                    return 0;
                line(out, level + 4, "case %d:", keys[k]);
                if (!emit_phi_edge(out, ssa, enc, bid, target, level + 5))
                    return 0;
                line(out, level + 5, "state = %u; continue dispatch;", target);
            }
            line(out, level + 4, "default:");
            if (!emit_phi_edge(out, ssa, enc, bid, fall, level + 5)) return 0;
            line(out, level + 5, "state = %u; continue dispatch;", fall);
            line(out, level + 3, "}");
        } else if (last && is_branch(op)) {
            uint32_t target = ssa->cfg->addr_to_block[last->raw->target];
            uint32_t fall = last->raw->addr + last->raw->len < ssa->cfg->code->insns_size
                                ? ssa->cfg->addr_to_block[last->raw->addr + last->raw->len] : CFG_NO_BLOCK;
            if (target == CFG_NO_BLOCK || fall == CFG_NO_BLOCK || last->use_count < 1) return 0;
            const char *symbol = "==";
            static const char *ops[] = {"==", "!=", "<", ">=", ">", "<="};
            if (op >= OP_IF_EQ && op <= OP_IF_LE) symbol = ops[op - OP_IF_EQ];
            else if (op >= OP_IF_EQZ && op <= OP_IF_LEZ) symbol = ops[op - OP_IF_EQZ];
            indent(out, level + 3);
            buf_puts(out, "if (");
            if (!emit_value(out, ssa, enc, last->use_values[0])) return 0;
            if (op >= OP_IF_EQ && op <= OP_IF_LE) {
                buf_printf(out, " %s ", symbol);
                if (last->use_count < 2 || !emit_value(out, ssa, enc, last->use_values[1])) return 0;
            } else {
                const char *type = value_type(types, last->use_values[0]);
                const char *zero = type && type[0] == 'Z' ? "false" :
                                  (type && (type[0] == 'L' || type[0] == '[') ? "null" : "0");
                buf_printf(out, " %s %s", symbol, zero);
            }
            buf_puts(out, ") {\n");
            if (!emit_phi_edge(out, ssa, enc, bid, target, level + 4)) return 0;
            line(out, level + 4, "state = %u; continue dispatch;", target);
            line(out, level + 3, "}");
            if (!emit_phi_edge(out, ssa, enc, bid, fall, level + 3)) return 0;
            line(out, level + 3, "state = %u; continue dispatch;", fall);
        } else if (normal_count == 1) {
            uint32_t target = normal[0];
            if (!emit_phi_edge(out, ssa, enc, bid, target, level + 3)) return 0;
            line(out, level + 3, "state = %u; continue dispatch;", target);
        } else if (normal_count == 0 && count == 0) {
            line(out, level + 3, "return;");
        } else {
            return 0;
        }
        line(out, level + 2, "}");
    }
    line(out, level + 2, "default: throw new IllegalStateException(\"bad state\");");
    line(out, level + 1, "}");
    line(out, level, "}");
    if (handler_block != CFG_NO_BLOCK) {
        char catch_type[512];
        if (handler_type)
            remap_java_type(handler_type, catch_type, sizeof(catch_type));
        else
            snprintf(catch_type, sizeof(catch_type), "java.lang.Throwable");
        line(out, level - 1, "} catch (%s e) {", catch_type);
        const CfgBlock *handler = &ssa->cfg->blocks[handler_block];
        uint32_t handler_norms[1024];
        int count = block_norms(ssa, handler, handler_norms, 1024);
        uint32_t constructed = SSA_NO_VALUE;
        for (int i = 0; i < count; i++) {
            const SsaInstr *in = &ssa->insns[handler_norms[i]];
            if (in->raw && in->raw->opcode == OP_MOVE_EXCEPTION) {
                if (in->def_value == SSA_NO_VALUE)
                    return 0;
                line(out, level, "v%u = e;", in->def_value);
                continue;
            }
            if (!emit_linear_instruction(out, dex, enc, ssa, types, in, level, &constructed, 0)) return 0;
        }
        if (constructed != SSA_NO_VALUE)
            return 0;
        line(out, level - 1, "}");
    }
    return 1;
}

int body_emit_ssa(Dex *dex, uint32_t class_def_idx, const DexEncodedMethod *enc,
                  int indent_level, Buf *out, SsaMethod *ssa, const TypeInfer *types,
                  Arena *arena)
{
    (void)class_def_idx;
    (void)arena;
    if (!dex || !enc || !out || !ssa || !types ||
        ssa_validate(ssa) != 0 || type_infer_validate(types) != 0 ||
        types->conflicts != 0 || !ssa_types_complete(ssa, types) ||
        !ssa_emitter_safe(ssa, enc))
        return -1;
    size_t start = out->len;
    int ok;
    if (ssa->cfg->block_count == 1) {
        uint32_t constructed = SSA_NO_VALUE, last_norm = SSA_NO_INDEX;
        CfgBlock *block = &ssa->cfg->blocks[0];
        ok = 1;
        for (uint32_t i = 0; i < block->insn_count; i++) {
            uint32_t raw = block->insn_start + i;
            if (raw >= ssa->raw_count) break;
            uint32_t norm = ssa->raw_to_norm[raw];
            if (norm == SSA_NO_INDEX || norm == last_norm) continue;
            last_norm = norm;
            if (!emit_linear_instruction(out, dex, enc, ssa, types, &ssa->insns[norm],
                                         indent_level, &constructed, 1)) {
                ok = 0;
                break;
            }
        }
        if (constructed != SSA_NO_VALUE) ok = 0;
    } else {
        uint32_t handler_block = CFG_NO_BLOCK;
        const char *handler_type = NULL;
        for (uint32_t i = 0; i < ssa->cfg->handler_count; i++) {
            if (handler_block == CFG_NO_BLOCK) {
                handler_block = ssa->cfg->handlers[i].handler;
                handler_type = ssa->cfg->handlers[i].type;
            } else if (handler_block != ssa->cfg->handlers[i].handler ||
                       (handler_type && ssa->cfg->handlers[i].type &&
                        strcmp(handler_type, ssa->cfg->handlers[i].type))) {
                handler_block = CFG_NO_BLOCK;
                break;
            }
        }
        ok = emit_dispatch(out, dex, enc, ssa, types, indent_level, arena,
                           handler_block, handler_type);
    }
    if (!ok) {
        out->len = start;
        if (out->data) out->data[start] = '\0';
        return -1;
    }
    return 0;
}
