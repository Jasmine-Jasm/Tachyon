src/ir/body.o: src/ir/body.c src/ir/body.h src/common/arena.h \
 src/common/buf.h src/dex/dex.h src/common/io.h src/ir/cfg.h \
 src/ir/opcode.h src/ir/emulate.h src/ir/ssa.h src/ir/type_infer.h \
 src/ir/body_emit.h src/emit/java.h src/emit/renamer.h \
 src/emit/heuristic.h src/emit/java_type.h src/emit/remap.h

src/ir/body.h:

src/common/arena.h:

src/common/buf.h:

src/dex/dex.h:

src/common/io.h:

src/ir/cfg.h:

src/ir/opcode.h:

src/ir/emulate.h:

src/ir/ssa.h:

src/ir/type_infer.h:

src/ir/body_emit.h:

src/emit/java.h:

src/emit/renamer.h:

src/emit/heuristic.h:

src/emit/java_type.h:

src/emit/remap.h:
