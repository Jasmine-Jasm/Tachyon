#include "ir/type_infer.h"

#include <string.h>

#define TYPE_MAX_STEPS 200000u

static int is_invoke_raw(uint8_t op);

static int is_move_raw(uint8_t op)
{
    return op == OP_MOVE || op == OP_MOVE_FROM16 || op == OP_MOVE_16 ||
           op == OP_MOVE_WIDE || op == OP_MOVE_WIDE_FROM16 || op == OP_MOVE_WIDE_16 ||
           op == OP_MOVE_OBJECT || op == OP_MOVE_OBJECT_FROM16 || op == OP_MOVE_OBJECT_16;
}

static int is_field_get(uint8_t op)
{
    return (op >= OP_IGET && op <= OP_IGET_SHORT) ||
           (op >= OP_SGET && op <= OP_SGET_SHORT);
}

static int is_array_get(uint8_t op)
{
    return op >= OP_AGET && op <= OP_AGET_SHORT;
}

static int is_arithmetic(uint8_t op)
{
    return insn_is_unop(op) || insn_is_binop(op) || insn_is_binop_lit(op);
}

typedef struct {
    uint32_t *items;
    uint32_t count;
    uint8_t *queued;
    uint32_t item_count;
} Worklist;

static int is_ref(const char *type)
{
    return type && (type[0] == 'L' || type[0] == '[');
}

static int same(const char *a, const char *b)
{
    return a && b && !strcmp(a, b);
}

static const char *canonical_primitive(const char *type)
{
    if (!type)
        return NULL;
    if (!strcmp(type, "Z") || !strcmp(type, "B") || !strcmp(type, "C") ||
        !strcmp(type, "S") || !strcmp(type, "I"))
        return "I";
    return type;
}

static const char *merge_types(TypeInfer *infer, const char *old, const char *next)
{
    if (!old)
        return next;
    if (!next || same(old, next))
        return old;
    if (is_ref(old) && is_ref(next)) {
        if (!strcmp(old, "Ljava/lang/Object;"))
            return next;
        if (!strcmp(next, "Ljava/lang/Object;"))
            return old;
        if (!strcmp(old, "Ljava/lang/Throwable;"))
            return next;
        if (!strcmp(next, "Ljava/lang/Throwable;"))
            return old;
        infer->conflicts++;
        return old;
    }
    const char *a = canonical_primitive(old);
    const char *b = canonical_primitive(next);
    if (a && b && !strcmp(a, b))
        return a;
    infer->conflicts++;
    return old;
}

static void push(Worklist *work, uint32_t item)
{
    if (item >= work->item_count || work->queued[item])
        return;
    work->queued[item] = 1;
    work->items[work->count++] = item;
}

static void schedule_users(const TypeInfer *infer, Worklist *work, uint32_t value_id)
{
    if (!infer->use_offsets || value_id >= infer->value_count)
        return;
    uint32_t begin = infer->use_offsets[value_id];
    uint32_t end = infer->use_offsets[value_id + 1];
    for (uint32_t i = begin; i < end; i++)
        push(work, infer->use_items[i]);
}

static int set_type(TypeInfer *infer, Worklist *work, uint32_t value_id, const char *type)
{
    if (!type || value_id >= infer->value_count)
        return 0;
    const char *merged = merge_types(infer, infer->types[value_id], type);
    if (same(infer->types[value_id], merged))
        return 0;
    infer->types[value_id] = merged;
    schedule_users(infer, work, value_id);
    return 1;
}

static const char *field_type(const Dex *dex, uint32_t field_idx)
{
    if (!dex || field_idx >= dex->hdr.field_ids_size)
        return NULL;
    return dex_type_desc((Dex *)dex, dex->fields[field_idx].type_idx);
}

static const char *method_return(const Dex *dex, const Insn *raw)
{
    if (!dex || !raw)
        return NULL;
    if (raw->opcode == OP_INVOKE_POLYMORPHIC || raw->opcode == OP_INVOKE_POLYMORPHIC_RANGE) {
        if (raw->proto_idx >= dex->hdr.proto_ids_size)
            return NULL;
        return dex_type_desc((Dex *)dex, dex->protos[raw->proto_idx].return_type_idx);
    }
    if (raw->opcode == OP_FILLED_NEW_ARRAY || raw->opcode == OP_FILLED_NEW_ARRAY_RANGE)
        return raw->idx < dex->hdr.type_ids_size ? dex_type_desc((Dex *)dex, raw->idx) : NULL;
    if (!is_invoke_raw(raw->opcode) || raw->idx >= dex->hdr.method_ids_size)
        return NULL;
    uint32_t proto = dex->methods[raw->idx].proto_idx;
    if (proto >= dex->hdr.proto_ids_size)
        return NULL;
    return dex_type_desc((Dex *)dex, dex->protos[proto].return_type_idx);
}

static int is_invoke_raw(uint8_t op)
{
    return (op >= OP_INVOKE_VIRTUAL && op <= OP_INVOKE_INTERFACE) ||
           (op >= OP_INVOKE_VIRTUAL_RANGE && op <= OP_INVOKE_INTERFACE_RANGE) ||
           op == OP_INVOKE_POLYMORPHIC || op == OP_INVOKE_POLYMORPHIC_RANGE ||
           op == OP_INVOKE_CUSTOM || op == OP_INVOKE_CUSTOM_RANGE;
}

static const char *invoke_param(const Dex *dex, const Insn *raw, uint32_t arg_index,
                                int *is_receiver)
{
    *is_receiver = 0;
    if (!dex || !raw)
        return NULL;
    uint32_t proto = SSA_NO_INDEX;
    uint32_t class_idx = DEX_NO_INDEX;
    int is_static = raw->opcode == OP_INVOKE_STATIC || raw->opcode == OP_INVOKE_STATIC_RANGE;
    if (raw->opcode == OP_INVOKE_POLYMORPHIC || raw->opcode == OP_INVOKE_POLYMORPHIC_RANGE) {
        proto = raw->proto_idx;
    } else if (raw->opcode == OP_INVOKE_CUSTOM || raw->opcode == OP_INVOKE_CUSTOM_RANGE) {
        return NULL;
    } else if (raw->idx < dex->hdr.method_ids_size) {
        proto = dex->methods[raw->idx].proto_idx;
        class_idx = dex->methods[raw->idx].class_idx;
    }
    if (!is_static && arg_index == 0) {
        *is_receiver = 1;
        return class_idx < dex->hdr.type_ids_size ? dex_type_desc((Dex *)dex, class_idx) : NULL;
    }
    uint32_t param = is_static ? arg_index : arg_index - 1;
    if (proto >= dex->hdr.proto_ids_size)
        return NULL;
    DexParamList *list = dex_proto_params((Dex *)dex, proto);
    if (!list || param >= list->param_count)
        return NULL;
    return dex_type_desc((Dex *)dex, list->type_idx[param]);
}

static const char *array_element(const char *type)
{
    return type && type[0] == '[' && type[1] ? type + 1 : NULL;
}

static const char *primitive_array_element(uint8_t op)
{
    switch (op) {
    case OP_AGET_WIDE: return "J";
    case OP_AGET_BOOLEAN: return "Z";
    case OP_AGET_BYTE: return "B";
    case OP_AGET_CHAR: return "C";
    case OP_AGET_SHORT: return "S";
    case OP_AGET: return "I";
    default: return NULL;
    }
}

static const char *conversion_result_type(uint8_t op)
{
    switch (op) {
    case 0x81: return "J";
    case 0x82: return "F";
    case 0x83: return "D";
    case 0x84: return "I";
    case 0x85: return "F";
    case 0x86: return "D";
    case 0x87: return "I";
    case 0x88: return "J";
    case 0x89: return "D";
    case 0x8a: return "I";
    case 0x8b: return "J";
    case 0x8c: return "F";
    case 0x8d: return "B";
    case 0x8e: return "C";
    case 0x8f: return "S";
    default: return NULL;
    }
}

static const char *conversion_input_type(uint8_t op)
{
    if (op >= 0x81 && op <= 0x83) return "I";
    if (op >= 0x84 && op <= 0x86) return "J";
    if (op >= 0x87 && op <= 0x89) return "F";
    if (op >= 0x8a && op <= 0x8c) return "D";
    if (op >= 0x8d && op <= 0x8f) return "I";
    return NULL;
}

static const char *direct_def_type(TypeInfer *infer, const SsaInstr *in)
{
    const Insn *raw = in->raw;
    Dex *dex = infer->ssa->cfg->dex;
    if (!raw || !in->def_count)
        return NULL;
    uint8_t op = raw->opcode;
    if (op == OP_CONST_4 || (op >= OP_CONST_16 && op <= OP_CONST_HIGH16)) return "I";
    if (op >= OP_CONST_WIDE_16 && op <= OP_CONST_WIDE_HIGH16) return "J";
    if (op == OP_CONST_STRING || op == OP_CONST_STRING_JUMBO) return "Ljava/lang/String;";
    if (op == OP_CONST_CLASS) return "Ljava/lang/Class;";
    if (op == OP_NEW_INSTANCE) return raw->idx < dex->hdr.type_ids_size ? dex_type_desc(dex, raw->idx) : NULL;
    if (op == OP_NEW_ARRAY) return raw->idx < dex->hdr.type_ids_size ? dex_type_desc(dex, raw->idx) : NULL;
    if (op == OP_CONST_METHOD_HANDLE) return "Ljava/lang/invoke/MethodHandle;";
    if (op == OP_CONST_METHOD_TYPE) return "Ljava/lang/invoke/MethodType;";
    if (op == OP_MOVE_EXCEPTION) {
        for (uint32_t i = 0; i < infer->ssa->cfg->handler_count; i++) {
            const CfgHandler *handler = &infer->ssa->cfg->handlers[i];
            if (handler->handler == in->block_id)
                return handler->type ? handler->type : "Ljava/lang/Throwable;";
        }
        return "Ljava/lang/Throwable;";
    }
    if (op == OP_ARRAY_LENGTH || op == OP_INSTANCE_OF) return "I";
    if (op >= 0x81 && op <= 0x8f) return conversion_result_type(op);
    if (op >= OP_CMPL_FLOAT && op <= OP_CMP_LONG) return "I";
    if (is_field_get(op)) return field_type(dex, raw->idx);
    if (is_array_get(op)) {
        const char *array = in->use_count ? infer->types[in->use_values[0]] : NULL;
        return array_element(array) ? array_element(array) : primitive_array_element(op);
    }
    if (op == OP_CHECK_CAST)
        return raw->idx < dex->hdr.type_ids_size ? dex_type_desc(dex, raw->idx) : NULL;
    if (is_arithmetic(op)) {
        const char *t = insn_arith_type(op);
        if (t) return t;
        if (op >= 0x81 && op <= 0x8c) {
            switch (op) {
            case 0x81: case 0x84: return "I";
            case 0x82: case 0x87: case 0x8c: return "F";
            case 0x83: case 0x86: case 0x89: return "D";
            default: return "J";
            }
        }
    }
    if (is_invoke_raw(op) || op == OP_FILLED_NEW_ARRAY || op == OP_FILLED_NEW_ARRAY_RANGE)
        return method_return(dex, raw);
    return NULL;
}

static void seed_initial(TypeInfer *infer, Worklist *work)
{
    SsaMethod *m = infer->ssa;
    Dex *dex = m->cfg->dex;
    DexCode *code = m->cfg->code;
    uint32_t base = code->registers_size >= code->ins_size ? code->registers_size - code->ins_size : 0;
    const DexEncodedMethod *enc = m->cfg->enc;
    int has_this = enc && !(enc->access_flags & DEX_ACC_STATIC);
    for (uint32_t r = base; r < code->registers_size && r < m->reg_count; r++) {
        uint32_t slot = r - base;
        const char *type = NULL;
        if (has_this && slot == 0) {
            if (m->cfg->class_def_idx < dex->hdr.class_defs_size)
                type = dex_type_desc(dex, dex->classes[m->cfg->class_def_idx].class_idx);
        } else if (enc && enc->method_idx < dex->hdr.method_ids_size) {
            uint32_t param = has_this ? slot - 1 : slot;
            DexParamList *params = dex_proto_params(dex, dex->methods[enc->method_idx].proto_idx);
            if (params && param < params->param_count)
                type = dex_type_desc(dex, params->type_idx[param]);
        }
        if (type)
            set_type(infer, work, m->initial_values[r], type);
    }
}

static void process_phi(TypeInfer *infer, Worklist *work, uint32_t phi_id)
{
    SsaPhi *phi = &infer->ssa->phis[phi_id];
    const char *merged = NULL;
    for (uint32_t i = 0; i < phi->input_count; i++) {
        const char *type = phi->inputs[i] < infer->value_count ? infer->types[phi->inputs[i]] : NULL;
        if (type)
            merged = merge_types(infer, merged, type);
    }
    if (merged)
        set_type(infer, work, phi->value_id, merged);
}

static void process_instruction(TypeInfer *infer, Worklist *work, uint32_t index)
{
    SsaMethod *m = infer->ssa;
    SsaInstr *in = &m->insns[index];
    const Insn *raw = in->raw;
    Dex *dex = m->cfg->dex;
    const char *direct = direct_def_type(infer, in);
    if (direct && in->def_value != SSA_NO_VALUE)
        set_type(infer, work, in->def_value, direct);

    if (in->def_value != SSA_NO_VALUE && raw && is_move_raw(raw->opcode) && in->use_count)
        set_type(infer, work, in->def_value, infer->types[in->use_values[0]]);

    if (!raw)
        return;
    if (is_invoke_raw(raw->opcode)) {
        for (uint32_t i = 0; i < in->use_count; i++) {
            int receiver = 0;
            const char *expected = invoke_param(dex, raw, i, &receiver);
            if (expected)
                set_type(infer, work, in->use_values[i], expected);
        }
    }
    if (raw->opcode >= OP_IPUT && raw->opcode <= OP_IPUT_SHORT && in->use_count) {
        const char *expected = field_type(dex, raw->idx);
        if (expected)
            set_type(infer, work, in->use_values[0], expected);
    }
    if (raw->opcode >= OP_SPUT && raw->opcode <= OP_SPUT_SHORT && in->use_count) {
        const char *expected = field_type(dex, raw->idx);
        if (expected)
            set_type(infer, work, in->use_values[0], expected);
    }
    if (raw->opcode == OP_THROW && in->use_count)
        set_type(infer, work, in->use_values[0], "Ljava/lang/Throwable;");
    if (raw->opcode == OP_RETURN || raw->opcode == OP_RETURN_WIDE || raw->opcode == OP_RETURN_OBJECT) {
        if (in->use_count && m->cfg->enc && m->cfg->enc->method_idx < dex->hdr.method_ids_size) {
            uint32_t proto = dex->methods[m->cfg->enc->method_idx].proto_idx;
            if (proto < dex->hdr.proto_ids_size)
                set_type(infer, work, in->use_values[0], dex_type_desc(dex, dex->protos[proto].return_type_idx));
        }
    }
    if (is_arithmetic(raw->opcode)) {
        const char *expected = insn_arith_type(raw->opcode);
        if (expected)
            for (uint32_t i = 0; i < in->use_count; i++)
                set_type(infer, work, in->use_values[i], expected);
    }
    if (raw->opcode >= 0x81 && raw->opcode <= 0x8f && in->use_count) {
        const char *expected = conversion_input_type(raw->opcode);
        if (expected)
            set_type(infer, work, in->use_values[0], expected);
    }
}

TypeInfer *type_infer_build(SsaMethod *ssa, Arena *arena)
{
    if (!ssa || !arena)
        return NULL;
    TypeInfer *infer = arena_zalloc(arena, sizeof(*infer));
    if (!infer)
        return NULL;
    infer->ssa = ssa;
    infer->value_count = ssa->value_count;
    infer->types = arena_zalloc(arena, (size_t)infer->value_count * sizeof(*infer->types));
    infer->locked = arena_zalloc(arena, (size_t)infer->value_count);
    uint32_t *use_counts = arena_zalloc(arena, (size_t)(infer->value_count + 1) * sizeof(*use_counts));
    if (infer->value_count) {
        for (uint32_t i = 0; i < ssa->count; i++) {
            const SsaInstr *in = &ssa->insns[i];
            for (uint32_t u = 0; u < in->use_count; u++)
                if (in->use_values[u] < infer->value_count)
                    use_counts[in->use_values[u]]++;
        }
        for (uint32_t i = 0; i < ssa->phi_count; i++) {
            const SsaPhi *phi = &ssa->phis[i];
            for (uint32_t p = 0; p < phi->input_count; p++)
                if (phi->inputs[p] < infer->value_count)
                    use_counts[phi->inputs[p]]++;
        }
    }
    infer->use_offsets = arena_alloc(arena, (size_t)(infer->value_count + 1) * sizeof(*infer->use_offsets));
    if (!infer->use_offsets || !use_counts)
        return NULL;
    infer->use_offsets[0] = 0;
    for (uint32_t i = 0; i < infer->value_count; i++)
        infer->use_offsets[i + 1] = infer->use_offsets[i] + use_counts[i];
    infer->use_item_count = infer->use_offsets[infer->value_count];
    infer->use_items = infer->use_item_count
                           ? arena_alloc(arena, (size_t)infer->use_item_count * sizeof(*infer->use_items))
                           : NULL;
    if (infer->use_item_count && !infer->use_items)
        return NULL;
    if (infer->use_item_count) {
        uint32_t *cursor = arena_alloc(arena, (size_t)infer->value_count * sizeof(*cursor));
        if (!cursor)
            return NULL;
        memcpy(cursor, infer->use_offsets, (size_t)infer->value_count * sizeof(*cursor));
        for (uint32_t i = 0; i < ssa->count; i++) {
            const SsaInstr *in = &ssa->insns[i];
            for (uint32_t u = 0; u < in->use_count; u++) {
                uint32_t value = in->use_values[u];
                if (value < infer->value_count)
                    infer->use_items[cursor[value]++] = i;
            }
        }
        for (uint32_t i = 0; i < ssa->phi_count; i++) {
            const SsaPhi *phi = &ssa->phis[i];
            for (uint32_t p = 0; p < phi->input_count; p++) {
                uint32_t value = phi->inputs[p];
                if (value < infer->value_count)
                    infer->use_items[cursor[value]++] = ssa->count + i;
            }
        }
    }
    uint32_t item_count = ssa->count + ssa->phi_count;
    Worklist work;
    work.items = arena_alloc(arena, (size_t)(item_count ? item_count : 1) * sizeof(*work.items));
    work.queued = arena_zalloc(arena, (size_t)(item_count ? item_count : 1));
    work.count = 0;
    work.item_count = item_count;
    if ((infer->value_count && (!infer->types || !infer->locked)) || !work.items || !work.queued)
        return NULL;

    seed_initial(infer, &work);
    for (uint32_t i = 0; i < ssa->count; i++)
        push(&work, i);
    for (uint32_t i = 0; i < ssa->phi_count; i++)
        push(&work, ssa->count + i);

    while (work.count && infer->iterations++ < TYPE_MAX_STEPS) {
        uint32_t item = work.items[--work.count];
        work.queued[item] = 0;
        if (item < ssa->count)
            process_instruction(infer, &work, item);
        else
            process_phi(infer, &work, item - ssa->count);
    }
    if (work.count)
        infer->malformed = 1;
    return infer;
}

int type_infer_validate(const TypeInfer *infer)
{
    return infer && infer->ssa && !infer->malformed && infer->value_count == infer->ssa->value_count
               ? 0 : -1;
}

const char *type_infer_desc(const TypeInfer *infer, uint32_t value_id)
{
    if (!infer || value_id >= infer->value_count)
        return NULL;
    return infer->types[value_id];
}
