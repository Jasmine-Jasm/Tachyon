#ifndef TACHYON_IR_TYPE_INFER_H
#define TACHYON_IR_TYPE_INFER_H

#include <stdint.h>

#include "common/arena.h"
#include "ir/ssa.h"

typedef struct {
    SsaMethod *ssa;
    const char **types;
    uint8_t *locked;
    uint32_t value_count;
    uint32_t conflicts;
    uint32_t iterations;
    uint32_t *use_offsets;
    uint32_t *use_items;
    uint32_t use_item_count;
    uint8_t malformed;
} TypeInfer;

/* Infers descriptors for SSA values using a work queue over instruction and
 * phi users. Unknown values remain NULL; conflicts are counted and resolved
 * conservatively without invalidating the method. */
TypeInfer *type_infer_build(SsaMethod *ssa, Arena *arena);

int type_infer_validate(const TypeInfer *infer);
const char *type_infer_desc(const TypeInfer *infer, uint32_t value_id);

#endif
