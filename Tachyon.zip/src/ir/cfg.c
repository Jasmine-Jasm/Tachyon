#include "ir/cfg.h"

#include <stdio.h>
#include <string.h>

#define NO 0xffffffffu

static void add_edge(CfgMethod *m, Arena *a, uint32_t from, uint32_t to)
{
    if (from >= m->block_count || to >= m->block_count)
        return;
    CfgBlock *b = &m->blocks[from];

    for (uint32_t i = 0; i < b->succ_count; i++)
        if (b->succ[i] == to)
            return;

    uint32_t *ns = arena_alloc(a, (size_t)(b->succ_count + 1) * sizeof(uint32_t));
    if (!ns)
        return;
    if (b->succ_count)
        memcpy(ns, b->succ, (size_t)b->succ_count * sizeof(uint32_t));
    ns[b->succ_count] = to;
    b->succ = ns;
    b->succ_count++;

    CfgBlock *t = &m->blocks[to];
    uint32_t *np = arena_alloc(a, (size_t)(t->pred_count + 1) * sizeof(uint32_t));
    if (!np)
        return;
    if (t->pred_count)
        memcpy(np, t->pred, (size_t)t->pred_count * sizeof(uint32_t));
    np[t->pred_count] = from;
    t->pred = np;
    t->pred_count++;
}

/* Reads the payload of a packed/sparse switch and returns every case target. */
static uint32_t switch_targets(CfgMethod *m, uint32_t payload_addr, uint32_t switch_addr,
                               int32_t **out, Arena *a)
{
    const uint16_t *c = m->code->insns;
    uint32_t n = m->code->insns_size;
    if (payload_addr + 2 > n)
        return 0;

    uint16_t ident = c[payload_addr];
    uint32_t count = c[payload_addr + 1];

    if (ident == 0x0100) { /* packed-switch payload */
        if (payload_addr + 4 + (size_t)count * 2 > n || count > 0x10000)
            return 0;
        int32_t *t = arena_alloc(a, ((size_t)count + 1) * sizeof(int32_t));
        if (!t)
            return 0;
        for (uint32_t i = 0; i < count; i++) {
            uint16_t lo = c[payload_addr + 4 + i * 2];
            uint16_t hi = c[payload_addr + 5 + i * 2];
            int32_t rel = (int32_t)((uint32_t)lo | ((uint32_t)hi << 16));
            t[i] = (int32_t)switch_addr + rel;
        }
        *out = t;
        return count;
    }
    if (ident == 0x0200) { /* sparse-switch payload */
        if (payload_addr + 2 + (size_t)count * 4 > n || count > 0x10000)
            return 0;
        int32_t *t = arena_alloc(a, ((size_t)count + 1) * sizeof(int32_t));
        if (!t)
            return 0;
        for (uint32_t i = 0; i < count; i++) {
            uint32_t base = payload_addr + 2 + i * 4;
            uint16_t lo = c[base + 2];
            uint16_t hi = c[base + 3];
            int32_t rel = (int32_t)((uint32_t)lo | ((uint32_t)hi << 16));
            t[i] = (int32_t)switch_addr + rel;
        }
        *out = t;
        return count;
    }
    return 0;
}

uint32_t cfg_switch_cases(const CfgMethod *m, const Insn *in, int32_t **keys,
                          int32_t **targets, Arena *arena)
{
    if (!m || !in || !keys || !targets ||
        (in->opcode != OP_PACKED_SWITCH && in->opcode != OP_SPARSE_SWITCH))
        return 0;
    const uint16_t *c = m->code->insns;
    uint32_t n = m->code->insns_size;
    uint32_t addr = in->payload;
    if (addr + 2 > n)
        return 0;
    uint16_t ident = c[addr];
    uint32_t count = c[addr + 1];
    int32_t *ks = arena_alloc(arena, (size_t)count * sizeof(*ks));
    int32_t *ts = arena_alloc(arena, (size_t)count * sizeof(*ts));
    if (!ks || !ts)
        return 0;
    if (ident == 0x0100) {
        if (addr + 4 + (size_t)count * 2 > n)
            return 0;
        int32_t first = (int32_t)((uint32_t)c[addr + 2] | ((uint32_t)c[addr + 3] << 16));
        for (uint32_t i = 0; i < count; i++) {
            uint32_t p = addr + 4 + i * 2;
            int32_t rel = (int32_t)((uint32_t)c[p] | ((uint32_t)c[p + 1] << 16));
            ks[i] = first + (int32_t)i;
            ts[i] = (int32_t)in->addr + rel;
        }
    } else if (ident == 0x0200) {
        if (addr + 2 + (size_t)count * 4 > n)
            return 0;
        for (uint32_t i = 0; i < count; i++) {
            uint32_t p = addr + 2 + i * 4;
            ks[i] = (int32_t)((uint32_t)c[p] | ((uint32_t)c[p + 1] << 16));
            uint32_t t = p + 2;
            int32_t rel = (int32_t)((uint32_t)c[t] | ((uint32_t)c[t + 1] << 16));
            ts[i] = (int32_t)in->addr + rel;
        }
    } else {
        return 0;
    }
    *keys = ks;
    *targets = ts;
    return count;
}

/* Length of a switch payload in code units. */
static uint32_t payload_length(const uint16_t *c, uint32_t n, uint32_t addr)
{
    if (addr + 2 > n)
        return 0;
    uint16_t ident = c[addr];
    uint32_t count = c[addr + 1];
    if (ident == 0x0100)
        return 4 + count * 2;
    if (ident == 0x0200)
        return 2 + count * 4;
    if (ident == 0x0300) {
        if (addr + 4 > n)
            return 0;
        uint32_t width = c[addr + 1];
        uint32_t elems = (uint32_t)c[addr + 2] | ((uint32_t)c[addr + 3] << 16);
        return 4 + (width * elems + 1) / 2;
    }
    return 0;
}

CfgMethod *cfg_build(Dex *dex, uint32_t class_def_idx, const DexEncodedMethod *enc,
                     Arena *arena)
{
    if (!enc || !enc->code_off)
        return NULL;
    DexCode *code = dex_code(dex, enc->code_off);
    if (!code || code->insns_size == 0)
        return NULL;

    CfgMethod *m = arena_zalloc(arena, sizeof(*m));
    if (!m)
        return NULL;
    m->dex = dex;
    m->method_idx = enc->method_idx;
    m->class_def_idx = class_def_idx;
    m->enc = enc;
    m->code = code;

    uint32_t n = code->insns_size;

    /* ---- decode every instruction, skipping payloads ---- */
    m->insns = arena_zalloc(arena, ((size_t)n + 1) * sizeof(Insn));
    m->addr_to_insn = arena_zalloc(arena, ((size_t)n + 1) * sizeof(uint32_t));
    if (!m->insns || !m->addr_to_insn)
        return NULL;
    for (uint32_t i = 0; i <= n; i++)
        m->addr_to_insn[i] = NO;

    uint32_t icount = 0;
    for (uint32_t pc = 0; pc < n;) {
        uint16_t raw = code->insns[pc];
        if ((raw & 0xff) == 0 && raw != 0) {
            uint32_t plen = payload_length(code->insns, n, pc);
            if (plen == 0)
                break;
            pc += plen;
            continue;
        }
        Insn in;
        uint32_t len = insn_decode(code->insns, n, pc, &in);
        if (!len)
            break;
        m->insns[icount] = in;
        m->addr_to_insn[pc] = icount;
        icount++;
        pc += len;
    }

    /* ---- recover try/catch handlers from the code item ---- */
    if (code->tries_size) {
        m->handlers = arena_zalloc(arena, (size_t)code->tries_size * 4 * sizeof(CfgHandler));
        m->handler_count = 0;
    }

    /* ---- identify basic block leaders ---- */
    uint8_t *leader = arena_zalloc(arena, (size_t)n + 1);
    if (!leader)
        return NULL;
    leader[0] = 1;

    for (uint32_t i = 0; i < icount; i++) {
        Insn *in = &m->insns[i];
        uint32_t next = in->addr + in->len;

        int32_t targets[8];
        int nt = insn_target(in, targets, 8);
        for (int t = 0; t < nt; t++) {
            uint32_t a = (uint32_t)targets[t];
            if (a < n)
                leader[a] = 1;
            if (next < n && !insn_is_exit(in))
                leader[next] = 1;
        }
        if (in->opcode == OP_PACKED_SWITCH || in->opcode == OP_SPARSE_SWITCH) {
            int32_t *tg = NULL;
            uint32_t cnt = switch_targets(m, in->payload, in->addr, &tg, arena);
            for (uint32_t k = 0; k < cnt; k++)
                if ((uint32_t)tg[k] < n)
                    leader[(uint32_t)tg[k]] = 1;
            if (next < n)
                leader[next] = 1;
        } else if (insn_is_terminator(in) && next < n) {
            leader[next] = 1;
        }

        /* A try range boundary also starts a block. */
        if (code->tries_size) {
            for (uint32_t t = 0; t < code->tries_size; t++) {
                uint32_t s = code->tries[t].start_addr;
                uint32_t e = s + code->tries[t].insn_count;
                if (s == in->addr || e == in->addr || e == next)
                    leader[in->addr] = 1;
            }
        }
    }

    /* ---- build blocks ---- */
    uint32_t cap = 16;
    m->blocks = arena_zalloc(arena, (size_t)cap * sizeof(CfgBlock));
    if (!m->blocks)
        return NULL;

    uint32_t idx = 0;
    uint32_t cur = 0;
    while (idx < icount) {
        if (cur >= cap) {
            uint32_t nc = cap * 2;
            CfgBlock *nb = arena_zalloc(arena, (size_t)nc * sizeof(CfgBlock));
            if (!nb)
                break;
            memcpy(nb, m->blocks, (size_t)cur * sizeof(CfgBlock));
            m->blocks = nb;
            cap = nc;
        }
        uint32_t start = m->insns[idx].addr;
        uint32_t end_idx = idx;
        while (end_idx < icount) {
            Insn *in = &m->insns[end_idx];
            if (end_idx > idx && leader[in->addr])
                break;
            end_idx++;
            if (insn_is_terminator(in))
                break;
        }
        CfgBlock *b = &m->blocks[cur];
        b->id = cur;
        b->start = start;
        b->insn_start = idx;
        b->insn_count = end_idx - idx;
        b->end = end_idx < icount ? m->insns[end_idx].addr : n;
        cur++;
        idx = end_idx;
    }
    m->block_count = cur;
    if (cur == 0)
        return NULL;

    /* map addresses to block ids */
    m->addr_to_block = arena_zalloc(arena, ((size_t)n + 1) * sizeof(uint32_t));
    if (!m->addr_to_block)
        return NULL;
    for (uint32_t i = 0; i <= n; i++)
        m->addr_to_block[i] = NO;
    for (uint32_t i = 0; i < m->block_count; i++) {
        CfgBlock *b = &m->blocks[i];
        for (uint32_t a = b->start; a < b->end && a < n; a++)
            m->addr_to_block[a] = i;
    }

    /* ---- edges ---- */
    for (uint32_t i = 0; i < m->block_count; i++) {
        CfgBlock *b = &m->blocks[i];
        if (b->insn_count == 0)
            continue;
        Insn *last = &m->insns[b->insn_start + b->insn_count - 1];
        uint32_t next_addr = last->addr + last->len;

        int32_t targets[8];
        int nt = insn_target(last, targets, 8);
        for (int t = 0; t < nt; t++) {
            uint32_t a = (uint32_t)targets[t];
            if (a < n && m->addr_to_block[a] != NO)
                add_edge(m, arena, i, m->addr_to_block[a]);
        }

        if (last->opcode == OP_PACKED_SWITCH || last->opcode == OP_SPARSE_SWITCH) {
            int32_t *tg = NULL;
            uint32_t cnt = switch_targets(m, last->payload, last->addr, &tg, arena);
            for (uint32_t k = 0; k < cnt; k++)
                if ((uint32_t)tg[k] < n && m->addr_to_block[(uint32_t)tg[k]] != NO)
                    add_edge(m, arena, i, m->addr_to_block[(uint32_t)tg[k]]);
            if (next_addr < n && m->addr_to_block[next_addr] != NO)
                add_edge(m, arena, i, m->addr_to_block[next_addr]);
        } else if (!insn_is_exit(last)) {
            if (next_addr < n && m->addr_to_block[next_addr] != NO)
                add_edge(m, arena, i, m->addr_to_block[next_addr]);
        }
    }

    /* ---- exception edges: a try block can transfer to its handler ---- */
    if (code->tries_size) {
        for (uint32_t t = 0; t < code->tries_size; t++) {
            DexTryBlock *tb = &code->tries[t];
            uint32_t s = tb->start_addr;
            uint32_t e = s + tb->insn_count;
            for (uint32_t i = 0; i < m->block_count; i++) {
                CfgBlock *b = &m->blocks[i];
                if (b->start < s || b->start >= e)
                    continue;
                for (uint32_t h = 0; h < tb->handler_count; h++) {
                    uint32_t ha = tb->handlers[h].addr;
                    if (ha < n && m->addr_to_block[ha] != NO) {
                        uint32_t hb = m->addr_to_block[ha];
                        if (m->handler_count < code->tries_size * 4) {
                            m->handlers[m->handler_count].start = s;
                            m->handlers[m->handler_count].end = e;
                            m->handlers[m->handler_count].type =
                                tb->handlers[h].type_idx == DEX_NO_INDEX
                                    ? NULL
                                    : dex_type_desc(dex, tb->handlers[h].type_idx);
                            m->handlers[m->handler_count].handler = hb;
                            m->handler_count++;
                        }
                        add_edge(m, arena, i, hb);
                    }
                }
            }
        }
    }

    m->entry = 0;
    m->exit = NO;
    return m;
}

/* ---------------------------------------------------------------- */
/* dominators                                                        */
/* ---------------------------------------------------------------- */

static int block_index(const CfgMethod *m, uint32_t id)
{
    return (int)(id < m->block_count ? id : 0);
}

void cfg_compute_dominators(CfgMethod *m, Arena *arena)
{
    uint32_t nb = m->block_count;
    if (!nb)
        return;

    /* Reverse post order via iterative DFS from the entry block. */
    uint32_t *rpo = arena_alloc(arena, (size_t)nb * sizeof(uint32_t));
    uint32_t *order = arena_alloc(arena, (size_t)nb * sizeof(uint32_t));
    uint8_t *seen = arena_zalloc(arena, nb);
    uint32_t *stack = arena_alloc(arena, (size_t)(nb + 1) * sizeof(uint32_t));
    uint32_t *sp_pos = arena_zalloc(arena, (size_t)(nb + 1) * sizeof(uint32_t));
    if (!rpo || !order || !seen || !stack || !sp_pos)
        return;

    uint32_t sp = 0, norder = 0;
    stack[sp] = m->entry;
    sp_pos[sp] = 0;
    seen[m->entry] = 1;
    sp++;
    while (sp) {
        uint32_t v = stack[sp - 1];
        CfgBlock *b = &m->blocks[v];
        if (sp_pos[sp - 1] < b->succ_count) {
            uint32_t w = b->succ[sp_pos[sp - 1]++];
            if (w < nb && !seen[w]) {
                seen[w] = 1;
                stack[sp] = w;
                sp_pos[sp] = 0;
                sp++;
            }
        } else {
            order[norder++] = v;
            sp--;
        }
    }

    for (uint32_t i = 0; i < nb; i++)
        m->blocks[i].idom = NO;
    for (uint32_t i = 0; i < norder; i++)
        rpo[i] = order[norder - 1 - i];

    uint32_t *rpo_num = arena_alloc(arena, (size_t)nb * sizeof(uint32_t));
    if (!rpo_num)
        return;
    for (uint32_t i = 0; i < nb; i++)
        rpo_num[i] = NO;
    for (uint32_t i = 0; i < norder; i++)
        rpo_num[rpo[i]] = i;

    if (norder == 0)
        return;
    m->blocks[m->entry].idom = m->entry;

    int changed = 1;
    int guard = 0;
    while (changed && guard++ < 200) {
        changed = 0;
        for (uint32_t i = 0; i < norder; i++) {
            uint32_t b = rpo[i];
            if (b == m->entry)
                continue;
            CfgBlock *blk = &m->blocks[b];
            uint32_t newidom = NO;
            for (uint32_t p = 0; p < blk->pred_count; p++) {
                uint32_t pred = blk->pred[p];
                if (pred >= nb || rpo_num[pred] == NO)
                    continue;
                if (m->blocks[pred].idom == NO)
                    continue;
                if (newidom == NO) {
                    newidom = pred;
                    continue;
                }
                /* intersect */
                uint32_t a = pred, c = newidom;
                int steps = 0;
                while (a != c && steps++ < (int)nb * 2) {
                    while (rpo_num[a] != NO && rpo_num[c] != NO && rpo_num[a] > rpo_num[c] &&
                           m->blocks[a].idom != NO && m->blocks[a].idom != a)
                        a = m->blocks[a].idom;
                    while (rpo_num[a] != NO && rpo_num[c] != NO && rpo_num[c] > rpo_num[a] &&
                           m->blocks[c].idom != NO && m->blocks[c].idom != c)
                        c = m->blocks[c].idom;
                }
                newidom = a;
            }
            if (newidom != NO && m->blocks[b].idom != newidom) {
                m->blocks[b].idom = newidom;
                changed = 1;
            }
        }
    }
}

/* ---------------------------------------------------------------- */
/* loops                                                             */
/* ---------------------------------------------------------------- */

void cfg_find_loops(CfgMethod *m, Arena *arena)
{
    uint32_t nb = m->block_count;
    if (!nb)
        return;

    for (uint32_t i = 0; i < nb; i++) {
        CfgBlock *b = &m->blocks[i];
        for (uint32_t s = 0; s < b->succ_count; s++) {
            uint32_t su = b->succ[s];
            if (su >= nb)
                continue;
            /* A back edge is one whose head dominates its tail. */
            uint32_t walk = i;
            int dominated = 0;
            int steps = 0;
            while (steps++ < (int)nb * 2) {
                if (walk == su) {
                    dominated = 1;
                    break;
                }
                uint32_t id = m->blocks[walk].idom;
                if (id == NO || id == walk)
                    break;
                walk = id;
            }
            if (!dominated)
                continue;

            /* Collect the natural loop body by walking predecessors back to the
             * header. */
            uint8_t *inloop = arena_zalloc(arena, nb);
            uint32_t *stk = arena_alloc(arena, (size_t)(nb + 1) * sizeof(uint32_t));
            if (!inloop || !stk)
                continue;
            uint32_t top = 0;
            inloop[su] = 1;
            stk[top++] = i;
            inloop[i] = 1;
            while (top) {
                uint32_t v = stk[--top];
                CfgBlock *vb = &m->blocks[v];
                for (uint32_t p = 0; p < vb->pred_count; p++) {
                    uint32_t pr = vb->pred[p];
                    if (pr >= nb || inloop[pr])
                        continue;
                    inloop[pr] = 1;
                    if (top < nb)
                        stk[top++] = pr;
                }
            }

            uint32_t cnt = 0;
            for (uint32_t k = 0; k < nb; k++)
                if (inloop[k])
                    cnt++;
            uint32_t *body = arena_alloc(arena, ((size_t)cnt + 1) * sizeof(uint32_t));
            if (!body)
                continue;
            uint32_t o = 0;
            for (uint32_t k = 0; k < nb; k++)
                if (inloop[k])
                    body[o++] = k;

            m->blocks[su].is_loop_header = 1;
            m->blocks[su].loop_body = body;
            m->blocks[su].loop_size = o;
        }
    }
    (void)block_index;
}

void cfg_dump_dot(const CfgMethod *m, void *fp)
{
    FILE *f = fp;
    fprintf(f, "digraph m%u {\n", m->method_idx);
    for (uint32_t i = 0; i < m->block_count; i++) {
        const CfgBlock *b = &m->blocks[i];
        fprintf(f, "  b%u [label=\"b%u [%04x-%04x]%s\"];\n", b->id, b->id, b->start, b->end,
                b->is_loop_header ? " loop" : "");
    }
    for (uint32_t i = 0; i < m->block_count; i++) {
        const CfgBlock *b = &m->blocks[i];
        for (uint32_t s = 0; s < b->succ_count; s++)
            fprintf(f, "  b%u -> b%u;\n", b->id, b->succ[s]);
    }
    fprintf(f, "}\n");
}
