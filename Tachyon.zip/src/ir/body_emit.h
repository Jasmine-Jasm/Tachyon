#ifndef TACHYON_IR_BODY_EMIT_H
#define TACHYON_IR_BODY_EMIT_H

#include "common/arena.h"
#include "common/buf.h"
#include "dex/dex.h"
#include "ir/ssa.h"
#include "ir/type_infer.h"

/* Emits a semantically safe body for the subset proven by the SSA model.
 * Returns 0 when the whole method was emitted, -1 when the caller should use
 * the legacy renderer or stub fallback. */
int body_emit_ssa(Dex *dex, uint32_t class_def_idx, const DexEncodedMethod *enc,
                  int indent, Buf *out, SsaMethod *ssa, const TypeInfer *types,
                  Arena *arena);

#endif
