#ifndef TACHYON_IR_BODY_H
#define TACHYON_IR_BODY_H

#include <stdint.h>

#include "common/arena.h"
#include "common/buf.h"
#include "dex/dex.h"
#include "ir/cfg.h"

/* Decompiles one method body into Java statements. Returns 0 when a structured
 * rendering was produced, -1 when the caller must fall back to a stub.
 * `indent` is the number of tab levels the body should start at. */
int body_decompile(Dex *dex, uint32_t class_def_idx, const DexEncodedMethod *enc,
                   int indent, Buf *out, Arena *arena);

/* Emits just the super(...) chain of a constructor, taken from the parent's
 * declared descriptor. Returns 0 when a chain was written. */
int body_decompile_ctor_chain(Dex *dex, uint32_t class_def_idx, int indent, Buf *out,
                              Arena *arena);

#endif
