src/ir/emulate.o: src/ir/emulate.c src/ir/emulate.h src/common/arena.h \
 src/dex/dex.h src/common/buf.h src/common/io.h src/ir/opcode.h

src/ir/emulate.h:

src/common/arena.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/ir/opcode.h:
