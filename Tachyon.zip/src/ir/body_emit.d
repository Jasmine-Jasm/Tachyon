src/ir/body_emit.o: src/ir/body_emit.c src/ir/body_emit.h \
 src/common/arena.h src/common/buf.h src/dex/dex.h src/common/io.h \
 src/ir/ssa.h src/ir/cfg.h src/ir/opcode.h src/ir/type_infer.h \
 src/emit/java.h src/emit/renamer.h src/emit/heuristic.h \
 src/emit/java_type.h src/emit/remap.h

src/ir/body_emit.h:

src/common/arena.h:

src/common/buf.h:

src/dex/dex.h:

src/common/io.h:

src/ir/ssa.h:

src/ir/cfg.h:

src/ir/opcode.h:

src/ir/type_infer.h:

src/emit/java.h:

src/emit/renamer.h:

src/emit/heuristic.h:

src/emit/java_type.h:

src/emit/remap.h:
