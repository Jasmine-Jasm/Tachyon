#ifndef TACHYON_ZIP_INFLATE_H
#define TACHYON_ZIP_INFLATE_H

#include <stddef.h>
#include <stdint.h>

/* Result codes for inflate_raw. */
enum {
    INFLATE_OK = 0,
    INFLATE_ERR_TRUNCATED = -1,
    INFLATE_ERR_CORRUPT = -2,
    INFLATE_ERR_NOMEM = -3,
    INFLATE_ERR_OUTPUT = -4,
};

/* Decompresses a raw DEFLATE stream (no zlib header).
 * `out` must be at least `out_cap` bytes; *out_len receives the produced size.
 * Returns INFLATE_OK or a negative error. */
int inflate_raw(const uint8_t *in, size_t in_len, uint8_t *out, size_t out_cap,
                size_t *out_len);

/* Decompresses a zlib stream (2-byte header + adler32 trailer). */
int inflate_zlib(const uint8_t *in, size_t in_len, uint8_t *out, size_t out_cap,
                 size_t *out_len);

#endif
