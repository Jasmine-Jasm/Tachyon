#include "zip/zip.h"

#include <stdlib.h>
#include <string.h>

#include "zip/inflate.h"

static uint16_t rd16(const uint8_t *p)
{
    return (uint16_t)(p[0] | (p[1] << 8));
}

static uint32_t rd32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

#define EOCD_SIG 0x06054b50u
#define CEN_SIG 0x02014b50u
#define LOC_SIG 0x04034b50u

ZipFile *zip_open(const uint8_t *data, size_t size, Arena *arena)
{
    if (size < 22)
        return NULL;

    /* The EOCD sits at the end, possibly followed by a comment of up to 64K. */
    size_t scan_from = size > 65557 ? size - 65557 : 0;
    size_t eocd = (size_t)-1;
    for (size_t i = size - 21; i > scan_from; i--) {
        if (rd32(data + i - 1) == EOCD_SIG) {
            eocd = i - 1;
            break;
        }
    }
    if (eocd == (size_t)-1)
        return NULL;

    uint32_t total = rd16(data + eocd + 10);
    uint32_t cd_size = rd32(data + eocd + 12);
    uint32_t cd_off = rd32(data + eocd + 16);
    if (cd_off > size || cd_size > size - cd_off)
        return NULL;

    ZipFile *z = arena_zalloc(arena, sizeof(*z));
    if (!z)
        return NULL;
    z->data = data;
    z->size = size;
    z->arena = arena;
    z->entries = arena_zalloc(arena, ((size_t)total + 1) * sizeof(ZipEntry));
    if (!z->entries)
        return NULL;

    size_t p = cd_off;
    for (uint32_t i = 0; i < total && p + 46 <= size; i++) {
        if (rd32(data + p) != CEN_SIG)
            break;
        ZipEntry *e = &z->entries[z->count];
        e->method = rd16(data + p + 10);
        e->crc32 = rd32(data + p + 16);
        e->comp_size = rd32(data + p + 20);
        e->uncomp_size = rd32(data + p + 24);
        uint16_t name_len = rd16(data + p + 28);
        uint16_t extra_len = rd16(data + p + 30);
        uint16_t comment_len = rd16(data + p + 32);
        e->local_header_off = rd32(data + p + 42);

        if (p + 46 + name_len > size)
            break;
        char *name = arena_alloc(arena, (size_t)name_len + 1);
        if (!name)
            break;
        memcpy(name, data + p + 46, name_len);
        name[name_len] = '\0';
        e->name = name;

        z->count++;
        p += 46 + (size_t)name_len + extra_len + comment_len;
    }
    return z;
}

const ZipEntry *zip_find(ZipFile *z, const char *name)
{
    for (uint32_t i = 0; i < z->count; i++)
        if (!strcmp(z->entries[i].name, name))
            return &z->entries[i];
    return NULL;
}

int zip_extract(ZipFile *z, const ZipEntry *e, uint8_t **out, size_t *out_len)
{
    *out = NULL;
    *out_len = 0;
    if (!e || e->local_header_off >= z->size)
        return -1;
    if (rd32(z->data + e->local_header_off) != LOC_SIG)
        return -1;

    uint16_t name_len = rd16(z->data + e->local_header_off + 26);
    uint16_t extra_len = rd16(z->data + e->local_header_off + 28);
    size_t data_off = (size_t)e->local_header_off + 30 + name_len + extra_len;
    if (data_off > z->size || (size_t)e->comp_size > z->size - data_off)
        return -1;

    if (e->method == 0) {
        uint8_t *buf = arena_alloc(z->arena, (size_t)e->uncomp_size + 1);
        if (!buf)
            return -1;
        memcpy(buf, z->data + data_off, e->uncomp_size);
        *out = buf;
        *out_len = e->uncomp_size;
        return 0;
    }
    if (e->method != 8)
        return -1; /* unsupported compression method */

    uint8_t *buf = arena_alloc(z->arena, (size_t)e->uncomp_size + 1);
    if (!buf)
        return -1;
    size_t produced = 0;
    int rc = inflate_raw(z->data + data_off, e->comp_size, buf, e->uncomp_size, &produced);
    if (rc != INFLATE_OK)
        return -1;
    *out = buf;
    *out_len = produced;
    return 0;
}
