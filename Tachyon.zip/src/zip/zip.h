#ifndef TACHYON_ZIP_ZIP_H
#define TACHYON_ZIP_ZIP_H

#include <stddef.h>
#include <stdint.h>

#include "common/arena.h"

typedef struct {
    const char *name;
    uint16_t method;      /* 0 = stored, 8 = deflate */
    uint32_t comp_size;
    uint32_t uncomp_size;
    uint32_t local_header_off;
    uint32_t crc32;
} ZipEntry;

typedef struct {
    const uint8_t *data;   /* borrowed */
    size_t size;
    ZipEntry *entries;
    uint32_t count;
    Arena *arena;
} ZipFile;

/* Parses the central directory. Returns NULL on failure. */
ZipFile *zip_open(const uint8_t *data, size_t size, Arena *arena);

/* Extracts an entry into a newly allocated buffer (arena-owned). */
int zip_extract(ZipFile *z, const ZipEntry *e, uint8_t **out, size_t *out_len);

/* Looks up an entry by exact name; returns NULL when absent. */
const ZipEntry *zip_find(ZipFile *z, const char *name);

#endif
