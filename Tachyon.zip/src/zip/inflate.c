#include "zip/inflate.h"

#include <string.h>

/*
 * A compact RFC 1951 decoder. Huffman tables are built as canonical codes and
 * decoded bit-by-bit with a count/offset table, which keeps the code small and
 * is fast enough for APK entries (dex payloads are a few MB at most).
 */

typedef struct {
    const uint8_t *in;
    size_t in_len;
    size_t in_pos;
    uint32_t bitbuf;
    int bitcnt;

    uint8_t *out;
    size_t out_cap;
    size_t out_pos;
    int err;
} State;

static int bits(State *s, int need)
{
    while (s->bitcnt < need) {
        if (s->in_pos >= s->in_len) {
            s->err = INFLATE_ERR_TRUNCATED;
            return 0;
        }
        s->bitbuf |= (uint32_t)s->in[s->in_pos++] << s->bitcnt;
        s->bitcnt += 8;
    }
    int v = (int)(s->bitbuf & ((1u << need) - 1));
    s->bitbuf >>= need;
    s->bitcnt -= need;
    return v;
}

typedef struct {
    uint16_t count[16];
    uint16_t symbol[320];
} Huff;

/* Builds a canonical Huffman decoding table from code lengths. */
static int huff_build(Huff *h, const uint8_t *lengths, int n)
{
    memset(h->count, 0, sizeof(h->count));
    for (int i = 0; i < n; i++)
        h->count[lengths[i]]++;
    if (h->count[0] == n)
        return 0; /* no codes: valid but never decodes */

    int left = 1;
    for (int len = 1; len < 16; len++) {
        left <<= 1;
        left -= h->count[len];
        if (left < 0)
            return INFLATE_ERR_CORRUPT; /* over-subscribed */
    }

    uint16_t offs[16];
    offs[1] = 0;
    for (int len = 1; len < 15; len++)
        offs[len + 1] = (uint16_t)(offs[len] + h->count[len]);
    for (int i = 0; i < n; i++)
        if (lengths[i])
            h->symbol[offs[lengths[i]]++] = (uint16_t)i;
    return 0;
}

static int huff_decode(State *s, const Huff *h)
{
    int code = 0, first = 0, index = 0;
    for (int len = 1; len < 16; len++) {
        code |= bits(s, 1);
        if (s->err)
            return -1;
        int count = h->count[len];
        if (code - first < count)
            return h->symbol[index + (code - first)];
        index += count;
        first = (first + count) << 1;
        code <<= 1;
    }
    s->err = INFLATE_ERR_CORRUPT;
    return -1;
}

static const uint16_t LEN_BASE[29] = {
    3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
    35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
static const uint8_t LEN_EXTRA[29] = {
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
    3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
static const uint16_t DIST_BASE[30] = {
    1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
    257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145,
    8193, 12289, 16385, 24577};
static const uint8_t DIST_EXTRA[30] = {
    0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
    7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

static int inflate_block(State *s, Huff *lit, Huff *dist)
{
    for (;;) {
        int sym = huff_decode(s, lit);
        if (s->err)
            return s->err;
        if (sym < 256) {
            if (s->out_pos >= s->out_cap)
                return INFLATE_ERR_OUTPUT;
            s->out[s->out_pos++] = (uint8_t)sym;
        } else if (sym == 256) {
            return INFLATE_OK;
        } else {
            sym -= 257;
            if (sym >= 29)
                return INFLATE_ERR_CORRUPT;
            int len = LEN_BASE[sym] + bits(s, LEN_EXTRA[sym]);
            if (s->err)
                return s->err;
            int dsym = huff_decode(s, dist);
            if (s->err)
                return s->err;
            if (dsym >= 30)
                return INFLATE_ERR_CORRUPT;
            int d = DIST_BASE[dsym] + bits(s, DIST_EXTRA[dsym]);
            if (s->err)
                return s->err;
            if ((size_t)d > s->out_pos)
                return INFLATE_ERR_CORRUPT;
            if (s->out_pos + (size_t)len > s->out_cap)
                return INFLATE_ERR_OUTPUT;
            size_t src = s->out_pos - (size_t)d;
            for (int i = 0; i < len; i++)
                s->out[s->out_pos++] = s->out[src++];
        }
    }
}

static int inflate_fixed(State *s)
{
    static Huff lit, dist;
    static int ready;
    if (!ready) {
        uint8_t lengths[288];
        for (int i = 0; i < 144; i++) lengths[i] = 8;
        for (int i = 144; i < 256; i++) lengths[i] = 9;
        for (int i = 256; i < 280; i++) lengths[i] = 7;
        for (int i = 280; i < 288; i++) lengths[i] = 8;
        if (huff_build(&lit, lengths, 288))
            return INFLATE_ERR_CORRUPT;
        for (int i = 0; i < 30; i++) lengths[i] = 5;
        if (huff_build(&dist, lengths, 30))
            return INFLATE_ERR_CORRUPT;
        ready = 1;
    }
    return inflate_block(s, &lit, &dist);
}

static int inflate_dynamic(State *s)
{
    static const uint8_t ORDER[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5,
                                      11, 4, 12, 3, 13, 2, 14, 1, 15};
    int hlit = bits(s, 5) + 257;
    int hdist = bits(s, 5) + 1;
    int hclen = bits(s, 4) + 4;
    if (s->err)
        return s->err;
    if (hlit > 286 || hdist > 30)
        return INFLATE_ERR_CORRUPT;

    uint8_t clen[19];
    memset(clen, 0, sizeof(clen));
    for (int i = 0; i < hclen; i++)
        clen[ORDER[i]] = (uint8_t)bits(s, 3);
    if (s->err)
        return s->err;

    Huff code_huff;
    int rc = huff_build(&code_huff, clen, 19);
    if (rc)
        return rc;

    uint8_t lengths[288 + 30];
    memset(lengths, 0, sizeof(lengths));
    int total = hlit + hdist;
    for (int i = 0; i < total;) {
        int sym = huff_decode(s, &code_huff);
        if (s->err)
            return s->err;
        if (sym < 16) {
            lengths[i++] = (uint8_t)sym;
        } else if (sym == 16) {
            if (i == 0)
                return INFLATE_ERR_CORRUPT;
            int rep = 3 + bits(s, 2);
            if (s->err)
                return s->err;
            uint8_t prev = lengths[i - 1];
            while (rep-- && i < total)
                lengths[i++] = prev;
        } else if (sym == 17) {
            int rep = 3 + bits(s, 3);
            if (s->err)
                return s->err;
            while (rep-- && i < total)
                lengths[i++] = 0;
        } else {
            int rep = 11 + bits(s, 7);
            if (s->err)
                return s->err;
            while (rep-- && i < total)
                lengths[i++] = 0;
        }
    }

    Huff lit, dist;
    rc = huff_build(&lit, lengths, hlit);
    if (rc)
        return rc;
    rc = huff_build(&dist, lengths + hlit, hdist);
    if (rc)
        return rc;
    return inflate_block(s, &lit, &dist);
}

int inflate_raw(const uint8_t *in, size_t in_len, uint8_t *out, size_t out_cap,
                size_t *out_len)
{
    State s;
    memset(&s, 0, sizeof(s));
    s.in = in;
    s.in_len = in_len;
    s.out = out;
    s.out_cap = out_cap;

    int rc = INFLATE_OK;
    int final = 0;
    while (!final) {
        final = bits(&s, 1);
        if (s.err) {
            rc = s.err;
            break;
        }
        int type = bits(&s, 2);
        if (s.err) {
            rc = s.err;
            break;
        }
        if (type == 0) {
            /* Stored block: align to a byte boundary then copy verbatim. */
            s.bitbuf = 0;
            s.bitcnt = 0;
            if (s.in_pos + 4 > s.in_len) {
                rc = INFLATE_ERR_TRUNCATED;
                break;
            }
            uint32_t len = (uint32_t)s.in[s.in_pos] | ((uint32_t)s.in[s.in_pos + 1] << 8);
            uint32_t nlen = (uint32_t)s.in[s.in_pos + 2] | ((uint32_t)s.in[s.in_pos + 3] << 8);
            s.in_pos += 4;
            if ((len ^ 0xffffu) != nlen || s.in_pos + len > s.in_len) {
                rc = INFLATE_ERR_CORRUPT;
                break;
            }
            if (s.out_pos + len > s.out_cap) {
                rc = INFLATE_ERR_OUTPUT;
                break;
            }
            memcpy(s.out + s.out_pos, s.in + s.in_pos, len);
            s.out_pos += len;
            s.in_pos += len;
        } else if (type == 1) {
            rc = inflate_fixed(&s);
            if (rc) break;
        } else if (type == 2) {
            rc = inflate_dynamic(&s);
            if (rc) break;
        } else {
            rc = INFLATE_ERR_CORRUPT;
            break;
        }
    }
    if (out_len)
        *out_len = s.out_pos;
    return rc;
}

int inflate_zlib(const uint8_t *in, size_t in_len, uint8_t *out, size_t out_cap,
                 size_t *out_len)
{
    if (in_len < 6)
        return INFLATE_ERR_TRUNCATED;
    /* 0x78 is the common CMF byte for deflate with a 32K window. */
    if ((in[0] & 0x0f) != 8)
        return INFLATE_ERR_CORRUPT;
    if (((uint32_t)in[0] << 8 | in[1]) % 31 != 0)
        return INFLATE_ERR_CORRUPT;
    return inflate_raw(in + 2, in_len - 6, out, out_cap, out_len);
}
