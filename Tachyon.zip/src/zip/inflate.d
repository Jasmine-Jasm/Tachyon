src/zip/inflate.o: src/zip/inflate.c src/zip/inflate.h

src/zip/inflate.h:
