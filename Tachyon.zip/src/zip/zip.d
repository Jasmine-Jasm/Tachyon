src/zip/zip.o: src/zip/zip.c src/zip/zip.h src/common/arena.h \
 src/zip/inflate.h

src/zip/zip.h:

src/common/arena.h:

src/zip/inflate.h:
