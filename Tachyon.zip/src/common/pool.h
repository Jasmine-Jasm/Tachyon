#ifndef TACHYON_POOL_H
#define TACHYON_POOL_H

#include <stdint.h>

/* Work item: renders one class. Returning non-zero marks a failure. */
typedef int (*pool_task_fn)(void *ctx, uint32_t index, void *out_arg);

typedef struct {
    /* number of worker threads for CPU-bound decompilation */
    int workers;
    /* number of threads used for the write stage; may exceed CPU count because
     * these are I/O bound and mostly blocked in write() */
    int io_workers;
    /* Items are handed out in contiguous chunks of this size. One bigger unit of
     * work per fetch amortises the atomic operation over many items; too large a
     * chunk leaves late workers idle. 0 selects a size from the item count. */
    uint32_t chunk;
} PoolConfig;

/* Runs `fn` for indices [0, count) across `workers` threads. `out_arg` is passed
 * through unchanged. Returns the number of failed items. */
uint32_t pool_run(const PoolConfig *cfg, uint32_t count, pool_task_fn fn, void *ctx,
                  void *out_arg);

/* Number of online CPUs, clamped to [1, 256]. */
int pool_cpu_count(void);

#endif
