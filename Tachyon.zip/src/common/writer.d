src/common/writer.o: src/common/writer.c src/common/writer.h \
 src/common/io.h

src/common/writer.h:

src/common/io.h:
