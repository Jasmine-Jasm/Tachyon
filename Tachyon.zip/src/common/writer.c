#include "common/writer.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "common/io.h"

static int join(char *out, size_t cap, const char *dir, const char *rel)
{
    int n = snprintf(out, cap, "%s/%s", dir, rel);
    return (n > 0 && (size_t)n < cap) ? 0 : -1;
}

int writer_mkdirs_for(const char *dir, const char *relpath)
{
    char full[4096];
    if (join(full, sizeof(full), dir, relpath))
        return -1;
    char *slash = strrchr(full, '/');
    if (!slash)
        return 0;
    *slash = '\0';
    return io_mkdirs(full);
}

/* Creating directories is by far the most expensive part: classes arrive in
 * name order, so consecutive writes usually hit different directories and the
 * "last directory" cache below almost never fires. A small set of recently seen
 * directories, keyed by hash, removes nearly all of those mkdir walks. */
#define DIR_CACHE_SLOTS 16384
static _Thread_local char *t_dir_cache[DIR_CACHE_SLOTS];
static _Thread_local int t_dir_fds[DIR_CACHE_SLOTS];
static _Thread_local unsigned char t_dir_used[DIR_CACHE_SLOTS];

static uint32_t dir_hash(const char *s)
{
    uint32_t h = 2166136261u;
    while (*s)
        h = (h ^ (uint8_t)*s++) * 16777619u;
    return h;
}

static int dir_fd(const char *path)
{
    uint32_t k = dir_hash(path) & (DIR_CACHE_SLOTS - 1);
    if (t_dir_used[k] && t_dir_cache[k] && !strcmp(t_dir_cache[k], path))
        return t_dir_fds[k];
    int fd = open(path, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (fd < 0)
        return -1;
    if (t_dir_used[k]) {
        close(t_dir_fds[k]);
        free(t_dir_cache[k]);
    }
    size_t n = strlen(path);
    char *copy = malloc(n + 1);
    if (!copy) {
        close(fd);
        return -1;
    }
    memcpy(copy, path, n + 1);
    t_dir_cache[k] = copy;
    t_dir_fds[k] = fd;
    t_dir_used[k] = 1;
    return fd;
}

static int writer_open_cached(const char *dir, const char *relpath, int flags)
{
    char full[4096];
    if (join(full, sizeof(full), dir, relpath))
        return -1;
    char *slash = strrchr(full, '/');
    if (!slash)
        return open(full, flags | O_CLOEXEC, 0644);
    *slash = '\0';
    int dfd = dir_fd(full);
    if (dfd < 0) {
        *slash = '/';
        return open(full, flags | O_CLOEXEC, 0644);
    }
    return openat(dfd, slash + 1, flags | O_CLOEXEC, 0644);
}

/* Batched write: several classes destined for one directory are appended to a
 * single file. f2fs charges roughly the same for a create as for a small write,
 * so collapsing N tiny files into one removes most of the metadata cost. */
int writer_append(const char *dir, const char *relpath, const char *data, size_t len)
{
    int fd = writer_open_cached(dir, relpath, O_WRONLY | O_CREAT | O_APPEND);
    if (fd < 0)
        return -1;
    size_t off = 0;
    while (off < len) {
        ssize_t w = write(fd, data + off, len - off);
        if (w < 0) {
            if (errno == EINTR)
                continue;
            close(fd);
            return -1;
        }
        off += (size_t)w;
    }
    return close(fd) == 0 ? 0 : -1;
}

int writer_write(const char *dir, const char *relpath, const char *data, size_t len)
{
    /* Every directory is created before the workers start (see cmd_decompile),
     * so the hot path only opens and writes. */
    int fd = writer_open_cached(dir, relpath, O_WRONLY | O_CREAT | O_TRUNC);
    if (fd < 0)
        return -1;

    size_t off = 0;
    while (off < len) {
        ssize_t w = write(fd, data + off, len - off);
        if (w < 0) {
            if (errno == EINTR)
                continue;
            close(fd);
            return -1;
        }
        off += (size_t)w;
    }
    if (close(fd) < 0)
        return -1;
    return 0;
}
