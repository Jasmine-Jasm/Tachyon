#include "common/io.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

int io_map(const char *path, MappedFile *out)
{
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0)
        return -1;

    struct stat st;
    if (fstat(fd, &st) < 0) {
        int e = errno;
        close(fd);
        errno = e;
        return -1;
    }
    if (st.st_size <= 0) {
        close(fd);
        errno = EINVAL;
        return -1;
    }

    void *p = mmap(NULL, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if (p == MAP_FAILED) {
        int e = errno;
        close(fd);
        errno = e;
        return -1;
    }
    close(fd);

    out->data = p;
    out->len = (size_t)st.st_size;
    return 0;
}

void io_unmap(MappedFile *m)
{
    if (m->data && m->len)
        munmap((void *)m->data, m->len);
    m->data = NULL;
    m->len = 0;
}

int io_mkdirs(const char *path)
{
    char tmp[4096];
    size_t n = strlen(path);
    if (n == 0 || n >= sizeof(tmp)) {
        errno = ENAMETOOLONG;
        return -1;
    }
    memcpy(tmp, path, n + 1);

    for (size_t i = 1; i < n; i++) {
        if (tmp[i] != '/')
            continue;
        tmp[i] = '\0';
        if (mkdir(tmp, 0755) < 0 && errno != EEXIST)
            return -1;
        tmp[i] = '/';
    }
    if (mkdir(tmp, 0755) < 0 && errno != EEXIST)
        return -1;
    return 0;
}

int io_rmtree(const char *path)
{
    if (!path || !path[0])
        return -1;
    DIR *d = opendir(path);
    if (!d)
        return unlink(path) == 0 ? 0 : 0; /* not a directory, or already gone */
    struct dirent *e;
    int rc = 0;
    while ((e = readdir(d)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, ".."))
            continue;
        char child[4096];
        if (snprintf(child, sizeof(child), "%s/%s", path, e->d_name) >= (int)sizeof(child))
            continue;
        struct stat st;
        if (lstat(child, &st) == 0 && S_ISDIR(st.st_mode))
            io_rmtree(child);
        else
            unlink(child);
    }
    closedir(d);
    if (rmdir(path) != 0)
        rc = -1;
    return rc;
}
