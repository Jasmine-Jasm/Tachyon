src/common/buf.o: src/common/buf.c src/common/buf.h

src/common/buf.h:
