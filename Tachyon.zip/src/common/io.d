src/common/io.o: src/common/io.c src/common/io.h

src/common/io.h:
