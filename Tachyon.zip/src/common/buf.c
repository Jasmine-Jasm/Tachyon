#include "common/buf.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void buf_init(Buf *b, size_t cap)
{
    if (cap < 64)
        cap = 64;
    b->data = malloc(cap);
    b->cap = b->data ? cap : 0;
    b->len = 0;
    if (b->data)
        b->data[0] = '\0';
}

void buf_free(Buf *b)
{
    free(b->data);
    b->data = NULL;
    b->cap = 0;
    b->len = 0;
}

void buf_reset(Buf *b)
{
    b->len = 0;
    if (b->data)
        b->data[0] = '\0';
}

int buf_reserve(Buf *b, size_t extra)
{
    if (b->cap > b->len && b->len + extra + 1 <= b->cap)
        return 0;

    size_t need = b->len + extra + 1;
    size_t nc = b->cap ? b->cap : 256;
    while (nc < need) {
        if (nc > (size_t)-1 / 2)
            return -1;
        nc *= 2;
    }
    char *p = realloc(b->data, nc);
    if (!p)
        return -1;
    b->data = p;
    b->cap = nc;
    return 0;
}

int buf_putc(Buf *b, char c)
{
    if (buf_reserve(b, 1))
        return -1;
    b->data[b->len++] = c;
    b->data[b->len] = '\0';
    return 0;
}

int buf_write(Buf *b, const void *p, size_t n)
{
    if (buf_reserve(b, n))
        return -1;
    if (n)
        memcpy(b->data + b->len, p, n);
    b->len += n;
    b->data[b->len] = '\0';
    return 0;
}

int buf_puts(Buf *b, const char *s)
{
    return buf_write(b, s, strlen(s));
}

int buf_printf(Buf *b, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    va_list ap2;
    va_copy(ap2, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) {
        va_end(ap2);
        return -1;
    }
    if (buf_reserve(b, (size_t)n)) {
        va_end(ap2);
        return -1;
    }
    vsnprintf(b->data + b->len, (size_t)n + 1, fmt, ap2);
    va_end(ap2);
    b->len += (size_t)n;
    return 0;
}

int buf_indent(Buf *b, int level)
{
    for (int i = 0; i < level; i++)
        if (buf_putc(b, '\t'))
            return -1;
    return 0;
}
