#ifndef TACHYON_ARENA_H
#define TACHYON_ARENA_H

#include <stddef.h>
#include <stdint.h>

#define ARENA_ALIGN 16u

typedef struct ArenaChunk {
    struct ArenaChunk *next;
    size_t cap;
    size_t used;
} ArenaChunk;

typedef struct {
    ArenaChunk *cur;
    size_t chunk_size;
    size_t total;
    /* Workers share the dex arena, so allocation must be serialised. */
    int lock;
} Arena;

void arena_init(Arena *a, size_t chunk_size);
void *arena_alloc(Arena *a, size_t n);
void *arena_zalloc(Arena *a, size_t n);
char *arena_memdup(Arena *a, const void *p, size_t n);
char *arena_strdup(Arena *a, const char *s);
void arena_destroy(Arena *a);

#endif
