#ifndef TACHYON_BUF_H
#define TACHYON_BUF_H

#include <stddef.h>

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} Buf;

void buf_init(Buf *b, size_t cap);
void buf_free(Buf *b);
void buf_reset(Buf *b);
int buf_reserve(Buf *b, size_t extra);
int buf_putc(Buf *b, char c);
int buf_write(Buf *b, const void *p, size_t n);
int buf_puts(Buf *b, const char *s);
int buf_printf(Buf *b, const char *fmt, ...);
int buf_indent(Buf *b, int level);

#endif
