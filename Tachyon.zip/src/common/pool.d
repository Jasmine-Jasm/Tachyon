src/common/pool.o: src/common/pool.c src/common/pool.h

src/common/pool.h:
