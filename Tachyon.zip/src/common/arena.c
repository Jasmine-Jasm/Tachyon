#include "common/arena.h"

#include <sched.h>
#include <stdlib.h>
#include <string.h>

#define CHUNK_HDR ((sizeof(ArenaChunk) + ARENA_ALIGN - 1) & ~(size_t)(ARENA_ALIGN - 1))

static ArenaChunk *chunk_new(size_t cap)
{
    ArenaChunk *c = malloc(CHUNK_HDR + cap);
    if (!c)
        return NULL;
    c->next = NULL;
    c->cap = cap;
    c->used = 0;
    return c;
}

void arena_init(Arena *a, size_t chunk_size)
{
    a->cur = NULL;
    a->total = 0;
    a->chunk_size = chunk_size < 4096 ? 4096 : chunk_size;
    a->lock = 0;
}

/* A thread that never waits does not pay for the atomic, so this is only a
 * relaxed load in the common single-owner case. Multiple workers do share the
 * dex arena (static values, class data), so the lock has to be real. */
static void arena_lock(Arena *a)
{
    for (int spin = 0; __atomic_exchange_n(&a->lock, 1, __ATOMIC_ACQUIRE); spin++) {
        if (spin < 64)
            continue;
        sched_yield();
    }
}

static void arena_unlock(Arena *a)
{
    __atomic_store_n(&a->lock, 0, __ATOMIC_RELEASE);
}

void *arena_alloc(Arena *a, size_t n)
{
    if (n == 0)
        n = 1;
    n = (n + ARENA_ALIGN - 1) & ~(size_t)(ARENA_ALIGN - 1);

    arena_lock(a);
    ArenaChunk *c = a->cur;
    if (!c || c->cap - c->used < n) {
        size_t cap = a->chunk_size;
        if (cap < n)
            cap = n;
        ArenaChunk *nc = chunk_new(cap);
        if (!nc) {
            arena_unlock(a);
            return NULL;
        }
        nc->next = c;
        a->cur = c = nc;
        a->total += cap;
    }
    void *p = (uint8_t *)c + CHUNK_HDR + c->used;
    c->used += n;
    arena_unlock(a);
    return p;
}

void *arena_zalloc(Arena *a, size_t n)
{
    void *p = arena_alloc(a, n);
    if (p)
        memset(p, 0, n);
    return p;
}

char *arena_memdup(Arena *a, const void *p, size_t n)
{
    char *d = arena_alloc(a, n + 1);
    if (!d)
        return NULL;
    if (n)
        memcpy(d, p, n);
    d[n] = '\0';
    return d;
}

char *arena_strdup(Arena *a, const char *s)
{
    return arena_memdup(a, s, strlen(s));
}

void arena_destroy(Arena *a)
{
    ArenaChunk *c = a->cur;
    while (c) {
        ArenaChunk *next = c->next;
        free(c);
        c = next;
    }
    a->cur = NULL;
    a->total = 0;
}
