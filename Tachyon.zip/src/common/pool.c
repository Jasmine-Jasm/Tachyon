#include "common/pool.h"

#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct {
    const PoolConfig *cfg;
    uint32_t count;
    uint32_t chunk;
    pool_task_fn fn;
    void *ctx;
    void *out_arg;
    atomic_uint next;
    atomic_uint failures;
} PoolShared;

/* Claims a run of indices at once. Chunking turns one atomic operation into many
 * items of work, which matters because a single class decompiles in well under a
 * microsecond on average: without it the fetch itself dominates. */
static void *worker_main(void *arg)
{
    PoolShared *s = arg;
    for (;;) {
        uint32_t start = atomic_fetch_add_explicit(&s->next, s->chunk, memory_order_relaxed);
        if (start >= s->count)
            break;
        uint32_t end = start + s->chunk;
        if (end > s->count)
            end = s->count;
        for (uint32_t i = start; i < end; i++) {
            if (s->fn(s->ctx, i, s->out_arg) != 0)
                atomic_fetch_add_explicit(&s->failures, 1, memory_order_relaxed);
        }
    }
    return NULL;
}

int pool_cpu_count(void)
{
    long n = sysconf(_SC_NPROCESSORS_ONLN);
    if (n < 1)
        n = 1;
    if (n > 256)
        n = 256;
    return (int)n;
}

uint32_t pool_run(const PoolConfig *cfg, uint32_t count, pool_task_fn fn, void *ctx,
                  void *out_arg)
{
    PoolShared s;
    s.cfg = cfg;
    s.count = count;
    s.fn = fn;
    s.ctx = ctx;
    s.out_arg = out_arg;
    uint32_t chunk = cfg ? cfg->chunk : 0;
    if (chunk == 0) {
        /* Aim for a few chunks per worker: enough to balance, few enough that the
         * atomic traffic stays negligible. */
        uint32_t want = count / 8;
        chunk = want ? want : 1;
        if (chunk > 256)
            chunk = 256;
    }
    if (chunk < 1)
        chunk = 1;
    s.chunk = chunk;
    atomic_init(&s.next, 0);
    atomic_init(&s.failures, 0);

    int workers = cfg ? cfg->workers : 0;
    if (workers <= 0)
        workers = pool_cpu_count();
    /* More workers than items is pure overhead. */
    if ((uint32_t)workers > count)
        workers = (int)(count ? count : 1);
    if (workers < 1)
        workers = 1;
    /* Beyond a few hundred threads the per-thread bookkeeping (arena chunks,
     * output buffers) dominates and creation starts failing; clamp to a level
     * that still saturates I/O without exhausting the process. */
    if (workers > 512)
        workers = 512;

    if (workers == 1 || count <= 1) {
        worker_main(&s);
        return atomic_load(&s.failures);
    }

    pthread_t *tid = calloc((size_t)workers, sizeof(pthread_t));
    int *started = calloc((size_t)workers, sizeof(int));
    if (!tid || !started) {
        free(tid);
        free(started);
        worker_main(&s);
        return atomic_load(&s.failures);
    }

    /* Decompilation recurses over nested control flow, so give workers a stack
     * large enough for deeply structured methods; the default is often too small
     * once many threads are live. */
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 8u * 1024u * 1024u);

    int launched = 0;
    for (int i = 0; i < workers; i++) {
        if (pthread_create(&tid[i], &attr, worker_main, &s) == 0) {
            started[i] = 1;
            launched++;
        }
    }
    pthread_attr_destroy(&attr);
    if (launched == 0) {
        /* Could not start any thread (resource limit); do the work inline. */
        free(tid);
        free(started);
        worker_main(&s);
        return atomic_load(&s.failures);
    }
    for (int i = 0; i < workers; i++)
        if (started[i])
            pthread_join(tid[i], NULL);

    free(tid);
    free(started);
    return atomic_load(&s.failures);
}
