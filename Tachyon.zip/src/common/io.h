#ifndef TACHYON_IO_H
#define TACHYON_IO_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    const uint8_t *data;
    size_t len;
} MappedFile;

/* Returns 0 on success, -1 on failure with errno set. */
int io_map(const char *path, MappedFile *out);
void io_unmap(MappedFile *m);

int io_mkdirs(const char *path);

/* Removes `path` and everything under it. Missing paths are not an error. */
int io_rmtree(const char *path);

#endif
