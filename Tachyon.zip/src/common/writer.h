#ifndef TACHYON_WRITER_H
#define TACHYON_WRITER_H

#include <stddef.h>

/* Writes `len` bytes to `dir/relpath`, creating intermediate directories.
 * Returns 0 on success. */
int writer_write(const char *dir, const char *relpath, const char *data, size_t len);

/* Appends to the target file instead of replacing it. */
int writer_append(const char *dir, const char *relpath, const char *data, size_t len);

/* Creates all directories leading up to `dir/relpath` (not the file itself). */
int writer_mkdirs_for(const char *dir, const char *relpath);

#endif
