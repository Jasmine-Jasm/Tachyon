src/main.o: src/main.c src/apk/apk.h src/common/arena.h src/dex/dex.h \
 src/common/buf.h src/common/io.h src/apk/axml.h src/common/arena.h \
 src/common/buf.h src/common/io.h src/common/pool.h src/common/writer.h \
 src/dex/dex.h src/emit/java.h src/emit/renamer.h src/emit/heuristic.h \
 src/emit/heuristic.h src/emit/stubs.h src/emit/platform_ctors.h \
 src/emit/renamer.h src/emit/remap.h src/ir/opcode.h src/zip/zip.h \
 src/formats/provider.h

src/apk/apk.h:

src/common/arena.h:

src/dex/dex.h:

src/common/buf.h:

src/common/io.h:

src/apk/axml.h:

src/common/arena.h:

src/common/buf.h:

src/common/io.h:

src/common/pool.h:

src/common/writer.h:

src/dex/dex.h:

src/emit/java.h:

src/emit/renamer.h:

src/emit/heuristic.h:

src/emit/heuristic.h:

src/emit/stubs.h:

src/emit/platform_ctors.h:

src/emit/renamer.h:

src/emit/remap.h:

src/ir/opcode.h:

src/zip/zip.h:

src/formats/provider.h:
