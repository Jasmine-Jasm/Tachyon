#!/usr/bin/env python3
"""Collect javac errors from a decompiled tree and group them by root cause.

Usage: diagnose.py <outdir> [--limit N]

Prints, for each distinct error, the exact message, the affected files, and one
concrete source line. The goal is a checklist to work from instead of guessing.
"""
import collections
import os
import re
import subprocess
import sys

ANDROID_JAR = "/opt/android-sdk/platforms/android-34/android.jar"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    outdir = os.path.abspath(sys.argv[1])
    limit = 0
    if "--limit" in sys.argv:
        limit = int(sys.argv[sys.argv.index("--limit") + 1])

    files = []
    for root, _dirs, names in os.walk(outdir):
        for n in names:
            if n.endswith(".java"):
                files.append(os.path.join(root, n))
    if limit:
        files = files[:limit]
    if not files:
        print("no .java files under", outdir)
        return 1

    listfile = "/tmp/diag_sources.txt"
    with open(listfile, "w") as f:
        f.write("\n".join(files))

    cmd = [
        "javac", "-encoding", "UTF-8", "-proc:none", "-nowarn",
        "-Xmaxerrs", "1000000", "-cp", ANDROID_JAR,
        "-d", "/tmp/diag_classes", "@" + listfile,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)

    # javac prints: ./path/File.java:LINE: error: message
    err_re = re.compile(r"^(?P<file>[^:]+\.java):(?P<line>\d+): error: (?P<msg>.*)$")
    entries = []
    for raw in proc.stderr.splitlines():
        m = err_re.match(raw)
        if m:
            entries.append({
                "file": m.group("file"),
                "line": int(m.group("line")),
                "msg": m.group("msg").strip(),
                "detail": [],
            })
        elif entries and raw.startswith(("\t", " ")) and not raw.strip().startswith("^"):
            if len(entries[-1]["detail"]) < 4:
                entries[-1]["detail"].append(raw.rstrip())

    if not entries:
        print("no errors (%d files compiled)" % len(files))
        return 0

    groups = collections.defaultdict(list)
    for e in entries:
        key = re.sub(r"'[^']*'", "'X'", e["msg"])
        key = re.sub(r"\b[A-Za-z0-9_$.]+\.[A-Za-z0-9_$]+\b", "X.Y", key)
        groups[key].append(e)

    print("=" * 78)
    print("files=%d  errors=%d  affected_files=%d  distinct=%d"
          % (len(files), len(entries), len({e["file"] for e in entries}), len(groups)))
    print("=" * 78)

    for key, items in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        examples = {e["file"] for e in items}
        print("\n[%d errors / %d files] %s" % (len(items), len(examples), key))
        shown = set()
        for e in items:
            if e["file"] in shown:
                continue
            shown.add(e["file"])
            print("  %s:%d" % (e["file"], e["line"]))
            for d in e["detail"][:3]:
                print("    " + d.strip())
            if len(shown) >= 3:
                break
    return 1


if __name__ == "__main__":
    sys.exit(main())
