#!/usr/bin/env python3
"""Benchmark harness for tachyon.

Measures wall-clock time and throughput for a set of input files across a range
of thread counts, taking the median of several runs. When `--against` is given
it also times an external decompiler on the same inputs for comparison.
"""
import argparse
import os
import shutil
import statistics
import subprocess
import sys
import tempfile
import time


def run_once(cmd, timeout):
    start = time.monotonic()
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=timeout)
    except subprocess.TimeoutExpired:
        return None
    return time.monotonic() - start


def bench(cmd_factory, rounds, timeout):
    samples = []
    for _ in range(rounds):
        out = tempfile.mkdtemp(prefix="tachyon-bench-")
        try:
            el = run_once(cmd_factory(out), timeout)
        finally:
            shutil.rmtree(out, ignore_errors=True)
        if el is None:
            return None
        samples.append(el)
    return statistics.median(samples)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", help="dex/apk/jar files to measure")
    ap.add_argument("--bin", default="/tmp/tbuild/tachyon")
    ap.add_argument("--threads", default="1,2,4,8")
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--timeout", type=float, default=300.0)
    ap.add_argument("--bodies", action="store_true", help="also measure --bodies")
    ap.add_argument("--against", metavar="CMD", default=None,
                    help="external decompiler; use {out} and {threads} placeholders")
    args = ap.parse_args()

    threads = [int(t) for t in args.threads.split(",")]

    for path in args.inputs:
        if not os.path.isfile(path):
            print(f"skip (missing): {path}")
            continue
        size_mb = os.path.getsize(path) / (1024 * 1024)
        print(f"\n=== {os.path.basename(path)}  {size_mb:.2f} MB ===")
        print(f"{'tool':<22}{'threads':>8}{'median(s)':>11}{'MB/s':>9}")

        modes = [("tachyon", [])]
        if args.bodies:
            modes.append(("tachyon --bodies", ["--bodies"]))

        for label, extra in modes:
            for t in threads:
                el = bench(lambda o, t=t, extra=extra: [
                    args.bin, "d", path, "-o", o, "-j", str(t)] + extra,
                    args.rounds, args.timeout)
                if el is None:
                    print(f"{label:<22}{t:>8}{'TIMEOUT':>11}")
                else:
                    print(f"{label:<22}{t:>8}{el:>11.3f}{size_mb / el:>9.2f}")

        if args.against:
            for t in threads:
                def cmd(o, t=t):
                    return args.against.format(out=o, threads=t, input=path).split()
                el = bench(cmd, args.rounds, args.timeout)
                if el is None:
                    print(f"{'baseline':<22}{t:>8}{'TIMEOUT':>11}")
                else:
                    print(f"{'baseline':<22}{t:>8}{el:>11.3f}{size_mb / el:>9.2f}")


if __name__ == "__main__":
    sys.exit(main())
