#!/bin/sh
# Fixed working directory so repeated runs never pile up in /tmp.
# Usage: bench/run.sh <input> [threads]
set -e
BIN=/tmp/tbuild/tachyon
OUT=/tmp/tout
INPUT=${1:-$HOME/workspace/tachyon/source.apk}
THREADS=${2:-8}

rm -rf "$OUT"
mkdir -p "$OUT"
"$BIN" d "$INPUT" -o "$OUT" -j "$THREADS"
echo "files: $(find "$OUT" -name '*.java' | wc -l)"
