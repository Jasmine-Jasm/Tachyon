#!/bin/sh
# End-to-end checks for tachyon. Run from the repository root.
set -u

BIN="${TACHYON:-/tmp/tbuild/tachyon}"
TMP="${TMPDIR:-/tmp}/tachyon-test"
FAIL=0

say() { printf '%s\n' "$*"; }
ok()  { say "  ok   $*"; }
bad() { say "  FAIL $*"; FAIL=$((FAIL + 1)); }

if [ ! -x "$BIN" ]; then
    say "error: $BIN not found; run 'make run' first"
    exit 2
fi

rm -rf "$TMP"
mkdir -p "$TMP"

# ---------------------------------------------------------------- fixtures
# A tiny dex is built from Java so the expected shape is known exactly.
if command -v javac >/dev/null 2>&1 && command -v d8 >/dev/null 2>&1; then
    mkdir -p "$TMP/src"
    cat > "$TMP/src/T.java" <<'EOF'
public class T {
    public static int add(int a, int b) { return a + b; }
    public static String greet(String s) { return "hi " + s; }
}
EOF
    if javac --release 8 -d "$TMP/out" "$TMP/src/T.java" 2>/dev/null \
       && (cd "$TMP/out" && jar cf ../t.jar .) 2>/dev/null \
       && d8 --min-api 21 --output "$TMP" "$TMP/t.jar" 2>/dev/null; then
        FIXTURE="$TMP/classes.dex"
    fi
fi

# ---------------------------------------------------------------- commands
say "commands"
"$BIN" --version >/dev/null 2>&1 && ok "--version" || bad "--version"
"$BIN" --help >/dev/null 2>&1 && ok "--help" || bad "--help"

if [ -n "${FIXTURE:-}" ] && [ -f "${FIXTURE:-}" ]; then
    "$BIN" info "$FIXTURE" >/dev/null 2>&1 && ok "info" || bad "info"
    "$BIN" dis "$FIXTURE" -n 5 >/dev/null 2>&1 && ok "dis" || bad "dis"
    "$BIN" json "$FIXTURE" >/dev/null 2>&1 && ok "json" || bad "json"

    rm -rf "$TMP/out1"
    if "$BIN" d "$FIXTURE" -o "$TMP/out1" >/dev/null 2>&1; then
        n=$(find "$TMP/out1" -name '*.java' | wc -l)
        [ "$n" -gt 0 ] && ok "decompile ($n files)" || bad "decompile produced nothing"
        if command -v javac >/dev/null 2>&1; then
            if (cd "$TMP/out1" && javac -nowarn -d "$TMP/cls1" $(find . -name '*.java') 2>/dev/null); then
                ok "javac accepts output"
            else
                bad "javac rejects output"
            fi
        fi
    else
        bad "decompile"
    fi
else
    say "  skip fixture-dependent checks (javac/d8 unavailable)"
fi

# ---------------------------------------------------------------- robustness
say "robustness"
printf 'not a dex' > "$TMP/bad.dex"
if "$BIN" info "$TMP/bad.dex" >/dev/null 2>&1; then
    bad "accepted a non-dex file"
else
    ok "rejects a non-dex file"
fi

head -c 200 /dev/zero > "$TMP/zero.dex" 2>/dev/null
if "$BIN" info "$TMP/zero.dex" >/dev/null 2>&1; then
    bad "accepted all-zero input"
else
    ok "rejects truncated input"
fi

# ---------------------------------------------------------------- concurrency
if [ -n "${FIXTURE:-}" ] && [ -f "${FIXTURE:-}" ]; then
    say "concurrency"
    rm -rf "$TMP/par1" "$TMP/par8"
    "$BIN" d "$FIXTURE" -o "$TMP/par1" -j 1 >/dev/null 2>&1
    "$BIN" d "$FIXTURE" -o "$TMP/par8" -j 8 >/dev/null 2>&1
    if diff -r "$TMP/par1" "$TMP/par8" >/dev/null 2>&1; then
        ok "1 and 8 threads produce identical output"
    else
        bad "threaded output differs"
    fi
fi

say ""
if [ "$FAIL" -eq 0 ]; then
    say "all checks passed"
else
    say "$FAIL check(s) failed"
fi
exit "$FAIL"
