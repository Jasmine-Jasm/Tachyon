#!/usr/bin/env python3
"""Full error report for a decompiled tree.

Usage: report.py [outdir]

Writes /tmp/report/ with:
  summary.txt   counts, pass rate, error classes ranked by frequency
  groups/NN.txt one file per error class, listing every affected file plus the
                exact source line and javac detail
  fixes.md      a checklist to work through

Exit code is 0 only when every file compiles.
"""
import collections
import os
import re
import subprocess
import sys

ANDROID_JAR = "/opt/android-sdk/platforms/android-34/android.jar"
OUT = "/tmp/report"

# Errors caused by libraries that are not part of android.jar. They are real
# dependencies of the app, not emitter bugs, so they are reported separately.
# `cannot find symbol` pointing at a package that is not in android.jar is a
# missing library, not an emitter bug.
EXTERNAL_SYMBOLS = (
    "symbol:   class Fragment",
    "android.support.v4",
    "android.support.v7",
)

EXTERNAL_PREFIXES = (
    "package androidx.window.sidecar",
    "package androidx.window.extensions",
    "package androidx.camera",
    "package com.google.android.material",
    "package com.tencent.liteav",
    "package org.scilab",
    "package io.reactivex",
    "package com.tencent.mm",
)

ERR_RE = re.compile(r"^(?P<file>[^:]+\.java):(?P<line>\d+): error: (?P<msg>.*)$")

# javac stops before the attribution phase when any file fails to parse, so a
# single syntax error hides every semantic error in the tree. The report runs a
# second pass without the unparsable files to surface what is actually behind them.
SYNTAX_RE = re.compile(
    r"expected|not a statement|illegal start of|reached end of file"
    r"|unclosed|invalid method declaration|illegal character")


def collect(outdir):
    files = []
    for root, _d, names in os.walk(outdir):
        for n in names:
            if n.endswith(".java"):
                files.append(os.path.join(root, n))
    files.sort()
    return files


def compile_tree(files):
    os.makedirs("/tmp/report_classes", exist_ok=True)
    listfile = "/tmp/report_sources.txt"
    with open(listfile, "w") as f:
        f.write("\n".join(files))
    proc = subprocess.run(
        ["javac", "-encoding", "UTF-8", "-proc:none", "-nowarn",
         "-Xmaxerrs", "1000000", "-cp", ANDROID_JAR,
         "-d", "/tmp/report_classes", "@" + listfile],
        capture_output=True, text=True)
    return proc.stderr


def parse(stderr):
    entries = []
    for raw in stderr.splitlines():
        m = ERR_RE.match(raw)
        if m:
            entries.append({"file": m.group("file"), "line": int(m.group("line")),
                            "msg": m.group("msg").strip(), "detail": []})
        elif entries and raw[:1] in (" ", "\t") and not raw.strip().startswith("^"):
            if len(entries[-1]["detail"]) < 6:
                entries[-1]["detail"].append(raw.rstrip())
    return entries


def classify(msg):
    m = msg
    if "cannot find symbol" in m:
        return "cannot find symbol"
    if "does not exist" in m:
        pkg = re.search(r"package ([A-Za-z0-9_.]+) does not exist", m)
        return "missing package: " + (pkg.group(1) if pkg else "?")
    if "clashes with class of same name" in m:
        return "package/class name clash"
    if "no suitable constructor found" in m:
        base = re.search(r"for ([A-Za-z0-9_$.]+)\(", m)
        return "no usable constructor: " + (base.group(1) if base else "?")
    if "constructor " in m and "cannot be applied" in m:
        return "constructor argument mismatch"
    if "is not abstract and does not override" in m:
        base = re.search(r"abstract method ([A-Za-z0-9_$]+)", m)
        return "missing implementation: " + (base.group(1) if base else "?")
    if "is not public" in m:
        return "access violation"
    if "incompatible types" in m:
        return "incompatible types"
    if "bad operand types" in m:
        return "bad operand types"
    if "expected" in m:
        return "syntax"
    if "duplicate class" in m:
        return "duplicate class"
    return m[:70]


def main():
    outdir = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "/tmp/tout")
    files = collect(outdir)
    if not files:
        print("no .java under", outdir)
        return 2

    stderr = compile_tree(files)
    entries = parse(stderr)

    # A parse error suppresses attribution for the whole compilation, so recompile
    # without the unparsable files to see the semantic errors they were hiding.
    syntax_files = {e["file"] for e in entries if SYNTAX_RE.search(e["msg"])}
    masked = []
    if syntax_files:
        rest = [f for f in files if f not in syntax_files]
        if rest:
            masked = parse(compile_tree(rest))

    os.makedirs(OUT, exist_ok=True)
    groups_dir = os.path.join(OUT, "groups")
    os.makedirs(groups_dir, exist_ok=True)
    for old in os.listdir(groups_dir):
        os.remove(os.path.join(groups_dir, old))

    internal, external = [], []
    for e in entries:
        blob = e["msg"] + "\n" + "\n".join(e["detail"])
        if any(p in blob for p in EXTERNAL_PREFIXES) or \
           any(p in blob for p in EXTERNAL_SYMBOLS):
            external.append(e)
        else:
            internal.append(e)

    buckets = collections.defaultdict(list)
    for e in internal:
        buckets[classify(e["msg"])].append(e)

    total = len(files)
    failed = {e["file"] for e in entries} | {e["file"] for e in masked}
    pass_rate = 100.0 * (total - len(failed)) / total if total else 100.0

    lines = []
    lines.append(f"files={total}  failed_files={len(failed)}  "
                 f"pass_rate={pass_rate:.2f}%")
    lines.append(f"errors={len(entries)}  internal={len(internal)}  "
                 f"external_dependency={len(external)}")
    if syntax_files:
        lines.append("")
        lines.append(f"NOTE: {len(syntax_files)} file(s) failed to PARSE. javac skips "
                     f"semantic analysis entirely in that case, so the counts above")
        lines.append(f"      cover syntax only. Recompiling without them exposes "
                     f"{len(masked)} further error(s).")
        lines.append("      Fix the syntax errors first: they mask everything else.")
    lines.append("")
    lines.append("=== internal errors by class ===")
    for i, (k, items) in enumerate(sorted(buckets.items(), key=lambda kv: -len(kv[1]))):
        lines.append(f"{len(items):5d}  {len({e['file'] for e in items}):4d} files  {k}")
        with open(os.path.join(groups_dir, f"{i:02d}.txt"), "w") as g:
            g.write(f"# {k}  ({len(items)} errors in "
                    f"{len({e['file'] for e in items})} files)\n\n")
            seen = set()
            for e in items:
                g.write(f"{e['file']}:{e['line']}\n  {e['msg']}\n")
                for d in e["detail"]:
                    g.write(f"  {d.strip()}\n")
                g.write("\n")
                seen.add(e["file"])

    if external:
        lines.append("")
        lines.append("=== external dependency errors (not emitter bugs) ===")
        ext_buckets = collections.Counter(classify(e["msg"]) for e in external)
        for k, v in ext_buckets.most_common():
            lines.append(f"{v:5d}  {k}")

    summary = "\n".join(lines) + "\n"
    with open(os.path.join(OUT, "summary.txt"), "w") as f:
        f.write(summary)

    checklist = ["# Fix checklist", ""]
    for k, items in sorted(buckets.items(), key=lambda kv: -len(kv[1])):
        checklist.append(f"- [ ] {k} ({len(items)} errors)")
    with open(os.path.join(OUT, "fixes.md"), "w") as f:
        f.write("\n".join(checklist) + "\n")

    print(summary)
    print(f"details in {groups_dir}/")
    return 0 if not internal else 1


if __name__ == "__main__":
    sys.exit(main())
