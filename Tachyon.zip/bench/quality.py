#!/usr/bin/env python3
"""Build and measure the fixed Java-to-DEX quality sample.

The sample is intentionally source-controlled so every run exercises the same
bytecode shapes. This is a baseline harness, not a semantic oracle yet: it
records output count, Tachyon status, javac errors, and wall-clock time for the
three supported body modes.
"""
from __future__ import annotations

import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SAMPLE = ROOT / "tests" / "quality" / "QualitySample.java"
ADVANCED_SAMPLE = ROOT / "tests" / "quality" / "AdvancedSample.java"


def find_d8() -> str | None:
    configured = os.environ.get("D8")
    if configured and os.access(configured, os.X_OK):
        return configured
    found = shutil.which("d8")
    if found:
        return found
    candidates = sorted(
        glob.glob("/opt/android-sdk/build-tools/*/d8")
        + glob.glob(str(Path.home() / ".cache/android-sdk/build-tools/*/d8")),
        reverse=True,
    )
    for candidate in candidates:
        if os.access(candidate, os.X_OK):
            return candidate
    return None


def run(cmd: list[str], *, cwd: Path | None = None,
        env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=cwd, text=True, capture_output=True, env=env)


def count_java_errors(stderr: str) -> int:
    return sum(1 for line in stderr.splitlines() if ": error:" in line)


def build_fixture(work: Path, d8: str) -> Path:
    src = work / "src"
    classes = work / "classes"
    dex = work / "dex"
    src.mkdir()
    classes.mkdir()
    dex.mkdir()

    proc = run(["javac", "--release", "8", "-g", "-d", str(classes),
                str(SAMPLE), str(ADVANCED_SAMPLE)])
    if proc.returncode:
        raise RuntimeError("javac sample failed:\n" + proc.stderr)

    jar = work / "quality.jar"
    proc = run(["jar", "cf", str(jar), "-C", str(classes), "."])
    if proc.returncode:
        raise RuntimeError("jar sample failed:\n" + proc.stderr)

    proc = run([d8, "--min-api", "21", "--output", str(dex), str(jar)])
    if proc.returncode:
        raise RuntimeError("d8 sample failed:\n" + proc.stderr)
    result = dex / "classes.dex"
    if not result.is_file():
        raise RuntimeError("d8 did not produce classes.dex")
    return result


def compile_output(out: Path, work: Path) -> tuple[int, int, Path]:
    sources = sorted(str(p) for p in out.rglob("*.java"))
    work.mkdir(parents=True, exist_ok=True)
    if not sources:
        return 0, 0, work / "compiled"
    source_list = work / "sources.txt"
    source_list.write_text("\n".join(sources) + "\n", encoding="utf-8")
    classes = work / "compiled"
    classes.mkdir(exist_ok=True)
    proc = run([
        "javac", "-encoding", "UTF-8", "-proc:none", "-nowarn",
        "-Xmaxerrs", "10000", "-d", str(classes), "@" + str(source_list),
    ])
    return proc.returncode, count_java_errors(proc.stderr), classes


def measure(bin_path: str, dex: Path, out: Path, extra: list[str]) -> dict[str, object]:
    start = time.monotonic()
    env = os.environ.copy()
    if extra == ["--bodies"]:
        env["TACHYON_EXPERIMENTAL_SSA"] = "1"
    proc = run([bin_path, "d", str(dex), "-o", str(out), "-j", "1"] + extra, env=env)
    elapsed = time.monotonic() - start
    files = sorted(out.rglob("*.java")) if out.exists() else []
    compile_rc, errors, classes = compile_output(out, out.parent / (out.name + "-compile"))
    semantic_rc = None
    semantic_match = None
    semantic_diff = ""
    if extra == ["--bodies"] and compile_rc == 0:
        original = run(["java", "-cp", str(out.parent / "classes"), "QualitySample"])
        recovered = run(["java", "-cp", str(classes), "defpkg.QualitySample"])
        semantic_rc = recovered.returncode
        semantic_match = original.returncode == 0 and recovered.returncode == 0 and original.stdout == recovered.stdout
        if not semantic_match:
            semantic_diff = "".join(__import__("difflib").unified_diff(
                original.stdout.splitlines(True), recovered.stdout.splitlines(True),
                fromfile="original", tofile="decompiled"))
    return {
        "tachyon_rc": proc.returncode,
        "files": len(files),
        "javac_rc": compile_rc,
        "javac_errors": errors,
        "semantic_rc": semantic_rc,
        "semantic_match": semantic_match,
        "semantic_diff": semantic_diff,
        "seconds": round(elapsed, 4),
        "stderr_tail": proc.stderr.splitlines()[-3:],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bin", default="/tmp/tbuild/tachyon")
    parser.add_argument("--keep", action="store_true", help="keep the temporary fixture")
    args = parser.parse_args()

    if not os.path.isfile(args.bin) or not os.access(args.bin, os.X_OK):
        print(f"error: executable not found: {args.bin}", file=sys.stderr)
        return 2
    d8 = find_d8()
    if not d8:
        print("error: d8 not found; set D8 or install Android build-tools", file=sys.stderr)
        return 2

    work = Path(tempfile.mkdtemp(prefix="tachyon-quality-"))
    try:
        dex = build_fixture(work, d8)
        print(f"sample={SAMPLE}")
        print(f"advanced_sample={ADVANCED_SAMPLE}")
        print(f"dex={dex} bytes={dex.stat().st_size}")
        modes = {
            "default": [],
            "strict": ["--strict"],
            "bodies": ["--bodies"],
        }
        failed = False
        for name, extra in modes.items():
            result = measure(args.bin, dex, work / name, extra)
            print(
                f"mode={name} files={result['files']} "
                f"tachyon_rc={result['tachyon_rc']} "
                f"javac_rc={result['javac_rc']} "
                f"javac_errors={result['javac_errors']} "
                f"semantic_match={result['semantic_match']} "
                f"seconds={result['seconds']:.4f}"
            )
            if result["tachyon_rc"] != 0 or result["files"] == 0 or result["javac_errors"]:
                failed = True
            if name == "bodies" and result["semantic_match"] is False:
                failed = True
                print("  semantic_diff:")
                print(result["semantic_diff"], end="")
            if result["stderr_tail"]:
                print("  log:", " | ".join(result["stderr_tail"]))
        return 1 if failed else 0
    finally:
        if args.keep:
            print(f"work={work}")
        else:
            shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
