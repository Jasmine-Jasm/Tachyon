#!/bin/sh
# Compile the tree produced by bench/run.sh and report pass rate.
OUT=${1:-/tmp/tout}
JAR=/opt/android-sdk/platforms/android-34/android.jar
find "$OUT" -name '*.java' > /tmp/verify_sources.txt || exit 1
rm -rf /tmp/verify_classes
javac -encoding UTF-8 -proc:none -nowarn -Xmaxerrs 1000000 \
      -cp "$JAR" -d /tmp/verify_classes @/tmp/verify_sources.txt 2>/tmp/verify.log
rc=$?
total=$(wc -l < /tmp/verify_sources.txt)
failed=$(grep -a 'error:' /tmp/verify.log | cut -d: -f1 | sort -u | wc -l)
errors=$(grep -ac 'error:' /tmp/verify.log)
echo "files=$total failed_files=$failed errors=$errors"
python3 -c "print('pass rate: %.2f%%' % (100.0*($total-$failed)/$total))" 2>/dev/null
exit $rc
