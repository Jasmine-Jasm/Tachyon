#include <stdio.h>
#include <string.h>

#include "common/arena.h"
#include "ir/opcode.h"
#include "ir/ssa.h"

static int fail(const char *what)
{
    fprintf(stderr, "ssa-smoke: FAIL: %s\n", what);
    return 1;
}

static int check_decode(void)
{
    Insn in;

    uint16_t const4[] = {(uint16_t)(0x12 | (3u << 8) | (1u << 12))};
    if (insn_decode(const4, 1, 0, &in) != 1 || in.a != 3 || in.aa != 0)
        return fail("const/4 destination");

    uint16_t move32[] = {0x0003, 0x1234, 0x5678};
    if (insn_decode(move32, 3, 0, &in) != 3 || in.aa != 0x1234 || in.first_reg != 0x5678)
        return fail("move/16 32x registers");

    uint16_t lit8[] = {(uint16_t)(0xd8 | (20u << 8)), (uint16_t)(5u | (1u << 8))};
    if (insn_decode(lit8, 2, 0, &in) != 2 || in.aa != 20 || in.b != 5 || in.literal != 1)
        return fail("add-int/lit8 registers");

    uint16_t poly[] = {(uint16_t)(0xfa | (3u << 12) | (4u << 8)), 0x1234, 0x4321, 0x5678};
    if (insn_decode(poly, 4, 0, &in) != 4 || in.reg_count != 3 || in.idx != 0x1234 ||
        in.regs[0] != 1 || in.regs[1] != 2 || in.regs[2] != 3 || in.regs[3] != 4 ||
        in.regs[4] != 4 || in.proto_idx != 0x5678)
        return fail("invoke-polymorphic 45cc");

    uint16_t polyr[] = {(uint16_t)(0xfb | (5u << 8)), 0x1234, 0x5678, 0x9abc};
    if (insn_decode(polyr, 4, 0, &in) != 4 || in.reg_count != 5 || in.idx != 0x1234 ||
        in.first_reg != 0x5678 || in.proto_idx != 0x9abc)
        return fail("invoke-polymorphic/range 4rcc");

    uint16_t long_code[70005];
    memset(long_code, 0, sizeof(long_code));
    long_code[70000] = 0x0000;
    if (insn_decode(long_code, 70005, 70000, &in) != 1 || in.addr != 70000)
        return fail("32-bit instruction address");

    return 0;
}

static int check_ssa(void)
{
    Insn raw[6];
    memset(raw, 0, sizeof(raw));

    raw[0].addr = 0;
    raw[0].len = 1;
    raw[0].opcode = OP_CONST_4;
    raw[0].fmt = FMT_11n;
    raw[0].a = 3;

    raw[1].addr = 1;
    raw[1].len = 2;
    raw[1].opcode = OP_ADD_INT_LIT8;
    raw[1].fmt = FMT_22b;
    raw[1].aa = 20;
    raw[1].b = 5;

    raw[2].addr = 3;
    raw[2].len = 1;
    raw[2].opcode = OP_CMPL_FLOAT;
    raw[2].fmt = FMT_23x;
    raw[2].aa = 7;
    raw[2].regs[0] = 1;
    raw[2].regs[1] = 2;

    raw[3].addr = 4;
    raw[3].len = 1;
    raw[3].opcode = OP_PACKED_SWITCH;
    raw[3].fmt = FMT_31t;
    raw[3].aa = 8;

    raw[4].addr = 5;
    raw[4].len = 3;
    raw[4].opcode = OP_INVOKE_STATIC;
    raw[4].fmt = FMT_35c;
    raw[4].reg_count = 1;
    raw[4].regs[0] = 3;

    raw[5].addr = 8;
    raw[5].len = 1;
    raw[5].opcode = OP_MOVE_RESULT;
    raw[5].fmt = FMT_11x;
    raw[5].aa = 9;

    CfgBlock block;
    memset(&block, 0, sizeof(block));
    block.id = 0;
    block.insn_start = 0;
    block.insn_count = 6;

    DexCode code;
    memset(&code, 0, sizeof(code));
    code.insns_size = 16;
    code.registers_size = 32;

    CfgMethod cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.code = &code;
    cfg.insns = raw;
    cfg.blocks = &block;
    cfg.block_count = 1;

    Arena arena;
    arena_init(&arena, 4096);
    SsaMethod *method = ssa_build(&cfg, &arena);
    if (!method || ssa_validate(method) != 0)
        return fail("ssa build/validate");
    if (method->count != 5 || method->raw_count != 6)
        return fail("invoke-result normalization count");
    if (method->insns[0].def_count != 1 || method->insns[0].def[0].reg != 3)
        return fail("const/4 SSA def");
    if (method->insns[1].def[0].reg != 20)
        return fail("lit8 SSA def");
    if (method->insns[2].def[0].reg != 7 || method->insns[2].use_count != 2)
        return fail("compare SSA def/use");
    if (method->insns[3].use_count != 1 || method->insns[3].use[0].reg != 8)
        return fail("switch SSA use");
    if (!method->insns[4].has_result || method->insns[4].def_count != 1 ||
        method->insns[4].def[0].reg != 9 || method->raw_to_norm[5] != 4)
        return fail("invoke-result SSA merge");

    arena_destroy(&arena);
    return 0;
}

int main(void)
{
    if (check_decode() || check_ssa())
        return 1;
    puts("ssa-smoke: ok");
    return 0;
}
