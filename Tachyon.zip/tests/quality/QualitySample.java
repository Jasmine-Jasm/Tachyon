public final class QualitySample {
    private int value;

    public QualitySample() {
        value = 1;
    }

    public int receiverAndParameter(int delta) {
        return value + delta;
    }

    public int invokeResult(String text) {
        return text.length();
    }

    public int sameRegisterReadWrite(int input) {
        int result = input;
        result += value;
        return result;
    }

    public int branch(int input) {
        if (input >= 0) {
            return input;
        }
        return -input;
    }

    public int loop(int limit) {
        int total = 0;
        for (int i = 0; i < limit; i++) {
            total += i;
        }
        return total;
    }

    public int switchValue(int input) {
        switch (input) {
            case 0:
                return 10;
            case 1:
                return 20;
            default:
                return -1;
        }
    }

    public int tryCatch(String text) {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public int throwCatch(boolean fail) {
        try {
            if (fail) {
                throw new IllegalStateException("boom");
            }
            return 7;
        } catch (IllegalStateException e) {
            return e.getMessage().length();
        }
    }

    public int arrayOps(int base) {
        int[] values = new int[3];
        values[0] = base;
        values[1] = base + 1;
        return values.length + values[0] + values[1];
    }

    public long numericConversion(int value) {
        return (long) value;
    }

    public int instanceCheck(Object value) {
        return value instanceof String ? 1 : 0;
    }

    public static String invokeChain(String text) {
        return new StringBuilder().append("x").append(text).toString();
    }

    public static void main(String[] args) {
        QualitySample sample = new QualitySample();
        System.out.println(sample.receiverAndParameter(2));
        System.out.println(sample.invokeResult("abc"));
        System.out.println(sample.sameRegisterReadWrite(3));
        System.out.println(sample.branch(-2));
        System.out.println(sample.loop(4));
        System.out.println(sample.switchValue(1));
        System.out.println(sample.tryCatch("bad"));
        System.out.println(sample.throwCatch(true));
        System.out.println(sample.arrayOps(4));
        System.out.println(sample.numericConversion(5));
        System.out.println(sample.instanceCheck("ok"));
        System.out.println(invokeChain("ok"));
    }
}
