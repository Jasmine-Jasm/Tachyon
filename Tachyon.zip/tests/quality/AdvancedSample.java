import java.util.List;

public class AdvancedSample<T extends Number> {
    public enum Mode {
        ZERO,
        ONE;

        public int code() {
            return ordinal();
        }
    }

    public interface Greeter {
        default String greet(String value) {
            return "hello " + value;
        }
    }

    public static class Nested {
        public int value = 7;
    }

    public int varargsSum(int... values) {
        int total = 0;
        for (int value : values) {
            total += value;
        }
        return total;
    }

    public String genericName(List<String> values) {
        return values.get(0);
    }

    public Runnable anonymous(String value) {
        return new Runnable() {
            @Override
            public void run() {
                System.out.println(value);
            }
        };
    }

    public static int enumCode() {
        return Mode.ONE.code();
    }

    public static void main(String[] args) {
        AdvancedSample<Integer> sample = new AdvancedSample<>();
        System.out.println(sample.varargsSum(1, 2, 3));
        System.out.println(sample.enumCode());
        System.out.println(new Nested().value);
    }
}
