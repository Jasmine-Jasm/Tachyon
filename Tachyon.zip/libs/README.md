# tachyon Engine (Embeddable)

> **Disclaimer**
>
> This tool is intended solely for security research, reverse engineering study,
> and lawful analysis. Do not use it to crack commercial software, infringe
> copyright, or for any other illegal purpose. Users bear full legal
> responsibility for their use.

This is an in-process decompilation engine. The directory contains a prebuilt
binary that can be placed into an application without Gradle dependencies, the
Android NDK, or third-party libraries.

```text
libs/
└── arm64-v8a/
    └── libtachyon.so      AArch64 static executable (1.4 MB, zero dynamic dependencies, directly executable)
```

The `.so` extension lets Android package the file as a native library. `jniLibs`
extracts it into `nativeLibraryDir`, one of the few locations where execution may
be allowed. It is still a normal executable and can also run directly on a PC,
Termux, or inside a container.

## Adding it to a project

**Android native project:** copy `libs/arm64-v8a` into
`app/src/main/jniLibs/arm64-v8a/` and add
`android:extractNativeLibs="true"` to the manifest. After installation it appears
at:

```text
/data/app/<pkg>/lib/arm64/libtachyon.so
```

The path can be obtained with:

```java
getApplicationInfo().nativeLibraryDir + "/libtachyon.so"
```

**Linux / Termux:** run it directly:

```sh
./libtachyon.so --version
```

## Calling interface

### Commands

```text
libtachyon.so d <apk|dex> [-o <dir>] [-j N] [--progress]
                          [--mode fast|balanced|accurate|max]
                          [--merge] [--keep] [--emit-only]
                          [--bodies] [--rename mapping.txt]

libtachyon.so info  <apk|dex>     DEX count and per-DEX string/type/method/class counts
libtachyon.so dis   <apk|dex>     disassemble; use -n N to limit methods
libtachyon.so list  <apk>         list archive entries
libtachyon.so json  <apk|dex>     export structure as JSON
libtachyon.so formats             list supported formats
```

| Option | Description |
|---|---|
| `-o DIR` | Output directory, default `./out`; cleared before each run |
| `-j N` | Worker count, default CPU count |
| `--progress` | Print machine-readable progress to stdout |
| `--keep` | Preserve the output directory |
| `--emit-only` | Decompile without writing; useful for timing |
| `--merge` | Merge each package into one `.java` file; the result remains compilable |
| `--mode max` | Experimental CPU count ×4 mode; desktop only, do not use on a phone |

### Progress protocol

With `--progress`, stdout receives one line per step:

```text
#PROGRESS <0-100> <message>
```

Typical sequence for a three-DEX APK:

```text
#PROGRESS 10 APK opened, dex parsed
#PROGRESS 15 global index built
#PROGRESS 20 dependency analysis done
#PROGRESS 25 decompiling dex 1/3
#PROGRESS 45 decompiling dex 2/3
#PROGRESS 65 decompiling dex 3/3
#PROGRESS 90 decompilation finished
#PROGRESS 95 project files written
#PROGRESS 100 done
```

Progress goes to stdout and logs go to stderr. Consumers can merge stderr into
stdout and process lines by the `#PROGRESS ` prefix.

### Exit codes

| Code | Meaning |
|---:|---|
| 0 | Success; all classes were written |
| 1 | At least one class failed; details are on stderr |
| 2 | Invalid arguments |

### Output layout

```text
out/
├── AndroidManifest.xml     binary AXML decoded to readable text
├── build.gradle            namespace / compileSdk / minSdk / targetSdk / versionCode / versionName
├── settings.gradle         rootProject.name + include ':app'
├── local.properties        placeholder sdk.dir
├── <package>/<Class>.java  decompiled source with a watermark header
└── <missing dependency>/... stub declarations for referenced but unpackaged libraries
```

## Calling examples

### Shell

```sh
./libtachyon.so d app.apk -o out --progress -j 4
```

### Java / Android

```java
File bin = new File(getApplicationInfo().nativeLibraryDir, "libtachyon.so");
File out = new File(getExternalFilesDir(null), "out");

ProcessBuilder pb = new ProcessBuilder(
        bin.getAbsolutePath(), "d", apk.getAbsolutePath(),
        "-o", out.getAbsolutePath(), "--progress", "-j", "4");
pb.redirectErrorStream(true);
Process p = pb.start();

try (BufferedReader r = new BufferedReader(
        new InputStreamReader(p.getInputStream()))) {
    String line;
    while ((line = r.readLine()) != null) {
        if (line.startsWith("#PROGRESS ")) {
            String rest = line.substring(10).trim();      // "<pct> <text>"
            int sp = rest.indexOf(' ');
            int pct = Integer.parseInt(sp < 0 ? rest : rest.substring(0, sp));
            String msg = sp < 0 ? "" : rest.substring(sp + 1);
            bar.setProgress(pct);                          // update progress bar
            status.setText(pct + "% " + msg);
        } else {
            log.append(line).append('\n');                 // log output
        }
    }
}
int rc = p.waitFor();
```

### Python

```python
import subprocess

p = subprocess.Popen(["./libtachyon.so", "d", "app.apk", "-o", "out", "--progress"],
                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
for line in p.stdout:
    if line.startswith("#PROGRESS "):
        pct, _, msg = line[10:].strip().partition(" ")
        print(f"{pct:>3}% {msg}")
    else:
        print(line, end="")
print("exit", p.wait())
```

### C

```c
#include <stdio.h>
int main(void) {
    return system("./libtachyon.so d app.apk -o out --progress");
}
```

## Two Android considerations

1. **`extractNativeLibs="true"` is required.** With `false`, the file remains inside
the APK and there is no executable on disk.
2. **SELinux may deny `execve`.** From Android 10, the `untrusted_app` domain restricts
execution from app-private directories. `nativeLibraryDir` is one of the few
exceptions. If `ProcessBuilder` throws
`IOException: error=13, Permission denied`, the system is blocking execution and
the engine must be built as a JNI library targeting bionic with the Android NDK.

Verification command:

```sh
adb shell /data/app/<pkg>-xxxx/lib/arm64/libtachyon.so --version
# tachyon 0.3.0
```

## Building from source

```sh
# Static AArch64 binary with no dynamic dependencies
aarch64-linux-gnu-gcc -O2 -std=c11 -D_GNU_SOURCE -Isrc \
    -DTACHYON_VERSION='"0.3.0"' -static \
    -o libs/arm64-v8a/libtachyon.so \
    src/*.c src/*/*.c src/*/*/*.c -lpthread -lm
```

Desktop x86_64 build:

```sh
cc -O2 -std=c11 -D_GNU_SOURCE -Isrc -DTACHYON_VERSION='"0.3.0"' \
   -o tachyon src/*.c src/*/*.c src/*/*/*.c -lpthread -lm
```

## Internal engines

| Module | Purpose |
|---|---|
| `src/dex/dex.c` | DEX parsing: string pool, types, prototypes, class data, bytecode |
| `src/ir/emulate.c` | Dalvik interpreter for evaluating string-decryption helpers |
| `src/emit/heuristic.c` | Obfuscated-name recovery from class contents |
| `src/emit/platform_builtin.c` | Built-in platform constructor, abstract-method, and method-signature tables |
| `src/emit/stubs.c` | Placeholder declarations for missing dependencies |
| `src/apk/axml.c` | Binary XML decoder for `AndroidManifest.xml` |
| `src/formats/` | Pluggable DEX, JVM, pyc, and Lua providers |

The modules are independent. Their headers form the interfaces and can be compiled
into other programs.
