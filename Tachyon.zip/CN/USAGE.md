# 使用说明

> **免责声明**
>
> 本工具仅供安全研究、逆向工程学习和合法分析使用。请勿用于破解商业软件、侵犯版权或任何其他非法用途。使用者需自行承担使用本工具产生的一切法律责任。

## 构建

```sh
make run                     # -> /tmp/tbuild/tachyon
make run OUT=/tmp/mytachyon  # 指定其他输出位置
```

工作区挂载为 `noexec`，因此二进制必须输出到可执行位置。`make run` 默认将产物放入 `/tmp`。

交叉编译为 Android 可直接执行的静态 AArch64 二进制：

```sh
aarch64-linux-gnu-gcc -O2 -std=c11 -D_GNU_SOURCE -Isrc \
    -DTACHYON_VERSION='"0.3.0"' -static \
    -o libs/arm64-v8a/libtachyon.so \
    src/*.c src/*/*.c src/*/*/*.c -lpthread -lm
```

## GUI

项目现在包含一个零第三方依赖的本地浏览器 GUI。它启动本地 HTTP 服务并调用现有 CLI 二进制，不会改变反编译引擎。

```sh
make gui
# 或
python3 gui/tachyon_gui.py --bin /tmp/tbuild/tachyon
```

GUI 支持选择 APK/DEX 输入、输出目录、线程数、模式、`--bodies`、`--strict`、`--merge`，并显示实时进度、日志和停止任务按钮。默认绑定 `127.0.0.1:8765`。无图形环境启动时可使用 `--no-browser`。

## 命令

### `d` —— 反编译

```sh
tachyon d app.apk                     # 输出到 ./out，运行前清空
tachyon d app.apk -o /tmp/out         # 指定输出目录，同样会先清空
tachyon d app.apk -o /tmp/out --keep  # 不清空
tachyon d app.apk -j 8                # 8 个 worker
tachyon d app.apk --bodies            # 输出真实方法体，而不是桩
tachyon d app.apk --merge             # 每个包合并为一个文件
tachyon d app.apk --emit-only         # 反编译但不写盘（测速）
tachyon d app.apk --progress          # stdout 输出机器可读进度
tachyon d app.apk --rename mapping.txt # 应用 ProGuard/R8 mapping
```

也可以直接处理 `.dex`，只是不会生成 manifest 或 Gradle 工程文件。

### `info` / `dis` / `list` / `json` / `formats`

```sh
tachyon info app.apk                  # DEX 数量和每个 DEX 的表大小
tachyon dis  app.apk                  # 反汇编
tachyon dis  app.apk -n 200           # 只显示前 200 个方法
tachyon list app.apk                  # 列出压缩包条目
tachyon json app.apk                  # 将结构导出为 JSON
tachyon formats                       # 查看内置格式
```

## 阅读输出

```
out/
├── AndroidManifest.xml
├── build.gradle
├── settings.gradle
├── local.properties
├── AndroidManifest.xml
├── com/example/...  .java
└── androidx/window/...  .java      <- APK 未打包的库对应的桩
```

- **`AndroidManifest.xml`** 从平台二进制 XML 解码而来。属性会以文本形式输出；
  资源引用由于未解析资源表，会显示为 `@ref/0x7f0e0001`。
- **`build.gradle`** 反映 APK 的构建信息（`compileSdk` 来自
  `android:compileSdkVersion`，不是 `targetSdk`）。它描述的是 APK，而不是原始源码布局。
- **`local.properties`** 只包含 `sdk.dir` 占位符，需要改成你的 SDK 路径。
- **`/* STUB: not the real value */`** 标记方法体无法恢复的方法。没有该标记的方法才是实际恢复的代码；
  带标记时，`return 0` / `return null` 只是占位值。使用 `--strict` 时这些方法会抛出异常。
  默认 `--bodies` 只有在 SSA 管线证明方法形状受支持时才输出真实方法体，否则输出该标记，避免发布猜测性 Java。
- `TACHYON_EXPERIMENTAL_SSA=1` 为受控开发和质量样本启用 SSA 方法体管线。
  `TACHYON_LEGACY_BODIES=1` 仅用于诊断旧的 best-effort renderer，不属于安全发布路径。
- **桩文件**是 APK 引用但未携带的类型的空声明。如果代码调用桩上的方法，该调用可能无法编译；
  桩只保证类型本身存在。
- 每个输出文件都以三行固定水印注释开头。

## 模式

| 模式 | 变化 |
|---|---|
| `fast` | 跳过全图分析，最快，但可能留下少量形状问题 |
| `balanced` | 默认模式 |
| `accurate` | 增加跨 DEX 父类型遍历，可发现少见的 override 形状 |
| `max` | **实验功能**：worker 数量为 CPU 数 ×4，只建议桌面使用，不要在手机上运行 |
| `--strict` | 未解码的方法体不再返回 `0`/`null`，而是抛出 `UnsupportedOperationException`。当输出可能被执行时建议使用，避免桩返回值被误认为真实结果 |

## 进度协议

`--progress` 会将每个步骤写入 **stdout**，日志仍写入 **stderr**：

```
#PROGRESS 10 APK opened, dex parsed
#PROGRESS 15 global index built
#PROGRESS 20 dependency analysis done
#PROGRESS 25 decompiling dex 1/3
#PROGRESS 45 decompiling dex 2/3
#PROGRESS 65 decompiling dex 3/3
#PROGRESS 90 decompilation finished
#PROGRESS 95 project files written
#PROGRESS 100 done
```

退出码：`0` 表示所有类写出；`1` 表示部分类失败，详情在 stderr；`2` 表示参数错误。

## 验证结果

```sh
tachyon d app.apk -o /tmp/out
python3 bench/report.py /tmp/out
make quality                  # 受控 Java -> DEX -> 编译/语义检查
```

`report.py` 使用 `javac` 和 `android-34` 编译整个输出树，并将错误分类写入 `/tmp/report/`。
它会有意编译两遍：单个语法错误会让 `javac` 跳过全部语义分析，一遍编译会造成虚高的通过率。
第一遍找出无法解析的文件，第二遍排除这些文件重新编译，暴露被掩盖的问题。

如果平台 jar 位于其他位置，请修改脚本顶部的 `ANDROID_JAR`。

## 大型应用的策略选择

在一个包含 253,230 个类、大小 285 MB 的应用上测得：

| 方案 | 文件数 | 墙钟时间 |
|---|---:|---:|
| 默认 | 253,376 | 47.8 秒 |
| `--merge` | 8,608 | 约 14 秒 |
| `--emit-only`（不写盘） | 0 | 10.8 秒 |

写盘是主要瓶颈。在当前硬件上，朴素的 `open/write/close` 循环创建 253,230 个文件需要 121 秒；
Tachyon 按包顺序写入，只需要 37 秒。如果只是想快速阅读，使用 `--merge` 最有效；如果必须一类一文件，
写盘成本基本无法避免。

## 嵌入

`libs/arm64-v8a/libtachyon.so` 是静态 AArch64 可执行文件。将它放入
`jniLibs/arm64-v8a/`，设置 `extractNativeLibs="true"`，再使用 `ProcessBuilder` 运行。
完整接口、Java / Python / C 示例以及 SELinux 注意事项请见 [libs/README.md](libs/README.md)。

## 排错

**运行二进制时出现 `Permission denied`**

它所在目录挂载为 `noexec`。请复制到 `/tmp` 或其他可执行位置。在 Android 上也只有部分目录允许执行。

**没有输出文件，退出码为 1**

读取 stderr，其中会报告逐类失败信息。`bench/report.py` 可以将失败整理为分类列表。

**重新运行后输出看起来为空**

这是设计行为：每次运行前会清空输出目录。需要追加到已有目录时传入 `--keep`。

**一个类消失，另一个类出现了意外名称**

不同包中的两个类可能共享简单名称，也可能是混淆类被重命名。重命名会追加原始短名，
例如 `Impl_Serializable_cn`，因此冲突会显示为不同文件，而不是覆盖。

**`javac` 报告某个类型不存在**

APK 引用了未打包的库，同时该包在允许列表中，因此没有生成桩。可以手动添加桩，或者从
`src/emit/stubs.c` 的 `kPlatformPkgs` 中移除该包。
