# 架构

> **免责声明**
>
> 本工具仅供安全研究、逆向工程学习和合法分析使用。请勿用于破解商业软件、侵犯版权或任何其他非法用途。使用者需自行承担使用本工具产生的一切法律责任。

## 分层

```
             main.c                  CLI、调度、进度协议
                |
   +------------+-------------+
   |                          |
 apk/                   formats/          容器与可插拔格式 provider
   |                          |
 zip/  +  apk/axml.c    dex/ jvm/ lua/ pyc/
   |
 dex/dex.c                             DEX 读取器（不了解输出逻辑）
   |
 ir/                                   CFG、指令解码、方法体
   |
 emit/                                 Java 文本、名称、桩、平台表
   |
 common/                               arena、buf、io、writer、线程池
```

每一层只调用下层。`dex/` 不知道 Java；`ir/` 不知道文件路径；`emit/` 不解析
DEX 原始字节。这种拆分让引擎模块可以独立使用，详见 `libs/README.md`。

## `tachyon d app.apk` 的数据流

```
1. apk_open
     mmap 文件，识别 "dex\n" 或 ZIP，解压所有 classes*.dex，
     对每个文件执行 dex_setup（校验头部并建立索引缓存）

2. java_build_global_defs
     使用开放寻址表将 class descriptor 映射到（所属 dex、class_def 索引）。
     类型索引是每个 dex 私有的，因此跨 dex 查找必须按字符串匹配，不能按索引匹配。

3. stub_collect
     遍历所有被引用的类型（父类、接口、字段、原型），保留 APK 未定义且平台包未提供的类型。
     该步骤在生成前完成，因为引用必须使用与桩文件名一致的名称。

4. 每个 dex：
     remap_init        当前 dex 的包名/类名冲突规则
     shadow table      与包目录冲突的简单名称
     warm_caches       预先解析 string/type/proto/class_data/code，避免线程池懒分配
     path precompute   预计算每个类的 java_class_path 并创建目录
     pool_run          N 个 worker，每个 worker 生成完整类

5. emit_project_files
     解码 AndroidManifest.xml（二进制 XML），写出 build.gradle、settings.gradle、local.properties

6. stub_write
     为每个无法解析的类型写入一个占位声明
```

## 模块

| 路径 | 行数 | 责任 |
|---|---:|---|
| `src/main.c` | 1082 | CLI、逐 dex 循环、线程池配置、进度、工程文件 |
| `src/dex/dex.c` | 1146 | 头部校验、字符串/类型/原型/字段/方法表、类数据、代码、MUTF-8 |
| `src/emit/java.c` | 2594 | 类/方法/字段生成、协变 winner 选择、名称解析 |
| `src/ir/body.c` | 1443 | 方法体渲染：寄存器、调用、分支 |
| `src/ir/body_emit.c` | — | 受安全门控的 SSA 方法体生成 |
| `src/ir/type_infer.c` | — | SSA 值的工作队列类型推导 |
| `src/ir/ssa.c` | — | SSA 构建、phi、def/use 和校验 |
| `src/ir/emulate.c` | 782 | 用于执行解密辅助函数的 Dalvik 解释器 |
| `src/ir/cfg.c` | 515 | 基本块和控制流图 |
| `src/ir/opcode.c` | 651 | 指令解码与格式化 |
| `src/emit/platform_ctors.c` | 475 | 可选的 android.jar 构造器读取器（class 文件解析器） |
| `src/apk/axml.c` | 402 | 二进制 XML 解码器 |
| `src/emit/remap.c` | 385 | 声明、路径和引用共享的名称重映射 |
| `src/emit/platform_builtin.c` | 327 | 框架构造器/抽象方法/签名表 |
| `src/emit/stubs.c` | 279 | 缺失依赖的占位类型 |
| `src/emit/heuristic.c` | 249 | 混淆名称恢复 |
| `src/common/arena.c` | 106 | 带自旋锁的 bump allocator |

## 关键结构

**`Arena`**（`common/arena.h`）：所有长期存活的分配都来自这里。它以 1 MB
为单位进行 bump allocation，直到 `arena_destroy` 才释放。线程共享一个 arena，
因此分配需要自旋锁。热路径上没有 `free`，但单次超大分配会很危险：早期实现为
每个字符串申请 `file_remaining_size`，在 253,000 类输入上会膨胀到数百 GB 虚拟内存。

**`Dex`**（`dex/dex.h`）：映射文件和懒填充缓存，包括 `string_cache`、
`type_name_cache`、`class_data_cache`、`code_cache`、`proto_params_cache`。所有缓存
都按 dex 分开，因为格式中的索引都是文件内索引。

**`Insn`**（`ir/opcode.h`）：一条解码后的指令，包括 `opcode`、`fmt`、`a` / `b` / `aa` /
`regs[]` 中的寄存器操作数、`literal`、`idx` 和 `target`。寄存器存放在哪个字段由
`fmt` 决定；混用这些字段是反复出现的 bug，详见 `DELIVERY.md`。

**`ClassFacts`**（`emit/java.c`）：一个类生成所需的全部事实，包括 interface/enum
标志、构造器存在性与签名、父类解析结果（`parent_known`、`parent_dex`、
`parent_has_noarg_ctor`、`parent_ctor_proto`）以及平台构造器参数。

## 线程模型

`pool_run` 将完整类交给 worker。线程池依赖以下不变量：

1. **生成期间不能发生懒分配。** 主线程必须先执行 `warm_caches`、
   `java_prepare_missing_bitmap` 和 `java_build_package_dirs`，否则 worker 会竞争同一缓存槽。
2. **线程池启动前创建目录。** `io_mkdirs` 会遍历路径组件；每个类都调用会造成大量重复系统调用。
3. **每个任务的临时空间是线程局部的**，包括 body arena、writer 的目录缓存以及父类解析时使用的“上一个所属 dex”指针。
4. **缓冲区按任务隔离。** 每个 worker 构建一个 `Buf` 并交给 writer，因此不要求输出顺序。

## 名称解析

一个类名会出现在三个独立位置，三者必须一致，否则输出无法编译：

| 位置 | 函数 |
|---|---|
| 文件路径 | `java_class_path` → `java_class_fqname` |
| 声明 | `java_emit_class` 中的 `facts.name` |
| 每个引用 | `remap_java_type` |

应用规则包括：将默认包类移动到 `defpkg`；为遮蔽包名的类追加后缀（`cn` → `cn_`）；
只对 APK 定义的类型将 `$` 折叠为 `_`；为 Java 关键字追加 `_`；为混淆类替换推断名称。
任何新增规则都必须同步到以上三个位置。

## 扩展点

**格式 provider**（`src/formats/provider.h`）：实现 `probe`，以及可选的
`describe` / `disassemble` / `decompile` / `extract`。`dispatch.c` 选择得分最高的 provider。
新增格式不需要修改其他模块：

```c
static int my_probe(const uint8_t *d, size_t n) { return magic_ok ? 80 : 0; }
static int my_disassemble(FormatCtx *c) { /* write to c->out */ }

const Formatter g_my_formatter = {
    "myfmt", "My format", my_probe, NULL, my_disassemble, NULL, NULL
};
```

**平台知识**（`emit/platform_builtin.c`）：包含构造器、抽象方法以及与应用 override 冲突的方法三张表。
新增条目即可让新的框架类在没有 android.jar 时生成正确的 `super(...)` 调用。

**依赖桩**（`emit/stubs.c`）：包白名单决定哪些包被视为已存在。APK 引用但未携带的其他类型会得到占位声明。

## 有意保留的限制

- **方法体默认是可选的**（`--bodies`）。异常边和 `finally` 结构无法精确恢复，因此默认生成桩；
  该参数用于阅读和受控恢复，不承诺生成原始工程的可构建副本。
- **`--merge` 会改变输出形状。** 每个包一个文件意味着只有一个 public 类型，其余类型会降级。
  输出仍可编译，但不再是一类一文件。
- **名称是推断出来的，不是恢复出来的。** `heuristic.c` 只能根据类行为生成描述性名称；
  原始标识符已经丢失。没有足够证据的类会保留混淆名称。
