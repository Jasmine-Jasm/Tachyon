# tachyon 引擎（可直接嵌入）

> **免责声明**
>
> 本工具仅供安全研究、逆向工程学习和合法分析使用，请勿用于破解商业软件、
> 侵犯版权等非法用途，使用者需自行承担一切法律责任。

一个进程内的反编译引擎。这里是预编译好的二进制，放进项目就能用，不需要
Gradle 依赖、不需要 NDK、没有任何第三方库。

```
libs/
└── arm64-v8a/
    └── libtachyon.so      AArch64 静态可执行（1.4 MB，零动态依赖，可直接 exec）
```

`libtachyon.so` 扩展名是为了让 Android 把它当原生库打包（`jniLibs` 会被解压到
`nativeLibraryDir`，那是少数允许执行的目录之一）。它本身是普通可执行文件，
在 PC / Termux / 容器里直接跑也可以。

## 放进项目

**Android 原生工程**：把 `libs/arm64-v8a` 整个复制到 `app/src/main/jniLibs/arm64-v8a/`，
Manifest 里加 `android:extractNativeLibs="true"`。安装后它会出现在：

```
/data/app/<pkg>/lib/arm64/libtachyon.so
```

`getApplicationInfo().nativeLibraryDir + "/libtachyon.so"` 就是这个路径。

**普通 Linux / Termux**：直接 `./libtachyon.so --version`。

## 调用接口

### 命令

```
libtachyon.so d <apk|dex> [-o <dir>] [-j N] [--progress]
                          [--mode fast|balanced|accurate|max]
                          [--merge] [--keep] [--emit-only]
                          [--bodies] [--rename mapping.txt]

libtachyon.so info  <apk|dex>     dex 数量、每 dex 的字符串/类型/方法/类计数
libtachyon.so dis   <apk|dex>    反汇编（-n N 限制方法数）
libtachyon.so list  <apk>        列出压缩包条目
libtachyon.so json  <apk|dex>    结构导出为 JSON
libtachyon.so formats            列出支持的格式
```

| 参数 | 说明 |
|---|---|
| `-o DIR` | 输出目录，默认 `./out`，**每次运行前自动清空** |
| `-j N` | 线程数，默认 CPU 数 |
| `--progress` | 在 stdout 打印机器可读进度（见下） |
| `--keep` | 不清空输出目录 |
| `--emit-only` | 只反编译不落盘（测速用） |
| `--merge` | 按包合并为每目录一个 `.java`，文件数大幅下降且实测可编译 |
| `--mode max` | 测试功能：CPU 数 ×4 开线程，桌面用，手机上不要开 |

### 进度协议

加 `--progress` 后，**stdout** 每步输出一行：

```
#PROGRESS <0-100> <说明>
```

实测序列（3 dex 的 APK）：

```
#PROGRESS 10 APK opened, dex parsed
#PROGRESS 15 global index built
#PROGRESS 20 dependency analysis done
#PROGRESS 25 decompiling dex 1/3
#PROGRESS 45 decompiling dex 2/3
#PROGRESS 65 decompiling dex 3/3
#PROGRESS 90 decompilation finished
#PROGRESS 95 project files written
#PROGRESS 100 done
```

进度写 stdout，日志写 stderr，互不干扰。建议 `redirectErrorStream(true)` 后按行判断前缀。

### 退出码

| 码 | 含义 |
|---|---|
| 0 | 成功，所有类都写出 |
| 1 | 有类失败（详情见 stderr） |
| 2 | 参数错误 |

### 输出目录

```
out/
├── AndroidManifest.xml     二进制 AXML 解码成文本
├── build.gradle            namespace / compileSdk / minSdk / targetSdk / versionCode / versionName
├── settings.gradle         rootProject.name + include ':app'
├── local.properties        sdk.dir 占位
├── <包路径>/<类名>.java     反编译出的源码（首行是水印注释）
└── <缺失依赖包>/...          桩声明（APK 引用但没打包的库）
```

## 调用示例

### shell

```sh
./libtachyon.so d app.apk -o out --progress -j 4
```

### Java / Android

```java
File bin = new File(getApplicationInfo().nativeLibraryDir, "libtachyon.so");
File out = new File(getExternalFilesDir(null), "out");

ProcessBuilder pb = new ProcessBuilder(
        bin.getAbsolutePath(), "d", apk.getAbsolutePath(),
        "-o", out.getAbsolutePath(), "--progress", "-j", "4");
pb.redirectErrorStream(true);
Process p = pb.start();

try (BufferedReader r = new BufferedReader(
        new InputStreamReader(p.getInputStream()))) {
    String line;
    while ((line = r.readLine()) != null) {
        if (line.startsWith("#PROGRESS ")) {
            String rest = line.substring(10).trim();      // "<pct> <text>"
            int sp = rest.indexOf(' ');
            int pct = Integer.parseInt(sp < 0 ? rest : rest.substring(0, sp));
            String msg = sp < 0 ? "" : rest.substring(sp + 1);
            bar.setProgress(pct);                          // 更新进度条
            status.setText(pct + "% " + msg);
        } else {
            log.append(line).append('\n');                 // 日志
        }
    }
}
int rc = p.waitFor();
```

### Python

```python
import subprocess

p = subprocess.Popen(["./libtachyon.so", "d", "app.apk", "-o", "out", "--progress"],
                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
for line in p.stdout:
    if line.startswith("#PROGRESS "):
        pct, _, msg = line[10:].strip().partition(" ")
        print(f"{pct:>3}% {msg}")
    else:
        print(line, end="")
print("exit", p.wait())
```

### C

```c
#include <stdio.h>
int main(void) {
    return system("./libtachyon.so d app.apk -o out --progress");
}
```

## Android 上的两点注意

1. **必须 `extractNativeLibs="true"`。** 设为 `false` 时库留在 APK 里，没有可执行文件。
2. **SELinux 可能拒绝 `execve`。** Android 10 起，`untrusted_app` 域对应用私有目录的
   `execve` 是受限的；`nativeLibraryDir` 属于少数例外。如果 `ProcessBuilder` 抛
   `IOException: error=13, Permission denied`，说明当前系统仍然拦截了执行，
   这时需要把引擎编成 JNI 库（需要 Android NDK 与 bionic 目标）。

跑起来的验证方式：

```sh
adb shell /data/app/<pkg>-xxxx/lib/arm64/libtachyon.so --version
# tachyon 0.3.0
```

## 从源码构建

```sh
# 静态 aarch64（无动态依赖，可直接在 Android 上 exec）
aarch64-linux-gnu-gcc -O2 -std=c11 -D_GNU_SOURCE -Isrc \
    -DTACHYON_VERSION='"0.3.0"' -static \
    -o libs/arm64-v8a/libtachyon.so \
    src/*.c src/*/*.c src/*/*/*.c -lpthread -lm
```

x86_64 桌面版：

```sh
cc -O2 -std=c11 -D_GNU_SOURCE -Isrc -DTACHYON_VERSION='"0.3.0"' \
   -o tachyon src/*.c src/*/*.c src/*/*/*.c -lpthread -lm
```

## 引擎内部能力（可单独取用）

| 模块 | 作用 |
|---|---|
| `src/dex/dex.c` | DEX 解析（字符串池、类型、原型、类数据、字节码） |
| `src/ir/emulate.c` | Dalvik 解释器，用于求值字符串解密函数 |
| `src/emit/heuristic.c` | 混淆名重建（单字母类名按内容推断） |
| `src/emit/platform_builtin.c` | 内置平台构造器 / 抽象方法 / 方法签名表 |
| `src/emit/stubs.c` | 为缺失依赖生成占位声明 |
| `src/apk/axml.c` | 二进制 XML 解码（AndroidManifest） |
| `src/formats/` | 可插拔格式 provider（dex / jvm / pyc / lua） |

各模块互不依赖，头文件即接口，可以直接编进别的程序。
