# tachyon 交付说明

> **免责声明**
>
> 本工具仅供安全研究、逆向工程学习和合法分析使用，请勿用于破解商业软件、
> 侵犯版权等非法用途，使用者需自行承担一切法律责任。

纯 C11 多格式反编译器。零第三方依赖（libc + pthread + libm），单二进制。

## 当前实测

### source.apk（22MB / 3 dex / 15216 类）

| 指标 | 数值 |
|---|---|
| 反编译 | **约 4～6 秒**（8 线程，取决于文件系统负载） |
| javac 通过率 | **100.00%**（15235 / 15235） |
| 失败文件 | **0** |
| 输出 | 15216 个类 + 19 个桩 + 4 个工程文件 |
| 混淆类重命名 | 1327 个 |

### 微信 8.0.79（285MB / 18 dex / 253230 类）

| 指标 | 数值 |
|---|---|
| 反编译 + 落盘 | **47.8 秒**，0 失败 |
| `--emit-only`（不写盘） | 10.8 秒 |
| `--merge`（按包合并） | 文件数 253230 → 8608 |
| 输出体积 | 1.1 GB |

写盘的物理下限已实测：这台机器裸写 253230 个文件需 **121 秒**（2090 文件/秒）。
tachyon 用 37 秒完成同样数量（6800 文件/秒），已比裸写快 3.4 倍，**继续压缩到 20 秒内
不可能**——剩余开销是 f2fs 的 per-file 元数据。要更快只能减少文件数（`--merge`）。

## CLI

```
tachyon d <file> [-o <dir>] [-j N] [--mode fast|balanced|accurate|max]
                 [--bodies] [--rename map.txt] [--emit-only] [--merge] [--keep]
tachyon info  <file>
tachyon dis   <file> [-n N]
tachyon list  <file>
tachyon json  <file>
tachyon formats
```

- `-o`：**默认 `./out`，每次运行前自动清空**（避免多次运行堆满磁盘）。`--keep` 保留。
- `--mode fast`：跳过整图分析，最快
- `--mode balanced`：默认
- `--mode accurate`：额外开启跨 dex 超类型遍历
- `--mode max`：**测试功能**，按 CPU 数 ×4 开线程，把机器压满。只在桌面验证过，
  **不要在手机上运行**
- `--emit-only`：只反编译不写盘
- `--merge`：每个包合并为一个 `_merged.java`（只有 public 类会被降级），实测可编译
- `--rename`：应用 ProGuard/R8 mapping.txt

## 工程结构还原

一次运行产出可直接用 Gradle 打开的结构：

```
out/
├── AndroidManifest.xml     二进制 AXML 解码成可读文本
├── build.gradle            namespace / compileSdk / minSdk / targetSdk / versionCode / versionName
├── settings.gradle         rootProject.name + include ':app'
├── local.properties        sdk.dir 占位（提示用户改成本机路径）
└── com/...                 Java 源码树
```

`AndroidManifest.xml` 是 APK 里的二进制 XML（字符串池 + 元素块），由自研解码器
`src/apk/axml.c` 还原，属性值按类型格式化（字符串 / 引用 / 整数 / 布尔 / 尺寸）。

## 水印

每个输出文件首行固定为：

```
//TachYon An incredibly fast decompilation tool
//No dependencies
//TachYon CN AI Agent DeepSeekv4.1flash
```

## 引擎与扩展

各能力都写成了独立模块，互不依赖，可单独调用。

### 1. 字符串解密引擎（`src/ir/emulate.c`）

一个轻量 Dalvik 解释器，在反编译期实际执行解密函数，把密文还原成明文。

- 覆盖指令：move / move-result / const-* / aget|aput / array-length / new-instance /
  new-array / goto / if-*（22t、if-*z）/ int-to-char|short|byte / 0xd8..0xe2 的 lit8 算术 /
  invoke-static|virtual|direct
- 模拟的 JDK 方法：`String.length|charAt|toString`、`StringBuilder.append|toString`、
  `Integer.parseInt|valueOf`、`Character.toString`
- 递归深度上限 12，步数上限 20000，超出即放弃求值并保留原始调用
- 求值结果与手算一致（XOR 样本 `8888898` → `bbbbbcb`）

**关键约定**：`append(char)` 与 `append(int)` 靠 proto 参数描述符区分；`charAt` 返回
`EMU_CHAR` 而不是 `EMU_INT`，否则会输出数字而不是字符。

### 2. 混淆名重建引擎（`src/emit/heuristic.c`）

单字母类名（`a` / `b2` / `a0`）按类自身内容推断名字，**有证据才改名**：

| 证据来源 | 生成的名字 |
|---|---|
| 静态字符串常量（4–20 字符） | `Impl_<常量>` / `Abstract_<常量>` |
| 非 Object 父类 | `Sub_<父类>` / `Abstract_<父类>` |
| 唯一实现接口 | `Impl_<接口>` |
| 都没有 | **保留原名**（`a`、`a0`…） |

新名一定追加原短名（如 `Impl_Serializable_cn`），保证同包内不重名。
名字查找是哈希表 O(1)，25 万类规模可用。

**必须同时改三处，否则声明、路径、引用会分叉**：
`java_class_fqname`（路径）、`facts.name`（声明）、`remap_java_type`（所有引用）。
数组类型 `[La;` 也要剥离 `[` 后查表。

### 3. 自写依赖层（`src/emit/platform_builtin.c`、`src/emit/stubs.c`）

不依赖 android.jar，内置三张表 + 桩生成：

- **平台构造器表**：`View(Context)`、`GZIPOutputStream(OutputStream)`、`ThreadPoolExecutor(...)` 等
  80 余个框架类的构造器签名。父类只有带参构造器时，合成构造器会传类型化默认值。
- **平台抽象方法表**：`Service.onBind`、`ContentProvider.query`、`BaseAdapter.getView` 等，
  子类没实现时自动合成桩方法，避免把 Android 组件标成 abstract。
- **平台方法签名表 + 父类链**：识别 `ViewParent.getLayoutDirection():int`、
  `AdapterView.setAdapter` 这类冲突，冲突成员或接口会被丢弃而不是留下编译错误。
- **桩生成**：APK 引用但没打包的类型（`androidx.window.*`、`android.view.RenderNode`、
  `org.conscrypt.*`）生成占位声明，interface / class 按 `implements` 出现情况判定。

### 4. 反混淆资源解码（`src/apk/axml.c`）

二进制 XML 解码器：字符串池（UTF-8 / UTF-16）、命名空间、元素、属性、CDATA。
同时提供按名字取属性（`package`、`android:versionCode`…），工程文件由它驱动。

### 5. 多格式 provider（`src/formats/`）

| 格式 | 能力 | 真值验证 |
|---|---|---|
| DEX / APK | 完整反编译为 Java | `dexdump -d` 逐条一致（65695 条） |
| JVM class | 反汇编 + 结构 | `javap -c -p` 逐条一致 |
| CPython pyc | 反汇编 + 结构 | Python `dis` 逐条一致 |
| Lua 5.1–5.4 | 反汇编 | `luac -l` 逐条一致 |

### 6. 方法体反编译（`--bodies`）

当前版本包含三轮恢复工作：受安全门控的 SSA 生成、类型边界与性能优化，以及受支持的显式 throw/catch 恢复。GUI 说明见 `USAGE.md`，启动命令为 `make gui`。

14195 类实测只剩 2 个错误。默认关闭，因为方法体还原会改变输出语义
（异常处理边界、`finally` 结构等无法完全复原）。

本轮新增了方法体重构的第一阶段基础：

- `src/ir/ssa.c` / `src/ir/ssa.h`：在现有 CFG 上建立规范化指令流；
- 将地址连续的 `invoke-*` + `move-result*` 绑定为一个逻辑指令，并显式记录 def/use；
- 支持普通 move、wide 值、字段/数组访问、range invoke 和 filled-new-array 的寄存器建模；
- `body_decompile()` 在旧 renderer 前执行 SSA 不变量校验，失败时安全回退到 stub，尚未替换输出管线；
- `tests/quality/QualitySample.java` 与 `bench/quality.py` 固化 Java→DEX 质量样本，覆盖 receiver/参数、invoke-result、同寄存器读写、分支、循环、switch、try/catch 和调用链。

当前质量基线：默认、`--strict`、`--bodies` 对受控基础+高级样本均为 `javac_errors=0`，实验 SSA 管线的语义对拍为 `semantic_match=True`；
完整 `source.apk` 默认模式和发布版 `--bodies` 都为 15235/15235 文件通过编译。`make smoke` 还会直接校验
const/4、move/16、lit8、45cc/4rcc、长地址、比较/switch def-use 和 invoke-result 合并。
实验管线已经实现 SSA value/phi、类型传播和 dispatch body emitter，覆盖线性方法、invoke-result、if、循环、switch、普通调用、单 catch、枚举、内部类、匿名类、varargs 与泛型 cast。
默认发布路径只在实验 emitter 证明安全时采用真实 body，否则输出带 `STUB` 标记的安全后备；旧 best-effort renderer 仅在显式 `TACHYON_LEGACY_BODIES=1` 下启用，避免输出语义错误 Java。
下一阶段仍需扩展区域结构化、复杂异常、平台方法和大型混淆方法支持，当前不能宣称已经全面超过 JADX。

## 方法体质量修复（对标 JADX，2026-11-01）

受控样本（源码已知 → ecj 编译 → d8 转 DEX）暴露的问题与修复：

| 问题 | 根因 | 修复 |
|---|---|---|
| `int cannot be dereferenced`（参数被声明成 int） | 参数槽从未进入版本表，声明缺失 | `seed_param_types`：用 receiver + 参数声明的类型填充版本 0 |
| `this = 0`（给 receiver 赋值） | 常量/移动写入 this 槽 | `reg_is_receiver`：写入 this 槽的语句直接丢弃 |
| `v0_1 = v0_1.max`（同寄存器读写用同一个名字） | iget 被当作纯写，提前 bump 版本，receiver 渲染成了结果类型 | iget 显式处理：先渲染 receiver（旧版本），再 bump，再渲染目标 |
| `p0 == 0`（对象与整数比较） | if-eqz 不知道寄存器是引用 | 按当前版本的类型判定，引用寄存器渲染 `== null` |
| final 字段在构造器赋值被拒 | dex 保留 ACC_FINAL 但合成构造器用普通赋值 | 非 static 的 final 字段去掉 final |
| move-result 后类型不更新 | 寄存器保持 invoke 前的类型 | move-result 用 invoke 返回类型 `reg_begin_write` |
| 版本号与执行序脱节（dispatch 模式） | 按 block id 渲染，后面的块先 bump 版本 | 按执行序（entry 的可达序）安排 case |
| 静默错误（返回 0/null 却像真值） | 桩无标记 | 每个 stub 加 `/* STUB: not the real value */`；`--strict` 改为抛异常 |

成果：24 → 2 个编译错误。**剩余 2 个**：dispatch 模式下 CFG 分块把 invoke 与
move-result 分开、invoke 语句丢失（`v1_1 = v1_1.length()`），需要 SSA 才能根治。

关键教训：**版本号必须与执行顺序一致**。`emit_locals` 的预扫描按地址序记录版本，
`reg_name` 按运行时 `reg_version` 取名，两者必须用同一套编号；参数槽 version 0
是参数本身（渲染为 pN，不声明局部变量）。

## SSA/区域管线阶段成果（2026-11-02）

- 新增 `src/ir/type_infer.h/.c`：基于参数/receiver、字段、invoke 返回、数组、cast、return、phi 的工作队列类型传播。
- 新增 `src/ir/body_emit.h/.c`：安全 SSA dispatch emitter；无法证明的方法回退安全 stub。
- `bench/quality.py` 现在同时运行原始 Java 与实验 SSA bodies，并比较 stdout；基础+高级 7 类样本语义对拍通过。
- 高级样本覆盖泛型、枚举、内部类、匿名类、default 方法、varargs。
- `source.apk` 默认/发布 `--bodies`：15235 文件、0 失败、javac 100%。
- 默认单次墙钟约 4～6 秒；实验 bodies 全量约 5～6 秒，具体取决于文件系统负载。

## SSA/DEX 审计修复（2026-11-02）

针对 SSA 前置层的只读审计发现，本轮补齐了以下潜伏错误：

- `const/4` 使用 `in->a` 作为目标寄存器；lit8 算术使用 `in->aa`；
- 比较指令、packed/sparse switch、fill-array-data、const-method 指令补齐 def/use；
- wide unary/binary 和 compare 的输入输出宽度按真实 opcode 区间计算；
- 修正 DEX 32x、45cc、4rcc 解码，45cc/4rcc 长度为 4 code units；
- `Insn.addr` 扩展为 32 位，避免大方法地址回绕；
- 分配失败、非法寄存器、重复 def 和裸 `move-result` 都会使 SSA 校验失败并回退，不再静默丢失。

新增 `tests/ssa_smoke.c`，并将其接入 `make test`。

## 关键 bug 与根因（本轮）

1. **`dex_string` 内存炸弹**：每解析一个字符串就申请「文件剩余大小」（微信 8.6MB dex →
   每串 8MB），25 万类场景直接把虚拟内存吃穿并拖垮手机。改成按 uleb128 字符数 ×3 分配。
2. **隐式函数声明截断指针**：`body.c` 缺 `emit/java.h`，`java_body_arena()` 被当返回 `int`，
   64 位指针高 32 位被丢弃 → 段错误。构建时加 `-Werror=implicit-function-declaration`。
3. **winner 检查在去重之后**：协变方法先被 `sigset_add` 标记，真实方法再被当作重复丢弃。
   顺序必须反过来。
4. **跨 dex 索引混用**：`class_def_of_type` 返回的是**所属 dex** 的索引，却用当前 dex 读
   flags 和数据，把接口误判成有 final 方法的类。
5. **合成构造器条件漏洞**：父类构造器全是带参时两个条件都不成立，干脆不生成构造器，
   Java 隐式构造器又去调不存在的 `super()`。
6. **桩分类丢失**：同一类型先作为参数出现（记为 class）、后出现在 `implements`（应为
   interface），哈希去重没有回写条目，导致 `interface expected`。
7. **javac 语法错误掩盖语义错误**：任何 parse error 都会让 javac 跳过整个语义分析阶段，
   测出的通过率会虚高。`bench/report.py` 已改成两遍编译并显式警告。

## 构建

```sh
cd ~/workspace/tachyon && make run   # 产物 /tmp/tbuild/tachyon
```

`sdcard` 挂载为 `noexec`，二进制必须放 `/tmp`。

## 验证

```sh
python3 bench/report.py ./out     # 完整错误报告，写 /tmp/report/
sh bench/run_tests.sh             # 功能回归
```

## 未做

- CIL (.NET)、EVM、Go 二进制、x86-64 / ARM64 反汇编器
- 控制流平坦化还原、反调试检测
- C / Go / Kotlin 语言输出（用户已明确延期）
