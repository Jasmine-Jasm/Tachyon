# tachyon

一个使用纯 C11 编写的多格式反编译器。零第三方依赖、单二进制，可直接嵌入。

```
source.apk      15216 个类      约 4～6 秒    javac 通过率 100.00%
微信 8.0.79     253230 个类    47.8 秒      0 失败
```

> **免责声明**
>
> 本工具仅供安全研究、逆向工程学习和合法分析使用。请勿用于破解商业软件、侵犯版权或任何其他非法用途。使用者需自行承担使用本工具产生的一切法律责任。

## 快速开始

```sh
# 构建。工作区挂载为 noexec，因此二进制会输出到 /tmp。
make run

# 反编译到 ./out（每次运行前会清空目录）
/tmp/tbuild/tachyon d app.apk

# 输出机器可读的进度信息（见「接口」）
/tmp/tbuild/tachyon d app.apk --progress

# 类很多时按包合并，每个包一个文件，仍然可以编译
/tmp/tbuild/tachyon d app.apk --merge
```

输出是一套可以直接用 Gradle 打开的工程：

```
out/
├── AndroidManifest.xml     二进制 AXML 解码成文本
├── build.gradle            namespace / compileSdk / minSdk / targetSdk / version
├── settings.gradle
├── local.properties
├── <包路径>/<Class>.java
└── <缺失依赖>/...           APK 引用但未打包的库对应的桩声明
```

## 嵌入其他项目

`libs/arm64-v8a/libtachyon.so` 是预编译的 AArch64 **静态**可执行文件
（1.4 MB，零动态依赖）。将它放入 `jniLibs/` 后即可使用。完整接口——命令行、
`#PROGRESS` 协议、退出码、Java / Python / C 示例以及 Android SELinux 注意事项——
请参阅 [libs/README.md](libs/README.md)。

各个引擎模块也可以单独编译到其他程序中。头文件就是接口，模块之间没有相互依赖。

## GUI

项目包含一个零第三方依赖的本地浏览器 GUI：

```sh
make gui
# 或
python3 gui/tachyon_gui.py --bin /tmp/tbuild/tachyon
```

GUI 支持 APK/DEX 输入、输出目录、线程数、模式、方法体恢复、strict、merge、实时进度、日志和停止任务，并复用现有 CLI 引擎。

## CLI

```
tachyon d <file> [-o <dir>] [-j N] [--progress]
                 [--mode fast|balanced|accurate|max]
                 [--bodies] [--merge] [--keep] [--emit-only] [--rename map.txt]
tachyon info  <file>     DEX 数量和各表大小
tachyon dis   <file>     反汇编
tachyon list  <file>     列出压缩包条目
tachyon json  <file>     将结构导出为 JSON
tachyon formats          支持的格式
```

`--mode max` 是**实验功能**：线程数为 CPU 数量 ×4，只在桌面环境验证过，不要在手机上运行。

## 支持的格式

| 格式 | 能力 | 真值验证 |
|---|---|---|
| DEX / APK | 完整反编译为 Java | 与 `dexdump -d` 逐条匹配（65695 条指令） |
| JVM class | 反汇编和结构分析 | 与 `javap -c -p` 匹配 |
| CPython pyc | 反汇编和结构分析 | 与 Python `dis` 匹配 |
| Lua 5.1–5.4 | 反汇编 | 与 `luac -l` 匹配 |

## 引擎

每个模块都是独立的，可以单独使用。

| 模块 | 作用 |
|---|---|
| `src/dex/dex.c` | DEX 解析：字符串池（MUTF-8）、类型、原型、类数据和字节码 |
| `src/ir/emulate.c` | Dalvik 解释器；在反编译期求值字符串解密辅助函数，并将密文替换为明文 |
| `src/emit/heuristic.c` | 混淆名称恢复：根据类内容为 `a` / `b2` 推断名称，没有证据时保留原名 |
| `src/emit/platform_builtin.c` | 内置框架构造器、抽象方法和方法签名表；不需要 `android.jar` |
| `src/emit/stubs.c` | 为 APK 引用但未携带的类型生成桩声明 |
| `src/apk/axml.c` | 二进制 XML 解码器（AndroidManifest） |
| `src/formats/` | 可插拔格式 provider（dex / jvm / pyc / lua） |
| `bench/report.py` | 全量编译验证和错误分类；编译两遍，避免语法错误掩盖语义错误 |

设计取舍和问题根因记录在 [DELIVERY.md](DELIVERY.md) 与
[PERFORMANCE.md](PERFORMANCE.md) 中。

## 目录结构

```
src/apk/        APK 容器和二进制 XML
src/common/     arena / buf / io / 线程池 / writer
src/dex/        DEX 解析
src/emit/       Java 生成、重映射、混淆名称、平台表和桩
src/formats/    多格式 provider
src/ir/         CFG、指令解码、方法体生成和解释器
bench/          基准测试与验证脚本
libs/           预编译引擎和调用接口
tests/          回归用例
```

## 构建

```sh
make run                        # 本机编译，输出 /tmp/tbuild/tachyon
make run OUT=/your/path         # 指定其他输出位置

# 交叉编译为 Android 可直接执行的静态二进制
aarch64-linux-gnu-gcc -O2 -std=c11 -D_GNU_SOURCE -Isrc \
    -DTACHYON_VERSION='"0.3.0"' -static \
    -o libs/arm64-v8a/libtachyon.so \
    src/*.c src/*/*.c src/*/*/*.c -lpthread -lm
```

工作区挂载为 `noexec`，因此二进制必须放在可执行位置（例如 `/tmp`，或将 `libs/` 复制到其他位置）。

## 验证

```sh
/tmp/tbuild/tachyon d app.apk -o /tmp/out
python3 bench/report.py /tmp/out      # 编译全部输出并将报告写入 /tmp/report/
```

## 文档

| 文件 | 内容 |
|---|---|
| [README.md](README.md) | 中文项目说明 |
| [USAGE.md](USAGE.md) | 所有命令与示例、输出结构、模式、进度协议和排错 |
| [ARCHITECTURE.md](ARCHITECTURE.md) | 分层、数据流、关键结构、线程模型和扩展点 |
| [SECURITY.md](SECURITY.md) | 威胁模型、防御措施、资源限制、Android 执行限制和供应链 |
| [DELIVERY.md](DELIVERY.md) | 能力清单以及每个重要 bug 的根因 |
| [PERFORMANCE.md](PERFORMANCE.md) | 实测时间、写盘下限和性能陷阱 |
| [libs/README.md](libs/README.md) | 嵌入式引擎调用接口 |
| [gui/index.html](../gui/index.html) | 本地浏览器 GUI |
| [gui/tachyon_gui.py](../gui/tachyon_gui.py) | GUI 启动器和本地 API |

## 许可证

MIT License © 2024。完整许可证文本请见 [LICENSE](../LICENSE)。
