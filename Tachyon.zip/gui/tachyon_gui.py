#!/usr/bin/env python3
"""Local browser GUI for the Tachyon command-line decompiler."""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import threading
import time
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
PAGE = Path(__file__).resolve().with_name("index.html")


class JobState:
    def __init__(self, binary: str) -> None:
        self.binary = binary
        self.lock = threading.Lock()
        self.process: subprocess.Popen[str] | None = None
        self.thread: threading.Thread | None = None
        self.running = False
        self.returncode: int | None = None
        self.started_at: float | None = None
        self.finished_at: float | None = None
        self.progress = 0
        self.step = "Idle"
        self.lines: list[dict[str, Any]] = []
        self.next_id = 1

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "running": self.running,
                "returncode": self.returncode,
                "started_at": self.started_at,
                "finished_at": self.finished_at,
                "progress": self.progress,
                "step": self.step,
                "lines": list(self.lines[-500:]),
            }

    def add_line(self, stream: str, text: str) -> None:
        text = text.rstrip("\r\n")
        if not text:
            return
        with self.lock:
            if text.startswith("#PROGRESS "):
                parts = text.split(" ", 2)
                if len(parts) >= 3:
                    try:
                        self.progress = max(0, min(100, int(parts[1])))
                    except ValueError:
                        pass
                    self.step = parts[2]
            elif stream == "stderr":
                self.step = text
            item = {"id": self.next_id, "stream": stream, "text": text}
            self.next_id += 1
            self.lines.append(item)
            if len(self.lines) > 1000:
                del self.lines[:-500]

    def start(self, args: list[str]) -> None:
        with self.lock:
            if self.running:
                raise RuntimeError("A decompilation job is already running")
            self.returncode = None
            self.started_at = time.time()
            self.finished_at = None
            self.progress = 0
            self.step = "Starting Tachyon"
            self.lines.clear()
            self.next_id = 1
            self.process = subprocess.Popen(
                args,
                cwd=str(ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
            self.running = True
            self.thread = threading.Thread(target=self._watch, daemon=True)
            self.thread.start()

    def _watch(self) -> None:
        process = self.process
        if process is None:
            return

        def read_stream(stream: Any, name: str) -> None:
            for line in iter(stream.readline, ""):
                self.add_line(name, line)
            stream.close()

        stdout_thread = threading.Thread(
            target=read_stream, args=(process.stdout, "stdout"), daemon=True
        )
        stderr_thread = threading.Thread(
            target=read_stream, args=(process.stderr, "stderr"), daemon=True
        )
        stdout_thread.start()
        stderr_thread.start()
        code = process.wait()
        stdout_thread.join()
        stderr_thread.join()
        with self.lock:
            self.returncode = code
            self.running = False
            self.finished_at = time.time()
            self.progress = 100 if code == 0 else self.progress
            self.step = "Finished successfully" if code == 0 else f"Exited with code {code}"
            self.process = None

    def stop(self) -> bool:
        with self.lock:
            process = self.process
            if not self.running or process is None:
                return False
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                return False
            return True


def validate_start(payload: dict[str, Any], binary: str) -> list[str]:
    input_path = os.path.abspath(str(payload.get("input", "")).strip())
    output_path = os.path.abspath(str(payload.get("output", "")).strip())
    if not input_path or not os.path.isfile(input_path):
        raise ValueError("Input APK/DEX file does not exist")
    if not output_path:
        raise ValueError("Output directory is required")

    try:
        threads = int(payload.get("threads", 8))
    except (TypeError, ValueError):
        raise ValueError("Threads must be an integer")
    if threads < 1 or threads > 512:
        raise ValueError("Threads must be between 1 and 512")

    mode = str(payload.get("mode", "balanced"))
    if mode not in {"fast", "balanced", "accurate", "max"}:
        raise ValueError("Invalid mode")
    if not os.path.isfile(binary) or not os.access(binary, os.X_OK):
        raise ValueError(f"Tachyon binary is not executable: {binary}")

    args = [binary, "d", input_path, "-o", output_path, "-j", str(threads),
            "--mode", mode, "--progress"]
    if payload.get("bodies"):
        args.append("--bodies")
    if payload.get("strict"):
        args.append("--strict")
    if payload.get("merge"):
        args.append("--merge")
    return args


class Handler(BaseHTTPRequestHandler):
    server_version = "TachyonGUI/0.1"

    @property
    def state(self) -> JobState:
        return self.server.state  # type: ignore[attr-defined]

    def _json(self, status: int, value: dict[str, Any]) -> None:
        body = json.dumps(value).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/":
            try:
                body = PAGE.read_bytes()
            except OSError as exc:
                self._json(500, {"error": str(exc)})
                return
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path == "/api/status":
            self._json(HTTPStatus.OK, self.state.snapshot())
            return
        self._json(HTTPStatus.NOT_FOUND, {"error": "Not found"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length", "0"))
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
        except (json.JSONDecodeError, ValueError):
            self._json(400, {"error": "Invalid JSON"})
            return

        if path == "/api/start":
            try:
                args = validate_start(payload, self.server.binary)  # type: ignore[attr-defined]
                self.state.start(args)
            except (ValueError, RuntimeError, OSError) as exc:
                self._json(400, {"error": str(exc)})
                return
            self._json(HTTPStatus.OK, {"ok": True})
            return
        if path == "/api/stop":
            self._json(HTTPStatus.OK, {"stopped": self.state.stop()})
            return
        self._json(HTTPStatus.NOT_FOUND, {"error": "Not found"})

    def log_message(self, fmt: str, *args: Any) -> None:
        return


def main() -> int:
    parser = argparse.ArgumentParser(description="Local Tachyon browser GUI")
    parser.add_argument("--bin", default="/tmp/tbuild/tachyon", help="Tachyon executable")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    binary = os.path.abspath(args.bin)
    if not os.path.isfile(binary) or not os.access(binary, os.X_OK):
        parser.error(f"executable not found or not executable: {binary}")

    state = JobState(binary)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.state = state  # type: ignore[attr-defined]
    server.binary = binary  # type: ignore[attr-defined]
    url = f"http://{args.host}:{args.port}/"
    print(f"Tachyon GUI: {url}", flush=True)
    if not args.no_browser:
        threading.Timer(0.25, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        state.stop()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
